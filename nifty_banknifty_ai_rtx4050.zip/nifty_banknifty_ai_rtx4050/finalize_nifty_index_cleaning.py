#!/usr/bin/env python3
"""
Finalize the NIFTY index cleaning output.

Reads the already-created cleaned Parquet, removes the erroneous full-session
synthetic holiday (2024-11-20), adds explicit training eligibility metadata,
and writes a final dataset plus closure audits.

Run from the project root:
    python finalize_nifty_index_cleaning.py

Requires DuckDB (already used by the project).
The original source database and input Parquet are never modified.
"""
from pathlib import Path
import json
import time
import duckdb

STARTED = time.time()
PROJECT_ROOT = Path(__file__).resolve().parent
OUTPUT_DIR = PROJECT_ROOT / "data" / "processed" / "nifty_index_cleaned"
INPUT_PARQUET = OUTPUT_DIR / "nifty_index_cleaned.parquet"

# Confirmed calendar/data-quality decisions from the completed audit.
REMOVE_DATES = ["2024-11-20"]          # NSE Maharashtra Assembly election holiday
FULL_DAY_INELIGIBLE = ["2022-03-07"]  # 40 missing regular-session observations
GAP_DATES = ["2023-03-28"]            # one missing minute; only crossing windows excluded

def qpath(path: Path) -> str:
    return str(path.resolve()).replace("\\", "/").replace("'", "''")

def main():
    if not INPUT_PARQUET.exists():
        raise FileNotFoundError(f"Input not found: {INPUT_PARQUET}")

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    final_parquet = OUTPUT_DIR / "nifty_index_cleaned_final.parquet"
    daily_csv = OUTPUT_DIR / "nifty_final_daily_training_eligibility.csv"
    synthetic_csv = OUTPUT_DIR / "nifty_final_synthetic_bars.csv"
    removed_csv = OUTPUT_DIR / "nifty_final_removed_invalid_holiday.csv"
    summary_json = OUTPUT_DIR / "nifty_final_closure_summary.json"

    con = duckdb.connect()
    try:
        src = qpath(INPUT_PARQUET)
        out = qpath(final_parquet)

        # Fail closed if the expected holiday really is present as a full
        # synthetic session; do not silently remove a date with real source data.
        holiday_check = con.execute(f"""
            SELECT COUNT(*) AS n,
                   COUNT(*) FILTER (WHERE is_synthetic) AS synthetic_n,
                   COUNT(*) FILTER (WHERE NOT is_synthetic) AS real_n
            FROM read_parquet('{src}')
            WHERE CAST(trading_day AS VARCHAR) IN ({','.join(repr(x) for x in REMOVE_DATES)})
        """).fetchone()
        holiday_rows, holiday_synthetic, holiday_real = map(int, holiday_check)
        if holiday_rows and holiday_real:
            raise RuntimeError(
                "2024-11-20 contains non-synthetic source rows. "
                "Stop and review the source/calendar before removing this date."
            )

        con.execute(f"""
            COPY (
                SELECT
                    *,
                    CASE
                      WHEN CAST(trading_day AS VARCHAR) IN ({','.join(repr(x) for x in FULL_DAY_INELIGIBLE)})
                        THEN FALSE
                      ELSE TRUE
                    END AS training_day_eligible,
                    CASE
                      WHEN CAST(trading_day AS VARCHAR) IN ({','.join(repr(x) for x in GAP_DATES)})
                        THEN TRUE
                      ELSE FALSE
                    END AS has_intraday_gap_fill,
                    CASE
                      WHEN CAST(trading_day AS VARCHAR) IN ({','.join(repr(x) for x in FULL_DAY_INELIGIBLE)})
                        THEN 'EXCLUDE_FULL_DAY_40_MISSING_MINUTES'
                      WHEN CAST(trading_day AS VARCHAR) IN ({','.join(repr(x) for x in GAP_DATES)})
                        THEN 'EXCLUDE_WINDOWS_CROSSING_SYNTHETIC_MINUTE'
                      ELSE 'ELIGIBLE_SUBJECT_TO_SYNTHETIC_WINDOW_FILTER'
                    END AS training_eligibility_reason
                FROM read_parquet('{src}')
                WHERE CAST(trading_day AS VARCHAR) NOT IN ({','.join(repr(x) for x in REMOVE_DATES)})
            ) TO '{out}' (FORMAT PARQUET, COMPRESSION ZSTD)
        """)

        # Final daily integrity and eligibility audit.
        con.execute(f"""
            COPY (
                SELECT
                    CAST(trading_day AS VARCHAR) AS trading_day,
                    ANY_VALUE(session_type) AS session_type,
                    COUNT(*) AS rows,
                    COUNT(*) FILTER (WHERE NOT is_synthetic) AS source_bars,
                    COUNT(*) FILTER (WHERE is_synthetic) AS synthetic_bars,
                    COUNT(DISTINCT timestamp_ist) AS unique_timestamps,
                    COUNT(*) FILTER (
                      WHERE open IS NULL OR high IS NULL OR low IS NULL OR close IS NULL
                    ) AS null_ohlc_rows,
                    COUNT(*) FILTER (WHERE NOT training_day_eligible) = 0
                      AS training_day_eligible,
                    ANY_VALUE(training_eligibility_reason) AS eligibility_reason
                FROM read_parquet('{out}')
                GROUP BY CAST(trading_day AS VARCHAR)
                ORDER BY trading_day
            ) TO '{qpath(daily_csv)}' (HEADER, DELIMITER ',')
        """)

        con.execute(f"""
            COPY (
                SELECT *
                FROM read_parquet('{out}')
                WHERE is_synthetic
                ORDER BY timestamp_ist
            ) TO '{qpath(synthetic_csv)}' (HEADER, DELIMITER ',')
        """)

        con.execute(f"""
            COPY (
                SELECT *
                FROM read_parquet('{src}')
                WHERE CAST(trading_day AS VARCHAR) IN ({','.join(repr(x) for x in REMOVE_DATES)})
            ) TO '{qpath(removed_csv)}' (HEADER, DELIMITER ',')
        """)

        stats = con.execute(f"""
            SELECT
              COUNT(*) AS rows,
              COUNT(DISTINCT timestamp_ist) AS distinct_timestamps,
              COUNT(*) FILTER (WHERE is_synthetic) AS synthetic_rows,
              COUNT(*) FILTER (WHERE NOT is_synthetic) AS source_rows,
              COUNT(*) FILTER (
                WHERE open IS NULL OR high IS NULL OR low IS NULL OR close IS NULL
              ) AS null_ohlc_rows,
              COUNT(*) FILTER (WHERE NOT training_day_eligible) AS rows_on_ineligible_days,
              MIN(CAST(trading_day AS VARCHAR)) AS first_day,
              MAX(CAST(trading_day AS VARCHAR)) AS last_day,
              COUNT(DISTINCT CAST(trading_day AS VARCHAR)) AS trading_dates
            FROM read_parquet('{out}')
        """).fetchone()
        (rows, distinct_ts, synthetic, source_rows, nulls,
         ineligible_rows, first_day, last_day, dates) = stats

        # Expected totals after removing 2024-11-20's 375 synthetic bars.
        if rows != 334335:
            raise RuntimeError(f"Unexpected final row count {rows}; expected 334335.")
        if synthetic != 41:
            raise RuntimeError(f"Unexpected synthetic count {synthetic}; expected 41.")
        if distinct_ts != rows:
            raise RuntimeError("Duplicate timestamps detected in final Parquet.")
        if nulls:
            raise RuntimeError(f"{nulls} rows have null OHLC values.")

        summary = {
            "status": "CLOSED_WITH_TRAINING_GUARDS",
            "dataset": "NIFTY index",
            "period": {"start": first_day, "end": last_day},
            "trading_dates": int(dates),
            "final_rows": int(rows),
            "source_rows": int(source_rows),
            "synthetic_rows": int(synthetic),
            "removed_invalid_holiday": {
                "date": "2024-11-20",
                "rows_removed": holiday_rows,
                "synthetic_rows_removed": holiday_synthetic,
                "real_source_rows_found": holiday_real
            },
            "duplicate_timestamps": int(rows - distinct_ts),
            "null_ohlc_rows": int(nulls),
            "full_day_training_exclusions": FULL_DAY_INELIGIBLE,
            "intraday_gap_dates": GAP_DATES,
            "rows_on_full_day_ineligible_dates": int(ineligible_rows),
            "synthetic_bar_policy": (
                "Keep is_synthetic. Do not treat synthetic bars as observed trades. "
                "Exclude any feature/label window containing a synthetic bar."
            ),
            "timezone_and_session_convention": (
                "Inherited from prior cleaner: naive source timestamps interpreted as UTC, "
                "converted to Asia/Kolkata; provisional minute-start 09:15-15:29."
            ),
            "source_database_modified": False,
            "input_parquet_modified": False,
            "elapsed_seconds": round(time.time() - STARTED, 2)
        }
        summary_json.write_text(json.dumps(summary, indent=2), encoding="utf-8")
        print(json.dumps(summary, indent=2))
        print(f"\nFINAL PARQUET: {final_parquet}")
        print(f"DAILY AUDIT:   {daily_csv}")
        print(f"SYNTHETIC AUDIT:{synthetic_csv}")
        print(f"REMOVED AUDIT: {removed_csv}")
        print(f"CLOSURE JSON:  {summary_json}")
    finally:
        con.close()

if __name__ == "__main__":
    main()
