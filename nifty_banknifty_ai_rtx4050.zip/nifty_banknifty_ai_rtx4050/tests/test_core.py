import pandas as pd
import numpy as np
from niftyai.features import build_features
from niftyai.labels import add_forward_labels
from niftyai.split import chronological_split

def sample():
    n=1500
    ts=pd.date_range("2025-01-01 09:15",periods=n,freq="min")
    c=22000*np.exp(np.cumsum(np.random.default_rng(2).normal(0,.0004,n)))
    return pd.DataFrame({"timestamp":ts,"symbol":"NIFTY","open":c,"high":c*1.001,
        "low":c*.999,"close":c,"volume":1000,"oi":100000})

def test_features_and_labels():
    d=add_forward_labels(build_features(sample()),5)
    assert "ret_1" in d and "target" in d
    assert d["forward_return"].notna().sum() > 1000

def test_split_is_chronological():
    d=add_forward_labels(build_features(sample()),5).dropna()
    tr,va,te=chronological_split(d,5)
    assert tr.timestamp.max() < va.timestamp.min()
    assert va.timestamp.max() < te.timestamp.min()
