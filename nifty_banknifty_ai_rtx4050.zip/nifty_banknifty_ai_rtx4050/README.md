# NIFTY / BANKNIFTY AI — Windows + RTX 4050 starter

A local-first, research and paper-trading codebase for NIFTY and BANKNIFTY.
Designed for Windows, 16 GB RAM and NVIDIA RTX 4050 6 GB.

**Important:** This is a runnable research starter, not a profitable trading system or a production broker terminal. It does not place orders. Demo data are synthetic and must never be confused with market data. Validate every dataset's license and provenance. Kite API access and exchange data use remain subject to their terms.

## What is included

- CSV/Parquet ingestion and schema normalisation
- DuckDB + Parquet local storage
- Causal price/OI feature engineering
- Forward-return labels for 5/15/30-minute horizons
- Chronological train/validation/test split with a horizon embargo
- LightGBM CPU baseline and XGBoost CUDA/CPU fallback
- Optional small PyTorch TCN sequence model
- Options-contract ranking baseline (research only)
- Walk-forward-ready evaluation metrics and simple cost-aware backtest
- Kite Connect 3 WebSocket collector skeleton (requires credentials and instrument tokens)
- FastAPI prediction endpoint and CLI
- Synthetic demo-data generator, tests and Windows setup scripts

## 1. Requirements

- Windows 10/11 x64
- Python 3.12 (recommended)
- 16 GB RAM
- NVIDIA driver supporting your RTX 4050
- Optional: Kite Connect API credentials for live data collection

## 2. Setup

Open PowerShell in this directory:

```powershell
.\scripts\setup.ps1
.\scripts\verify_gpu.ps1
```

The setup installs CPU dependencies. Install GPU packages separately:

```powershell
# XGBoost CUDA support (NVIDIA driver required)
pip install xgboost

# PyTorch: choose the current Windows + CUDA build from:
# https://pytorch.org/get-started/locally/
```

Then activate the environment if needed:
```powershell
.\.venv\Scripts\Activate.ps1
```

## 3. Quick demo (synthetic data only)

```powershell
python -m niftyai.cli make-demo --days 30
python -m niftyai.cli train --input data/demo/nifty_1m.parquet --symbol NIFTY --horizon 5 --model xgb
python -m niftyai.cli predict --model artifacts/NIFTY_5_xgb.joblib --input data/demo/nifty_1m.parquet
python -m niftyai.cli backtest --input data/demo/nifty_1m.parquet --symbol NIFTY --horizon 5
```

Demo results only verify that the software runs. They say nothing about real trading performance.

## 4. Use your own historical data

CSV or Parquet input must contain:
- `timestamp`: exchange/local timestamp; use Asia/Kolkata consistently
- `symbol`: NIFTY or BANKNIFTY
- `open`, `high`, `low`, `close`
- `volume`
- optional `oi`

Example:
```powershell
python -m niftyai.cli ingest --input C:\marketdata\nifty.csv --symbol NIFTY
```

Input can be one-minute index candles. For options, use a separate contract-level file with:
`timestamp, underlying, expiry, strike, option_type, open, high, low, close, volume, oi`.
The options ranker expects those contract fields and an underlying spot price column called `underlying_close` if supplied.

Do not combine vendor datasets until timestamps, expiry conventions, symbol identities, duplicate bars, missing intervals and corporate/exchange calendar differences have been reconciled.

## 5. Training

```powershell
python -m niftyai.cli train --input data/normalized/NIFTY.parquet --symbol NIFTY --horizon 5 --model lightgbm
python -m niftyai.cli train --input data/normalized/NIFTY.parquet --symbol NIFTY --horizon 15 --model xgb
python -m niftyai.cli train --input data/normalized/BANKNIFTY.parquet --symbol BANKNIFTY --horizon 30 --model xgb
```

Repeat for both indices and all horizons. The starter uses one model per symbol/horizon. It uses only causal features and a chronological split. For serious research, expand to multiple rolling walk-forward folds and add purging/embargo for all overlapping labels.

GPU training:
- XGBoost: `tree_method="hist", device="cuda"`.
- If CUDA fails, the code falls back to CPU only when `--allow-cpu-fallback` is supplied.
- Do not run several GPU jobs simultaneously on 6 GB VRAM.
- LightGBM is CPU by default; its GPU build on Windows is not assumed.

## 6. Optional TCN

Install PyTorch from the official selector: https://pytorch.org/get-started/locally/
The TCN module is optional and uses small batches. Start with batch size 32 and sequence length 128. The RTX 4050 6 GB VRAM budget is shared with Windows/display use. The included TCN is an experimental challenger, not automatically part of the final ensemble.

## 7. Kite Connect 3 live collector

Set environment variables (never commit secrets):
```powershell
$env:KITE_API_KEY="..."
$env:KITE_ACCESS_TOKEN="..."
```
Edit `config/kite_instruments.json` with current instrument tokens and symbols, then:
```powershell
python -m niftyai.cli collect-kite --config config/kite_instruments.json
```
Collector writes raw JSONL snapshots. It stores both exchange timestamp (when provided) and local receipt time. Kite full mode exposes market depth snapshots; it is not a historical exchange order-event archive. Confirm current API limits and subscription terms in Kite's documentation.

## 8. API

```powershell
uvicorn niftyai.api:app --host 127.0.0.1 --port 8000
```
Open `http://127.0.0.1:8000/docs`. The `/health` endpoint is always available. `/predict` requires a trained artifact.

## 9. Hardware guidance

- Keep feature generation on CPU with Polars/Pandas/DuckDB.
- Store raw data as partitioned Parquet; never load hundreds of millions of rows into RAM.
- Train one GPU model at a time; start with XGBoost GPU.
- TCN initial settings: 128 sequence length, batch 32, hidden channels 32–64, FP16 only after checking stability.
- Keep 2–3 GB system RAM free. Close browsers and heavy apps during training.
- CPU inference is the default for the live service; it avoids GPU contention and is usually fast enough for these models.

## 10. Before trusting any results

This starter is intentionally conservative but not yet a complete institutional-grade backtesting stack. Before any real-money use, add:
1. Full walk-forward folds with purging and embargo.
2. Point-in-time option universe and survivorship-safe contract history.
3. Executable bid/ask fills, queue/partial-fill assumptions and all charges.
4. Contract expiry/holiday handling and exact exchange calendars.
5. Calibration on a separate period and regime-specific reporting.
6. Robust drift monitoring, audit logs and independent paper-trading validation.

Never infer historical bid/ask or order-book depth from OHLC/OI. Do not interpret public participant-wise reports as identifying individual institutions.
