
from __future__ import annotations

import json
import sys
import traceback
from datetime import datetime
from pathlib import Path

import duckdb


ROOT = Path(__file__).resolve().parents[1]

INDEX_FILE = (
        ROOT / "data/processed/nifty_features_v1/"
               "nifty_features_labels_long.parquet"
)

OPTIONS_FILE = (
        ROOT / "data/processed/nifty_options_features_v4/"
               "nifty_options_features_v4.parquet"
)

OUTPUT_DIR = (
        ROOT / "data/processed/nifty_index_options_features_v1"
)

OUTPUT_FILE = (
        OUTPUT_DIR / "nifty_index_options_features_v1.parquet"
)

REPORT_DIR = ROOT / "reports/nifty_index_options_features_v1"


def sql_string(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"


def quote_identifier(value: str) -> str:
    return '"' + value.replace('"', '""') + '"'


def describe_file(con, path: Path):
    return con.execute(
        f"DESCRIBE SELECT * FROM read_parquet("
        f"{sql_string(path.resolve().as_posix())})"
    ).fetchall()


def main():

    if not INDEX_FILE.exists():
        raise FileNotFoundError(INDEX_FILE)

    if not OPTIONS_FILE.exists():
        raise FileNotFoundError(OPTIONS_FILE)

    if OUTPUT_FILE.exists():
        raise FileExistsError(
            f"Refusing to overwrite existing output: {OUTPUT_FILE}"
        )

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    REPORT_DIR.mkdir(parents=True, exist_ok=True)

    con = duckdb.connect(":memory:")
    con.execute("SET TimeZone='Asia/Kolkata'")
    con.execute("SET threads TO 4")

    try:
        index_path = sql_string(INDEX_FILE.resolve().as_posix())
        options_path = sql_string(OPTIONS_FILE.resolve().as_posix())
        output_path = sql_string(OUTPUT_FILE.resolve().as_posix())

        print("Inspecting input schemas...")

        index_schema_rows = describe_file(con, INDEX_FILE)
        options_schema_rows = describe_file(con, OPTIONS_FILE)

        index_columns = {
            row[0]: row[1] for row in index_schema_rows
        }

        options_columns = {
            row[0]: row[1] for row in options_schema_rows
        }

        required_index = [
            "timestamp_ist",
            "horizon_minutes",
            "trading_day",
            "label",
            "sample_eligible",
        ]

        required_options = [
            "timestamp_ist",
            "trading_date",
            "spot_close",
            "atm_pair_available",
            "atm_pair_return_available",
            "atm_pair_oi_change_available",
            "pcr_available",
        ]

        missing_index = [
            c for c in required_index if c not in index_columns
        ]

        missing_options = [
            c for c in required_options if c not in options_columns
        ]

        if missing_index:
            raise ValueError(
                f"Missing required index columns: {missing_index}"
            )

        if missing_options:
            raise ValueError(
                f"Missing required options columns: {missing_options}"
            )

        # The index close column is needed for an independent
        # spot-price consistency check.
        index_close_column = next(
            (
                c for c in ["close", "spot_close", "index_close"]
                if c in index_columns
            ),
            None,
        )

        if not index_close_column:
            raise ValueError(
                "No close/spot_close/index_close column found "
                "in index feature dataset."
            )

        con.execute(f"""
            CREATE VIEW index_data AS
            SELECT *
            FROM read_parquet({index_path})
        """)

        con.execute(f"""
            CREATE VIEW options_data AS
            SELECT *
            FROM read_parquet({options_path})
        """)

        print("Checking input row counts...")

        index_rows = con.execute(
            "SELECT COUNT(*) FROM index_data"
        ).fetchone()[0]

        options_rows = con.execute(
            "SELECT COUNT(*) FROM options_data"
        ).fetchone()[0]

        index_timestamps = con.execute(
            "SELECT COUNT(DISTINCT timestamp_ist) FROM index_data"
        ).fetchone()[0]

        options_timestamps = con.execute(
            "SELECT COUNT(DISTINCT timestamp_ist) FROM options_data"
        ).fetchone()[0]

        index_key_duplicates = con.execute("""
                                           SELECT COUNT(*)
                                           FROM (
                                                    SELECT timestamp_ist, horizon_minutes
                                                    FROM index_data
                                                    GROUP BY timestamp_ist, horizon_minutes
                                                    HAVING COUNT(*) > 1
                                                )
                                           """).fetchone()[0]

        options_key_duplicates = con.execute("""
                                             SELECT COUNT(*)
                                             FROM (
                                                      SELECT timestamp_ist
                                                      FROM options_data
                                                      GROUP BY timestamp_ist
                                                      HAVING COUNT(*) > 1
                                                  )
                                             """).fetchone()[0]

        if index_key_duplicates:
            raise ValueError(
                f"Index timestamp+horizon duplicates: "
                f"{index_key_duplicates}"
            )

        if options_key_duplicates:
            raise ValueError(
                f"Options timestamp duplicates: {options_key_duplicates}"
            )

        # ------------------------------------------------
        # Determine options columns to append.
        # ------------------------------------------------

        excluded_options = {
            "timestamp_ist",
            "trading_date",
            "spot_close",
        }

        overlapping = (
                set(index_columns)
                & (set(options_columns) - excluded_options)
        )

        if overlapping:
            raise ValueError(
                "Unexpected overlapping columns between index and "
                f"options datasets: {sorted(overlapping)}"
            )

        options_feature_columns = [
            c for c in options_columns
            if c not in excluded_options
        ]

        options_select = [
            'o."trading_date" AS options_trading_date',
            'o."spot_close" AS options_spot_close',
        ]

        options_select.extend(
            f"o.{quote_identifier(c)}"
            for c in options_feature_columns
        )

        # ------------------------------------------------
        # Pre-merge audit.
        # ------------------------------------------------

        print("Checking timestamp and trading-day alignment...")

        premerge = con.execute(f"""
            SELECT
                COUNT(*) AS index_rows,

                COUNT(*) FILTER (
                    WHERE o.timestamp_ist IS NOT NULL
                ) AS matched_index_rows,

                COUNT(*) FILTER (
                    WHERE o.timestamp_ist IS NULL
                ) AS index_rows_without_options,

                COUNT(*) FILTER (
                    WHERE o.timestamp_ist IS NOT NULL
                      AND CAST(i.trading_day AS DATE)
                          <> CAST(o.trading_date AS DATE)
                ) AS trading_day_mismatches,

                COUNT(*) FILTER (
                    WHERE o.timestamp_ist IS NOT NULL
                      AND ABS(
                          CAST(i.{quote_identifier(index_close_column)} AS DOUBLE)
                          - CAST(o.spot_close AS DOUBLE)
                      ) > 0.000001
                ) AS spot_close_mismatches,

                MAX(
                    CASE
                        WHEN o.timestamp_ist IS NOT NULL
                        THEN ABS(
                            CAST(i.{quote_identifier(index_close_column)} AS DOUBLE)
                            - CAST(o.spot_close AS DOUBLE)
                        )
                    END
                ) AS max_spot_close_difference

            FROM index_data i
            LEFT JOIN options_data o
                ON i.timestamp_ist = o.timestamp_ist
        """).fetchone()

        premerge_result = {
            "index_rows": premerge[0],
            "matched_index_rows": premerge[1],
            "index_rows_without_options": premerge[2],
            "trading_day_mismatches": premerge[3],
            "spot_close_mismatches": premerge[4],
            "max_spot_close_difference": premerge[5],
        }

        # ------------------------------------------------
        # Merge using LEFT JOIN.
        # Preserve every index row and every index label.
        # ------------------------------------------------

        print("Merging index and options features...")

        con.execute(f"""
            COPY (
                SELECT
                    i.*,
                    {",".join(options_select)}
                FROM index_data i
                LEFT JOIN options_data o
                    ON i.timestamp_ist = o.timestamp_ist
            )
            TO {output_path}
            (FORMAT PARQUET, COMPRESSION ZSTD)
        """)

        # ------------------------------------------------
        # Validate output.
        # ------------------------------------------------

        con.execute(f"""
            CREATE VIEW merged_data AS
            SELECT *
            FROM read_parquet({output_path})
        """)

        merged_rows = con.execute(
            "SELECT COUNT(*) FROM merged_data"
        ).fetchone()[0]

        merged_duplicate_keys = con.execute("""
                                            SELECT COUNT(*)
                                            FROM (
                                                     SELECT timestamp_ist, horizon_minutes
                                                     FROM merged_data
                                                     GROUP BY timestamp_ist, horizon_minutes
                                                     HAVING COUNT(*) > 1
                                                 )
                                            """).fetchone()[0]

        merged_label_changes = con.execute("""
                                           WITH original AS (
                                               SELECT
                                                   timestamp_ist,
                                                   horizon_minutes,
                                                   trading_day,
                                                   label,
                                                   target_z,
                                                   future_close,
                                                   forward_return,
                                                   sample_eligible
                                               FROM index_data
                                           ),
                                                merged AS (
                                                    SELECT
                                                        timestamp_ist,
                                                        horizon_minutes,
                                                        trading_day,
                                                        label,
                                                        target_z,
                                                        future_close,
                                                        forward_return,
                                                        sample_eligible
                                                    FROM merged_data
                                                )
                                           SELECT COUNT(*)
                                           FROM (
                                                    SELECT * FROM original
                                                    EXCEPT ALL
                                                    SELECT * FROM merged
                                                )
                                           """).fetchone()[0]

        merged_options_rows = con.execute("""
                                          SELECT COUNT(*)
                                          FROM merged_data
                                          WHERE options_trading_date IS NOT NULL
                                          """).fetchone()[0]

        merged_missing_options = con.execute("""
                                             SELECT COUNT(*)
                                             FROM merged_data
                                             WHERE options_trading_date IS NULL
                                             """).fetchone()[0]

        # Count availability flags across timestamp-level data.
        # Divide by 3 horizons only for display if every timestamp
        # has all three horizons.
        availability = con.execute("""
                                   SELECT
                                       COUNT(*) AS total_merged_rows,

                                       COUNT(*) FILTER (
                    WHERE atm_pair_available = TRUE
                ) AS atm_pair_available_rows,

                                       COUNT(*) FILTER (
                    WHERE atm_pair_return_available = TRUE
                ) AS atm_return_available_rows,

                                       COUNT(*) FILTER (
                    WHERE atm_pair_oi_change_available = TRUE
                ) AS atm_oi_change_available_rows,

                                       COUNT(*) FILTER (
                    WHERE pcr_available = TRUE
                ) AS pcr_available_rows,

                                       COUNT(*) FILTER (
                    WHERE atm_pair_available IS NULL
                ) AS missing_options_join_rows

                                   FROM merged_data
                                   """).fetchone()

        availability_result = {
            "total_merged_rows": availability[0],
            "atm_pair_available_rows": availability[1],
            "atm_return_available_rows": availability[2],
            "atm_oi_change_available_rows": availability[3],
            "pcr_available_rows": availability[4],
            "missing_options_join_rows": availability[5],
        }

        # ------------------------------------------------
        # Per-horizon coverage.
        # ------------------------------------------------

        horizon_df = con.execute("""
                                 SELECT
                                     horizon_minutes,
                                     COUNT(*) AS rows,
                COUNT(*) FILTER (
                    WHERE options_trading_date IS NOT NULL
                ) AS rows_with_options,
                COUNT(*) FILTER (
                    WHERE options_trading_date IS NULL
                ) AS rows_without_options,
                COUNT(*) FILTER (
                    WHERE atm_pair_available = TRUE
                ) AS atm_pair_rows,
                COUNT(*) FILTER (
                    WHERE pcr_available = TRUE
                ) AS pcr_rows
                                 FROM merged_data
                                 GROUP BY horizon_minutes
                                 ORDER BY horizon_minutes
                                 """).df()

        horizon_df.to_csv(
            REPORT_DIR / "merged_feature_coverage_by_horizon.csv",
            index=False,
            )

        # ------------------------------------------------
        # Output schema.
        # ------------------------------------------------

        output_schema = con.execute(
            f"DESCRIBE SELECT * FROM read_parquet({output_path})"
        ).df()

        output_schema.to_csv(
            REPORT_DIR / "merged_feature_schema.csv",
            index=False,
            )

        # ------------------------------------------------
        # Checks.
        # ------------------------------------------------

        checks = {
            "merged_row_count_equals_index_rows": (
                    merged_rows == index_rows
            ),
            "no_duplicate_index_keys": (
                    merged_duplicate_keys == 0
            ),
            "index_labels_and_targets_preserved": (
                    merged_label_changes == 0
            ),
            "no_trading_day_mismatches": (
                    premerge_result["trading_day_mismatches"] == 0
            ),
            "no_spot_close_mismatches": (
                    premerge_result["spot_close_mismatches"] == 0
            ),
            "options_timestamps_match_exactly": (
                    premerge_result["matched_index_rows"]
                    + premerge_result["index_rows_without_options"]
                    == index_rows
            ),
            "left_join_preserved_missing_options": (
                    merged_missing_options
                    == premerge_result["index_rows_without_options"]
            ),
        }

        summary = {
            "generated_at": datetime.now().isoformat(),
            "index_file": str(INDEX_FILE),
            "options_file": str(OPTIONS_FILE),
            "output_file": str(OUTPUT_FILE),
            "index_rows": index_rows,
            "options_rows": options_rows,
            "index_unique_timestamps": index_timestamps,
            "options_unique_timestamps": options_timestamps,
            "merged_rows": merged_rows,
            "index_key_duplicates": index_key_duplicates,
            "options_key_duplicates": options_key_duplicates,
            "merged_duplicate_keys": merged_duplicate_keys,
            "options_feature_columns_added": len(options_select),
            "output_column_count": len(output_schema),
            "premerge_alignment": premerge_result,
            "merged_options_coverage": {
                "rows_with_options": merged_options_rows,
                "rows_without_options": merged_missing_options,
            },
            "availability": availability_result,
            "label_preservation_difference_rows": merged_label_changes,
            "checks": checks,
            "passed_checks": sum(bool(v) for v in checks.values()),
            "total_checks": len(checks),
            "overall_status": (
                "PASS" if all(checks.values()) else "REVIEW_REQUIRED"
            ),
            "join_policy": "LEFT JOIN on exact timestamp_ist",
            "labels_modified": False,
            "source_files_modified": False,
            "missing_options_policy": "Preserve as NULL; no forward fill",
        }

        summary_path = (
                REPORT_DIR / "index_options_merge_summary.json"
        )

        with open(summary_path, "w", encoding="utf-8") as f:
            json.dump(summary, f, indent=2, default=str)

        print("\n" + "=" * 78)
        print("NIFTY INDEX + OPTIONS FEATURE MERGE")
        print("=" * 78)

        print(f"Index rows: {index_rows:,}")
        print(f"Options rows: {options_rows:,}")
        print(f"Merged rows: {merged_rows:,}")
        print(
            "Index rows with options: "
            f"{merged_options_rows:,}"
        )
        print(
            "Index rows without options: "
            f"{merged_missing_options:,}"
        )

        print("\nPer-horizon coverage:")
        print(horizon_df.to_string(index=False))

        print("\nChecks:")
        for name, passed in checks.items():
            print(f"{'PASS' if passed else 'FAIL'} : {name}")

        print("-" * 78)
        print(f"Overall status: {summary['overall_status']}")
        print(f"Output: {OUTPUT_FILE}")
        print(f"Reports: {REPORT_DIR}")
        print("=" * 78)

    finally:
        con.close()


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print("\nINDEX + OPTIONS MERGE FAILED")
        print(str(exc))
        traceback.print_exc()
        sys.exit(1)
