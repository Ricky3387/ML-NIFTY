
#!/usr/bin/env python3
"""
NIFTY Experimental Feature Quality Audit v1

Run from project root:
    python scripts/audit_nifty_experimental_feature_quality_v1.py

Input:
    data/processed/nifty_features_experimental_v1/
        nifty_features_labels_experimental_v1.parquet

Output:
    reports/nifty_experimental_feature_quality_v1/

Purpose:
    1. Compare baseline and experimental features.
    2. Measure feature/class separation.
    3. Identify redundant feature pairs.
    4. Compare feature separation by year.
    5. Compare feature separation by volatility regime.
    6. Rank experimental features for further investigation.

No model training or feature deletion is performed.
"""

from pathlib import Path
import json
import time
import logging

import numpy as np
import pandas as pd

START = time.time()

HORIZONS = (5, 15, 30)
CLASSES = ("DOWN", "SIDEWAYS", "UP")

TARGETS = {
    "label", "target_z", "future_close",
    "future_return", "forward_return",
    "sample_eligible", "horizon_minutes"
}

METADATA = {
    "timestamp_ist", "trading_day", "year",
    "symbol", "close", "open", "high", "low",
    "volume", "is_synthetic",
    "feature_window_valid", "label_window_valid",
    "exclusion_reason", "split", "dataset_split"
}


def standardized_difference(a, b):

    a = pd.Series(a).dropna().astype(float)
    b = pd.Series(b).dropna().astype(float)

    if len(a) < 2 or len(b) < 2:
        return np.nan

    va = a.var(ddof=1)
    vb = b.var(ddof=1)

    pooled = np.sqrt(
        (
                (len(a) - 1) * va
                + (len(b) - 1) * vb
        ) / max(len(a) + len(b) - 2, 1)
    )

    if not np.isfinite(pooled) or pooled == 0:
        return 0.0

    return float((a.mean() - b.mean()) / pooled)


def spearman(x, y):

    pair = pd.DataFrame({
        "x": x,
        "y": y
    }).replace([np.inf, -np.inf], np.nan).dropna()

    if len(pair) < 3:
        return np.nan

    if pair["x"].nunique() < 2:
        return np.nan

    if pair["y"].nunique() < 2:
        return np.nan

    return float(
        pair["x"].corr(pair["y"], method="spearman")
    )


def main():

    script_dir = Path(__file__).resolve().parent

    root = (
        script_dir.parent
        if script_dir.name.lower() == "scripts"
        else script_dir
    )

    input_path = (
            root
            / "data/processed/nifty_features_experimental_v1/"
              "nifty_features_labels_experimental_v1.parquet"
    )

    output_dir = (
            root
            / "reports/nifty_experimental_feature_quality_v1"
    )

    output_dir.mkdir(parents=True, exist_ok=True)

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(message)s"
    )

    log = logging.getLogger(
        "nifty_experimental_feature_quality_v1"
    )

    if not input_path.exists():
        raise FileNotFoundError(input_path)

    # --------------------------------------------------
    # LOAD DATA
    # --------------------------------------------------

    log.info("Loading experimental feature dataset")

    df = pd.read_parquet(input_path)

    required = {
        "timestamp_ist",
        "trading_day",
        "horizon_minutes",
        "sample_eligible",
        "label",
        "target_z",
        "realized_vol_60m"
    }

    missing = required - set(df.columns)

    if missing:
        raise RuntimeError(
            f"Missing required columns: {sorted(missing)}"
        )

    df["timestamp_ist"] = pd.to_datetime(
        df["timestamp_ist"]
    )

    df["trading_day"] = pd.to_datetime(
        df["trading_day"]
    ).dt.strftime("%Y-%m-%d")

    df["year"] = pd.to_datetime(
        df["trading_day"]
    ).dt.year

    df["horizon_minutes"] = (
        df["horizon_minutes"].astype(int)
    )

    df = df[
        df["horizon_minutes"].isin(HORIZONS)
    ].copy()

    df = df[
        df["sample_eligible"].astype(bool)
    ].copy()

    if df.empty:
        raise RuntimeError("No eligible samples found.")

    if df.duplicated([
        "trading_day",
        "timestamp_ist",
        "horizon_minutes"
    ]).any():

        raise RuntimeError(
            "Duplicate day/timestamp/horizon keys found."
        )

    # --------------------------------------------------
    # IDENTIFY BASELINE AND EXPERIMENTAL FEATURES
    # --------------------------------------------------

    excluded = TARGETS | METADATA

    all_numeric = []

    for col in df.columns:

        if col in excluded:
            continue

        if pd.api.types.is_numeric_dtype(df[col]):

            df[col] = pd.to_numeric(
                df[col], errors="coerce"
            ).astype("float64")

            if df[col].nunique(dropna=True) > 1:
                all_numeric.append(col)

    experimental = [
        c for c in all_numeric
        if c.startswith("exp_")
    ]

    baseline = [
        c for c in all_numeric
        if not c.startswith("exp_")
    ]

    if not baseline or not experimental:
        raise RuntimeError(
            "Could not identify both baseline and experimental features."
        )

    log.info(
        "Baseline features: %s | Experimental features: %s",
        len(baseline), len(experimental)
    )

    # --------------------------------------------------
    # FEATURE COVERAGE
    # --------------------------------------------------

    coverage_rows = []

    for feature in baseline + experimental:

        s = df[feature]

        coverage_rows.append({

            "feature": feature,

            "feature_group": (
                "EXPERIMENTAL"
                if feature.startswith("exp_")
                else "BASELINE"
            ),

            "eligible_samples": int(len(df)),

            "non_null_samples": int(s.notna().sum()),

            "missing_pct": float(
                s.isna().mean() * 100
            ),

            "unique_values": int(
                s.nunique(dropna=True)
            ),

            "mean": float(s.mean()),

            "std": float(s.std()),

            "min": float(s.min()),

            "p01": float(s.quantile(.01)),

            "median": float(s.median()),

            "p99": float(s.quantile(.99)),

            "max": float(s.max())
        })

    pd.DataFrame(coverage_rows).to_csv(
        output_dir / "feature_coverage.csv",
        index=False
    )

    # --------------------------------------------------
    # FEATURE VS CLASS SEPARATION
    # --------------------------------------------------

    log.info("Calculating feature/class separation")

    separation_rows = []

    for horizon, g in df.groupby("horizon_minutes"):

        for feature in baseline + experimental:

            values = g[feature]

            for cls in CLASSES:

                positive = g.loc[
                    g["label"] == cls, feature
                ]

                negative = g.loc[
                    g["label"] != cls, feature
                ]

                separation_rows.append({

                    "horizon_minutes": int(horizon),

                    "feature": feature,

                    "feature_group": (
                        "EXPERIMENTAL"
                        if feature.startswith("exp_")
                        else "BASELINE"
                    ),

                    "class": cls,

                    "class_samples": int(
                        positive.notna().sum()
                    ),

                    "other_samples": int(
                        negative.notna().sum()
                    ),

                    "standardized_mean_difference": (
                        standardized_difference(
                            positive, negative
                        )
                    ),

                    "spearman_vs_target_z": spearman(
                        values, g["target_z"]
                    )
                })

    separation = pd.DataFrame(separation_rows)

    separation.to_csv(
        output_dir / "feature_class_separation.csv",
        index=False
    )

    # --------------------------------------------------
    # FEATURE SEPARATION BY YEAR
    # --------------------------------------------------

    log.info("Calculating yearly feature separation")

    yearly_rows = []

    for horizon, g in df.groupby("horizon_minutes"):

        for year, gy in g.groupby("year"):

            for feature in baseline + experimental:

                for cls in CLASSES:

                    a = gy.loc[
                        gy["label"] == cls, feature
                    ]

                    b = gy.loc[
                        gy["label"] != cls, feature
                    ]

                    yearly_rows.append({

                        "horizon_minutes": int(horizon),

                        "year": int(year),

                        "feature": feature,

                        "feature_group": (
                            "EXPERIMENTAL"
                            if feature.startswith("exp_")
                            else "BASELINE"
                        ),

                        "class": cls,

                        "standardized_mean_difference": (
                            standardized_difference(a, b)
                        ),

                        "class_samples": int(a.notna().sum()),

                        "other_samples": int(b.notna().sum())
                    })

    pd.DataFrame(yearly_rows).to_csv(
        output_dir / "feature_separation_by_year.csv",
        index=False
    )

    # --------------------------------------------------
    # FEATURE SEPARATION BY VOLATILITY REGIME
    # --------------------------------------------------

    log.info("Calculating volatility-regime separation")

    regime_rows = []

    for horizon, g in df.groupby("horizon_minutes"):

        train_vol = g.loc[
            g["year"] <= 2023,
            "realized_vol_60m"
        ].dropna()

        q1, q2 = train_vol.quantile(
            [1/3, 2/3]
        ).tolist()

        regimes = pd.cut(
            g["realized_vol_60m"],
            bins=[-np.inf, q1, q2, np.inf],
            labels=["LOW", "MEDIUM", "HIGH"],
            include_lowest=True
        )

        temp = g.assign(
            volatility_regime=regimes
        )

        for regime, gr in temp.groupby(
                "volatility_regime",
                observed=False
        ):

            for feature in baseline + experimental:

                for cls in CLASSES:

                    a = gr.loc[
                        gr["label"] == cls, feature
                    ]

                    b = gr.loc[
                        gr["label"] != cls, feature
                    ]

                    regime_rows.append({

                        "horizon_minutes": int(horizon),

                        "volatility_regime": str(regime),

                        "feature": feature,

                        "feature_group": (
                            "EXPERIMENTAL"
                            if feature.startswith("exp_")
                            else "BASELINE"
                        ),

                        "class": cls,

                        "standardized_mean_difference": (
                            standardized_difference(a, b)
                        ),

                        "class_samples": int(a.notna().sum()),

                        "other_samples": int(b.notna().sum()),

                        "train_vol_q1": float(q1),

                        "train_vol_q2": float(q2)
                    })

    pd.DataFrame(regime_rows).to_csv(
        output_dir / "feature_separation_by_volatility.csv",
        index=False
    )

    # --------------------------------------------------
    # FEATURE CORRELATION
    # --------------------------------------------------

    log.info("Calculating feature correlations")

    correlation_rows = []

    combined = baseline + experimental

    for horizon, g in df.groupby("horizon_minutes"):

        corr = g[combined].corr(
            method="spearman"
        )

        for i, feature_a in enumerate(combined):

            for feature_b in combined[i + 1:]:

                value = corr.loc[
                    feature_a, feature_b
                ]

                if pd.isna(value):
                    continue

                correlation_rows.append({

                    "horizon_minutes": int(horizon),

                    "feature_a": feature_a,

                    "feature_b": feature_b,

                    "pair_type": (
                        "EXPERIMENTAL_VS_BASELINE"
                        if (
                                feature_a.startswith("exp_")
                                != feature_b.startswith("exp_")
                        )
                        else (
                            "EXPERIMENTAL_VS_EXPERIMENTAL"
                            if feature_a.startswith("exp_")
                            else "BASELINE_VS_BASELINE"
                        )
                    ),

                    "spearman_correlation": float(value),

                    "absolute_correlation": abs(float(value))
                })

    corr_df = pd.DataFrame(correlation_rows)

    corr_df = corr_df.sort_values(
        ["horizon_minutes", "absolute_correlation"],
        ascending=[True, False]
    )

    corr_df.to_csv(
        output_dir / "feature_correlation_pairs.csv",
        index=False
    )

    # --------------------------------------------------
    # EXPERIMENTAL FEATURE RANKING
    # --------------------------------------------------

    log.info("Ranking experimental features")

    exp_sep = separation[
        separation["feature_group"] == "EXPERIMENTAL"
        ].copy()

    ranking = (
        exp_sep.groupby([
            "horizon_minutes", "feature"
        ])
        .agg(
            mean_abs_class_separation=(
                "standardized_mean_difference",
                lambda x: float(np.nanmean(np.abs(x)))
            ),
            max_abs_class_separation=(
                "standardized_mean_difference",
                lambda x: float(np.nanmax(np.abs(x)))
            ),
            mean_abs_target_correlation=(
                "spearman_vs_target_z",
                lambda x: float(np.nanmean(np.abs(x)))
            )
        )
        .reset_index()
    )

    ranking["feature_group"] = "EXPERIMENTAL"

    ranking = ranking.sort_values(
        [
            "horizon_minutes",
            "mean_abs_class_separation"
        ],
        ascending=[True, False]
    )

    ranking.to_csv(
        output_dir / "experimental_feature_ranking.csv",
        index=False
    )

    # --------------------------------------------------
    # CORRELATION SUMMARY
    # --------------------------------------------------

    high_corr = corr_df[
        corr_df["absolute_correlation"] >= 0.90
        ]

    high_corr_summary = {}

    for horizon in HORIZONS:

        h = high_corr[
            high_corr["horizon_minutes"] == horizon
            ]

        high_corr_summary[str(horizon)] = {

            "total_pairs": int(len(h)),

            "experimental_vs_baseline": int(
                (h["pair_type"] == "EXPERIMENTAL_VS_BASELINE").sum()
            ),

            "experimental_vs_experimental": int(
                (h["pair_type"] == "EXPERIMENTAL_VS_EXPERIMENTAL").sum()
            ),

            "baseline_vs_baseline": int(
                (h["pair_type"] == "BASELINE_VS_BASELINE").sum()
            )
        }

    # --------------------------------------------------
    # SUMMARY
    # --------------------------------------------------

    summary = {

        "status": (
            "EXPERIMENTAL_FEATURE_QUALITY_AUDIT_COMPLETED"
        ),

        "eligible_rows": int(len(df)),

        "eligible_rows_by_horizon": {
            str(int(h)): int(len(g))
            for h, g in df.groupby("horizon_minutes")
        },

        "baseline_feature_count": int(len(baseline)),

        "experimental_feature_count": int(len(experimental)),

        "baseline_features": baseline,

        "experimental_features": experimental,

        "high_correlation_pairs_abs_spearman_ge_0_90": (
            high_corr_summary
        ),

        "outputs": [
            "feature_coverage.csv",
            "feature_class_separation.csv",
            "feature_separation_by_year.csv",
            "feature_separation_by_volatility.csv",
            "feature_correlation_pairs.csv",
            "experimental_feature_ranking.csv"
        ],

        "caveats": [

            "All comparisons use the existing eligible sample population.",

            "No model training or feature selection is performed.",

            "Univariate feature separation does not prove predictive power.",

            "Correlation does not prove that a feature is useless.",

            "Volatility regimes use 2021-2023 training-period cutoffs.",

            "2024 is diagnostic data, not an untouched final test.",

            "All features assume prediction at the close of the current bar."
        ],

        "elapsed_seconds": round(
            time.time() - START, 2
        )
    }

    summary_path = (
            output_dir / "experimental_feature_quality_summary.json"
    )

    summary_path.write_text(
        json.dumps(summary, indent=2),
        encoding="utf-8"
    )

    print("\n")
    print("=" * 70)
    print("NIFTY EXPERIMENTAL FEATURE QUALITY AUDIT")
    print("=" * 70)

    print(json.dumps(summary, indent=2))

    print("\nREPORT DIRECTORY:")
    print(output_dir)


if __name__ == "__main__":
    main()
