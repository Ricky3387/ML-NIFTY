
from pathlib import Path
import sys
import pandas as pd
import duckdb

# ============================================================
# CONFIGURATION
# ============================================================

ROOT = Path(__file__).resolve().parents[1]

DB_PATH = ROOT / "data" / "database" / "nifty_options.duckdb"
REPORT_DIR = ROOT / "data" / "reports"
OUTPUT_DIR = ROOT / "data" / "training" / "eligibility"

INDEXES = {
    "NIFTY": {
        "view": "nifty_index",
        "minute_file": "nifty_atm_minute_daily_coverage.csv",
        "expiry_file": "nifty_nearest_expiry_quality.csv",
    },
    "BANKNIFTY": {
        "view": "banknifty_index",
        "minute_file": "banknifty_atm_minute_daily_coverage.csv",
        "expiry_file": "banknifty_nearest_expiry_quality.csv",
    },
}

BANDS = [0.5, 1.0, 2.0]

# Initial model eligibility thresholds
MIN_INDEX_MINUTES = 60
OPTIONS_MIN_DTE = 0
OPTIONS_MAX_DTE = 7
OPTIONS_MIN_COVERAGE = 95.0
REVIEW_MIN_COVERAGE = 80.0


# ============================================================
# HELPERS
# ============================================================

def read_report(path):
    if not path.exists():
        raise FileNotFoundError(f"Missing report: {path}")

    df = pd.read_csv(path)

    if "trading_day" in df.columns:
        df["trading_day"] = pd.to_datetime(
            df["trading_day"]
        ).dt.date

    return df


def band_suffix(value):
    return str(value).replace(".", "_")


def validate_unique(df, keys, description):
    duplicates = df[df.duplicated(keys, keep=False)]

    if not duplicates.empty:
        raise ValueError(
            f"{description} contains duplicate records "
            f"for keys {keys}. Examples:\n"
            f"{duplicates.head(10).to_string(index=False)}"
        )


def get_index_daily_data(con, view_name):
    """
    Retrieve all index trading days directly from DuckDB.
    COUNT(DISTINCT timestamp) is the actual observed
    index-minute denominator.
    """

    query = f"""
        SELECT
            CAST(trading_day AS DATE) AS trading_day,
            COUNT(DISTINCT timestamp) AS index_minutes,
            MIN(strftime(timestamp, '%H:%M:%S')) AS first_index_time,
            MAX(strftime(timestamp, '%H:%M:%S')) AS last_index_time
        FROM {view_name}
        GROUP BY CAST(trading_day AS DATE)
        ORDER BY trading_day
    """

    df = con.execute(query).fetchdf()
    df["trading_day"] = pd.to_datetime(
        df["trading_day"]
    ).dt.date

    return df


# ============================================================
# ATM MINUTE COVERAGE PIVOT
# ============================================================

def prepare_minute_coverage(df, index_name):

    required = {
        "index_name",
        "trading_day",
        "nearest_expiry",
        "days_to_expiry",
        "dte_bucket",
        "band_pct",
        "total_index_minutes",
        "paired_index_minutes",
        "unavailable_index_minutes",
        "atm_minute_coverage_pct",
        "unique_paired_strikes",
        "paired_strike_minute_records",
    }

    missing = required - set(df.columns)

    if missing:
        raise ValueError(
            f"{index_name} minute report missing columns: {missing}"
        )

    df = df.copy()
    df["nearest_expiry"] = pd.to_datetime(
        df["nearest_expiry"]
    ).dt.date

    df["band_pct"] = pd.to_numeric(df["band_pct"])
    df["days_to_expiry"] = pd.to_numeric(
        df["days_to_expiry"]
    )

    validate_unique(
        df,
        ["trading_day", "band_pct"],
        f"{index_name} ATM minute report",
    )

    # Daily fields should be identical across ATM bands.
    for col in [
        "nearest_expiry",
        "days_to_expiry",
        "dte_bucket",
        "total_index_minutes",
    ]:
        counts = df.groupby("trading_day")[col].nunique(
            dropna=False
        )

        if (counts > 1).any():
            raise ValueError(
                f"Inconsistent {col} across ATM bands "
                f"for {index_name}"
            )

    daily = (
        df.sort_values("band_pct")
        .groupby("trading_day", as_index=False)
        .first()[
            [
                "trading_day",
                "nearest_expiry",
                "days_to_expiry",
                "dte_bucket",
            ]
        ]
    )

    for band in BANDS:
        part = df[df["band_pct"] == band].copy()

        if part.empty:
            raise ValueError(
                f"{index_name}: missing ATM band {band}"
            )

        suffix = band_suffix(band)

        part = part.rename(
            columns={
                "total_index_minutes":
                    f"coverage_index_minutes_{suffix}",
                "paired_index_minutes":
                    f"paired_index_minutes_{suffix}",
                "unavailable_index_minutes":
                    f"unavailable_index_minutes_{suffix}",
                "atm_minute_coverage_pct":
                    f"atm_coverage_pct_{suffix}",
                "unique_paired_strikes":
                    f"unique_paired_strikes_{suffix}",
                "paired_strike_minute_records":
                    f"paired_strike_minute_records_{suffix}",
            }
        )

        cols = [
            "trading_day",
            f"coverage_index_minutes_{suffix}",
            f"paired_index_minutes_{suffix}",
            f"unavailable_index_minutes_{suffix}",
            f"atm_coverage_pct_{suffix}",
            f"unique_paired_strikes_{suffix}",
            f"paired_strike_minute_records_{suffix}",
        ]

        daily = daily.merge(
            part[cols],
            on="trading_day",
            how="left",
            validate="one_to_one",
        )

    return daily


# ============================================================
# EXPIRY QUALITY PIVOT
# ============================================================

def prepare_expiry_quality(df, index_name):

    required = {
        "trading_day",
        "expiry",
        "days_to_expiry",
        "band_pct",
        "eligible_contract_minute_slots",
        "ce_contract_minute_slots",
        "pe_contract_minute_slots",
        "paired_contract_minute_slots",
        "paired_slot_percentage",
        "strikes_in_band",
        "option_minutes_in_band",
        "minutes_with_ce",
        "minutes_with_pe",
        "minutes_with_same_strike_ce_pe",
    }

    missing = required - set(df.columns)

    if missing:
        raise ValueError(
            f"{index_name} expiry report missing columns: {missing}"
        )

    df = df.copy()
    df["expiry"] = pd.to_datetime(df["expiry"]).dt.date
    df["band_pct"] = pd.to_numeric(df["band_pct"])
    df["days_to_expiry"] = pd.to_numeric(
        df["days_to_expiry"]
    )

    validate_unique(
        df,
        ["trading_day", "band_pct"],
        f"{index_name} expiry quality report",
    )

    daily = None

    for band in BANDS:
        part = df[df["band_pct"] == band].copy()

        if part.empty:
            raise ValueError(
                f"{index_name}: missing expiry quality band {band}"
            )

        suffix = band_suffix(band)

        part = part.rename(
            columns={
                "expiry": f"quality_expiry_{suffix}",
                "days_to_expiry": f"quality_dte_{suffix}",
                "eligible_contract_minute_slots":
                    f"eligible_slots_{suffix}",
                "ce_contract_minute_slots":
                    f"ce_slots_{suffix}",
                "pe_contract_minute_slots":
                    f"pe_slots_{suffix}",
                "paired_contract_minute_slots":
                    f"paired_slots_{suffix}",
                "paired_slot_percentage":
                    f"paired_slot_pct_{suffix}",
                "strikes_in_band":
                    f"strikes_in_band_{suffix}",
                "option_minutes_in_band":
                    f"option_minutes_{suffix}",
                "minutes_with_ce":
                    f"minutes_with_ce_{suffix}",
                "minutes_with_pe":
                    f"minutes_with_pe_{suffix}",
                "minutes_with_same_strike_ce_pe":
                    f"same_strike_pair_minutes_{suffix}",
            }
        )

        cols = [
            "trading_day",
            f"quality_expiry_{suffix}",
            f"quality_dte_{suffix}",
            f"eligible_slots_{suffix}",
            f"ce_slots_{suffix}",
            f"pe_slots_{suffix}",
            f"paired_slots_{suffix}",
            f"paired_slot_pct_{suffix}",
            f"strikes_in_band_{suffix}",
            f"option_minutes_{suffix}",
            f"minutes_with_ce_{suffix}",
            f"minutes_with_pe_{suffix}",
            f"same_strike_pair_minutes_{suffix}",
        ]

        if daily is None:
            daily = part[cols].copy()
        else:
            daily = daily.merge(
                part[cols],
                on="trading_day",
                how="outer",
                validate="one_to_one",
            )

    return daily


# ============================================================
# BUILD ONE INDEX
# ============================================================

def build_index(con, index_name, config):

    print(f"\nBuilding eligibility: {index_name}")

    # Complete index trading-day universe
    index_daily = get_index_daily_data(
        con, config["view"]
    )

    print("Index trading days:", len(index_daily))

    # Existing ATM minute coverage report
    minute_path = REPORT_DIR / config["minute_file"]
    minute_df = read_report(minute_path)

    minute_daily = prepare_minute_coverage(
        minute_df, index_name
    )

    # Existing expiry quality report
    expiry_path = REPORT_DIR / config["expiry_file"]
    expiry_df = read_report(expiry_path)

    expiry_daily = prepare_expiry_quality(
        expiry_df, index_name
    )

    # Combine reports
    result = index_daily.merge(
        minute_daily,
        on="trading_day",
        how="left",
        validate="one_to_one",
    )

    result = result.merge(
        expiry_daily,
        on="trading_day",
        how="left",
        validate="one_to_one",
    )

    result.insert(0, "index_name", index_name)

    # --------------------------------------------------------
    # Validate expiry agreement
    # --------------------------------------------------------

    for band in BANDS:
        suffix = band_suffix(band)
        expiry_col = f"quality_expiry_{suffix}"

        if expiry_col in result.columns:
            mismatch = (
                    result["nearest_expiry"].notna()
                    & result[expiry_col].notna()
                    & (
                            result["nearest_expiry"]
                            != result[expiry_col]
                    )
            )

            if mismatch.any():
                raise ValueError(
                    f"{index_name}: expiry mismatch at band {band}. "
                    f"Examples:\n"
                    f"{result.loc[mismatch, ['trading_day', 'nearest_expiry', expiry_col]].head()}"
                )

    # --------------------------------------------------------
    # Index-model eligibility
    # --------------------------------------------------------

    result["eligible_for_index_model"] = (
            result["index_minutes"] >= MIN_INDEX_MINUTES
    )

    result["index_exclusion_reason"] = ""

    result.loc[
        result["index_minutes"] < MIN_INDEX_MINUTES,
        "index_exclusion_reason",
    ] = "LESS_THAN_60_INDEX_MINUTES"

    # --------------------------------------------------------
    # Options-model eligibility
    # --------------------------------------------------------

    primary_coverage = result["atm_coverage_pct_0_5"]

    result["options_quality_grade"] = "MISSING"

    result.loc[
        primary_coverage.notna()
        & (primary_coverage >= 98),
        "options_quality_grade",
    ] = "A"

    result.loc[
        primary_coverage.notna()
        & (primary_coverage >= 95)
        & (primary_coverage < 98),
        "options_quality_grade",
    ] = "B"

    result.loc[
        primary_coverage.notna()
        & (primary_coverage >= 80)
        & (primary_coverage < 95),
        "options_quality_grade",
    ] = "C"

    result.loc[
        primary_coverage.notna()
        & (primary_coverage < 80),
        "options_quality_grade",
    ] = "D"

    dte = result["days_to_expiry"]

    valid_dte = (
            dte.notna()
            & (dte >= OPTIONS_MIN_DTE)
            & (dte <= OPTIONS_MAX_DTE)
    )

    good_coverage = (
            primary_coverage.notna()
            & (primary_coverage >= OPTIONS_MIN_COVERAGE)
    )

    result["eligible_for_options_model"] = (
            result["eligible_for_index_model"]
            & valid_dte
            & good_coverage
    )

    # Review flag: useful for later sensitivity analysis.
    result["options_review_required"] = (
            result["eligible_for_index_model"]
            & primary_coverage.notna()
            & (primary_coverage >= REVIEW_MIN_COVERAGE)
            & (primary_coverage < OPTIONS_MIN_COVERAGE)
    )

    # --------------------------------------------------------
    # Explain exclusions
    # --------------------------------------------------------

    reasons = []

    for _, row in result.iterrows():

        if not row["eligible_for_index_model"]:
            reasons.append("INDEX_DATA_INSUFFICIENT")
            continue

        day_reasons = []

        if pd.isna(row["nearest_expiry"]):
            day_reasons.append("NO_ELIGIBLE_OBSERVED_EXPIRY")

        elif pd.isna(row["days_to_expiry"]):
            day_reasons.append("DTE_MISSING")

        elif not (
                OPTIONS_MIN_DTE
                <= row["days_to_expiry"]
                <= OPTIONS_MAX_DTE
        ):
            day_reasons.append("DTE_OUTSIDE_0_TO_7")

        if pd.isna(row["atm_coverage_pct_0_5"]):
            day_reasons.append("ATM_COVERAGE_MISSING")

        elif row["atm_coverage_pct_0_5"] < REVIEW_MIN_COVERAGE:
            day_reasons.append("ATM_COVERAGE_BELOW_80")

        elif row["atm_coverage_pct_0_5"] < OPTIONS_MIN_COVERAGE:
            day_reasons.append("ATM_COVERAGE_BELOW_95")

        reasons.append(
            "ELIGIBLE"
            if not day_reasons
            else ";".join(day_reasons)
        )

    result["options_exclusion_reason"] = reasons

    result["year"] = pd.to_datetime(
        result["trading_day"]
    ).dt.year

    # --------------------------------------------------------
    # Output
    # --------------------------------------------------------

    result = result.sort_values("trading_day")

    parquet_path = (
            OUTPUT_DIR / f"{index_name.lower()}_daily_eligibility.parquet"
    )

    result.to_parquet(
        parquet_path,
        index=False,
        compression="zstd",
    )

    csv_path = (
            OUTPUT_DIR / f"{index_name.lower()}_daily_eligibility.csv"
    )

    result.to_csv(csv_path, index=False)

    print("Generated:", parquet_path)
    print("Generated:", csv_path)

    return result


# ============================================================
# SUMMARY REPORTS
# ============================================================

def create_summaries(combined):

    summary = (
        combined.groupby("index_name")
        .agg(
            total_trading_days=("trading_day", "count"),
            index_eligible_days=(
                "eligible_for_index_model", "sum"
            ),
            options_eligible_days=(
                "eligible_for_options_model", "sum"
            ),
            options_review_days=(
                "options_review_required", "sum"
            ),
            average_index_minutes=("index_minutes", "mean"),
            average_atm_coverage=(
                "atm_coverage_pct_0_5", "mean"
            ),
        )
        .reset_index()
    )

    summary["index_ineligible_days"] = (
            summary["total_trading_days"]
            - summary["index_eligible_days"]
    )

    summary["options_eligible_percentage"] = (
            summary["options_eligible_days"]
            / summary["total_trading_days"]
            * 100
    )

    summary_path = OUTPUT_DIR / "eligibility_summary.csv"
    summary.to_csv(summary_path, index=False)

    yearly = (
        combined.groupby(["index_name", "year"])
        .agg(
            total_trading_days=("trading_day", "count"),
            index_eligible_days=(
                "eligible_for_index_model", "sum"
            ),
            options_eligible_days=(
                "eligible_for_options_model", "sum"
            ),
            options_review_days=(
                "options_review_required", "sum"
            ),
            average_atm_coverage=(
                "atm_coverage_pct_0_5", "mean"
            ),
        )
        .reset_index()
    )

    yearly.to_csv(
        OUTPUT_DIR / "eligibility_yearly_summary.csv",
        index=False,
        )

    excluded = combined[
        ~combined["eligible_for_options_model"]
    ].copy()

    excluded.to_csv(
        OUTPUT_DIR / "options_excluded_days.csv",
        index=False,
        )

    print("\nOVERALL ELIGIBILITY SUMMARY")
    print(summary.to_string(index=False))

    print("\nYEARLY ELIGIBILITY SUMMARY")
    print(yearly.to_string(index=False))

    print("\nGenerated:", summary_path)
    print("Generated:", OUTPUT_DIR / "eligibility_yearly_summary.csv")
    print("Generated:", OUTPUT_DIR / "options_excluded_days.csv")


# ============================================================
# MAIN
# ============================================================

def main():

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    if not DB_PATH.exists():
        raise FileNotFoundError(
            f"DuckDB database not found: {DB_PATH}"
        )

    con = duckdb.connect(
        str(DB_PATH),
        read_only=True,
    )

    try:
        con.execute("SET TimeZone = 'Asia/Calcutta'")

        all_results = []

        for index_name, config in INDEXES.items():

            result = build_index(
                con,
                index_name,
                config,
            )

            all_results.append(result)

        combined = pd.concat(
            all_results,
            ignore_index=True,
        )

        combined_path = (
                OUTPUT_DIR / "combined_daily_eligibility.csv"
        )

        combined.to_csv(
            combined_path,
            index=False,
        )

        combined_parquet = (
                OUTPUT_DIR / "combined_daily_eligibility.parquet"
        )

        combined.to_parquet(
            combined_parquet,
            index=False,
            compression="zstd",
        )

        create_summaries(combined)

        print("\n" + "=" * 80)
        print("DAILY ELIGIBILITY BUILD COMPLETED")
        print("=" * 80)
        print("Total daily records:", len(combined))
        print("Output directory:", OUTPUT_DIR)

    finally:
        con.close()


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print("\nERROR:", exc)
        sys.exit(1)
