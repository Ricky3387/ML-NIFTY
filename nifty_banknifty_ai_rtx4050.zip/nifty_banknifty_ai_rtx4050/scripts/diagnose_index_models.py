
from pathlib import Path
import json

import numpy as np
import pandas as pd

from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    f1_score,
    confusion_matrix,
    classification_report,
    log_loss,
)

ROOT = Path(__file__).resolve().parents[1]

RESULT_DIR = ROOT / "data" / "training" / "model_results"
MODEL_DIR = ROOT / "models" / "index_models"
DIAG_DIR = RESULT_DIR / "diagnostics"

DIAG_DIR.mkdir(parents=True, exist_ok=True)

DATASETS = [
    "nifty_5m",
    "nifty_15m",
    "nifty_30m",
    "banknifty_5m",
    "banknifty_15m",
    "banknifty_30m",
]

CLASS_NAMES = ["DOWN", "SIDEWAYS", "UP"]
CLASS_IDS = [0, 1, 2]


def safe_float(value):
    if pd.isna(value):
        return None
    return float(value)


overall_rows = []
class_rows = []
year_rows = []
confidence_rows = []
regression_rows = []
confusion_rows = []
validation_rows = []

for name in DATASETS:
    print("\n" + "=" * 75)
    print("DIAGNOSING", name.upper())
    print("=" * 75)

    path = RESULT_DIR / f"{name}_test_predictions.parquet"

    if not path.exists():
        raise FileNotFoundError(path)

    df = pd.read_parquet(path)

    required = [
        "trading_day",
        "actual_class",
        "predicted_class",
        "actual_z",
        "predicted_z",
        "prob_down",
        "prob_sideways",
        "prob_up",
    ]

    missing = [c for c in required if c not in df.columns]
    if missing:
        raise RuntimeError(f"{name}: Missing columns: {missing}")

    df["trading_day"] = pd.to_datetime(df["trading_day"])
    df["year"] = df["trading_day"].dt.year
    df["month"] = df["trading_day"].dt.to_period("M").astype(str)

    y = df["actual_class"].astype(int)
    pred = df["predicted_class"].astype(int)

    probs = df[
        ["prob_down", "prob_sideways", "prob_up"]
    ].to_numpy()

    # --------------------------------------------------------
    # Overall classification diagnostics
    # --------------------------------------------------------

    accuracy = accuracy_score(y, pred)
    balanced = balanced_accuracy_score(y, pred)
    macro_f1 = f1_score(
        y, pred, average="macro", zero_division=0
    )

    ll = log_loss(y, probs, labels=CLASS_IDS)

    actual_distribution = y.value_counts(normalize=True)
    predicted_distribution = pred.value_counts(normalize=True)

    actual_majority = int(y.value_counts().idxmax())

    majority_accuracy = float((y == actual_majority).mean())

    overall_rows.append({
        "dataset": name,
        "observations": len(df),
        "accuracy": accuracy,
        "balanced_accuracy": balanced,
        "macro_f1": macro_f1,
        "log_loss": ll,
        "majority_class": CLASS_NAMES[actual_majority],
        "test_majority_accuracy": majority_accuracy,
        "actual_down_pct": actual_distribution.get(0, 0) * 100,
        "actual_sideways_pct": actual_distribution.get(1, 0) * 100,
        "actual_up_pct": actual_distribution.get(2, 0) * 100,
        "pred_down_pct": predicted_distribution.get(0, 0) * 100,
        "pred_sideways_pct": predicted_distribution.get(1, 0) * 100,
        "pred_up_pct": predicted_distribution.get(2, 0) * 100,
    })

    print("Observations:", f"{len(df):,}")
    print("Accuracy:", round(accuracy, 4))
    print("Balanced accuracy:", round(balanced, 4))
    print("Macro F1:", round(macro_f1, 4))
    print("Log loss:", round(ll, 4))

    print("\nActual class distribution:")
    print((actual_distribution * 100).round(2))

    print("\nPredicted class distribution:")
    print((predicted_distribution * 100).round(2))

    # --------------------------------------------------------
    # Per-class precision, recall, F1
    # --------------------------------------------------------

    report = classification_report(
        y,
        pred,
        labels=CLASS_IDS,
        target_names=CLASS_NAMES,
        output_dict=True,
        zero_division=0,
    )

    for class_name in CLASS_NAMES:
        row = report[class_name]
        class_rows.append({
            "dataset": name,
            "class": class_name,
            "precision": row["precision"],
            "recall": row["recall"],
            "f1": row["f1-score"],
            "support": row["support"],
        })

    # --------------------------------------------------------
    # Confusion matrix
    # Rows = actual, columns = predicted
    # --------------------------------------------------------

    matrix = confusion_matrix(y, pred, labels=CLASS_IDS)

    for actual_id in CLASS_IDS:
        for predicted_id in CLASS_IDS:
            confusion_rows.append({
                "dataset": name,
                "actual_class": CLASS_NAMES[actual_id],
                "predicted_class": CLASS_NAMES[predicted_id],
                "count": int(matrix[actual_id, predicted_id]),
            })

    print("\nConfusion matrix:")
    print(pd.DataFrame(
        matrix,
        index=CLASS_NAMES,
        columns=CLASS_NAMES
    ))

    # --------------------------------------------------------
    # Per-year performance
    # --------------------------------------------------------

    for year, group in df.groupby("year"):
        gy = group["actual_class"].astype(int)
        gp = group["predicted_class"].astype(int)

        year_rows.append({
            "dataset": name,
            "year": int(year),
            "observations": len(group),
            "accuracy": accuracy_score(gy, gp),
            "balanced_accuracy": balanced_accuracy_score(gy, gp),
            "macro_f1": f1_score(
                gy, gp, average="macro", zero_division=0
            ),
            "actual_down_pct": (gy == 0).mean() * 100,
            "actual_sideways_pct": (gy == 1).mean() * 100,
            "actual_up_pct": (gy == 2).mean() * 100,
        })

    # --------------------------------------------------------
    # Confidence diagnostics
    # --------------------------------------------------------

    df["max_probability"] = probs.max(axis=1)
    df["confidence_class"] = probs.argmax(axis=1)
    df["correct"] = (
            df["confidence_class"] == df["actual_class"]
    )

    for lower, upper in [
        (0.33, 0.40),
        (0.40, 0.45),
        (0.45, 0.50),
        (0.50, 0.55),
        (0.55, 0.60),
        (0.60, 0.70),
        (0.70, 0.80),
        (0.80, 1.01),
    ]:
        subset = df[
            (df["max_probability"] >= lower)
            & (df["max_probability"] < upper)
            ]

        confidence_rows.append({
            "dataset": name,
            "confidence_min": lower,
            "confidence_max": upper,
            "observations": len(subset),
            "coverage_pct": len(subset) / len(df) * 100,
            "accuracy": (
                subset["correct"].mean()
                if len(subset) else None
            ),
        })

    # --------------------------------------------------------
    # Regression diagnostics
    # --------------------------------------------------------

    actual_z = df["actual_z"].to_numpy(dtype=float)
    predicted_z = df["predicted_z"].to_numpy(dtype=float)

    correlation = np.corrcoef(actual_z, predicted_z)[0, 1]

    regression_rows.append({
        "dataset": name,
        "actual_z_mean": np.mean(actual_z),
        "predicted_z_mean": np.mean(predicted_z),
        "actual_z_std": np.std(actual_z),
        "predicted_z_std": np.std(predicted_z),
        "correlation": correlation,
        "actual_positive_pct": (actual_z > 0).mean() * 100,
        "predicted_positive_pct": (
                                          predicted_z > 0
                                  ).mean() * 100,
        "directional_agreement": (
                np.sign(actual_z) == np.sign(predicted_z)
        ).mean(),
    })

    # --------------------------------------------------------
    # Read validation metrics from saved metadata
    # --------------------------------------------------------

    metadata_path = MODEL_DIR / name / "classifier_metadata.json"

    if metadata_path.exists():
        with open(metadata_path, encoding="utf-8") as f:
            metadata = json.load(f)

        vm = metadata.get("validation_metrics", {})

        validation_rows.append({
            "dataset": name,
            "validation_accuracy": vm.get("accuracy"),
            "validation_balanced_accuracy": vm.get(
                "balanced_accuracy"
            ),
            "validation_macro_f1": vm.get("macro_f1"),
            "validation_log_loss": vm.get("log_loss"),
            "best_iteration": metadata.get("best_iteration"),
        })

# ------------------------------------------------------------
# Save all diagnostics
# ------------------------------------------------------------

reports = {
    "overall_diagnostics.csv": overall_rows,
    "class_diagnostics.csv": class_rows,
    "yearly_diagnostics.csv": year_rows,
    "confidence_diagnostics.csv": confidence_rows,
    "regression_diagnostics.csv": regression_rows,
    "confusion_matrices.csv": confusion_rows,
    "validation_diagnostics.csv": validation_rows,
}

for filename, rows in reports.items():
    pd.DataFrame(rows).to_csv(
        DIAG_DIR / filename,
        index=False
    )

print("\n" + "=" * 75)
print("DIAGNOSTICS COMPLETED")
print("=" * 75)

print("\nOverall:")
print(pd.DataFrame(overall_rows).round(4).to_string(index=False))

print("\nRegression:")
print(pd.DataFrame(regression_rows).round(4).to_string(index=False))

print("\nValidation:")
print(pd.DataFrame(validation_rows).round(4).to_string(index=False))

print("\nReports saved to:", DIAG_DIR)
