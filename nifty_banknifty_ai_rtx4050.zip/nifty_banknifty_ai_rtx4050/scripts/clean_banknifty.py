
from pathlib import Path
import pandas as pd
import traceback

BASE_DIR = Path(__file__).resolve().parent.parent
RAW_DIR = BASE_DIR / "data" / "raw" / "india-index-options-1m"

PROCESSED_DIR = BASE_DIR / "data" / "processed"
QUARANTINE_DIR = BASE_DIR / "data" / "quarantine"
REPORT_DIR = BASE_DIR / "data" / "reports"

INDICES = {"NIFTY", "BANKNIFTY"}
OHLC = ["open", "high", "low", "close"]

OPTION_KEY = [
    "timestamp", "symbol", "expiry", "strike", "option_type"
]

INDEX_KEY = ["timestamp", "symbol"]


def validate_ohlc(df):
    prices = df[OHLC].apply(pd.to_numeric, errors="coerce")

    return (
            prices.isna().any(axis=1)
            | (prices <= 0).any(axis=1)
            | (prices["high"] < prices["low"])
            | (
                    prices["high"]
                    < prices[["open", "close"]].max(axis=1)
            )
            | (
                    prices["low"]
                    > prices[["open", "close"]].min(axis=1)
            )
    )


def get_file_info(file):
    relative = file.relative_to(RAW_DIR)
    parts = relative.parts

    if len(parts) < 2:
        return None

    data_type = parts[0].lower()

    if data_type == "index":
        index_name = file.stem.upper()
        if index_name not in INDICES:
            return None

        return index_name, "index", Path(file.name)

    if data_type == "options":
        index_name = parts[1].upper()
        if index_name not in INDICES:
            return None

        remaining = Path(*parts[2:])
        return index_name, "options", remaining

    return None


def main():
    REPORT_DIR.mkdir(parents=True, exist_ok=True)

    files = sorted(RAW_DIR.rglob("*.parquet"))
    results = []

    totals = {
        "input": 0,
        "duplicates": 0,
        "invalid": 0,
        "conflicts": 0,
        "output": 0
    }

    selected = []

    for file in files:
        info = get_file_info(file)
        if info:
            selected.append((file, info))

    print(f"Selected files: {len(selected)}")
    print("Processing NIFTY and BANKNIFTY only.\n")

    for number, (source, info) in enumerate(selected, 1):
        index_name, data_type, relative = info

        output_dir = (
                PROCESSED_DIR / index_name / data_type
        )

        invalid_dir = (
                QUARANTINE_DIR / index_name / "invalid_ohlc"
        )

        conflict_dir = (
                QUARANTINE_DIR / index_name / "conflicting_duplicates"
        )

        output_file = output_dir / relative
        invalid_file = invalid_dir / relative
        conflict_file = conflict_dir / relative

        print(
            f"[{number}/{len(selected)}] "
            f"{index_name} / {data_type} / {source.name}"
        )

        input_rows = duplicates = invalid_count = 0
        conflict_count = output_rows = 0

        try:
            df = pd.read_parquet(source)
            input_rows = len(df)
            totals["input"] += input_rows

            required = set(OHLC)

            key = (
                OPTION_KEY if data_type == "options"
                else INDEX_KEY
            )

            required.update(key)

            missing = required - set(df.columns)

            if missing:
                raise ValueError(
                    f"Missing required columns: {sorted(missing)}"
                )

            # Remove exact duplicate rows
            before = len(df)
            df = df.drop_duplicates(keep="first").copy()
            duplicates = before - len(df)
            totals["duplicates"] += duplicates

            # Detect conflicting duplicate keys
            conflict_mask = df.duplicated(
                subset=key,
                keep=False
            )

            conflict_rows = df.loc[conflict_mask].copy()

            if not conflict_rows.empty:
                conflict_count = len(conflict_rows)
                conflict_file.parent.mkdir(
                    parents=True, exist_ok=True
                )
                conflict_rows.to_parquet(
                    conflict_file, index=False
                )

                totals["conflicts"] += conflict_count

                status = "CONFLICT_QUARANTINED"

            else:
                # Validate OHLC
                invalid_mask = validate_ohlc(df)
                invalid_rows = df.loc[invalid_mask].copy()
                valid_df = df.loc[~invalid_mask].copy()

                invalid_count = len(invalid_rows)
                totals["invalid"] += invalid_count

                if invalid_count:
                    invalid_file.parent.mkdir(
                        parents=True, exist_ok=True
                    )
                    invalid_rows.to_parquet(
                        invalid_file, index=False
                    )

                # Write clean output
                output_file.parent.mkdir(
                    parents=True, exist_ok=True
                )
                valid_df.to_parquet(
                    output_file,
                    index=False,
                    compression="snappy"
                )

                output_rows = len(valid_df)
                totals["output"] += output_rows
                status = "SUCCESS"

            print(
                f"  Input={input_rows:,}, "
                f"Duplicates={duplicates:,}, "
                f"Invalid={invalid_count:,}, "
                f"Conflicts={conflict_count:,}, "
                f"Output={output_rows:,}, "
                f"Status={status}"
            )

            results.append({
                "index": index_name,
                "data_type": data_type,
                "file": str(source.relative_to(RAW_DIR)),
                "input_rows": input_rows,
                "duplicates_removed": duplicates,
                "invalid_ohlc_rows": invalid_count,
                "conflicting_rows": conflict_count,
                "output_rows": output_rows,
                "status": status,
                "error": ""
            })

        except Exception as exc:
            print(f"  FAILED: {exc}")
            traceback.print_exc()

            results.append({
                "index": index_name,
                "data_type": data_type,
                "file": str(source.relative_to(RAW_DIR)),
                "input_rows": input_rows,
                "duplicates_removed": duplicates,
                "invalid_ohlc_rows": invalid_count,
                "conflicting_rows": conflict_count,
                "output_rows": 0,
                "status": "FAILED",
                "error": str(exc)
            })

    summary = pd.DataFrame(results)

    summary.to_csv(
        REPORT_DIR / "index_options_cleaning_summary.csv",
        index=False
    )

    print("\n========== CLEANING SUMMARY ==========")
    print(f"Selected files : {len(selected)}")
    print(f"Input rows     : {totals['input']:,}")
    print(f"Duplicates     : {totals['duplicates']:,}")
    print(f"Invalid OHLC   : {totals['invalid']:,}")
    print(f"Conflicts      : {totals['conflicts']:,}")
    print(f"Output rows    : {totals['output']:,}")

    print("\nStatus by index and data type:")
    if not summary.empty:
        print(
            summary.groupby(
                ["index", "data_type", "status"]
            ).size().to_string()
        )

    print("\nReport:")
    print(
        REPORT_DIR / "index_options_cleaning_summary.csv"
    )

    print("\nProcessed output:")
    print(PROCESSED_DIR)


if __name__ == "__main__":
    main()
