
from pathlib import Path
import duckdb
import time

ROOT = Path(__file__).resolve().parents[1]
DB_PATH = ROOT / "data" / "database" / "nifty_options.duckdb"
REPORT_DIR = ROOT / "data" / "reports"
TEMP_DIR = ROOT / "data" / "duckdb_temp"

REPORT_DIR.mkdir(parents=True, exist_ok=True)
TEMP_DIR.mkdir(parents=True, exist_ok=True)

CONFIG = {
    "NIFTY": {
        "options": "nifty_options",
        "index": "nifty_index",
    },
    "BANKNIFTY": {
        "options": "banknifty_options",
        "index": "banknifty_index",
    },
}

BANDS = (0.5, 1.0, 2.0)
MAX_DTE = 14


def export_query(con, query, filename):
    path = (REPORT_DIR / filename).as_posix().replace("'", "''")
    con.execute(
        f"COPY ({query}) TO '{path}' (HEADER, DELIMITER ',')"
    )
    print("Generated:", filename)


def get_columns(con, view):
    return {
        row[0].lower()
        for row in con.execute(f"DESCRIBE SELECT * FROM {view}").fetchall()
    }


def validate_index(con, name, options_view, index_view):
    started = time.time()
    prefix = name.lower()

    print("\n" + "=" * 90)
    print(f"{name}: ATM CONTRACT CONTINUITY")
    print("=" * 90)

    option_columns = get_columns(con, options_view)
    index_columns = get_columns(con, index_view)

    for column in ("timestamp", "trading_day", "expiry",
                   "strike", "option_type"):
        if column not in option_columns:
            raise RuntimeError(
                f"{options_view} is missing column {column}"
            )

    for column in ("timestamp", "trading_day", "close"):
        if column not in index_columns:
            raise RuntimeError(
                f"{index_view} is missing column {column}"
            )

    # --------------------------------------------------------
    # 1. Find the nearest expiry observed on each trading day.
    # Only non-expired contracts are considered.
    # --------------------------------------------------------

    print("Finding nearest observed expiry...")

    con.execute(f"""
        CREATE OR REPLACE TEMP TABLE {prefix}_nearest_expiry AS
        SELECT
            CAST(trading_day AS DATE) AS trading_day,
            MIN(CAST(expiry AS DATE)) AS nearest_expiry
        FROM {options_view}
        WHERE expiry IS NOT NULL
          AND CAST(expiry AS DATE) >= CAST(trading_day AS DATE)
        GROUP BY CAST(trading_day AS DATE)
    """)

    # --------------------------------------------------------
    # 2. Match option observations with the index at the exact
    # same timestamp. Calculate strike distance from spot.
    #
    # Exclude nearest observed expiries with DTE > 14.
    # --------------------------------------------------------

    print("Matching options with index spot prices...")

    con.execute(f"""
        CREATE OR REPLACE TEMP TABLE {prefix}_atm_base AS

        SELECT
            CAST(o.trading_day AS DATE) AS trading_day,
            CAST(o.expiry AS DATE) AS expiry,
            DATE_DIFF(
                'day',
                CAST(o.trading_day AS DATE),
                CAST(o.expiry AS DATE)
            ) AS days_to_expiry,

            o.strike,
            UPPER(o.option_type) AS option_type,
            o.timestamp AS ts,

            i.close AS spot_close,
            o.close AS option_close,
            o.volume,
            o.open_interest,

            ABS(o.strike - i.close) * 100.0
                / NULLIF(i.close, 0) AS distance_pct

        FROM {options_view} o

        INNER JOIN {prefix}_nearest_expiry e
            ON CAST(o.trading_day AS DATE) = e.trading_day
           AND CAST(o.expiry AS DATE) = e.nearest_expiry

        INNER JOIN {index_view} i
            ON o.timestamp = i.timestamp
           AND CAST(o.trading_day AS DATE)
               = CAST(i.trading_day AS DATE)

        WHERE i.close > 0
          AND o.close > 0
          AND o.strike > 0
          AND UPPER(o.option_type) IN ('CE', 'PE')
          AND CAST(o.expiry AS DATE)
              BETWEEN CAST(o.trading_day AS DATE)
                  AND CAST(o.trading_day AS DATE) + INTERVAL 14 DAY
    """)

    # --------------------------------------------------------
    # 3. Report nearest-expiry and exact index timestamp match.
    # --------------------------------------------------------

    expiry_summary = f"""
        SELECT
            '{name}' AS index_name,
            COUNT(DISTINCT trading_day) AS days_with_matched_options,
            MIN(trading_day) AS first_trading_day,
            MAX(trading_day) AS last_trading_day,
            ROUND(AVG(days_to_expiry), 2) AS avg_dte,
            MIN(days_to_expiry) AS minimum_dte,
            MAX(days_to_expiry) AS maximum_dte,
            COUNT(*) AS matched_option_rows,
            COUNT(DISTINCT ts) AS matched_timestamps
        FROM {prefix}_atm_base
    """

    export_query(
        con,
        expiry_summary,
        f"{prefix}_atm_continuity_expiry_summary.csv"
    )

    # --------------------------------------------------------
    # 4. Expand observations into three ATM bands.
    # --------------------------------------------------------

    print("Building ATM band observations...")

    con.execute(f"""
        CREATE OR REPLACE TEMP TABLE {prefix}_atm_band_observations AS

        SELECT
            b.*,
            bands.band_pct
        FROM {prefix}_atm_base b

        CROSS JOIN (
            VALUES (0.5), (1.0), (2.0)
        ) AS bands(band_pct)

        WHERE b.distance_pct <= bands.band_pct
    """)

    # --------------------------------------------------------
    # 5. Individual CE/PE contract-day continuity.
    # --------------------------------------------------------

    print("Calculating ATM contract intervals...")

    con.execute(f"""
        CREATE OR REPLACE TEMP TABLE {prefix}_atm_contract_daily AS

        WITH ordered AS (
            SELECT
                trading_day,
                expiry,
                days_to_expiry,
                strike,
                option_type,
                band_pct,
                ts,

                LAG(ts) OVER (
                    PARTITION BY
                        trading_day,
                        expiry,
                        strike,
                        option_type,
                        band_pct
                    ORDER BY ts
                ) AS previous_ts

            FROM {prefix}_atm_band_observations
        ),

        intervals AS (
            SELECT
                *,
                CASE
                    WHEN previous_ts IS NULL THEN NULL
                    ELSE DATE_DIFF(
                        'minute',
                        STRPTIME(
                            STRFTIME(
                                previous_ts,
                                '%Y-%m-%d %H:%M:%S'
                            ),
                            '%Y-%m-%d %H:%M:%S'
                        ),
                        STRPTIME(
                            STRFTIME(ts, '%Y-%m-%d %H:%M:%S'),
                            '%Y-%m-%d %H:%M:%S'
                        )
                    )
                END AS elapsed_minutes

            FROM ordered
        )

        SELECT
            trading_day,
            expiry,
            days_to_expiry,
            strike,
            option_type,
            band_pct,

            COUNT(*) AS observed_minutes,
            MIN(STRFTIME(ts, '%H:%M:%S')) AS first_observation,
            MAX(STRFTIME(ts, '%H:%M:%S')) AS last_observation,

            COUNT(elapsed_minutes) AS observed_intervals,

            SUM(CASE WHEN elapsed_minutes = 1
                     THEN 1 ELSE 0 END)
                AS consecutive_1m_intervals,

            SUM(CASE WHEN elapsed_minutes BETWEEN 2 AND 5
                     THEN 1 ELSE 0 END)
                AS intervals_2_to_5m,

            SUM(CASE WHEN elapsed_minutes BETWEEN 6 AND 15
                     THEN 1 ELSE 0 END)
                AS intervals_6_to_15m,

            SUM(CASE WHEN elapsed_minutes > 15
                     THEN 1 ELSE 0 END)
                AS intervals_over_15m,

            MAX(elapsed_minutes) AS maximum_elapsed_minutes

        FROM intervals

        GROUP BY
            trading_day,
            expiry,
            days_to_expiry,
            strike,
            option_type,
            band_pct
    """)

    contract_table = f"{prefix}_atm_contract_daily"

    export_query(
        con,
        f"SELECT * FROM {contract_table}",
        f"{prefix}_atm_contract_daily_continuity.csv"
    )

    # --------------------------------------------------------
    # 6. Aggregate contract quality by ATM band and option side.
    # --------------------------------------------------------

    contract_summary = f"""
        SELECT
            '{name}' AS index_name,
            band_pct,
            option_type,

            COUNT(*) AS contract_days,
            COUNT(DISTINCT trading_day) AS trading_days,

            ROUND(AVG(observed_minutes), 2)
                AS avg_observed_minutes,

            ROUND(MEDIAN(observed_minutes), 2)
                AS median_observed_minutes,

            ROUND(AVG(maximum_elapsed_minutes), 2)
                AS avg_maximum_gap_minutes,

            MAX(maximum_elapsed_minutes)
                AS maximum_gap_minutes,

            SUM(consecutive_1m_intervals)
                AS consecutive_1m_intervals,

            SUM(intervals_2_to_5m)
                AS intervals_2_to_5m,

            SUM(intervals_6_to_15m)
                AS intervals_6_to_15m,

            SUM(intervals_over_15m)
                AS intervals_over_15m,

            SUM(CASE WHEN observed_minutes >= 300
                     THEN 1 ELSE 0 END)
                AS contracts_300plus_minutes,

            SUM(CASE WHEN observed_minutes >= 350
                     THEN 1 ELSE 0 END)
                AS contracts_350plus_minutes

        FROM {contract_table}

        GROUP BY band_pct, option_type
        ORDER BY band_pct, option_type
    """

    export_query(
        con,
        contract_summary,
        f"{prefix}_atm_contract_summary.csv"
    )

    # --------------------------------------------------------
    # 7. Exact-timestamp same-strike CE/PE pairing.
    # --------------------------------------------------------

    print("Calculating same-strike CE/PE pairing...")

    con.execute(f"""
        CREATE OR REPLACE TEMP TABLE {prefix}_atm_pair_daily AS

        WITH per_timestamp AS (
            SELECT
                trading_day,
                expiry,
                days_to_expiry,
                strike,
                ts,
                spot_close,
                distance_pct,

                MAX(CASE WHEN option_type = 'CE'
                         THEN 1 ELSE 0 END) AS has_ce,

                MAX(CASE WHEN option_type = 'PE'
                         THEN 1 ELSE 0 END) AS has_pe

            FROM {prefix}_atm_base

            GROUP BY
                trading_day,
                expiry,
                days_to_expiry,
                strike,
                ts,
                spot_close,
                distance_pct
        ),

        expanded AS (
            SELECT
                p.*,
                bands.band_pct
            FROM per_timestamp p

            CROSS JOIN (
                VALUES (0.5), (1.0), (2.0)
            ) AS bands(band_pct)

            WHERE p.distance_pct <= bands.band_pct
        )

        SELECT
            trading_day,
            expiry,
            days_to_expiry,
            strike,
            band_pct,

            SUM(has_ce) AS ce_minutes,
            SUM(has_pe) AS pe_minutes,

            SUM(
                CASE WHEN has_ce = 1 AND has_pe = 1
                     THEN 1 ELSE 0 END
            ) AS paired_minutes,

            COUNT(*) AS timestamps_with_either_side,

            ROUND(
                100.0 * SUM(
                    CASE WHEN has_ce = 1 AND has_pe = 1
                         THEN 1 ELSE 0 END
                ) / NULLIF(COUNT(*), 0),
                2
            ) AS paired_percentage_of_union

        FROM expanded

        GROUP BY
            trading_day,
            expiry,
            days_to_expiry,
            strike,
            band_pct
    """)

    pair_table = f"{prefix}_atm_pair_daily"

    export_query(
        con,
        f"SELECT * FROM {pair_table}",
        f"{prefix}_atm_paired_contract_daily.csv"
    )

    # --------------------------------------------------------
    # 8. Daily paired coverage by band.
    # --------------------------------------------------------

    daily_pair_summary = f"""
        SELECT
            '{name}' AS index_name,
            trading_day,
            band_pct,

            MIN(days_to_expiry) AS days_to_expiry,

            COUNT(*) AS expiry_strike_pairs,

            SUM(ce_minutes) AS total_ce_minutes,
            SUM(pe_minutes) AS total_pe_minutes,
            SUM(paired_minutes) AS total_paired_minutes,

            ROUND(AVG(paired_percentage_of_union), 2)
                AS avg_pairing_percentage,

            ROUND(MEDIAN(paired_percentage_of_union), 2)
                AS median_pairing_percentage,

            SUM(CASE WHEN paired_minutes >= 300
                     THEN 1 ELSE 0 END)
                AS pairs_300plus_minutes,

            SUM(CASE WHEN paired_minutes >= 350
                     THEN 1 ELSE 0 END)
                AS pairs_350plus_minutes

        FROM {pair_table}

        GROUP BY trading_day, band_pct
        ORDER BY trading_day, band_pct
    """

    export_query(
        con,
        daily_pair_summary,
        f"{prefix}_atm_paired_daily_summary.csv"
    )

    # --------------------------------------------------------
    # 9. Aggregate paired quality by band.
    # --------------------------------------------------------

    pair_summary = f"""
        SELECT
            '{name}' AS index_name,
            band_pct,

            COUNT(*) AS expiry_strike_days,
            COUNT(DISTINCT trading_day) AS trading_days,

            ROUND(AVG(paired_minutes), 2)
                AS avg_paired_minutes,

            ROUND(MEDIAN(paired_minutes), 2)
                AS median_paired_minutes,

            ROUND(AVG(paired_percentage_of_union), 2)
                AS avg_pairing_percentage,

            ROUND(MEDIAN(paired_percentage_of_union), 2)
                AS median_pairing_percentage,

            SUM(CASE WHEN paired_minutes >= 300
                     THEN 1 ELSE 0 END)
                AS pairs_300plus_minutes,

            SUM(CASE WHEN paired_minutes >= 350
                     THEN 1 ELSE 0 END)
                AS pairs_350plus_minutes

        FROM {pair_table}

        GROUP BY band_pct
        ORDER BY band_pct
    """

    export_query(
        con,
        pair_summary,
        f"{prefix}_atm_pair_summary.csv"
    )

    # --------------------------------------------------------
    # 10. Worst daily pairing observations.
    # --------------------------------------------------------

    export_query(
        con,
        f"""
        SELECT *
        FROM {pair_table}
        WHERE band_pct = 0.5
        ORDER BY paired_minutes ASC
        LIMIT 1000
        """,
        f"{prefix}_atm_worst_paired_contracts.csv"
    )

    # --------------------------------------------------------
    # 11. Console output.
    # --------------------------------------------------------

    print("\nINDIVIDUAL CONTRACT SUMMARY")

    print(
        con.execute(contract_summary).fetchdf().to_string(
            index=False
        )
    )

    print("\nSAME-STRIKE CE/PE PAIR SUMMARY")

    print(
        con.execute(pair_summary).fetchdf().to_string(
            index=False
        )
    )

    print(
        f"\n{name} completed in "
        f"{(time.time() - started) / 60:.2f} minutes"
    )


def main():
    if not DB_PATH.exists():
        raise FileNotFoundError(DB_PATH)

    con = duckdb.connect(str(DB_PATH))

    try:
        con.execute("SET memory_limit = '6GB'")
        con.execute("SET threads = 4")
        con.execute(
            f"SET temp_directory = '{TEMP_DIR.as_posix()}'"
        )
        con.execute("SET preserve_insertion_order = false")
        con.execute("SET TimeZone = 'Asia/Calcutta'")

        print("=" * 90)
        print("ATM CONTRACT CONTINUITY VALIDATION")
        print("=" * 90)
        print("DuckDB:", con.execute(
            "SELECT version()"
        ).fetchone()[0])
        print("Timezone:", con.execute(
            "SELECT current_setting('TimeZone')"
        ).fetchone()[0])
        print("Maximum DTE:", MAX_DTE)
        print("ATM bands:", BANDS)

        for name, views in CONFIG.items():
            validate_index(
                con,
                name,
                views["options"],
                views["index"]
            )

        print("\n" + "=" * 90)
        print("ATM CONTRACT CONTINUITY VALIDATION FINISHED")
        print("Reports:", REPORT_DIR)
        print("=" * 90)

    finally:
        con.close()


if __name__ == "__main__":
    main()
