
from pathlib import Path
import duckdb
import pandas as pd

BASE = Path(__file__).resolve().parent.parent
DB = BASE / "data" / "database" / "nifty_options.duckdb"
OUT = BASE / "data" / "reports"
OUT.mkdir(parents=True, exist_ok=True)

con = duckdb.connect(str(DB), read_only=True)
con.execute("SET threads = 4")

datasets = ["nifty_options", "banknifty_options"]

for table in datasets:
    print(f"\n========== {table.upper()} ==========")

    # 1. Basic date and timestamp coverage
    coverage = con.execute(f"""
        SELECT
            COUNT(*) AS rows,
            COUNT(DISTINCT trading_day) AS trading_days,
            MIN(timestamp) AS first_timestamp,
            MAX(timestamp) AS last_timestamp,
            MIN(trading_day) AS first_trading_day,
            MAX(trading_day) AS last_trading_day,
            COUNT(DISTINCT symbol) AS symbols
        FROM {table}
    """).fetchdf()

    print("\nDate coverage:")
    print(coverage.to_string(index=False))

    # 2. Option types
    option_types = con.execute(f"""
        SELECT option_type, COUNT(*) AS rows
        FROM {table}
        GROUP BY option_type
        ORDER BY option_type
    """).fetchdf()

    print("\nOption types:")
    print(option_types.to_string(index=False))
    option_types.to_csv(
        OUT / f"{table}_option_types.csv", index=False
    )

    # 3. Expiry coverage
    expiries = con.execute(f"""
        SELECT
            expiry,
            COUNT(*) AS rows,
            COUNT(DISTINCT strike) AS strikes,
            COUNT(DISTINCT trading_day) AS trading_days
        FROM {table}
        GROUP BY expiry
        ORDER BY expiry
    """).fetchdf()

    print("\nExpiry coverage (first 20):")
    print(expiries.head(20).to_string(index=False))
    expiries.to_csv(
        OUT / f"{table}_expiry_coverage.csv", index=False
    )

    # 4. Timestamp distribution
    timestamps = con.execute(f"""
        SELECT
            CAST(timestamp AS DATE) AS timestamp_date,
            strftime(timestamp, '%H:%M:%S') AS timestamp_time,
            COUNT(*) AS rows
        FROM {table}
        GROUP BY 1, 2
        ORDER BY 1, 2
        LIMIT 100
    """).fetchdf()

    print("\nTimestamp samples:")
    print(timestamps.head(20).to_string(index=False))

    # 5. Trading-day versus timestamp-date relationship
    date_check = con.execute(f"""
        SELECT
            COUNT(*) AS total_rows,
            COUNT(*) FILTER (
                WHERE CAST(timestamp AS DATE) =
                      CAST(trading_day AS DATE)
            ) AS same_date_rows,
            COUNT(*) FILTER (
                WHERE CAST(timestamp AS DATE) <>
                      CAST(trading_day AS DATE)
            ) AS different_date_rows
        FROM {table}
    """).fetchdf()

    print("\nTimestamp date comparison:")
    print(date_check.to_string(index=False))

    # 6. Daily contract coverage
    daily = con.execute(f"""
        SELECT
            trading_day,
            COUNT(*) AS rows,
            COUNT(DISTINCT expiry) AS expiries,
            COUNT(DISTINCT strike) AS strikes,
            COUNT(DISTINCT option_type) AS option_types,
            COUNT(DISTINCT symbol) AS symbols
        FROM {table}
        GROUP BY trading_day
        ORDER BY trading_day
    """).fetchdf()

    daily.to_csv(
        OUT / f"{table}_daily_coverage.csv", index=False
    )

    print("\nDaily coverage sample:")
    print(daily.head(10).to_string(index=False))

con.close()

print("\n========== VALIDATION COMPLETE ==========")
print("Reports saved in:", OUT)
