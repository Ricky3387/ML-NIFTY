
from pathlib import Path
from datetime import datetime
import json
import warnings

import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)

warnings.filterwarnings("ignore", category=FutureWarning)

# ============================================================
# CONFIGURATION
# ============================================================

ROOT = Path(__file__).resolve().parent.parent
RUN_ID = "20261111_200710"

DATA_DIR = ROOT / "data" / "processed" / "nifty_walkforward_v1"

TRAIN_FILE = DATA_DIR / "train_5m.parquet"
VALIDATION_FILE = DATA_DIR / "validation_5m.parquet"

RUN_DIR = (
        ROOT / "reports"
        / "nifty_calibrated_threshold_transfer_v2"
        / RUN_ID
)

PROBABILITY_FILE = (
        RUN_DIR / "2024_raw_and_calibrated_probabilities.parquet"
)

POLICY_FILES = {
    "RAW_OLD_THRESHOLDS":
        RUN_DIR / "2024_raw_old_thresholds_predictions.parquet",

    "CALIBRATED_OLD_THRESHOLDS":
        RUN_DIR / "2024_calibrated_old_thresholds_predictions.parquet",

    "CALIBRATED_NEW_THRESHOLDS":
        RUN_DIR / "2024_calibrated_new_thresholds_predictions.parquet",
}

OUTPUT_DIR = ROOT / "reports" / "nifty_5m_market_regimes_v1"

LABELS = ["DOWN", "SIDEWAYS", "UP"]

JOIN_KEYS = ["__timestamp_utc", "__trading_day_key"]

FEATURES = [
    "realized_vol_15m",
    "realized_vol_60m",
    "return_60m",
    "close_vs_ema21_pct",
    "close_vs_ema50_pct",
]

PROBABILITY_COLUMNS = [
    "p_directional_raw",
    "p_up_conditional_raw",
    "p_directional_calibrated",
    "p_up_conditional_calibrated",
]


# ============================================================
# VALIDATION AND NORMALIZATION
# ============================================================

def require_file(path):
    if not path.exists():
        raise FileNotFoundError(f"File not found: {path}")


def normalize_label(series):
    return series.astype(str).str.strip().str.upper()


def add_normalized_keys(df, source_name):
    required = ["timestamp_ist", "trading_day"]

    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(
            f"{source_name} missing join columns: {missing}"
        )

    result = df.copy()

    # Normalize timezone-aware and timezone-naive values to UTC.
    result["__timestamp_utc"] = pd.to_datetime(
        result["timestamp_ist"],
        utc=True,
        errors="coerce",
    )

    # datetime.date, pandas Timestamp and string dates all become
    # the same YYYY-MM-DD key.
    result["__trading_day_key"] = (
        result["trading_day"]
        .astype(str)
        .str.strip()
        .str[:10]
    )

    if result["__timestamp_utc"].isna().any():
        raise ValueError(
            f"{source_name}: invalid timestamp values found."
        )

    if result["__trading_day_key"].isna().any():
        raise ValueError(
            f"{source_name}: missing trading_day values found."
        )

    if result.duplicated(JOIN_KEYS).any():
        duplicates = int(result.duplicated(JOIN_KEYS).sum())
        raise ValueError(
            f"{source_name}: {duplicates:,} duplicate normalized "
            "timestamp/trading-day keys."
        )

    return result


def validate_prediction_labels(df, column, source_name):
    df[column] = normalize_label(df[column])

    unexpected = sorted(
        set(df[column].dropna().unique()) - set(LABELS)
    )

    if unexpected:
        raise ValueError(
            f"{source_name}: unexpected labels in {column}: "
            f"{unexpected}"
        )


# ============================================================
# METRICS
# ============================================================

def classification_metrics(actual, predicted):
    actual = normalize_label(actual)
    predicted = normalize_label(predicted)

    directional_actual = actual.isin(["DOWN", "UP"])
    directional_predicted = predicted.isin(["DOWN", "UP"])

    result = {
        "rows": int(len(actual)),
        "accuracy": accuracy_score(actual, predicted),
        "balanced_accuracy": balanced_accuracy_score(
            actual, predicted
        ),
        "macro_f1": f1_score(
            actual,
            predicted,
            labels=LABELS,
            average="macro",
            zero_division=0,
        ),
        "weighted_f1": f1_score(
            actual,
            predicted,
            labels=LABELS,
            average="weighted",
            zero_division=0,
        ),
        "actual_directional_pct": (
                100 * directional_actual.mean()
        ),
        "predicted_directional_pct": (
                100 * directional_predicted.mean()
        ),
        "directional_precision": precision_score(
            directional_actual,
            directional_predicted,
            zero_division=0,
        ),
        "directional_recall": recall_score(
            directional_actual,
            directional_predicted,
            zero_division=0,
        ),
    }

    for label in ["DOWN", "UP"]:
        actual_binary = actual.eq(label)
        predicted_binary = predicted.eq(label)

        result[f"{label.lower()}_precision"] = precision_score(
            actual_binary,
            predicted_binary,
            zero_division=0,
        )

        result[f"{label.lower()}_recall"] = recall_score(
            actual_binary,
            predicted_binary,
            zero_division=0,
        )

        result[f"actual_{label.lower()}_pct"] = (
                100 * actual_binary.mean()
        )

        result[f"predicted_{label.lower()}_pct"] = (
                100 * predicted_binary.mean()
        )

    return result


def safe_auc(actual_binary, probability):
    actual_binary = np.asarray(actual_binary, dtype=int)
    probability = np.asarray(probability, dtype=float)

    valid = np.isfinite(probability)

    actual_binary = actual_binary[valid]
    probability = probability[valid]

    if len(actual_binary) == 0:
        return np.nan

    if len(np.unique(actual_binary)) < 2:
        return np.nan

    return roc_auc_score(actual_binary, probability)


# ============================================================
# LOAD INPUTS
# ============================================================

def main():
    print("=" * 75)
    print("NIFTY 5-MINUTE MARKET REGIME AUDIT V1 - CORRECTED")
    print("=" * 75)

    for path in [
        TRAIN_FILE,
        VALIDATION_FILE,
        PROBABILITY_FILE,
        *POLICY_FILES.values(),
    ]:
        require_file(path)

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    print("\nLoading training features...")
    train = pd.read_parquet(TRAIN_FILE)

    print("Loading validation features...")
    validation = pd.read_parquet(VALIDATION_FILE)

    for name, df in [
        ("training", train),
        ("validation", validation),
    ]:
        missing = [
            c for c in FEATURES + ["sample_eligible", "label"]
            if c not in df.columns
        ]

        if missing:
            raise ValueError(
                f"{name} file missing columns: {missing}"
            )

    train = train.loc[
        train["sample_eligible"].astype(bool)
    ].copy()

    validation = validation.loc[
        validation["sample_eligible"].astype(bool)
    ].copy()

    train = add_normalized_keys(train, "TRAIN")
    validation = add_normalized_keys(validation, "VALIDATION")

    train["label"] = normalize_label(train["label"])
    validation["label"] = normalize_label(validation["label"])

    print(f"Training eligible rows: {len(train):,}")
    print(f"Validation eligible rows: {len(validation):,}")

    # ========================================================
    # PROBABILITY DATA
    # ========================================================

    print("\nLoading probability output...")
    probabilities = pd.read_parquet(PROBABILITY_FILE)

    required_probability_columns = (
            ["actual_label"] + PROBABILITY_COLUMNS
    )

    missing = [
        c for c in required_probability_columns
        if c not in probabilities.columns
    ]

    if missing:
        raise ValueError(
            f"Probability file missing columns: {missing}\n"
            f"Available columns: {probabilities.columns.tolist()}"
        )

    probabilities = add_normalized_keys(
        probabilities,
        "PROBABILITIES",
    )

    validate_prediction_labels(
        probabilities,
        "actual_label",
        "PROBABILITIES",
    )

    # ========================================================
    # EXACT JOIN AND LABEL VALIDATION
    # ========================================================

    print("\nJoining probability rows to validation features...")

    feature_columns = JOIN_KEYS + FEATURES + ["label"]

    data = probabilities.merge(
        validation[feature_columns],
        on=JOIN_KEYS,
        how="left",
        validate="one_to_one",
        indicator=True,
    )

    unmatched = int((data["_merge"] != "both").sum())

    print(f"Probability rows: {len(probabilities):,}")
    print(f"Matched feature rows: {len(data) - unmatched:,}")
    print(f"Unmatched probability rows: {unmatched:,}")

    if unmatched:
        raise ValueError(
            f"{unmatched:,} probability rows failed exact normalized "
            "timestamp/trading-day matching."
        )

    data.drop(columns=["_merge"], inplace=True)

    label_mismatches = int(
        (
                normalize_label(data["actual_label"])
                != normalize_label(data["label"])
        ).sum()
    )

    print(f"Actual-label mismatches: {label_mismatches:,}")

    if label_mismatches:
        raise ValueError(
            "Probability actual_label differs from validation label."
        )

    print("Exact timestamp, trading-day and label checks passed.")

    # ========================================================
    # LOAD THREE POLICY PREDICTIONS
    # ========================================================

    print("\nLoading policy predictions...")

    policy_columns = {}

    for policy, path in POLICY_FILES.items():
        pred = pd.read_parquet(path)

        if "predicted_label" not in pred.columns:
            raise ValueError(
                f"{policy}: predicted_label column not found. "
                f"Available columns: {pred.columns.tolist()}"
            )

        pred = add_normalized_keys(pred, policy)

        validate_prediction_labels(
            pred,
            "predicted_label",
            policy,
        )

        pred = pred[
            JOIN_KEYS + ["predicted_label"]
            ].copy()

        output_column = f"pred_{policy}"

        pred.rename(
            columns={"predicted_label": output_column},
            inplace=True,
        )

        before = len(data)

        data = data.merge(
            pred,
            on=JOIN_KEYS,
            how="left",
            validate="one_to_one",
            indicator="__policy_merge",
        )

        unmatched_policy = int(
            (data["__policy_merge"] != "both").sum()
        )

        data.drop(columns=["__policy_merge"], inplace=True)

        if unmatched_policy:
            raise ValueError(
                f"{policy}: {unmatched_policy:,} prediction rows "
                "did not match probability rows."
            )

        if len(data) != before:
            raise ValueError(
                f"{policy}: unexpected change in row count."
            )

        policy_columns[policy] = output_column

        print(f"{policy}: {len(data):,} exact matches")

    # ========================================================
    # REGIME BOUNDARIES: TRAINING PERIOD ONLY
    # ========================================================

    print("\nCalculating regime boundaries from 2021-2023...")

    train_vol = pd.to_numeric(
        train["realized_vol_60m"],
        errors="coerce",
    ).replace([np.inf, -np.inf], np.nan).dropna()

    train_expansion = (
            pd.to_numeric(train["realized_vol_15m"], errors="coerce")
            / pd.to_numeric(train["realized_vol_60m"], errors="coerce")
    ).replace([np.inf, -np.inf], np.nan).dropna()

    if train_vol.empty or train_expansion.empty:
        raise ValueError("Insufficient training volatility data.")

    vol_q1 = float(train_vol.quantile(1 / 3))
    vol_q2 = float(train_vol.quantile(2 / 3))

    expansion_q1 = float(train_expansion.quantile(0.40))
    expansion_q2 = float(train_expansion.quantile(0.60))

    boundaries = {
        "volatility": {
            "feature": "realized_vol_60m",
            "low_upper": vol_q1,
            "medium_upper": vol_q2,
            "method": "2021-2023 training terciles",
        },
        "volatility_expansion": {
            "feature": "realized_vol_15m / realized_vol_60m",
            "contracting_upper": expansion_q1,
            "expanding_lower": expansion_q2,
            "method": "2021-2023 training 40th/60th percentiles",
        },
        "trend": {
            "uptrend": (
                "close_vs_ema21_pct > 0 AND "
                "close_vs_ema50_pct > 0 AND return_60m > 0"
            ),
            "downtrend": (
                "close_vs_ema21_pct < 0 AND "
                "close_vs_ema50_pct < 0 AND return_60m < 0"
            ),
            "otherwise": "RANGE",
        },
    }

    # ========================================================
    # ASSIGN 2024 REGIMES
    # ========================================================

    data["realized_vol_60m"] = pd.to_numeric(
        data["realized_vol_60m"],
        errors="coerce",
    )

    data["realized_vol_15m"] = pd.to_numeric(
        data["realized_vol_15m"],
        errors="coerce",
    )

    data["volatility_expansion_ratio"] = (
            data["realized_vol_15m"]
            / data["realized_vol_60m"].replace(0, np.nan)
    )

    data["volatility_regime"] = np.select(
        [
            data["realized_vol_60m"] <= vol_q1,
            data["realized_vol_60m"] <= vol_q2,
            ],
        ["LOW", "MEDIUM"],
        default="HIGH",
    )

    data["trend_regime"] = np.select(
        [
            (
                    (data["close_vs_ema21_pct"] > 0)
                    & (data["close_vs_ema50_pct"] > 0)
                    & (data["return_60m"] > 0)
            ),
            (
                    (data["close_vs_ema21_pct"] < 0)
                    & (data["close_vs_ema50_pct"] < 0)
                    & (data["return_60m"] < 0)
            ),
        ],
        ["UPTREND", "DOWNTREND"],
        default="RANGE",
    )

    data["volatility_expansion_regime"] = np.select(
        [
            data["volatility_expansion_ratio"] <= expansion_q1,
            data["volatility_expansion_ratio"] >= expansion_q2,
            ],
        ["CONTRACTING", "EXPANDING"],
        default="STABLE",
    )

    data["volatility_trend_regime"] = (
            data["volatility_regime"].astype(str)
            + "_"
            + data["trend_regime"].astype(str)
    )

    data["full_regime"] = (
            data["volatility_regime"].astype(str)
            + "_"
            + data["trend_regime"].astype(str)
            + "_"
            + data["volatility_expansion_regime"].astype(str)
    )

    # ========================================================
    # REGIME METRICS
    # ========================================================

    print("\nCalculating metrics by regime...")

    regime_dimensions = [
        "volatility_regime",
        "trend_regime",
        "volatility_expansion_regime",
        "volatility_trend_regime",
        "full_regime",
    ]

    regime_rows = []

    for dimension in regime_dimensions:
        for regime, group in data.groupby(
                dimension,
                dropna=False,
        ):
            for policy, pred_column in policy_columns.items():
                metrics = classification_metrics(
                    group["actual_label"],
                    group[pred_column],
                )

                metrics.update({
                    "regime_dimension": dimension,
                    "regime": str(regime),
                    "policy": policy,
                    "sample_pct": (
                            100 * len(group) / len(data)
                    ),
                    "directional_auc_raw": safe_auc(
                        group["actual_label"].isin(
                            ["DOWN", "UP"]
                        ),
                        group["p_directional_raw"],
                    ),
                    "directional_auc_calibrated": safe_auc(
                        group["actual_label"].isin(
                            ["DOWN", "UP"]
                        ),
                        group["p_directional_calibrated"],
                    ),
                })

                regime_rows.append(metrics)

    regime_metrics = pd.DataFrame(regime_rows)

    # ========================================================
    # MONTHLY STABILITY
    # ========================================================

    print("Calculating monthly stability...")

    data["month"] = (
        data["__timestamp_utc"]
        .dt.strftime("%Y-%m")
    )

    monthly_rows = []

    monthly_dimensions = [
        "volatility_regime",
        "trend_regime",
        "volatility_expansion_regime",
    ]

    for dimension in monthly_dimensions:
        for (month, regime), group in data.groupby(
                ["month", dimension],
                dropna=False,
        ):
            for policy, pred_column in policy_columns.items():
                metrics = classification_metrics(
                    group["actual_label"],
                    group[pred_column],
                )

                metrics.update({
                    "month": month,
                    "regime_dimension": dimension,
                    "regime": str(regime),
                    "policy": policy,
                })

                monthly_rows.append(metrics)

    monthly_metrics = pd.DataFrame(monthly_rows)

    # ========================================================
    # CLASS DISTRIBUTIONS
    # ========================================================

    distribution_rows = []

    for dimension in regime_dimensions:
        for regime, group in data.groupby(
                dimension,
                dropna=False,
        ):
            actual_distribution = (
                group["actual_label"]
                .value_counts(normalize=True)
                .mul(100)
            )

            for policy, pred_column in policy_columns.items():
                predicted_distribution = (
                    group[pred_column]
                    .value_counts(normalize=True)
                    .mul(100)
                )

                distribution_rows.append({
                    "regime_dimension": dimension,
                    "regime": str(regime),
                    "policy": policy,
                    "rows": len(group),
                    "actual_down_pct":
                        actual_distribution.get("DOWN", 0),
                    "actual_sideways_pct":
                        actual_distribution.get("SIDEWAYS", 0),
                    "actual_up_pct":
                        actual_distribution.get("UP", 0),
                    "predicted_down_pct":
                        predicted_distribution.get("DOWN", 0),
                    "predicted_sideways_pct":
                        predicted_distribution.get("SIDEWAYS", 0),
                    "predicted_up_pct":
                        predicted_distribution.get("UP", 0),
                })

    distributions = pd.DataFrame(distribution_rows)

    # ========================================================
    # REGIME COUNTS
    # ========================================================

    count_rows = []

    for dimension in regime_dimensions:
        counts = data[dimension].value_counts(dropna=False)

        for regime, count in counts.items():
            count_rows.append({
                "regime_dimension": dimension,
                "regime": str(regime),
                "rows": int(count),
                "percentage": 100 * count / len(data),
            })

    regime_counts = pd.DataFrame(count_rows)

    # ========================================================
    # SAVE REPORTS
    # ========================================================

    regime_metrics.to_csv(
        OUTPUT_DIR / "regime_metrics_by_policy.csv",
        index=False,
        )

    monthly_metrics.to_csv(
        OUTPUT_DIR / "monthly_regime_stability.csv",
        index=False,
        )

    distributions.to_csv(
        OUTPUT_DIR / "regime_class_distributions.csv",
        index=False,
        )

    regime_counts.to_csv(
        OUTPUT_DIR / "regime_sample_counts.csv",
        index=False,
        )

    data.to_parquet(
        OUTPUT_DIR / "2024_predictions_with_regimes.parquet",
        index=False,
        )

    manifest = {
        "generated_at": datetime.now().isoformat(),
        "run_id": RUN_ID,
        "scope": "NIFTY 5-minute 2024 diagnostic",
        "training_period": "2021-2023",
        "validation_period": "2024",
        "training_rows": int(len(train)),
        "validation_rows": int(len(data)),
        "matched_probability_rows": int(len(probabilities)),
        "label_mismatches": label_mismatches,
        "join_keys": [
            "UTC-normalized timestamp_ist",
            "YYYY-MM-DD normalized trading_day",
        ],
        "regime_boundaries": boundaries,
        "notes": [
            "Regime boundaries use training data only.",
            "No model retraining was performed.",
            "No thresholds were optimized by regime.",
            "2024 is a diagnostic period, not an untouched test.",
            "This audit does not establish trading profitability.",
        ],
    }

    with open(
            OUTPUT_DIR / "regime_audit_manifest.json",
            "w",
            encoding="utf-8",
    ) as f:
        json.dump(manifest, f, indent=2, default=str)

    # ========================================================
    # CONSOLE OUTPUT
    # ========================================================

    print("\n" + "=" * 75)
    print("REGIME SAMPLE COUNTS")
    print("=" * 75)

    print(
        regime_counts[
            regime_counts["regime_dimension"].isin(
                [
                    "volatility_regime",
                    "trend_regime",
                    "volatility_expansion_regime",
                ]
            )
        ].to_string(index=False)
    )

    for dimension, title in [
        ("volatility_regime", "VOLATILITY REGIME"),
        ("trend_regime", "TREND REGIME"),
        (
                "volatility_expansion_regime",
                "VOLATILITY EXPANSION REGIME",
        ),
    ]:
        print("\n" + "=" * 75)
        print(title)
        print("=" * 75)

        print(
            regime_metrics[
                regime_metrics["regime_dimension"] == dimension
                ][
                [
                    "regime",
                    "policy",
                    "rows",
                    "macro_f1",
                    "balanced_accuracy",
                    "directional_precision",
                    "directional_recall",
                    "predicted_directional_pct",
                    "directional_auc_raw",
                    "directional_auc_calibrated",
                ]
            ].to_string(index=False)
        )

    print("\n" + "=" * 75)
    print("OUTPUT")
    print("=" * 75)
    print(f"Directory: {OUTPUT_DIR}")
    print("Audit completed successfully.")


if __name__ == "__main__":
    main()
