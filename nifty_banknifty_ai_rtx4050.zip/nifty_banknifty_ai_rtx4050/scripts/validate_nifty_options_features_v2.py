
from __future__ import annotations

import json
import sys
import traceback
from datetime import datetime
from pathlib import Path

import duckdb
import pandas as pd


# ============================================================
# NIFTY OPTIONS FEATURE VALIDATION V1
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parents[1]

OPTIONS_FILE = (
        PROJECT_ROOT
        / "data/processed/nifty_options_features_v2/nifty_options_features_v2.parquet"
)

REPORT_DIR = PROJECT_ROOT / "reports/nifty_options_feature_validation_v2"

CLEAN_INDEX_FILE = (
        PROJECT_ROOT
        / "data/processed/nifty_index_cleaned/nifty_index_cleaned_final.parquet"
)

INDEX_FEATURE_FILE = (
        PROJECT_ROOT
        / "data/processed/nifty_features_v1/nifty_features_labels_long.parquet"
)

START_DATE = "2021-05-24"
END_DATE = "2024-12-31"

SESSION_START = "09:15:00"
SESSION_END = "15:29:00"
TIMEZONE = "Asia/Kolkata"

SPECIAL_DATES = [
    "2021-11-04",
    "2022-10-24",
    "2023-11-12",
    "2024-11-01",
    "2024-01-20",
    "2024-03-02",
    "2024-05-18",
]

ROLLING_WINDOWS = {
    5: 4,
    15: 14,
    30: 29,
}

EXPECTED_OPTIONS_ROWS = 333709
EXPECTED_TRADING_DAYS = 890


# ============================================================
# HELPERS
# ============================================================

def log(message: str) -> None:
    print(f"[{datetime.now().strftime('%H:%M:%S')}] {message}")


def ensure_files() -> None:
    required = [OPTIONS_FILE, CLEAN_INDEX_FILE]

    missing = [str(p) for p in required if not p.exists()]

    if missing:
        raise FileNotFoundError(
            "Required input files not found:\n" + "\n".join(missing)
        )

    if not INDEX_FEATURE_FILE.exists():
        log(
            "WARNING: Index feature Parquet not found. "
            "Index-feature alignment check will be skipped."
        )


def get_schema(con, file_path: Path) -> dict[str, str]:
    escaped = str(file_path).replace("\\", "/").replace("'", "''")

    rows = con.execute(
        f"DESCRIBE SELECT * FROM read_parquet('{escaped}')"
    ).fetchall()

    return {row[0]: row[1] for row in rows}


def quote_path(path: Path) -> str:
    return "'" + str(path).replace("\\", "/").replace("'", "''") + "'"


def local_timestamp_expression(
        column_name: str,
        column_type: str,
) -> str:
    """
    Convert timezone-aware timestamp to IST wall-clock timestamp.
    Leave timezone-naive timestamp unchanged because the project
    stores timestamp_ist as local IST when it is timezone-naive.
    """
    col = f'"{column_name}"'
    normalized_type = column_type.upper()

    if (
            "WITH TIME ZONE" in normalized_type
            or "TIMESTAMPTZ" in normalized_type
    ):
        return f"timezone('{TIMEZONE}', {col})"

    return f"CAST({col} AS TIMESTAMP)"


def find_column(schema: dict[str, str], candidates: list[str]):
    lower_map = {name.lower(): name for name in schema}

    for candidate in candidates:
        if candidate.lower() in lower_map:
            return lower_map[candidate.lower()]

    return None


def write_csv(con, query: str, output_file: Path) -> int:
    df = con.execute(query).df()
    df.to_csv(output_file, index=False)
    return len(df)


def scalar(con, query: str):
    result = con.execute(query).fetchone()
    return result[0] if result else None


def safe_pct(numerator, denominator):
    if denominator in (None, 0):
        return None
    return round(float(numerator) * 100.0 / float(denominator), 6)


# ============================================================
# MAIN
# ============================================================

def main():
    REPORT_DIR.mkdir(parents=True, exist_ok=True)

    ensure_files()

    log("Starting NIFTY options feature validation v1")
    log(f"Project root: {PROJECT_ROOT}")

    con = duckdb.connect(database=":memory:")
    con.execute("SET TimeZone='Asia/Kolkata'")
    con.execute("SET threads TO 4")

    try:
        # ----------------------------------------------------
        # 1. Inspect schemas
        # ----------------------------------------------------

        log("Inspecting Parquet schemas")

        options_schema = get_schema(con, OPTIONS_FILE)
        clean_schema = get_schema(con, CLEAN_INDEX_FILE)

        feature_schema = {}
        if INDEX_FEATURE_FILE.exists():
            feature_schema = get_schema(con, INDEX_FEATURE_FILE)

        required_options_columns = [
            "timestamp_ist",
            "trading_date",
            "spot_close",
            "selected_expiry",
            "selected_dte",
            "atm_strike",
            "atm_ce_close",
            "atm_pe_close",
            "atm_straddle_premium",
            "atm_pair_available",
            "atm_pair_return_available",
            "atm_pair_oi_change_available",
            "pcr_available",
        ]

        missing_columns = [
            c for c in required_options_columns
            if c not in options_schema
        ]

        if missing_columns:
            raise ValueError(
                f"Options Parquet missing required columns: {missing_columns}"
            )

        options_ts_expr = local_timestamp_expression(
            "timestamp_ist",
            options_schema["timestamp_ist"],
        )

        clean_ts_column = find_column(
            clean_schema,
            ["timestamp", "timestamp_ist"],
        )

        if not clean_ts_column:
            raise ValueError(
                "Could not find timestamp or timestamp_ist "
                "in cleaned index Parquet."
            )

        clean_ts_expr = local_timestamp_expression(
            clean_ts_column,
            clean_schema[clean_ts_column],
        )

        clean_close_column = find_column(
            clean_schema,
            ["close", "spot_close", "index_close"],
        )

        if not clean_close_column:
            raise ValueError(
                "Could not find close/spot_close/index_close "
                "in cleaned index Parquet."
            )

        clean_synthetic_column = find_column(
            clean_schema,
            ["is_synthetic"],
        )

        # ----------------------------------------------------
        # 2. Create normalized views
        # ----------------------------------------------------

        log("Creating normalized timestamp views")

        con.execute(f"""
            CREATE VIEW options_data AS
            SELECT
                *,
                {options_ts_expr} AS ts_local,
                CAST(trading_date AS DATE) AS day_local
            FROM read_parquet({quote_path(OPTIONS_FILE)})
        """)

        synthetic_filter = (
            f"COALESCE({clean_synthetic_column}, FALSE) = FALSE"
            if clean_synthetic_column
            else "TRUE"
        )

        con.execute(f"""
            CREATE VIEW clean_index AS
            SELECT
                {clean_ts_expr} AS ts_local,
                CAST({clean_close_column} AS DOUBLE) AS clean_close,
                CAST({clean_ts_expr} AS DATE) AS day_local
            FROM read_parquet({quote_path(CLEAN_INDEX_FILE)})
            WHERE {synthetic_filter}
        """)

        # ----------------------------------------------------
        # 3. Basic counts and duplicate checks
        # ----------------------------------------------------

        log("Checking row counts and duplicate timestamps")

        basic = {}

        basic["options_rows"] = scalar(
            con, "SELECT COUNT(*) FROM options_data"
        )

        basic["options_unique_timestamps"] = scalar(
            con,
            """
            SELECT COUNT(DISTINCT ts_local)
            FROM options_data
            """
        )

        basic["options_duplicate_timestamp_groups"] = scalar(
            con,
            """
            SELECT COUNT(*)
            FROM (
                     SELECT ts_local
                     FROM options_data
                     GROUP BY ts_local
                     HAVING COUNT(*) > 1
                 )
            """
        )

        basic["options_trading_days"] = scalar(
            con,
            """
            SELECT COUNT(DISTINCT day_local)
            FROM options_data
            """
        )

        basic["clean_real_index_rows"] = scalar(
            con, "SELECT COUNT(*) FROM clean_index"
        )

        basic["clean_unique_timestamps"] = scalar(
            con,
            "SELECT COUNT(DISTINCT ts_local) FROM clean_index"
        )

        basic["clean_duplicate_timestamp_groups"] = scalar(
            con,
            """
            SELECT COUNT(*)
            FROM (
                     SELECT ts_local
                     FROM clean_index
                     GROUP BY ts_local
                     HAVING COUNT(*) > 1
                 )
            """
        )

        # ----------------------------------------------------
        # 4. Scope and session validation
        # ----------------------------------------------------

        log("Checking date range, session and special dates")

        scope_query = f"""
            SELECT
                COUNT(*) AS total_rows,

                COUNT(*) FILTER (
                    WHERE day_local < DATE '{START_DATE}'
                       OR day_local > DATE '{END_DATE}'
                ) AS outside_date_scope,

                COUNT(*) FILTER (
                    WHERE CAST(ts_local AS TIME) < TIME '{SESSION_START}'
                       OR CAST(ts_local AS TIME) > TIME '{SESSION_END}'
                ) AS outside_regular_session,

                COUNT(*) FILTER (
                    WHERE day_local IN (
                        {",".join("DATE '" + d + "'" for d in SPECIAL_DATES)}
                    )
                ) AS special_date_rows,

                COUNT(*) FILTER (
                    WHERE ts_local IS NULL
                ) AS null_timestamps,

                COUNT(*) FILTER (
                    WHERE day_local IS NULL
                ) AS null_trading_dates
            FROM options_data
        """

        scope_df = con.execute(scope_query).df()
        scope_df.to_csv(REPORT_DIR / "scope_validation.csv", index=False)

        scope = scope_df.iloc[0].to_dict()

        # ----------------------------------------------------
        # 5. Exact timestamp alignment with cleaned index
        # ----------------------------------------------------

        log("Checking exact timestamp alignment with cleaned index")

        alignment_query = """
                          SELECT
                              COUNT(*) AS options_rows,

                              COUNT(*) FILTER (
                    WHERE c.ts_local IS NOT NULL
                ) AS exact_timestamp_matches,

                              COUNT(*) FILTER (
                    WHERE c.ts_local IS NULL
                ) AS options_timestamps_missing_from_clean_index,

                              COUNT(*) FILTER (
                    WHERE c.ts_local IS NOT NULL
                      AND ABS(o.spot_close - c.clean_close) > 0.000001
                ) AS spot_close_mismatches,

                              MAX(
                                      CASE
                                          WHEN c.ts_local IS NOT NULL
                                              THEN ABS(o.spot_close - c.clean_close)
                                          END
                              ) AS max_absolute_spot_difference

                          FROM options_data o
                                   LEFT JOIN clean_index c
                                             ON o.ts_local = c.ts_local \
                          """

        alignment_df = con.execute(alignment_query).df()
        alignment_df.to_csv(
            REPORT_DIR / "clean_index_alignment.csv",
            index=False,
            )

        alignment = alignment_df.iloc[0].to_dict()

        # Also identify cleaned index timestamps missing from options.
        missing_options_query = """
                                SELECT
                                    c.ts_local,
                                    c.day_local,
                                    c.clean_close
                                FROM clean_index c
                                         LEFT JOIN options_data o
                                                   ON c.ts_local = o.ts_local
                                WHERE o.ts_local IS NULL
                                ORDER BY c.ts_local \
                                """

        write_csv(
            con,
            missing_options_query,
            REPORT_DIR / "clean_index_minutes_missing_options.csv",
            )

        # ----------------------------------------------------
        # 6. ATM pair and feature flag consistency
        # ----------------------------------------------------

        log("Checking ATM pair and quality flags")

        flag_query = """
                     SELECT
                         COUNT(*) AS total_rows,

                         COUNT(*) FILTER (
                    WHERE atm_pair_available = TRUE
                      AND (
                          atm_ce_close IS NULL
                          OR atm_pe_close IS NULL
                      )
                ) AS pair_flag_but_missing_price,

                         COUNT(*) FILTER (
                    WHERE atm_pair_available = FALSE
                      AND atm_straddle_premium IS NOT NULL
                ) AS no_pair_flag_but_straddle_present,

                         COUNT(*) FILTER (
                    WHERE atm_pair_available = TRUE
                      AND atm_straddle_premium IS NULL
                ) AS pair_flag_but_straddle_missing,

                         COUNT(*) FILTER (
                    WHERE atm_pair_return_available = TRUE
                      AND (
                          atm_ce_log_return_1m IS NULL
                          OR atm_pe_log_return_1m IS NULL
                      )
                ) AS return_flag_but_missing_return,

                         COUNT(*) FILTER (
                    WHERE atm_pair_oi_change_available = TRUE
                      AND (
                          atm_ce_oi_change_1m IS NULL
                          OR atm_pe_oi_change_1m IS NULL
                      )
                ) AS oi_flag_but_missing_change,

                         COUNT(*) FILTER (
                    WHERE pcr_available = TRUE
                      AND (
                          near_atm_pcr_oi IS NULL
                          OR near_atm_pcr_volume IS NULL
                      )
                ) AS pcr_flag_but_missing_pcr,

                         COUNT(*) FILTER (
                    WHERE atm_pair_available = TRUE
                      AND (
                          atm_ce_close <= 0
                          OR atm_pe_close <= 0
                      )
                ) AS non_positive_atm_prices,

                         COUNT(*) FILTER (
                    WHERE selected_dte < 0 OR selected_dte > 7
                ) AS invalid_selected_dte,

                         COUNT(*) FILTER (
                    WHERE atm_distance_pct < 0
                ) AS negative_atm_distance

                     FROM options_data \
                     """

        flag_df = con.execute(flag_query).df()
        flag_df.to_csv(
            REPORT_DIR / "quality_flag_validation.csv",
            index=False,
            )

        flag_results = flag_df.iloc[0].to_dict()

        # ----------------------------------------------------
        # 7. ATM missingness and availability
        # ----------------------------------------------------

        log("Auditing ATM missingness")

        atm_null_query = """
                         SELECT
                             COUNT(*) AS total_rows,

                             COUNT(*) FILTER (
                    WHERE selected_expiry IS NULL
                ) AS null_selected_expiry,

                             COUNT(*) FILTER (
                    WHERE atm_strike IS NULL
                ) AS null_atm_strike,

                             COUNT(*) FILTER (
                    WHERE atm_ce_close IS NULL
                ) AS null_atm_ce_close,

                             COUNT(*) FILTER (
                    WHERE atm_pe_close IS NULL
                ) AS null_atm_pe_close,

                             COUNT(*) FILTER (
                    WHERE atm_straddle_premium IS NULL
                ) AS null_atm_straddle,

                             COUNT(*) FILTER (
                    WHERE atm_pair_available = FALSE
                ) AS atm_pair_unavailable,

                             COUNT(*) FILTER (
                    WHERE atm_pair_return_available = FALSE
                ) AS atm_return_unavailable,

                             COUNT(*) FILTER (
                    WHERE atm_pair_oi_change_available = FALSE
                ) AS atm_oi_change_unavailable,

                             COUNT(*) FILTER (
                    WHERE pcr_available = FALSE
                ) AS pcr_unavailable

                         FROM options_data \
                         """

        atm_null_df = con.execute(atm_null_query).df()
        atm_null_df.to_csv(
            REPORT_DIR / "atm_missingness.csv",
            index=False,
            )

        # ----------------------------------------------------
        # 8. Rolling window integrity
        # ----------------------------------------------------

        log("Checking rolling volume window continuity")

        rolling_results = []

        for window, lag_offset in ROLLING_WINDOWS.items():

            ce_count = f"ce_volume_count_{window}m"
            pe_count = f"pe_volume_count_{window}m"

            ce_sum = f"atm_ce_volume_sum_{window}m"
            pe_sum = f"atm_pe_volume_sum_{window}m"

            required = [
                ce_count,
                pe_count,
                ce_sum,
                pe_sum,
            ]

            missing = [
                c for c in required
                if c not in options_schema
            ]

            if missing:
                rolling_results.append({
                    "window_minutes": window,
                    "status": "SKIPPED_MISSING_COLUMNS",
                    "missing_columns": ",".join(missing),
                })
                continue

            rolling_query = f"""
                WITH ordered AS (
                    SELECT
                        ts_local,
                        day_local,
                        {ce_count} AS ce_count,
                        {pe_count} AS pe_count,
                        {ce_sum} AS ce_sum,
                        {pe_sum} AS pe_sum,

                        LAG(ts_local, {lag_offset}) OVER (
                            PARTITION BY day_local
                            ORDER BY ts_local
                        ) AS prior_window_timestamp

                    FROM options_data
                ),

                checked AS (
                    SELECT
                        *,
                        CASE
                            WHEN prior_window_timestamp IS NOT NULL
                             AND DATE_DIFF(
                                 'minute',
                                 prior_window_timestamp,
                                 ts_local
                             ) = {lag_offset}
                            THEN TRUE
                            ELSE FALSE
                        END AS clock_window_contiguous

                    FROM ordered
                )

                SELECT
                    {window} AS window_minutes,

                    COUNT(*) AS total_rows,

                    COUNT(*) FILTER (
                        WHERE ce_count = {window}
                          AND pe_count = {window}
                    ) AS complete_count_rows,

                    COUNT(*) FILTER (
                        WHERE ce_sum IS NOT NULL
                          AND pe_sum IS NOT NULL
                    ) AS nonnull_rolling_sum_rows,

                    COUNT(*) FILTER (
                        WHERE ce_sum IS NOT NULL
                          AND pe_sum IS NOT NULL
                          AND (
                              ce_count <> {window}
                              OR pe_count <> {window}
                          )
                    ) AS sum_present_with_incomplete_count,

                    COUNT(*) FILTER (
                        WHERE ce_count = {window}
                          AND pe_count = {window}
                          AND NOT clock_window_contiguous
                    ) AS complete_counts_but_clock_gap,

                    COUNT(*) FILTER (
                        WHERE ce_sum IS NOT NULL
                          AND pe_sum IS NOT NULL
                          AND NOT clock_window_contiguous
                    ) AS rolling_sum_present_across_clock_gap,

                    COUNT(*) FILTER (
                        WHERE clock_window_contiguous = TRUE
                          AND ce_count = {window}
                          AND pe_count = {window}
                          AND ce_sum IS NOT NULL
                          AND pe_sum IS NOT NULL
                    ) AS valid_contiguous_rolling_rows

                FROM checked
            """

            rolling_df = con.execute(rolling_query).df()
            rolling_results.append(rolling_df.iloc[0].to_dict())

        rolling_df = pd.DataFrame(rolling_results)
        rolling_df.to_csv(
            REPORT_DIR / "rolling_window_validation.csv",
            index=False,
            )

        # ----------------------------------------------------
        # 9. Exact alignment with index feature dataset
        # ----------------------------------------------------

        feature_alignment = {
            "status": "SKIPPED",
            "reason": "Index feature Parquet not found",
        }

        if INDEX_FEATURE_FILE.exists():

            log("Checking alignment with index feature dataset")

            index_ts_column = find_column(
                feature_schema,
                ["timestamp_ist", "timestamp"],
            )

            if not index_ts_column:
                raise ValueError(
                    "Index feature Parquet has no timestamp_ist/timestamp."
                )

            index_ts_expr = local_timestamp_expression(
                index_ts_column,
                feature_schema[index_ts_column],
            )

            index_day_column = find_column(
                feature_schema,
                ["trading_day", "trading_date"],
            )

            index_close_column = find_column(
                feature_schema,
                ["close", "spot_close", "index_close"],
            )

            day_expr = (
                f"CAST({index_day_column} AS DATE)"
                if index_day_column
                else f"CAST({index_ts_expr} AS DATE)"
            )

            close_expr = (
                f"CAST({index_close_column} AS DOUBLE)"
                if index_close_column
                else "NULL::DOUBLE"
            )

            con.execute(f"""
                CREATE VIEW index_features AS
                SELECT
                    {index_ts_expr} AS ts_local,
                    {day_expr} AS day_local,
                    {close_expr} AS index_close
                FROM read_parquet({quote_path(INDEX_FEATURE_FILE)})
            """)

            # The index feature file has three horizons per timestamp.
            # Collapse to one row per timestamp before joining.
            feature_query = """
                            WITH idx AS (
                                SELECT
                                    ts_local,
                                    MIN(day_local) AS day_local,
                                    MIN(index_close) AS min_close,
                                    MAX(index_close) AS max_close,
                                    COUNT(DISTINCT index_close) AS distinct_close_values
                                FROM index_features
                                GROUP BY ts_local
                            )

                            SELECT
                                COUNT(*) AS options_rows,

                                COUNT(*) FILTER (
                        WHERE i.ts_local IS NOT NULL
                    ) AS timestamp_matches,

                                COUNT(*) FILTER (
                        WHERE i.ts_local IS NULL
                    ) AS missing_index_feature_timestamps,

                                COUNT(*) FILTER (
                        WHERE i.ts_local IS NOT NULL
                          AND i.day_local <> o.day_local
                    ) AS trading_day_mismatches,

                                COUNT(*) FILTER (
                        WHERE i.ts_local IS NOT NULL
                          AND i.distinct_close_values > 1
                    ) AS inconsistent_index_close_per_timestamp,

                                COUNT(*) FILTER (
                        WHERE i.ts_local IS NOT NULL
                          AND i.min_close IS NOT NULL
                          AND ABS(o.spot_close - i.min_close) > 0.000001
                    ) AS spot_close_mismatches

                            FROM options_data o
                                     LEFT JOIN idx i
                                               ON o.ts_local = i.ts_local \
                            """

            feature_df = con.execute(feature_query).df()
            feature_df.to_csv(
                REPORT_DIR / "index_feature_alignment.csv",
                index=False,
                )

            feature_alignment = feature_df.iloc[0].to_dict()
            feature_alignment["status"] = "COMPLETED"

        # ----------------------------------------------------
        # 10. Daily row-count and coverage audit
        # ----------------------------------------------------

        log("Generating daily coverage report")

        daily_query = """
                      SELECT
                          day_local AS trading_date,
                          COUNT(*) AS options_rows,
                          COUNT(DISTINCT ts_local) AS unique_minutes,
                          MIN(CAST(ts_local AS TIME)) AS first_time,
                          MAX(CAST(ts_local AS TIME)) AS last_time,

                          COUNT(*) FILTER (
                    WHERE atm_pair_available = TRUE
                ) AS atm_pair_rows,

                          COUNT(*) FILTER (
                    WHERE pcr_available = TRUE
                ) AS pcr_rows,

                          COUNT(*) FILTER (
                    WHERE atm_pair_return_available = TRUE
                ) AS atm_return_rows,

                          COUNT(*) FILTER (
                    WHERE atm_pair_oi_change_available = TRUE
                ) AS atm_oi_change_rows

                      FROM options_data
                      GROUP BY day_local
                      ORDER BY day_local \
                      """

        daily_count = write_csv(
            con,
            daily_query,
            REPORT_DIR / "daily_options_feature_coverage.csv",
            )

        # ----------------------------------------------------
        # 11. Missingness by date
        # ----------------------------------------------------

        missing_by_day_query = """
                               SELECT
                                   day_local AS trading_date,
                                   COUNT(*) AS rows,
                COUNT(*) FILTER (
                    WHERE selected_expiry IS NULL
                ) AS missing_expiry_rows,
                COUNT(*) FILTER (
                    WHERE atm_pair_available = FALSE
                ) AS unavailable_atm_pair_rows,
                COUNT(*) FILTER (
                    WHERE atm_pair_return_available = FALSE
                ) AS unavailable_return_rows,
                COUNT(*) FILTER (
                    WHERE atm_pair_oi_change_available = FALSE
                ) AS unavailable_oi_change_rows,
                COUNT(*) FILTER (
                    WHERE pcr_available = FALSE
                ) AS unavailable_pcr_rows
                               FROM options_data
                               GROUP BY day_local
                               ORDER BY day_local \
                               """

        write_csv(
            con,
            missing_by_day_query,
            REPORT_DIR / "feature_missingness_by_day.csv",
            )

        # ----------------------------------------------------
        # 12. Final status
        # ----------------------------------------------------

        log("Building final validation summary")

        rolling_problem_rows = 0

        for result in rolling_results:
            if "rolling_sum_present_across_clock_gap" in result:
                rolling_problem_rows += int(
                    result["rolling_sum_present_across_clock_gap"] or 0
                )

        checks = {
            "options_rows_match_expected": (
                    basic["options_rows"] == EXPECTED_OPTIONS_ROWS
            ),
            "no_duplicate_options_timestamps": (
                    basic["options_duplicate_timestamp_groups"] == 0
            ),
            "no_duplicate_clean_index_timestamps": (
                    basic["clean_duplicate_timestamp_groups"] == 0
            ),
            "no_out_of_scope_rows": (
                    int(scope["outside_date_scope"] or 0) == 0
            ),
            "no_out_of_session_rows": (
                    int(scope["outside_regular_session"] or 0) == 0
            ),
            "no_special_date_rows": (
                    int(scope["special_date_rows"] or 0) == 0
            ),
            "no_null_timestamps": (
                    int(scope["null_timestamps"] or 0) == 0
            ),
            "all_options_timestamps_match_clean_index": (
                    int(alignment["options_timestamps_missing_from_clean_index"] or 0) == 0
            ),
            "no_spot_close_mismatches": (
                    int(alignment["spot_close_mismatches"] or 0) == 0
            ),
            "no_rolling_sum_across_clock_gap": (
                    rolling_problem_rows == 0
            ),
        }

        # Include index-feature alignment if available.
        if feature_alignment.get("status") == "COMPLETED":
            checks["all_options_timestamps_match_index_features"] = (
                    int(feature_alignment["missing_index_feature_timestamps"] or 0) == 0
            )
            checks["no_index_feature_day_mismatches"] = (
                    int(feature_alignment["trading_day_mismatches"] or 0) == 0
            )
            checks["no_index_feature_spot_close_mismatches"] = (
                    int(feature_alignment["spot_close_mismatches"] or 0) == 0
            )

        # Flag consistency checks.
        checks["atm_pair_flag_consistent"] = (
                int(flag_results["pair_flag_but_missing_price"] or 0) == 0
                and int(flag_results["pair_flag_but_straddle_missing"] or 0) == 0
        )

        checks["return_flag_consistent"] = (
                int(flag_results["return_flag_but_missing_return"] or 0) == 0
        )

        checks["oi_change_flag_consistent"] = (
                int(flag_results["oi_flag_but_missing_change"] or 0) == 0
        )

        checks["pcr_flag_consistent"] = (
                int(flag_results["pcr_flag_but_missing_pcr"] or 0) == 0
        )

        summary = {
            "generated_at": datetime.now().isoformat(),
            "project_root": str(PROJECT_ROOT),
            "options_file": str(OPTIONS_FILE),
            "clean_index_file": str(CLEAN_INDEX_FILE),
            "index_feature_file": (
                str(INDEX_FEATURE_FILE)
                if INDEX_FEATURE_FILE.exists()
                else None
            ),
            "scope": {
                "start_date": START_DATE,
                "end_date": END_DATE,
                "timezone": TIMEZONE,
                "session_start": SESSION_START,
                "session_end": SESSION_END,
                "special_dates_excluded": SPECIAL_DATES,
            },
            "basic_counts": basic,
            "scope_validation": scope,
            "clean_index_alignment": alignment,
            "quality_flags": flag_results,
            "rolling_window_results": rolling_results,
            "index_feature_alignment": feature_alignment,
            "daily_report_rows": daily_count,
            "rolling_clock_gap_problem_rows": rolling_problem_rows,
            "checks": checks,
            "passed_checks": sum(bool(v) for v in checks.values()),
            "total_checks": len(checks),
            "overall_status": (
                "PASS"
                if all(checks.values())
                else "REVIEW_REQUIRED"
            ),
        }

        summary_path = (
                REPORT_DIR / "options_feature_validation_summary.json"
        )

        with open(summary_path, "w", encoding="utf-8") as f:
            json.dump(summary, f, indent=2, default=str)

        # ----------------------------------------------------
        # 13. Console summary
        # ----------------------------------------------------

        print("\n" + "=" * 78)
        print("NIFTY OPTIONS FEATURE VALIDATION V1")
        print("=" * 78)

        print(f"Options rows: {basic['options_rows']:,}")
        print(f"Unique timestamps: {basic['options_unique_timestamps']:,}")
        print(f"Trading days: {basic['options_trading_days']:,}")

        print(
            "Exact cleaned-index matches: "
            f"{alignment['exact_timestamp_matches']:,}"
        )

        print(
            "Missing from cleaned index: "
            f"{alignment['options_timestamps_missing_from_clean_index']:,}"
        )

        print(
            "Spot-close mismatches: "
            f"{alignment['spot_close_mismatches']:,}"
        )

        print("\nCHECK RESULTS")
        print("-" * 78)

        for name, passed in checks.items():
            print(f"{'PASS' if passed else 'FAIL'} : {name}")

        print("-" * 78)
        print(f"Overall status: {summary['overall_status']}")
        print(f"Reports: {REPORT_DIR}")
        print(f"Summary: {summary_path}")
        print("=" * 78)

        if summary["overall_status"] != "PASS":
            print(
                "\nValidation needs review. Do not proceed to model training "
                "until failed checks are understood."
            )

    finally:
        con.close()


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print("\nVALIDATION FAILED")
        print(str(exc))
        traceback.print_exc()
        sys.exit(1)
