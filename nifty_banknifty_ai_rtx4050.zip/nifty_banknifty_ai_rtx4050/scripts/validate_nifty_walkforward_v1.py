#!/usr/bin/env python3
"""
Validate NIFTY feature/label samples and create chronological split datasets.

Save under <project_root>/scripts/
Run from project root:
    python scripts/validate_nifty_walkforward_v1.py

Reads:
  data/processed/nifty_features_v1/nifty_features_labels_long.parquet

Writes:
  data/processed/nifty_walkforward_v1/
    train_5m.parquet, train_15m.parquet, train_30m.parquet
    validation_5m.parquet, validation_15m.parquet, validation_30m.parquet
    eligible_class_distribution.csv
    exclusion_reason_counts.csv
    split_boundary_audit.csv
    representative_sample.csv
    walkforward_validation_summary.json

This script does not train models and does not modify the source feature Parquet.
"""
from pathlib import Path
import json
import time
import duckdb
import pandas as pd

START = time.time()
SCRIPT_DIR = Path(__file__).resolve().parent
ROOT = SCRIPT_DIR.parent if SCRIPT_DIR.name.lower() == "scripts" else SCRIPT_DIR
INPUT = ROOT / "data" / "processed" / "nifty_features_v1" / "nifty_features_labels_long.parquet"
OUT = ROOT / "data" / "processed" / "nifty_walkforward_v1"
HORIZONS = (5, 15, 30)
SPLITS = ("TRAIN", "VALIDATION")
FEATURES = [
    "ret_1m", "logret_1m", "range_pct", "body_pct",
    "upper_wick_pct", "lower_wick_pct",
    "return_5m", "return_15m", "return_30m", "return_60m",
    "realized_vol_5m", "realized_vol_15m", "realized_vol_30m", "realized_vol_60m",
    "high_low_range_5m", "high_low_range_15m", "high_low_range_30m", "high_low_range_60m",
    "close_vs_ema9_pct", "close_vs_ema21_pct", "close_vs_ema50_pct",
    "rsi_14", "positive_return_count_5m", "negative_return_count_5m"
]

def main():
    if not INPUT.exists():
        raise FileNotFoundError(f"Feature Parquet not found: {INPUT}")
    OUT.mkdir(parents=True, exist_ok=True)
    con = duckdb.connect(database=":memory:")
    con.execute("PRAGMA threads=4")
    p = str(INPUT).replace("\\", "/").replace("'", "''")
    print("[1/7] Reading feature Parquet metadata and validating schema", flush=True)
    schema = con.execute(f"DESCRIBE SELECT * FROM read_parquet('{p}')").df()
    cols = set(schema["column_name"])
    required = set(FEATURES) | {
        "timestamp_ist", "trading_day", "is_synthetic", "training_day_eligible",
        "horizon_minutes", "future_close", "target_vol_scale", "target_z",
        "label", "sample_eligible", "sample_exclusion_reason", "split"
    }
    missing = sorted(required - cols)
    if missing:
        raise RuntimeError(f"Required fields missing from feature Parquet: {missing}")

    con.execute(f"CREATE VIEW f AS SELECT * FROM read_parquet('{p}')")
    print("[2/7] Checking row counts, horizons, date range and duplicate keys", flush=True)
    counts = con.execute("""
        SELECT horizon_minutes, COUNT(*) AS rows,
               COUNT(*) FILTER (WHERE sample_eligible) AS eligible,
               COUNT(*) FILTER (WHERE NOT sample_eligible) AS excluded,
               MIN(CAST(trading_day AS DATE)) AS min_day,
               MAX(CAST(trading_day AS DATE)) AS max_day,
               COUNT(DISTINCT CAST(trading_day AS DATE)) AS trading_dates
        FROM f GROUP BY horizon_minutes ORDER BY horizon_minutes
    """).df()
    if tuple(counts["horizon_minutes"].astype(int)) != HORIZONS:
        raise RuntimeError(f"Unexpected horizons: {counts['horizon_minutes'].tolist()}")
    if not (counts["rows"] == 334335).all():
        raise RuntimeError(
            "Expected 334,335 rows per horizon from the current cleaned period. "
            f"Observed: {counts[['horizon_minutes','rows']].to_dict('records')}"
        )

    dup = con.execute("""
        SELECT COUNT(*) FROM (
          SELECT timestamp_ist, horizon_minutes, COUNT(*) n
          FROM f GROUP BY 1,2 HAVING COUNT(*) > 1
        )
    """).fetchone()[0]
    if dup:
        raise RuntimeError(f"Duplicate timestamp+horizon keys: {dup}")

    print("[3/7] Validating eligibility guards and labels", flush=True)
    guard = con.execute(f"""
        SELECT
          COUNT(*) FILTER (WHERE sample_eligible AND is_synthetic) AS eligible_synthetic_rows,
          COUNT(*) FILTER (WHERE sample_eligible AND NOT training_day_eligible) AS eligible_ineligible_day_rows,
          COUNT(*) FILTER (WHERE sample_eligible AND future_close IS NULL) AS eligible_missing_future_close,
          COUNT(*) FILTER (WHERE sample_eligible AND target_vol_scale IS NULL) AS eligible_missing_vol_scale,
          COUNT(*) FILTER (WHERE sample_eligible AND target_vol_scale <= 0) AS eligible_nonpositive_vol_scale,
          COUNT(*) FILTER (WHERE sample_eligible AND ({' OR '.join(f'{c} IS NULL' for c in FEATURES)})) AS eligible_null_feature_rows,
          COUNT(*) FILTER (WHERE sample_eligible AND label NOT IN ('DOWN','SIDEWAYS','UP')) AS eligible_bad_labels,
          COUNT(*) FILTER (WHERE sample_eligible AND split NOT IN ('TRAIN','VALIDATION')) AS eligible_unassigned_split
        FROM f
    """).df().iloc[0].to_dict()
    bad = {k: int(v) for k, v in guard.items() if int(v or 0) != 0}
    if bad:
        raise RuntimeError(f"Eligibility guard failure(s): {bad}")

    # Ensure the full-day excluded date has no eligible samples.
    mar7 = con.execute("""
        SELECT COUNT(*) FROM f
        WHERE CAST(trading_day AS DATE) = DATE '2022-03-07' AND sample_eligible
    """).fetchone()[0]
    if mar7:
        raise RuntimeError(f"2022-03-07 unexpectedly has {mar7} eligible samples")

    print("[4/7] Building class and exclusion reports", flush=True)
    class_df = con.execute("""
        SELECT split, horizon_minutes, label, COUNT(*) AS samples
        FROM f WHERE sample_eligible
        GROUP BY 1,2,3 ORDER BY 1,2,3
    """).df()
    class_df.to_csv(OUT / "eligible_class_distribution.csv", index=False)

    exclusion_df = con.execute("""
        SELECT split, horizon_minutes, sample_exclusion_reason, COUNT(*) AS samples
        FROM f WHERE NOT sample_eligible
        GROUP BY 1,2,3 ORDER BY 1,2,3
    """).df()
    exclusion_df.to_csv(OUT / "exclusion_reason_counts.csv", index=False)

    print("[5/7] Auditing chronological split boundaries", flush=True)
    boundary_df = con.execute("""
        SELECT split, horizon_minutes,
               MIN(CAST(trading_day AS DATE)) AS first_day,
               MAX(CAST(trading_day AS DATE)) AS last_day,
               COUNT(*) AS all_rows,
               COUNT(*) FILTER (WHERE sample_eligible) AS eligible_rows
        FROM f
        WHERE split IN ('TRAIN','VALIDATION')
        GROUP BY 1,2 ORDER BY 1,2
    """).df()
    boundary_df.to_csv(OUT / "split_boundary_audit.csv", index=False)

    # The generated labels are same-day only; assert no source day crosses split.
    split_day_issues = con.execute("""
        SELECT COUNT(*) FROM f
        WHERE (split = 'TRAIN' AND CAST(trading_day AS DATE) >= DATE '2024-01-01')
           OR (split = 'VALIDATION' AND
               (CAST(trading_day AS DATE) < DATE '2024-01-01'
                OR CAST(trading_day AS DATE) > DATE '2024-12-31'))
    """).fetchone()[0]
    if split_day_issues:
        raise RuntimeError(f"Chronological split assignment issue: {split_day_issues} rows")

    print("[6/7] Exporting separate eligible datasets and representative samples", flush=True)
    for h in HORIZONS:
        for split in SPLITS:
            dest = (OUT / f"{split.lower()}_{h}m.parquet").as_posix()
            dest_sql = dest.replace("'", "''")
            con.execute(f"""
                COPY (
                  SELECT * FROM f
                  WHERE sample_eligible
                    AND horizon_minutes = {h}
                    AND split = '{split}'
                  ORDER BY timestamp_ist
                ) TO '{dest_sql}' (FORMAT PARQUET, COMPRESSION ZSTD)
            """)

    # Stratified preview: up to 100 eligible and 30 excluded examples per
    # horizon/split/reason group, so the sample is not just the first 5,000 rows.
    sample = con.execute("""
        WITH eligible_ranked AS (
          SELECT *, ROW_NUMBER() OVER (
            PARTITION BY horizon_minutes, split, label ORDER BY hash(timestamp_ist)
          ) AS rn
          FROM f WHERE sample_eligible
        ),
        excluded_ranked AS (
          SELECT *, ROW_NUMBER() OVER (
            PARTITION BY horizon_minutes, split, sample_exclusion_reason
            ORDER BY hash(timestamp_ist)
          ) AS rn
          FROM f WHERE NOT sample_eligible
        )
        SELECT * EXCLUDE (rn) FROM eligible_ranked WHERE rn <= 100
        UNION ALL
        SELECT * EXCLUDE (rn) FROM excluded_ranked WHERE rn <= 30
        ORDER BY horizon_minutes, split, sample_eligible DESC, timestamp_ist
    """).df()
    sample.to_csv(OUT / "representative_sample.csv", index=False)

    print("[7/7] Writing final validation summary", flush=True)
    eligible_totals = con.execute("""
        SELECT horizon_minutes,
               COUNT(*) FILTER (WHERE sample_eligible) AS eligible,
               COUNT(*) FILTER (WHERE NOT sample_eligible) AS excluded
        FROM f GROUP BY horizon_minutes ORDER BY horizon_minutes
    """).df()
    summary = {
        "status": "VALIDATED_SPLITS_EXPORTED_REVIEW_REQUIRED",
        "input": str(INPUT),
        "output_directory": str(OUT),
        "row_counts_by_horizon": counts.to_dict("records"),
        "eligible_excluded_by_horizon": eligible_totals.to_dict("records"),
        "duplicate_timestamp_horizon_groups": int(dup),
        "eligibility_guard_failures": bad,
        "march_7_2022_eligible_samples": int(mar7),
        "chronological_split_assignment_issues": int(split_day_issues),
        "split_policy": {
            "TRAIN": "2021-05-24 through 2023-12-31",
            "VALIDATION": "2024-01-01 through 2024-12-31",
            "TEST": "Not generated; 2025 data is not in the current calendar-cleaned input",
            "RECENT_HOLDOUT": "Not generated; 2026 data is not in the current calendar-cleaned input"
        },
        "purge_embargo_policy": (
            "Feature and target windows are constrained to one trading day/session. "
            "Year-boundary split therefore has no cross-split target overlap. "
            "Re-run a timestamp-level purge/embargo if split dates are changed "
            "or if multi-day features/targets are introduced."
        ),
        "notes": [
            "Only sample_eligible rows are exported to train/validation Parquets.",
            "Original feature Parquet is not modified.",
            "No model training is performed by this script.",
            "Inspect exclusion_reason_counts.csv and representative_sample.csv."
        ],
        "elapsed_seconds": round(time.time() - START, 2)
    }
    (OUT / "walkforward_validation_summary.json").write_text(
        json.dumps(summary, indent=2, default=str), encoding="utf-8"
    )
    print(json.dumps(summary, indent=2, default=str), flush=True)
    print(f"\nOUTPUT: {OUT}")

if __name__ == "__main__":
    main()
