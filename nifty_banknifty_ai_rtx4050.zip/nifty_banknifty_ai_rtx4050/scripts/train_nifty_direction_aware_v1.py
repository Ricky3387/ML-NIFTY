
from pathlib import Path
from datetime import datetime
import json
import warnings

import numpy as np
import pandas as pd
import lightgbm as lgb

from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
    log_loss,
    brier_score_loss,
)

warnings.filterwarnings("ignore", category=FutureWarning)

# ============================================================
# CONFIGURATION
# ============================================================

ROOT = Path(__file__).resolve().parent.parent

DATA_DIR = ROOT / "data" / "processed" / "nifty_walkforward_v1"

TRAIN_FILE = DATA_DIR / "train_5m.parquet"
VALIDATION_FILE = DATA_DIR / "validation_5m.parquet"

RUN_ID = datetime.now().strftime("%Y%m%d_%H%M%S")

MODEL_DIR = (
        ROOT / "models" / "nifty_direction_aware_v1" / RUN_ID
)

REPORT_DIR = (
        ROOT / "reports" / "nifty_direction_aware_v1" / RUN_ID
)

LABELS = ["DOWN", "SIDEWAYS", "UP"]

EARLY_STOPPING_YEARS = [2023]

INITIAL_TRAIN_END_YEAR = 2022

# Fixed iterations are selected using 2023 early stopping.
STAGE1_MAX_ESTIMATORS = 1800
STAGE2_MAX_ESTIMATORS = 1800

EARLY_STOPPING_ROUNDS = 100

DECISION_DIRECTIONAL_THRESHOLD = 0.50
DECISION_UP_THRESHOLD = 0.50

# Existing causal baseline features.
BASE_FEATURES = [
    "ret_1m",
    "logret_1m",
    "range_pct",
    "body_pct",
    "upper_wick_pct",
    "lower_wick_pct",
    "return_5m",
    "return_15m",
    "return_30m",
    "return_60m",
    "realized_vol_5m",
    "realized_vol_15m",
    "realized_vol_30m",
    "realized_vol_60m",
    "high_low_range_5m",
    "high_low_range_15m",
    "high_low_range_30m",
    "high_low_range_60m",
    "close_vs_ema9_pct",
    "close_vs_ema21_pct",
    "close_vs_ema50_pct",
    "rsi_14",
    "positive_return_count_5m",
    "negative_return_count_5m",
]

# target_vol_scale is deliberately excluded:
# it is an exact duplicate of realized_vol_60m according to
# the previous feature-quality audit.

RANDOM_STATE = 42


# ============================================================
# HELPERS
# ============================================================

def require_file(path):
    if not path.exists():
        raise FileNotFoundError(f"File not found: {path}")


def normalize_label(series):
    return series.astype(str).str.strip().str.upper()


def get_year(series):
    return pd.to_datetime(
        series.astype(str),
        errors="coerce",
    ).dt.year


def safe_auc(actual, probability):
    actual = np.asarray(actual, dtype=int)
    probability = np.asarray(probability, dtype=float)

    valid = np.isfinite(probability)

    actual = actual[valid]
    probability = probability[valid]

    if len(actual) == 0 or len(np.unique(actual)) < 2:
        return np.nan

    return roc_auc_score(actual, probability)


def safe_log_loss(actual, probabilities):
    try:
        return log_loss(
            actual,
            probabilities,
            labels=[0, 1],
        )
    except Exception:
        return np.nan


def check_columns(df, columns, name):
    missing = [c for c in columns if c not in df.columns]

    if missing:
        raise ValueError(
            f"{name} missing required columns: {missing}"
        )


def add_regime_features(df, vol_q1, vol_q2, expansion_q1, expansion_q2):
    """
    All features are derived from current/past completed bars.

    Boundaries are fitted on 2021-2022 and frozen.
    """

    x = df.copy()

    vol60 = pd.to_numeric(
        x["realized_vol_60m"],
        errors="coerce",
    )

    vol15 = pd.to_numeric(
        x["realized_vol_15m"],
        errors="coerce",
    )

    vol5 = pd.to_numeric(
        x["realized_vol_5m"],
        errors="coerce",
    )

    x["regime_vol_ratio_15_60"] = (
            vol15 / vol60.replace(0, np.nan)
    )

    x["regime_vol_ratio_5_60"] = (
            vol5 / vol60.replace(0, np.nan)
    )

    x["regime_trend_up"] = (
            (x["close_vs_ema21_pct"] > 0)
            & (x["close_vs_ema50_pct"] > 0)
            & (x["return_60m"] > 0)
    ).astype(float)

    x["regime_trend_down"] = (
            (x["close_vs_ema21_pct"] < 0)
            & (x["close_vs_ema50_pct"] < 0)
            & (x["return_60m"] < 0)
    ).astype(float)

    x["regime_trend_range"] = (
            (
                    x["regime_trend_up"] == 0
            )
            & (
                    x["regime_trend_down"] == 0
            )
    ).astype(float)

    x["regime_vol_low"] = (
            vol60 <= vol_q1
    ).astype(float)

    x["regime_vol_medium"] = (
            (vol60 > vol_q1)
            & (vol60 <= vol_q2)
    ).astype(float)

    x["regime_vol_high"] = (
            vol60 > vol_q2
    ).astype(float)

    expansion = x["regime_vol_ratio_15_60"]

    x["regime_vol_contracting"] = (
            expansion <= expansion_q1
    ).astype(float)

    x["regime_vol_expanding"] = (
            expansion >= expansion_q2
    ).astype(float)

    x["regime_vol_stable"] = (
            (expansion > expansion_q1)
            & (expansion < expansion_q2)
    ).astype(float)

    # Continuous trend context.
    x["regime_trend_alignment"] = (
            np.sign(x["close_vs_ema9_pct"])
            + np.sign(x["close_vs_ema21_pct"])
            + np.sign(x["close_vs_ema50_pct"])
    )

    # Continuous volatility context.
    x["regime_volatility_level"] = vol60

    return x


def prepare_feature_matrix(df, feature_columns):
    x = df[feature_columns].copy()

    for column in feature_columns:
        x[column] = pd.to_numeric(
            x[column],
            errors="coerce",
        )

    x = x.replace([np.inf, -np.inf], np.nan)

    return x.astype(np.float32)


def evaluate_binary(actual, probability, predicted):
    actual = np.asarray(actual, dtype=int)
    predicted = np.asarray(predicted, dtype=int)
    probability = np.asarray(probability, dtype=float)

    return {
        "rows": int(len(actual)),
        "accuracy": float(accuracy_score(actual, predicted)),
        "balanced_accuracy": float(
            balanced_accuracy_score(actual, predicted)
        ),
        "precision": float(
            precision_score(
                actual,
                predicted,
                zero_division=0,
            )
        ),
        "recall": float(
            recall_score(
                actual,
                predicted,
                zero_division=0,
            )
        ),
        "f1": float(
            f1_score(
                actual,
                predicted,
                zero_division=0,
            )
        ),
        "roc_auc": float(
            safe_auc(actual, probability)
        ),
        "log_loss": float(
            safe_log_loss(actual, probability)
        ),
        "brier_score": float(
            brier_score_loss(actual, probability)
        ),
        "actual_positive_pct": float(
            100 * actual.mean()
        ),
        "predicted_positive_pct": float(
            100 * predicted.mean()
        ),
    }


def make_classifier(n_estimators):
    return lgb.LGBMClassifier(
        objective="binary",
        n_estimators=n_estimators,
        learning_rate=0.025,
        num_leaves=31,
        max_depth=-1,
        min_child_samples=100,
        subsample=0.80,
        subsample_freq=1,
        colsample_bytree=0.80,
        reg_alpha=0.0,
        reg_lambda=2.0,
        class_weight=None,
        random_state=RANDOM_STATE,
        n_jobs=-1,
        verbosity=-1,
    )


def fit_with_early_stopping(model, x_train, y_train, x_valid, y_valid):
    model.fit(
        x_train,
        y_train,
        eval_set=[(x_valid, y_valid)],
        eval_metric="binary_logloss",
        callbacks=[
            lgb.early_stopping(
                EARLY_STOPPING_ROUNDS,
                verbose=True,
            ),
            lgb.log_evaluation(100),
        ],
    )

    best = getattr(model, "best_iteration_", None)

    if best is None or best <= 0:
        best = model.n_estimators

    return int(best)


def confusion_frame(actual, predicted, labels):
    matrix = confusion_matrix(
        actual,
        predicted,
        labels=labels,
    )

    return pd.DataFrame(
        matrix,
        index=[f"ACTUAL_{x}" for x in labels],
        columns=[f"PREDICTED_{x}" for x in labels],
    )


# ============================================================
# MAIN
# ============================================================

def main():

    print("=" * 75)
    print("NIFTY DIRECTION-AWARE MODEL V1")
    print("=" * 75)

    require_file(TRAIN_FILE)
    require_file(VALIDATION_FILE)

    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    REPORT_DIR.mkdir(parents=True, exist_ok=True)

    # --------------------------------------------------------
    # LOAD DATA
    # --------------------------------------------------------

    print("\nLoading data...")

    train_all = pd.read_parquet(TRAIN_FILE)
    validation = pd.read_parquet(VALIDATION_FILE)

    required = (
            BASE_FEATURES
            + [
                "timestamp_ist",
                "trading_day",
                "label",
                "sample_eligible",
            ]
    )

    check_columns(train_all, required, "TRAIN")
    check_columns(validation, required, "VALIDATION")

    train_all = train_all.loc[
        train_all["sample_eligible"].astype(bool)
    ].copy()

    validation = validation.loc[
        validation["sample_eligible"].astype(bool)
    ].copy()

    train_all["label"] = normalize_label(train_all["label"])
    validation["label"] = normalize_label(validation["label"])

    train_all["year"] = get_year(train_all["trading_day"])
    validation["year"] = get_year(validation["trading_day"])

    if train_all["year"].isna().any():
        raise ValueError("Invalid training trading_day values.")

    if validation["year"].isna().any():
        raise ValueError("Invalid validation trading_day values.")

    if not set(train_all["label"].unique()).issubset(set(LABELS)):
        raise ValueError("Unexpected labels in training data.")

    if not set(validation["label"].unique()).issubset(set(LABELS)):
        raise ValueError("Unexpected labels in validation data.")

    # Initial fit: 2021-2022.
    initial_train = train_all.loc[
        train_all["year"] <= INITIAL_TRAIN_END_YEAR
        ].copy()

    # Early stopping/model selection: 2023.
    early_valid = train_all.loc[
        train_all["year"].isin(EARLY_STOPPING_YEARS)
    ].copy()

    # Final model training: all 2021-2023.
    final_train = train_all.copy()

    # Final diagnostic: 2024.
    diagnostic = validation.copy()

    if initial_train.empty or early_valid.empty or diagnostic.empty:
        raise ValueError(
            "One or more chronological partitions are empty."
        )

    print(f"Initial fit 2021-2022: {len(initial_train):,}")
    print(f"Early stopping 2023:   {len(early_valid):,}")
    print(f"Final fit 2021-2023:   {len(final_train):,}")
    print(f"Diagnostic 2024:       {len(diagnostic):,}")

    # --------------------------------------------------------
    # REGIME BOUNDARIES FROM 2021-2022 ONLY
    # --------------------------------------------------------

    print("\nCalculating frozen regime boundaries...")

    vol60_train = pd.to_numeric(
        initial_train["realized_vol_60m"],
        errors="coerce",
    ).replace([np.inf, -np.inf], np.nan).dropna()

    expansion_train = (
            pd.to_numeric(
                initial_train["realized_vol_15m"],
                errors="coerce",
            )
            / pd.to_numeric(
        initial_train["realized_vol_60m"],
        errors="coerce",
    )
    ).replace([np.inf, -np.inf], np.nan).dropna()

    if vol60_train.empty or expansion_train.empty:
        raise ValueError("Insufficient data for regime boundaries.")

    vol_q1 = float(vol60_train.quantile(1 / 3))
    vol_q2 = float(vol60_train.quantile(2 / 3))

    expansion_q1 = float(expansion_train.quantile(0.40))
    expansion_q2 = float(expansion_train.quantile(0.60))

    regime_parameters = {
        "volatility_low_upper": vol_q1,
        "volatility_medium_upper": vol_q2,
        "expansion_contracting_upper": expansion_q1,
        "expansion_expanding_lower": expansion_q2,
    }

    # Same frozen regime boundaries across all partitions.
    initial_train = add_regime_features(
        initial_train,
        vol_q1,
        vol_q2,
        expansion_q1,
        expansion_q2,
    )

    early_valid = add_regime_features(
        early_valid,
        vol_q1,
        vol_q2,
        expansion_q1,
        expansion_q2,
    )

    final_train = add_regime_features(
        final_train,
        vol_q1,
        vol_q2,
        expansion_q1,
        expansion_q2,
    )

    diagnostic = add_regime_features(
        diagnostic,
        vol_q1,
        vol_q2,
        expansion_q1,
        expansion_q2,
    )

    REGIME_FEATURES = [
        "regime_vol_ratio_15_60",
        "regime_vol_ratio_5_60",
        "regime_trend_up",
        "regime_trend_down",
        "regime_trend_range",
        "regime_vol_low",
        "regime_vol_medium",
        "regime_vol_high",
        "regime_vol_contracting",
        "regime_vol_expanding",
        "regime_vol_stable",
        "regime_trend_alignment",
        "regime_volatility_level",
    ]

    FEATURE_COLUMNS = BASE_FEATURES + REGIME_FEATURES

    print(f"Baseline features: {len(BASE_FEATURES)}")
    print(f"Regime features:   {len(REGIME_FEATURES)}")
    print(f"Total features:    {len(FEATURE_COLUMNS)}")

    # --------------------------------------------------------
    # BUILD MATRICES
    # --------------------------------------------------------

    print("\nPreparing feature matrices...")

    x_initial = prepare_feature_matrix(
        initial_train,
        FEATURE_COLUMNS,
    )

    x_early = prepare_feature_matrix(
        early_valid,
        FEATURE_COLUMNS,
    )

    x_final = prepare_feature_matrix(
        final_train,
        FEATURE_COLUMNS,
    )

    x_diagnostic = prepare_feature_matrix(
        diagnostic,
        FEATURE_COLUMNS,
    )

    # Stage 1 target: directional versus sideways.
    y1_initial = (
            initial_train["label"] != "SIDEWAYS"
    ).astype(int)

    y1_early = (
            early_valid["label"] != "SIDEWAYS"
    ).astype(int)

    y1_final = (
            final_train["label"] != "SIDEWAYS"
    ).astype(int)

    y1_diagnostic = (
            diagnostic["label"] != "SIDEWAYS"
    ).astype(int)

    # Stage 2 target: UP versus DOWN, only for directional rows.
    initial_directional_mask = (
            initial_train["label"] != "SIDEWAYS"
    )

    early_directional_mask = (
            early_valid["label"] != "SIDEWAYS"
    )

    final_directional_mask = (
            final_train["label"] != "SIDEWAYS"
    )

    diagnostic_directional_mask = (
            diagnostic["label"] != "SIDEWAYS"
    )

    x2_initial = x_initial.loc[
        initial_directional_mask
    ]

    x2_early = x_early.loc[
        early_directional_mask
    ]

    x2_final = x_final.loc[
        final_directional_mask
    ]

    x2_diagnostic = x_diagnostic.loc[
        diagnostic_directional_mask
    ]

    y2_initial = (
            initial_train.loc[
                initial_directional_mask, "label"
            ] == "UP"
    ).astype(int)

    y2_early = (
            early_valid.loc[
                early_directional_mask, "label"
            ] == "UP"
    ).astype(int)

    y2_final = (
            final_train.loc[
                final_directional_mask, "label"
            ] == "UP"
    ).astype(int)

    y2_diagnostic = (
            diagnostic.loc[
                diagnostic_directional_mask, "label"
            ] == "UP"
    ).astype(int)

    print("\nSTAGE 1 CLASS DISTRIBUTION")
    print("Initial training:")
    print(y1_initial.value_counts(normalize=True).sort_index())

    print("\nEarly stopping:")
    print(y1_early.value_counts(normalize=True).sort_index())

    print("\nSTAGE 2 CLASS DISTRIBUTION")
    print("Initial directional training:")
    print(y2_initial.value_counts(normalize=True).sort_index())

    print("\nEarly directional validation:")
    print(y2_early.value_counts(normalize=True).sort_index())

    if len(np.unique(y2_initial)) < 2:
        raise ValueError("Stage 2 initial training has only one class.")

    if len(np.unique(y2_early)) < 2:
        raise ValueError("Stage 2 early validation has only one class.")

    # --------------------------------------------------------
    # STAGE 1: DIRECTIONAL VS SIDEWAYS
    # --------------------------------------------------------

    print("\n" + "=" * 75)
    print("STAGE 1: DIRECTIONAL VS SIDEWAYS")
    print("=" * 75)

    stage1_selector = make_classifier(
        STAGE1_MAX_ESTIMATORS
    )

    stage1_best_iteration = fit_with_early_stopping(
        stage1_selector,
        x_initial,
        y1_initial,
        x_early,
        y1_early,
    )

    print(
        f"\nStage 1 selected iteration: "
        f"{stage1_best_iteration}"
    )

    # --------------------------------------------------------
    # STAGE 2: DOWN VS UP
    # --------------------------------------------------------

    print("\n" + "=" * 75)
    print("STAGE 2: DOWN VS UP")
    print("=" * 75)

    stage2_selector = make_classifier(
        STAGE2_MAX_ESTIMATORS
    )

    stage2_best_iteration = fit_with_early_stopping(
        stage2_selector,
        x2_initial,
        y2_initial,
        x2_early,
        y2_early,
    )

    print(
        f"\nStage 2 selected iteration: "
        f"{stage2_best_iteration}"
    )

    # --------------------------------------------------------
    # FINAL REFIT ON 2021-2023
    # --------------------------------------------------------

    print("\n" + "=" * 75)
    print("FINAL MODEL REFIT: 2021-2023")
    print("=" * 75)

    stage1_final = make_classifier(
        stage1_best_iteration
    )

    stage1_final.fit(
        x_final,
        y1_final,
    )

    stage2_final = make_classifier(
        stage2_best_iteration
    )

    stage2_final.fit(
        x2_final,
        y2_final,
    )

    stage1_final.booster_.save_model(
        str(MODEL_DIR / "stage1_directional_vs_sideways.txt")
    )

    stage2_final.booster_.save_model(
        str(MODEL_DIR / "stage2_down_vs_up.txt")
    )

    # --------------------------------------------------------
    # GENERATE 2024 PROBABILITIES
    # --------------------------------------------------------

    print("\nGenerating 2024 predictions...")

    p_directional = stage1_final.predict_proba(
        x_diagnostic
    )[:, 1]

    p_up_conditional = stage2_final.predict_proba(
        x_diagnostic
    )[:, 1]

    # Combined probabilities:
    # P(DOWN) = P(directional) * P(DOWN | directional)
    # P(UP) = P(directional) * P(UP | directional)
    # P(SIDEWAYS) = 1 - P(directional)

    p_down = p_directional * (1 - p_up_conditional)
    p_up = p_directional * p_up_conditional
    p_sideways = 1 - p_directional

    probability_matrix = np.column_stack([
        p_down,
        p_sideways,
        p_up,
    ])

    # Fixed 0.50 thresholds. No threshold tuning.
    predicted = np.full(
        len(diagnostic),
        "SIDEWAYS",
        dtype=object,
    )

    directional_decision = (
            p_directional >= DECISION_DIRECTIONAL_THRESHOLD
    )

    predicted[
        directional_decision
        & (p_up_conditional < DECISION_UP_THRESHOLD)
        ] = "DOWN"

    predicted[
        directional_decision
        & (p_up_conditional >= DECISION_UP_THRESHOLD)
        ] = "UP"

    actual = diagnostic["label"].to_numpy()

    # --------------------------------------------------------
    # OVERALL MULTICLASS METRICS
    # --------------------------------------------------------

    print("\n" + "=" * 75)
    print("2024 MULTICLASS DIAGNOSTIC")
    print("=" * 75)

    multiclass_metrics = {
        "rows": int(len(actual)),
        "accuracy": float(
            accuracy_score(actual, predicted)
        ),
        "balanced_accuracy": float(
            balanced_accuracy_score(actual, predicted)
        ),
        "macro_f1": float(
            f1_score(
                actual,
                predicted,
                labels=LABELS,
                average="macro",
                zero_division=0,
            )
        ),
        "weighted_f1": float(
            f1_score(
                actual,
                predicted,
                labels=LABELS,
                average="weighted",
                zero_division=0,
            )
        ),
        "multiclass_log_loss": float(
            log_loss(
                actual,
                probability_matrix,
                labels=LABELS,
            )
        ),
        "actual_directional_pct": float(
            100 * (actual != "SIDEWAYS").mean()
        ),
        "predicted_directional_pct": float(
            100 * (predicted != "SIDEWAYS").mean()
        ),
    }

    print(json.dumps(multiclass_metrics, indent=2))

    report = classification_report(
        actual,
        predicted,
        labels=LABELS,
        zero_division=0,
        output_dict=True,
    )

    print("\nClassification report:")
    print(
        classification_report(
            actual,
            predicted,
            labels=LABELS,
            zero_division=0,
        )
    )

    confusion = confusion_frame(
        actual,
        predicted,
        LABELS,
    )

    confusion.to_csv(
        REPORT_DIR / "2024_confusion_matrix.csv"
    )

    # --------------------------------------------------------
    # STAGE 1 METRICS
    # --------------------------------------------------------

    stage1_predicted = (
            p_directional >= DECISION_DIRECTIONAL_THRESHOLD
    ).astype(int)

    stage1_metrics = evaluate_binary(
        y1_diagnostic,
        p_directional,
        stage1_predicted,
    )

    # --------------------------------------------------------
    # STAGE 2 METRICS
    # --------------------------------------------------------

    stage2_metrics = evaluate_binary(
        y2_diagnostic,
        p_up[diagnostic_directional_mask],
        (
                p_up_conditional[diagnostic_directional_mask]
                >= DECISION_UP_THRESHOLD
        ).astype(int),
    )

    # Stage 2 conditional metrics use only actual directional rows.
    # This is not the same as overall UP-vs-DOWN classification.

    print("\n" + "=" * 75)
    print("STAGE 1 METRICS")
    print("=" * 75)
    print(json.dumps(stage1_metrics, indent=2))

    print("\n" + "=" * 75)
    print("STAGE 2 CONDITIONAL METRICS")
    print("=" * 75)
    print(json.dumps(stage2_metrics, indent=2))

    # --------------------------------------------------------
    # SAVE PREDICTIONS
    # --------------------------------------------------------

    output = diagnostic[
        [
            "timestamp_ist",
            "trading_day",
            "label",
            "regime_vol_ratio_15_60",
            "regime_vol_ratio_5_60",
            "regime_trend_up",
            "regime_trend_down",
            "regime_trend_range",
            "regime_vol_low",
            "regime_vol_medium",
            "regime_vol_high",
            "regime_vol_contracting",
            "regime_vol_expanding",
            "regime_vol_stable",
        ]
    ].copy()

    output.rename(
        columns={"label": "actual_label"},
        inplace=True,
    )

    output["p_directional"] = p_directional
    output["p_up_conditional"] = p_up_conditional
    output["p_down"] = p_down
    output["p_sideways"] = p_sideways
    output["p_up"] = p_up
    output["predicted_label"] = predicted

    output.to_parquet(
        REPORT_DIR / "2024_direction_aware_predictions.parquet",
        index=False,
        )

    output.drop(
        columns=["timestamp_ist"],
    ).head(1000).to_csv(
        REPORT_DIR / "2024_prediction_sample.csv",
        index=False,
        )

    # --------------------------------------------------------
    # MONTHLY METRICS
    # --------------------------------------------------------

    print("\nCalculating monthly metrics...")

    output["month"] = pd.to_datetime(
        output["timestamp_ist"],
        utc=True,
    ).dt.strftime("%Y-%m")

    monthly_rows = []

    for month, group in output.groupby("month"):
        month_actual = group["actual_label"]
        month_predicted = group["predicted_label"]

        directional_actual = month_actual.isin(
            ["DOWN", "UP"]
        )

        directional_predicted = month_predicted.isin(
            ["DOWN", "UP"]
        )

        monthly_rows.append({
            "month": month,
            "rows": len(group),
            "accuracy": accuracy_score(
                month_actual,
                month_predicted,
            ),
            "balanced_accuracy": balanced_accuracy_score(
                month_actual,
                month_predicted,
            ),
            "macro_f1": f1_score(
                month_actual,
                month_predicted,
                labels=LABELS,
                average="macro",
                zero_division=0,
            ),
            "directional_precision": precision_score(
                directional_actual,
                directional_predicted,
                zero_division=0,
            ),
            "directional_recall": recall_score(
                directional_actual,
                directional_predicted,
                zero_division=0,
            ),
            "predicted_directional_pct": (
                    100 * directional_predicted.mean()
            ),
            "down_precision": precision_score(
                month_actual.eq("DOWN"),
                month_predicted.eq("DOWN"),
                zero_division=0,
            ),
            "down_recall": recall_score(
                month_actual.eq("DOWN"),
                month_predicted.eq("DOWN"),
                zero_division=0,
            ),
            "up_precision": precision_score(
                month_actual.eq("UP"),
                month_predicted.eq("UP"),
                zero_division=0,
            ),
            "up_recall": recall_score(
                month_actual.eq("UP"),
                month_predicted.eq("UP"),
                zero_division=0,
            ),
        })

    monthly = pd.DataFrame(monthly_rows)

    monthly.to_csv(
        REPORT_DIR / "2024_monthly_metrics.csv",
        index=False,
        )

    # --------------------------------------------------------
    # REGIME METRICS
    # --------------------------------------------------------

    regime_columns = [
        "regime_vol_low",
        "regime_vol_medium",
        "regime_vol_high",
        "regime_trend_up",
        "regime_trend_down",
        "regime_trend_range",
        "regime_vol_contracting",
        "regime_vol_expanding",
        "regime_vol_stable",
    ]

    regime_rows = []

    for column in regime_columns:
        group_mask = output[column] == 1

        group = output.loc[group_mask]

        if len(group) == 0:
            continue

        group_actual = group["actual_label"]
        group_predicted = group["predicted_label"]

        directional_actual = group_actual.isin(
            ["DOWN", "UP"]
        )

        directional_predicted = group_predicted.isin(
            ["DOWN", "UP"]
        )

        regime_rows.append({
            "regime_feature": column,
            "rows": len(group),
            "sample_pct": 100 * len(group) / len(output),
            "macro_f1": f1_score(
                group_actual,
                group_predicted,
                labels=LABELS,
                average="macro",
                zero_division=0,
            ),
            "balanced_accuracy": balanced_accuracy_score(
                group_actual,
                group_predicted,
            ),
            "directional_precision": precision_score(
                directional_actual,
                directional_predicted,
                zero_division=0,
            ),
            "directional_recall": recall_score(
                directional_actual,
                directional_predicted,
                zero_division=0,
            ),
            "predicted_directional_pct": (
                    100 * directional_predicted.mean()
            ),
            "down_precision": precision_score(
                group_actual.eq("DOWN"),
                group_predicted.eq("DOWN"),
                zero_division=0,
            ),
            "down_recall": recall_score(
                group_actual.eq("DOWN"),
                group_predicted.eq("DOWN"),
                zero_division=0,
            ),
            "up_precision": precision_score(
                group_actual.eq("UP"),
                group_predicted.eq("UP"),
                zero_division=0,
            ),
            "up_recall": recall_score(
                group_actual.eq("UP"),
                group_predicted.eq("UP"),
                zero_division=0,
            ),
        })

    regime_report = pd.DataFrame(regime_rows)

    regime_report.to_csv(
        REPORT_DIR / "2024_regime_metrics.csv",
        index=False,
        )

    # --------------------------------------------------------
    # FEATURE IMPORTANCE
    # --------------------------------------------------------

    stage1_importance = pd.DataFrame({
        "feature": FEATURE_COLUMNS,
        "stage1_gain": (
            stage1_final.booster_.feature_importance(
                importance_type="gain"
            )
        ),
        "stage1_split": (
            stage1_final.booster_.feature_importance(
                importance_type="split"
            )
        ),
    })

    stage2_importance = pd.DataFrame({
        "feature": FEATURE_COLUMNS,
        "stage2_gain": (
            stage2_final.booster_.feature_importance(
                importance_type="gain"
            )
        ),
        "stage2_split": (
            stage2_final.booster_.feature_importance(
                importance_type="split"
            )
        ),
    })

    importance = stage1_importance.merge(
        stage2_importance,
        on="feature",
        how="inner",
        validate="one_to_one",
    )

    importance = importance.sort_values(
        "stage1_gain",
        ascending=False,
    )

    importance.to_csv(
        REPORT_DIR / "feature_importance.csv",
        index=False,
        )

    # --------------------------------------------------------
    # SAVE METRICS AND MANIFEST
    # --------------------------------------------------------

    summary = {
        "run_id": RUN_ID,
        "model": "NIFTY Direction-Aware Two-Stage LightGBM",
        "scope": "NIFTY 5-minute",
        "training_period": "2021-2023",
        "initial_fit_period": "2021-2022",
        "early_stopping_period": "2023",
        "diagnostic_period": "2024",
        "initial_train_rows": int(len(initial_train)),
        "early_stopping_rows": int(len(early_valid)),
        "final_train_rows": int(len(final_train)),
        "diagnostic_rows": int(len(diagnostic)),
        "directional_train_rows": int(
            initial_directional_mask.sum()
        ),
        "directional_final_train_rows": int(
            final_directional_mask.sum()
        ),
        "stage1_best_iteration": stage1_best_iteration,
        "stage2_best_iteration": stage2_best_iteration,
        "decision_thresholds": {
            "directional": DECISION_DIRECTIONAL_THRESHOLD,
            "conditional_up": DECISION_UP_THRESHOLD,
        },
        "feature_count": len(FEATURE_COLUMNS),
        "baseline_feature_count": len(BASE_FEATURES),
        "regime_feature_count": len(REGIME_FEATURES),
        "regime_parameters": regime_parameters,
        "stage1_metrics_2024": stage1_metrics,
        "stage2_metrics_2024_conditional": stage2_metrics,
        "multiclass_metrics_2024": multiclass_metrics,
        "notes": [
            "Stage 1 predicts directional versus sideways.",
            "Stage 2 predicts UP versus DOWN on directional samples.",
            "Stage 2 training uses only actual directional rows.",
            "Stage 2 conditional evaluation uses only actual directional rows.",
            "Regime boundaries are fitted on 2021-2022 only.",
            "Decision thresholds are fixed at 0.50.",
            "No regime-specific threshold optimization was performed.",
            "2024 has previously been used for diagnostics and is not an untouched test.",
            "No transaction costs or trading profitability are evaluated.",
            "This is a research model, not a trading recommendation.",
        ],
    }

    with open(
            REPORT_DIR / "model_summary.json",
            "w",
            encoding="utf-8",
    ) as f:
        json.dump(summary, f, indent=2, default=str)

    with open(
            REPORT_DIR / "feature_list.json",
            "w",
            encoding="utf-8",
    ) as f:
        json.dump(
            {
                "baseline_features": BASE_FEATURES,
                "regime_features": REGIME_FEATURES,
                "all_features": FEATURE_COLUMNS,
            },
            f,
            indent=2,
        )

    print("\n" + "=" * 75)
    print("TRAINING COMPLETED")
    print("=" * 75)

    print(f"Run ID: {RUN_ID}")
    print(f"Models:  {MODEL_DIR}")
    print(f"Reports: {REPORT_DIR}")

    print("\nSelected iterations:")
    print("Stage 1:", stage1_best_iteration)
    print("Stage 2:", stage2_best_iteration)

    print("\n2024 multiclass metrics:")
    print(json.dumps(multiclass_metrics, indent=2))

    print("\nGenerated reports:")
    for path in sorted(REPORT_DIR.iterdir()):
        print(" ", path.name)

    print("\nNo source data or previous models were overwritten.")


if __name__ == "__main__":
    main()
