
from __future__ import annotations

import json
import sys
import traceback
from datetime import datetime
from pathlib import Path

import duckdb


ROOT = Path(__file__).resolve().parents[1]

INPUT_FILE = (
        ROOT / "data/processed/nifty_options_features_v1/"
               "nifty_options_features_v1.parquet"
)

OUTPUT_DIR = ROOT / "data/processed/nifty_options_features_v4"
OUTPUT_FILE = OUTPUT_DIR / "nifty_options_features_v4.parquet"

REPORT_DIR = ROOT / "reports/nifty_options_features_v4"

TIME_COL = "timestamp_ist"
DAY_COL = "trading_date"

WINDOWS = {
    5: 4,
    15: 14,
    30: 29,
}


def sql_string(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"


def main():
    if not INPUT_FILE.exists():
        raise FileNotFoundError(INPUT_FILE)

    if OUTPUT_FILE.exists():
        raise FileExistsError(
            f"Refusing to overwrite existing output: {OUTPUT_FILE}"
        )

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    REPORT_DIR.mkdir(parents=True, exist_ok=True)

    con = duckdb.connect(":memory:")
    con.execute("SET TimeZone='Asia/Kolkata'")
    con.execute("SET threads TO 4")

    try:
        input_path = INPUT_FILE.resolve().as_posix()
        output_path = OUTPUT_FILE.resolve().as_posix()

        input_sql = sql_string(input_path)
        output_sql = sql_string(output_path)

        print("Inspecting original v1 schema...")

        schema = con.execute(
            f"DESCRIBE SELECT * FROM read_parquet({input_sql})"
        ).fetchall()

        columns = [row[0] for row in schema]

        required = [TIME_COL, DAY_COL]

        for window in WINDOWS:
            required.extend([
                f"atm_ce_volume_sum_{window}m",
                f"atm_pe_volume_sum_{window}m",
                f"atm_volume_imbalance_{window}m",
            ])

        missing = [c for c in required if c not in columns]

        if missing:
            raise ValueError(f"Missing required columns: {missing}")

        rolling_columns = []

        for window in WINDOWS:
            rolling_columns.extend([
                f"atm_ce_volume_sum_{window}m",
                f"atm_pe_volume_sum_{window}m",
                f"atm_volume_imbalance_{window}m",
            ])

        input_rows = con.execute(
            f"SELECT COUNT(*) FROM read_parquet({input_sql})"
        ).fetchone()[0]

        duplicate_groups = con.execute(f"""
            SELECT COUNT(*)
            FROM (
                SELECT "{TIME_COL}"
                FROM read_parquet({input_sql})
                GROUP BY "{TIME_COL}"
                HAVING COUNT(*) > 1
            )
        """).fetchone()[0]

        if duplicate_groups:
            raise ValueError(
                f"Duplicate timestamps found: {duplicate_groups}"
            )

        print(f"Input rows: {input_rows:,}")
        print("Calculating timestamp continuity...")

        lag_expressions = []

        for window, offset in WINDOWS.items():
            lag_expressions.append(f"""
                LAG("{TIME_COL}", {offset}) OVER (
                    PARTITION BY "{DAY_COL}"
                    ORDER BY "{TIME_COL}"
                ) AS prior_timestamp_{window}m
            """)

        con.execute(f"""
            CREATE TEMP TABLE lagged_data AS
            SELECT
                *,
                {",".join(lag_expressions)}
            FROM read_parquet({input_sql})
        """)

        # Only replace the nine rolling output columns.
        # Original v1 formula and values are retained for
        # every clock-contiguous observation.

        excluded = (
                [f'"{c}"' for c in rolling_columns]
                + [
                    f'"prior_timestamp_{window}m"'
                    for window in WINDOWS
                ]
        )

        replacement_expressions = []

        for window, offset in WINDOWS.items():

            continuity = f"""
                prior_timestamp_{window}m IS NOT NULL
                AND DATE_DIFF(
                    'minute',
                    prior_timestamp_{window}m,
                    "{TIME_COL}"
                ) = {offset}
            """

            for col in [
                f"atm_ce_volume_sum_{window}m",
                f"atm_pe_volume_sum_{window}m",
                f"atm_volume_imbalance_{window}m",
            ]:
                replacement_expressions.append(f"""
                    CASE
                        WHEN ({continuity})
                        THEN "{col}"
                        ELSE NULL
                    END AS "{col}"
                """)

        print("Writing v4 with original imbalance semantics...")

        con.execute(f"""
            COPY (
                SELECT
                    * EXCLUDE ({",".join(excluded)}),
                    {",".join(replacement_expressions)}
                FROM lagged_data
            )
            TO {output_sql}
            (FORMAT PARQUET, COMPRESSION ZSTD)
        """)

        output_rows = con.execute(
            f"SELECT COUNT(*) FROM read_parquet({output_sql})"
        ).fetchone()[0]

        con.execute(f"""
            CREATE VIEW v4 AS
            SELECT * FROM read_parquet({output_sql})
        """)

        # ------------------------------------------------
        # Verify v4 rolling continuity
        # ------------------------------------------------

        print("Auditing v4 rolling windows...")

        audit_results = []

        for window, offset in WINDOWS.items():

            query = f"""
                WITH checked AS (
                    SELECT
                        *,
                        LAG("{TIME_COL}", {offset}) OVER (
                            PARTITION BY "{DAY_COL}"
                            ORDER BY "{TIME_COL}"
                        ) AS prior_ts
                    FROM v4
                )
                SELECT
                    {window} AS window_minutes,
                    COUNT(*) AS total_rows,

                    COUNT(*) FILTER (
                        WHERE atm_ce_volume_sum_{window}m IS NOT NULL
                          AND atm_pe_volume_sum_{window}m IS NOT NULL
                    ) AS nonnull_volume_sum_rows,

                    COUNT(*) FILTER (
                        WHERE atm_volume_imbalance_{window}m IS NOT NULL
                    ) AS nonnull_imbalance_rows,

                    COUNT(*) FILTER (
                        WHERE (
                            atm_ce_volume_sum_{window}m IS NOT NULL
                            OR atm_pe_volume_sum_{window}m IS NOT NULL
                            OR atm_volume_imbalance_{window}m IS NOT NULL
                        )
                        AND (
                            prior_ts IS NULL
                            OR DATE_DIFF(
                                'minute',
                                prior_ts,
                                "{TIME_COL}"
                            ) <> {offset}
                        )
                    ) AS any_feature_across_clock_gap

                FROM checked
            """

            result = con.execute(query).fetchone()

            audit_results.append({
                "window_minutes": result[0],
                "total_rows": result[1],
                "nonnull_volume_sum_rows": result[2],
                "nonnull_imbalance_rows": result[3],
                "any_feature_across_clock_gap": result[4],
            })

        # ------------------------------------------------
        # Exact preservation comparison
        # ------------------------------------------------

        print("Comparing non-rolling values with v1...")

        nonrolling_columns = [
            c for c in columns if c not in rolling_columns
        ]

        select_columns = ", ".join(
            f'"{c}"' for c in nonrolling_columns
        )

        preservation = con.execute(f"""
            WITH source_only AS (
                SELECT {select_columns}
                FROM read_parquet({input_sql})
                EXCEPT ALL
                SELECT {select_columns}
                FROM v4
            ),
            output_only AS (
                SELECT {select_columns}
                FROM v4
                EXCEPT ALL
                SELECT {select_columns}
                FROM read_parquet({input_sql})
            )
            SELECT
                (SELECT COUNT(*) FROM source_only),
                (SELECT COUNT(*) FROM output_only)
        """).fetchone()

        # Compare all rolling features.
        rolling_changes = []

        for col in rolling_columns:
            result = con.execute(f"""
                SELECT
                    COUNT(*) FILTER (
                        WHERE a."{col}" IS DISTINCT FROM b."{col}"
                    ) AS changed_rows,

                    COUNT(*) FILTER (
                        WHERE a."{col}" IS NOT NULL
                          AND b."{col}" IS NULL
                    ) AS became_null,

                    COUNT(*) FILTER (
                        WHERE a."{col}" IS NULL
                          AND b."{col}" IS NOT NULL
                    ) AS became_nonnull,

                    COUNT(*) FILTER (
                        WHERE a."{col}" IS NOT NULL
                          AND b."{col}" IS NOT NULL
                          AND a."{col}" <> b."{col}"
                    ) AS changed_nonnull_values

                FROM read_parquet({input_sql}) a
                INNER JOIN v4 b
                    ON a."{TIME_COL}" = b."{TIME_COL}"
            """).fetchone()

            rolling_changes.append({
                "column": col,
                "changed_rows": result[0],
                "became_null": result[1],
                "became_nonnull": result[2],
                "changed_nonnull_values": result[3],
            })

        # ------------------------------------------------
        # Final checks
        # ------------------------------------------------

        no_clock_gap_values = all(
            r["any_feature_across_clock_gap"] == 0
            for r in audit_results
        )

        only_null_changes = all(
            r["became_nonnull"] == 0
            and r["changed_nonnull_values"] == 0
            for r in rolling_changes
        )

        checks = {
            "row_count_preserved": input_rows == output_rows,
            "no_duplicate_timestamps": duplicate_groups == 0,
            "nonrolling_features_exactly_preserved": (
                    preservation[0] == 0 and preservation[1] == 0
            ),
            "no_rolling_features_across_clock_gaps": no_clock_gap_values,
            "rolling_changes_only_to_null": only_null_changes,
        }

        summary = {
            "generated_at": datetime.now().isoformat(),
            "input_file": str(INPUT_FILE),
            "output_file": str(OUTPUT_FILE),
            "input_rows": input_rows,
            "output_rows": output_rows,
            "nonrolling_columns_compared": len(nonrolling_columns),
            "rolling_columns_compared": len(rolling_columns),
            "nonrolling_rows_only_in_v1": preservation[0],
            "nonrolling_rows_only_in_v4": preservation[1],
            "rolling_window_audit": audit_results,
            "rolling_feature_changes": rolling_changes,
            "checks": checks,
            "passed_checks": sum(bool(v) for v in checks.values()),
            "total_checks": len(checks),
            "overall_status": (
                "PASS" if all(checks.values()) else "REVIEW_REQUIRED"
            ),
            "imbalance_policy": (
                "Preserve original v1 imbalance values for valid "
                "clock-contiguous windows; set NULL only for windows "
                "that cross clock gaps. No formula recalculation."
            ),
            "source_modified": False,
            "labels_modified": False,
        }

        summary_path = (
                REPORT_DIR / "options_feature_v4_summary.json"
        )

        with open(summary_path, "w", encoding="utf-8") as f:
            json.dump(summary, f, indent=2, default=str)

        import pandas as pd

        pd.DataFrame(audit_results).to_csv(
            REPORT_DIR / "rolling_window_validation_v4.csv",
            index=False,
            )

        pd.DataFrame(rolling_changes).to_csv(
            REPORT_DIR / "rolling_feature_change_audit_v4.csv",
            index=False,
            )

        print("\n" + "=" * 76)
        print("NIFTY OPTIONS FEATURE V4")
        print("=" * 76)

        print(f"Input rows : {input_rows:,}")
        print(f"Output rows: {output_rows:,}")
        print(f"Non-rolling columns compared: {len(nonrolling_columns)}")

        print("\nRolling window audit:")
        for item in audit_results:
            print(item)

        print("\nRolling feature changes:")
        for item in rolling_changes:
            print(item)

        print("\nChecks:")
        for name, passed in checks.items():
            print(f"{'PASS' if passed else 'FAIL'} : {name}")

        print(f"\nOverall status: {summary['overall_status']}")
        print(f"Output: {OUTPUT_FILE}")
        print(f"Summary: {summary_path}")
        print("=" * 76)

    finally:
        con.close()


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print("\nOPTIONS FEATURE V4 FAILED")
        print(str(exc))
        traceback.print_exc()
        sys.exit(1)
