"""
NIFTY index timestamp-semantics and price-anomaly audit.

Run from the project root:
    python audit_nifty_timestamp_and_price_anomalies.py

Database:
    data/database/nifty_options.duckdb

View:
    nifty_index

Timezone assumption:
    The database timestamp column is treated as naive UTC and converted to
    Asia/Kolkata, matching the previous raw-export audit. This is configurable.

This script is diagnostic only:
- It does not modify DuckDB, source CSVs, or Parquet files.
- It does not delete, fill, or repair bars.
- Statistical flags are candidates for manual review, not proof of bad data.
- Timestamp labels alone cannot prove minute-start versus minute-end semantics.
"""

from pathlib import Path
import json
import sys

import duckdb
import numpy as np
import pandas as pd


# ---------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------

DB_PATH = Path("data/database/nifty_options.duckdb")
VIEW_NAME = "nifty_index"

OUTPUT_DIR = Path("data/reports/nifty_index_price_timestamp_audit")

START_DATE = "2021-05-24"
END_DATE = "2024-12-31"
TIMEZONE = "Asia/Kolkata"

# Existing project convention: minute-start labels 09:15 through 15:29.
NORMAL_START = "09:15"
NORMAL_MINUTES = 375

# Special sessions. January 20 was full-day; March 2 and May 18 were split.
SPECIAL_WINDOWS = {
    "2024-01-20": [("09:15", 375)],
    "2024-03-02": [("09:15", 45), ("11:30", 60)],
    "2024-05-18": [("09:15", 45), ("11:30", 60)],
}

# Muhurat dates are listed for separate classification. Exact session windows
# are intentionally not assumed here.
MUHURAT_DATES = {
    "2021-11-04",
    "2022-10-24",
    "2023-11-12",
    "2024-11-01",
}

# Conservative diagnostic thresholds. Flags are not automatic exclusions.
ABS_ONE_MINUTE_RETURN_FLAG_PCT = 0.50
INTRABAR_RANGE_FLAG_PCT = 0.75
REPEATED_IDENTICAL_OHLC_MIN_BARS = 5

# Previously identified dates to retain in focused outputs.
FOCUS_DATES = [
    "2021-06-28",
    "2022-03-07",
    "2023-03-28",
    "2024-01-20",
    "2024-03-02",
    "2024-05-18",
]


# ---------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------

def convert_naive_utc_to_ist(values: pd.Series) -> pd.Series:
    """Interpret naive timestamps as UTC and convert them to IST."""
    parsed = pd.to_datetime(values, errors="coerce")
    if parsed.dt.tz is None:
        parsed = parsed.dt.tz_localize("UTC")
    else:
        parsed = parsed.dt.tz_convert("UTC")
    return parsed.dt.tz_convert(TIMEZONE).dt.tz_localize(None)


def expected_timestamps(trading_date: str, windows: list) -> pd.DatetimeIndex:
    parts = []
    for start_time, minutes in windows:
        start = pd.Timestamp(f"{trading_date} {start_time}")
        parts.append(pd.date_range(start, periods=int(minutes), freq="min"))
    if not parts:
        return pd.DatetimeIndex([])
    out = parts[0]
    for part in parts[1:]:
        out = out.append(part)
    return out


def get_session_windows(date_string: str):
    if date_string in SPECIAL_WINDOWS:
        return SPECIAL_WINDOWS[date_string], "SPECIAL"
    if date_string in MUHURAT_DATES:
        return [], "MUHURAT_REVIEW_REQUIRED"
    return [(NORMAL_START, NORMAL_MINUTES)], "NORMAL_ASSUMPTION"


def robust_threshold(series: pd.Series, multiplier: float = 12.0):
    """Median + multiplier * scaled MAD; returns NaN if not estimable."""
    x = pd.to_numeric(series, errors="coerce").dropna()
    if len(x) < 20:
        return np.nan
    median = float(x.median())
    mad = float((x - median).abs().median())
    if mad == 0:
        return np.nan
    return median + multiplier * 1.4826 * mad


def consecutive_identical_runs(day: pd.DataFrame):
    """Find runs of consecutive-minute bars with identical OHLC."""
    if day.empty:
        return []

    x = day.sort_values("timestamp_ist").copy()
    ohlc_cols = ["open", "high", "low", "close"]
    same_ohlc = x[ohlc_cols].eq(x[ohlc_cols].shift()).all(axis=1)
    one_minute_step = x["timestamp_ist"].diff().eq(pd.Timedelta(minutes=1))
    continuation = same_ohlc & one_minute_step

    runs = []
    start_idx = None
    previous_idx = None

    for idx, is_cont in zip(x.index, continuation):
        if is_cont:
            if start_idx is None:
                start_idx = previous_idx
            previous_idx = idx
        else:
            if start_idx is not None:
                run = x.loc[start_idx:previous_idx]
                if len(run) >= REPEATED_IDENTICAL_OHLC_MIN_BARS:
                    runs.append(run)
                start_idx = None
            previous_idx = idx

    if start_idx is not None:
        run = x.loc[start_idx:previous_idx]
        if len(run) >= REPEATED_IDENTICAL_OHLC_MIN_BARS:
            runs.append(run)

    return runs


# ---------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------

def main() -> int:
    if not DB_PATH.exists():
        print(f"ERROR: Database not found: {DB_PATH.resolve()}")
        print("Run from the project root or update DB_PATH.")
        return 1

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    print("Reading NIFTY index view in read-only mode...")
    con = duckdb.connect(str(DB_PATH), read_only=True)
    try:
        df = con.execute(
            f"""
            SELECT *
            FROM {VIEW_NAME}
            WHERE CAST(timestamp AS DATE)
                  BETWEEN DATE '{START_DATE}' AND DATE '{END_DATE}'
            ORDER BY timestamp
            """
        ).df()
    except Exception as exc:
        print(f"ERROR reading {VIEW_NAME}: {exc}")
        return 1
    finally:
        con.close()

    if df.empty:
        print("ERROR: No rows returned.")
        return 1

    required = {"timestamp", "open", "high", "low", "close"}
    missing_cols = required - set(df.columns)
    if missing_cols:
        print("ERROR: Missing required columns:", sorted(missing_cols))
        print("Available columns:", list(df.columns))
        return 1

    # Preserve database timestamp and create an IST audit timestamp.
    df["timestamp_ist"] = convert_naive_utc_to_ist(df["timestamp"])
    df = df.dropna(subset=["timestamp_ist"]).copy()
    df["trading_date_ist"] = df["timestamp_ist"].dt.strftime("%Y-%m-%d")
    df = df.sort_values("timestamp_ist").reset_index(drop=True)

    numeric_cols = ["open", "high", "low", "close"]
    if "volume" in df.columns:
        numeric_cols.append("volume")
    for col in numeric_cols:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    # Basic OHLC integrity checks.
    df["null_ohlc"] = df[["open", "high", "low", "close"]].isna().any(axis=1)
    df["nonpositive_ohlc"] = (
        (df[["open", "high", "low", "close"]] <= 0).any(axis=1)
    )
    df["high_below_low"] = df["high"] < df["low"]
    df["high_below_open_close"] = (
        (df["high"] < df["open"]) | (df["high"] < df["close"])
    )
    df["low_above_open_close"] = (
        (df["low"] > df["open"]) | (df["low"] > df["close"])
    )

    # Timestamp resolution/alignment checks.
    df["timestamp_seconds"] = df["timestamp_ist"].dt.second
    df["timestamp_microseconds"] = df["timestamp_ist"].dt.microsecond
    df["not_minute_aligned"] = (
        (df["timestamp_seconds"] != 0) |
        (df["timestamp_microseconds"] != 0)
    )

    # Session classification under the current minute-start assumption.
    session_records = []
    for trading_date, day in df.groupby("trading_date_ist", sort=True):
        windows, session_kind = get_session_windows(trading_date)
        expected = expected_timestamps(trading_date, windows) if windows else pd.DatetimeIndex([])
        expected_set = set(expected)
        observed = set(day["timestamp_ist"])
        missing = sorted(expected_set - observed)
        extra = sorted(observed - expected_set) if windows else []

        for ts in sorted(observed):
            if session_kind == "MUHURAT_REVIEW_REQUIRED":
                classification = "MUHURAT_WINDOW_NOT_CONFIGURED"
            elif ts in expected_set:
                classification = "EXPECTED_SESSION_MINUTE"
            else:
                minute_of_day = ts.hour * 60 + ts.minute
                if minute_of_day < 9 * 60 + 15:
                    classification = "BEFORE_REGULAR_SESSION"
                elif minute_of_day > 15 * 60 + 29:
                    classification = "AFTER_REGULAR_SESSION"
                else:
                    classification = "BETWEEN_OR_OUTSIDE_CONFIGURED_WINDOWS"

            session_records.append({
                "trading_date": trading_date,
                "timestamp_ist": ts,
                "session_kind": session_kind,
                "session_classification": classification,
            })

    session_df = pd.DataFrame(session_records)
    df = df.merge(
        session_df[["timestamp_ist", "session_kind", "session_classification"]],
        on="timestamp_ist",
        how="left",
    )

    # Duplicate timestamp diagnostic.
    df["duplicate_timestamp"] = df.duplicated(
        subset=["timestamp_ist"], keep=False
    )

    # Price diagnostics: bar range, close-to-close return, and previous-close gap.
    df["bar_range_pct"] = (
        (df["high"] - df["low"]) / df["close"].shift(1).abs()
    ) * 100.0

    df["previous_close"] = df["close"].shift(1)
    df["timestamp_gap_minutes"] = (
        df["timestamp_ist"].diff().dt.total_seconds() / 60.0
    )

    # Only compute adjacent one-minute returns when timestamps are exactly
    # one minute apart and both bars belong to the same IST trading date.
    same_day = df["trading_date_ist"].eq(df["trading_date_ist"].shift())
    adjacent_minute = df["timestamp_gap_minutes"].eq(1.0) & same_day

    df["close_return_1m_pct"] = np.where(
        adjacent_minute & df["previous_close"].ne(0),
        (df["close"] / df["previous_close"] - 1.0) * 100.0,
        np.nan,
    )

    # Overnight/session-open movement is kept separate; it is not labelled a
    # one-minute return.
    df["open_vs_previous_close_pct"] = np.where(
        (~same_day) & df["previous_close"].notna() & df["previous_close"].ne(0),
        (df["open"] / df["previous_close"] - 1.0) * 100.0,
        np.nan,
    )

    # Adaptive robust thresholds are descriptive, not automatic rejection.
    range_mad_threshold = robust_threshold(df["bar_range_pct"].clip(lower=0))
    return_abs = df["close_return_1m_pct"].abs()
    return_mad_threshold = robust_threshold(return_abs)

    df["flag_large_bar_range_fixed"] = (
        df["bar_range_pct"].abs() >= INTRABAR_RANGE_FLAG_PCT
    )
    df["flag_large_1m_return_fixed"] = (
        df["close_return_1m_pct"].abs() >= ABS_ONE_MINUTE_RETURN_FLAG_PCT
    )

    if pd.notna(range_mad_threshold):
        df["flag_large_bar_range_robust"] = (
            df["bar_range_pct"] >= range_mad_threshold
        )
    else:
        df["flag_large_bar_range_robust"] = False

    if pd.notna(return_mad_threshold):
        df["flag_large_1m_return_robust"] = (
            return_abs >= return_mad_threshold
        )
    else:
        df["flag_large_1m_return_robust"] = False

    # Repeated identical OHLC runs, with consecutive one-minute timestamps.
    repeated_rows = []
    for trading_date, day in df.groupby("trading_date_ist", sort=True):
        for run in consecutive_identical_runs(day):
            repeated_rows.append({
                "trading_date": trading_date,
                "start_timestamp_ist": run["timestamp_ist"].min(),
                "end_timestamp_ist": run["timestamp_ist"].max(),
                "bar_count": len(run),
                "open": run["open"].iloc[0],
                "high": run["high"].iloc[0],
                "low": run["low"].iloc[0],
                "close": run["close"].iloc[0],
                "interpretation": (
                    "Repeated identical OHLC run; may be stale/repeated source "
                    "values or genuine unchanged index bars; verify before exclusion."
                ),
            })

    repeated_df = pd.DataFrame(repeated_rows)

    # Keep only rows with one or more diagnostic flags for focused review.
    flag_cols = [
        "null_ohlc",
        "nonpositive_ohlc",
        "high_below_low",
        "high_below_open_close",
        "low_above_open_close",
        "not_minute_aligned",
        "duplicate_timestamp",
        "flag_large_bar_range_fixed",
        "flag_large_1m_return_fixed",
        "flag_large_bar_range_robust",
        "flag_large_1m_return_robust",
    ]
    flagged = df[df[flag_cols].any(axis=1)].copy()

    focus = df[df["trading_date_ist"].isin(FOCUS_DATES)].copy()

    # Minute-level gaps on all dates: timestamp gap > 1 minute, same date.
    gap_rows = []
    for trading_date, day in df.groupby("trading_date_ist", sort=True):
        day = day.sort_values("timestamp_ist")
        ts = day["timestamp_ist"].tolist()
        for previous, current in zip(ts, ts[1:]):
            gap_minutes = (current - previous).total_seconds() / 60.0
            if gap_minutes > 1:
                gap_rows.append({
                    "trading_date": trading_date,
                    "previous_timestamp_ist": previous,
                    "next_timestamp_ist": current,
                    "missing_clock_minutes_between_bars": int(gap_minutes) - 1,
                    "gap_minutes": gap_minutes,
                })
    gaps_df = pd.DataFrame(gap_rows)

    # Timestamp distribution by minute-of-day helps inspect the assumed
    # minute-start labels. It does not establish start/end semantics.
    df["minute_of_day"] = df["timestamp_ist"].dt.hour * 60 + df["timestamp_ist"].dt.minute
    minute_distribution = (
        df.groupby(["trading_date_ist", "minute_of_day"])
          .size()
          .reset_index(name="observations")
    )

    # Daily summary.
    daily_rows = []
    for trading_date, day in df.groupby("trading_date_ist", sort=True):
        windows, session_kind = get_session_windows(trading_date)
        expected = expected_timestamps(trading_date, windows) if windows else pd.DatetimeIndex([])
        observed = set(day["timestamp_ist"])
        expected_set = set(expected)

        daily_rows.append({
            "trading_date": trading_date,
            "session_kind": session_kind,
            "observed_rows": len(day),
            "unique_timestamps": len(observed),
            "expected_minutes_under_current_assumption": len(expected_set),
            "matched_expected_minutes": len(expected_set & observed),
            "missing_expected_minutes": len(expected_set - observed),
            "extra_timestamps": len(observed - expected_set) if windows else None,
            "ohlc_flag_rows": int(day[
                ["null_ohlc", "nonpositive_ohlc", "high_below_low",
                 "high_below_open_close", "low_above_open_close"]
            ].any(axis=1).sum()),
            "large_1m_return_flags_fixed": int(day["flag_large_1m_return_fixed"].sum()),
            "large_bar_range_flags_fixed": int(day["flag_large_bar_range_fixed"].sum()),
            "repeated_ohlc_runs": int(
                (repeated_df["trading_date"] == trading_date).sum()
            ) if not repeated_df.empty else 0,
            "first_timestamp_ist": day["timestamp_ist"].min(),
            "last_timestamp_ist": day["timestamp_ist"].max(),
        })

    daily_df = pd.DataFrame(daily_rows)

    # Summary JSON.
    summary = {
        "dataset": "NIFTY index",
        "period": {"start": START_DATE, "end": END_DATE},
        "timezone_handling": (
            "Database timestamp interpreted as naive UTC and converted to "
            "Asia/Kolkata. Verify this against original dataset documentation."
        ),
        "session_assumption": {
            "convention": "minute_start_provisional",
            "normal_start": NORMAL_START,
            "normal_expected_minutes": NORMAL_MINUTES,
            "warning": (
                "Timestamp sequences and OHLC values cannot conclusively prove "
                "minute-start versus minute-end semantics. Confirm provider documentation."
            ),
        },
        "rows": int(len(df)),
        "unique_ist_dates": int(df["trading_date_ist"].nunique()),
        "duplicate_timestamp_rows": int(df["duplicate_timestamp"].sum()),
        "null_ohlc_rows": int(df["null_ohlc"].sum()),
        "nonpositive_ohlc_rows": int(df["nonpositive_ohlc"].sum()),
        "high_below_low_rows": int(df["high_below_low"].sum()),
        "high_below_open_close_rows": int(df["high_below_open_close"].sum()),
        "low_above_open_close_rows": int(df["low_above_open_close"].sum()),
        "not_minute_aligned_rows": int(df["not_minute_aligned"].sum()),
        "fixed_thresholds": {
            "absolute_adjacent_1m_close_return_pct": ABS_ONE_MINUTE_RETURN_FLAG_PCT,
            "intrabar_high_low_range_pct_of_previous_close": INTRABAR_RANGE_FLAG_PCT,
        },
        "robust_thresholds": {
            "bar_range_pct_median_plus_12_scaled_MAD": (
                float(range_mad_threshold) if pd.notna(range_mad_threshold) else None
            ),
            "absolute_1m_return_pct_median_plus_12_scaled_MAD": (
                float(return_mad_threshold) if pd.notna(return_mad_threshold) else None
            ),
        },
        "flagged_price_rows": int(
            (df["flag_large_bar_range_fixed"] |
             df["flag_large_1m_return_fixed"] |
             df["flag_large_bar_range_robust"] |
             df["flag_large_1m_return_robust"]).sum()
        ),
        "repeated_identical_ohlc_runs": int(len(repeated_df)),
        "gap_intervals_over_one_minute": int(len(gaps_df)),
        "focus_dates": FOCUS_DATES,
        "important_caveat": (
            "All statistical flags require review. They are not automatic evidence "
            "of corrupt data and must not trigger automatic deletion or filling."
        ),
    }

    # Export files.
    exports = {
        "nifty_full_timestamp_price_audit.csv": df,
        "nifty_flagged_price_timestamp_rows.csv": flagged,
        "nifty_repeated_identical_ohlc_runs.csv": repeated_df,
        "nifty_intraday_timestamp_gaps.csv": gaps_df,
        "nifty_daily_price_timestamp_summary.csv": daily_df,
        "nifty_focus_dates_all_observations.csv": focus,
        "nifty_minute_of_day_distribution.csv": minute_distribution,
    }

    for filename, frame in exports.items():
        frame.to_csv(OUTPUT_DIR / filename, index=False)

    with open(OUTPUT_DIR / "nifty_price_timestamp_audit_summary.json",
              "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, default=str)

    print("\nAUDIT COMPLETE — no source data modified.")
    print("Rows audited:", len(df))
    print("IST dates:", df["trading_date_ist"].nunique())
    print("Duplicate timestamp rows:", summary["duplicate_timestamp_rows"])
    print("OHLC integrity issue rows:", int(
        df[["null_ohlc", "nonpositive_ohlc", "high_below_low",
            "high_below_open_close", "low_above_open_close"]].any(axis=1).sum()
    ))
    print("Large price-move/range flagged rows:", summary["flagged_price_rows"])
    print("Repeated identical OHLC runs:", len(repeated_df))
    print("Intraday timestamp gaps > 1 minute:", len(gaps_df))
    print("\nOutput folder:", OUTPUT_DIR.resolve())
    for filename in list(exports) + ["nifty_price_timestamp_audit_summary.json"]:
        print(" -", filename)

    print(
        "\nNOTE: Minute-start/minute-end semantics cannot be proven from this "
        "audit alone. Confirm the source provider's timestamp definition."
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
