
from pathlib import Path
import json
import duckdb
import pandas as pd
from datetime import datetime

# ============================================================
# NIFTY OPTIONS SCHEMA INSPECTION
# Read-only inspection. No source data is modified.
# ============================================================

ROOT = Path(__file__).resolve().parent.parent
DB_PATH = ROOT / "data" / "database" / "nifty_options.duckdb"
OUTPUT_DIR = ROOT / "reports" / "nifty_options_schema_v1"

VIEW_NAME = "nifty_options"
SAMPLE_ROWS = 20

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

def quote_identifier(name):
    return '"' + str(name).replace('"', '""') + '"'

def main():
    if not DB_PATH.exists():
        raise FileNotFoundError(f"DuckDB database not found: {DB_PATH}")

    con = duckdb.connect(str(DB_PATH), read_only=True)

    try:
        print("=" * 75)
        print("NIFTY OPTIONS SCHEMA INSPECTION")
        print("=" * 75)
        print("Database:", DB_PATH)
        print("View:", VIEW_NAME)

        # 1. Inspect available views/tables.
        objects = con.execute("""
                              SELECT table_name, table_type
                              FROM information_schema.tables
                              WHERE table_schema = 'main'
                              ORDER BY table_name
                              """).df()

        objects.to_csv(OUTPUT_DIR / "database_objects.csv", index=False)

        if VIEW_NAME not in objects["table_name"].tolist():
            raise RuntimeError(
                f"View/table '{VIEW_NAME}' not found. "
                f"Available objects: {objects['table_name'].tolist()}"
            )

        # 2. Inspect exact column names and types.
        schema = con.execute(
            f"DESCRIBE SELECT * FROM {quote_identifier(VIEW_NAME)}"
        ).df()

        schema.to_csv(OUTPUT_DIR / "nifty_options_columns.csv", index=False)

        print("\n--- COLUMN SCHEMA ---")
        print(schema.to_string(index=False))

        columns = schema["column_name"].tolist()

        # 3. Sample records.
        sample = con.execute(
            f"SELECT * FROM {quote_identifier(VIEW_NAME)} LIMIT {SAMPLE_ROWS}"
        ).df()

        sample.to_csv(OUTPUT_DIR / "nifty_options_sample.csv", index=False)

        print("\n--- SAMPLE RECORDS ---")
        print(sample.to_string(index=False))

        # 4. Detect likely candidate columns.
        normalized = {
            str(c).lower().replace("_", "").replace(" ", ""): c
            for c in columns
        }

        candidates = {
            "timestamp": [
                "timestamp", "datetime", "dateTime", "timeStamp"
            ],
            "date": ["date", "tradingdate", "businessdate"],
            "time": ["time", "tradetime"],
            "expiry": ["expiry", "expirydate", "expiration", "expirationdate"],
            "strike": ["strike", "strikeprice", "strike_price"],
            "option_type": [
                "optiontype", "option_type", "instrumenttype",
                "right", "cp", "cepe"
            ],
            "symbol": [
                "symbol", "tradingsymbol", "contractsymbol",
                "instrument", "ticker"
            ],
            "open": ["open", "o"],
            "high": ["high", "h"],
            "low": ["low", "l"],
            "close": ["close", "c", "ltp", "lastprice"],
            "oi": ["oi", "openinterest", "open_interest"],
            "volume": ["volume", "vol", "tradedvolume"],
            "underlying": [
                "underlying", "underlyingsymbol", "underlyingname"
            ],
        }

        detected = {}

        for logical_name, possible_names in candidates.items():
            found = None
            for candidate in possible_names:
                key = candidate.lower().replace("_", "").replace(" ", "")
                if key in normalized:
                    found = normalized[key]
                    break
            detected[logical_name] = found

        mapping = pd.DataFrame([
            {"logical_field": key, "detected_column": value}
            for key, value in detected.items()
        ])

        mapping.to_csv(OUTPUT_DIR / "detected_column_mapping.csv", index=False)

        print("\n--- DETECTED COLUMN MAPPING ---")
        print(mapping.to_string(index=False))

        # 5. Basic table count and timestamp range if possible.
        row_count = con.execute(
            f"SELECT COUNT(*) FROM {quote_identifier(VIEW_NAME)}"
        ).fetchone()[0]

        print("\nTotal rows:", f"{row_count:,}")

        timestamp_column = detected["timestamp"]

        if timestamp_column:
            qcol = quote_identifier(timestamp_column)

            time_stats = con.execute(f"""
                SELECT
                    MIN({qcol}) AS min_timestamp,
                    MAX({qcol}) AS max_timestamp,
                    COUNT(*) AS total_rows,
                    COUNT({qcol}) AS non_null_timestamps,
                    COUNT(*) - COUNT({qcol}) AS null_timestamps
                FROM {quote_identifier(VIEW_NAME)}
            """).df()

            time_stats.to_csv(
                OUTPUT_DIR / "timestamp_range.csv", index=False
            )
            print("\n--- TIMESTAMP RANGE ---")
            print(time_stats.to_string(index=False))

        # 6. If a likely option type field exists, inspect its values.
        option_type_column = detected["option_type"]

        if option_type_column:
            qcol = quote_identifier(option_type_column)

            option_types = con.execute(f"""
                SELECT
                    CAST({qcol} AS VARCHAR) AS option_type_value,
                    COUNT(*) AS rows
                FROM {quote_identifier(VIEW_NAME)}
                GROUP BY 1
                ORDER BY rows DESC
                LIMIT 50
            """).df()

            option_types.to_csv(
                OUTPUT_DIR / "option_type_values.csv", index=False
            )

            print("\n--- OPTION TYPE VALUES ---")
            print(option_types.to_string(index=False))

        # 7. If symbol exists, inspect sample distinct symbols.
        symbol_column = detected["symbol"]

        if symbol_column:
            qcol = quote_identifier(symbol_column)

            symbols = con.execute(f"""
                SELECT
                    CAST({qcol} AS VARCHAR) AS symbol_value,
                    COUNT(*) AS rows
                FROM {quote_identifier(VIEW_NAME)}
                GROUP BY 1
                ORDER BY rows DESC
                LIMIT 30
            """).df()

            symbols.to_csv(
                OUTPUT_DIR / "top_symbol_values.csv", index=False
            )

            print("\n--- TOP SYMBOL VALUES ---")
            print(symbols.to_string(index=False))

        summary = {
            "generated_at": datetime.now().isoformat(),
            "database": str(DB_PATH),
            "view": VIEW_NAME,
            "total_rows": int(row_count),
            "columns": [
                {
                    "name": str(row["column_name"]),
                    "type": str(row["column_type"])
                }
                for _, row in schema.iterrows()
            ],
            "detected_mapping": detected,
            "inspection_only": True,
            "source_modified": False
        }

        with open(
                OUTPUT_DIR / "schema_inspection_summary.json",
                "w",
                encoding="utf-8"
        ) as f:
            json.dump(summary, f, indent=2, default=str)

        print("\n" + "=" * 75)
        print("INSPECTION COMPLETED")
        print("=" * 75)
        print("Output directory:", OUTPUT_DIR)
        print("Source database was opened read-only.")

    finally:
        con.close()


if __name__ == "__main__":
    main()
