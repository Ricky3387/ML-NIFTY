
from pathlib import Path
from datetime import datetime
import json
import time
import warnings

import joblib
import lightgbm as lgb
import numpy as np
import pandas as pd

from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    brier_score_loss,
    classification_report,
    f1_score,
    log_loss,
    precision_score,
    recall_score,
    roc_auc_score,
)

warnings.filterwarnings("ignore", category=UserWarning)

# ============================================================
# CONFIGURATION
# ============================================================

ROOT = Path(__file__).resolve().parents[1]

DATA_DIR = ROOT / "data" / "processed" / "nifty_walkforward_v1"
TRAIN_FILE = DATA_DIR / "train_5m.parquet"
VALIDATION_FILE = DATA_DIR / "validation_5m.parquet"

MODEL_ROOT = ROOT / "models" / "nifty_two_stage_calibration_v1"
REPORT_ROOT = ROOT / "reports" / "nifty_two_stage_calibration_v1"

STAGE1_ITERATIONS = 57
STAGE2_ITERATIONS = 47

SEED = 42

DIRECTIONAL_THRESHOLD = 0.600
CONDITIONAL_UP_THRESHOLD = 0.525

LABELS = ["DOWN", "SIDEWAYS", "UP"]

FEATURES = [
    "ret_1m",
    "logret_1m",
    "range_pct",
    "body_pct",
    "upper_wick_pct",
    "lower_wick_pct",
    "return_5m",
    "return_15m",
    "return_30m",
    "return_60m",
    "realized_vol_5m",
    "realized_vol_15m",
    "realized_vol_30m",
    "realized_vol_60m",
    "high_low_range_5m",
    "high_low_range_15m",
    "high_low_range_30m",
    "high_low_range_60m",
    "close_vs_ema9_pct",
    "close_vs_ema21_pct",
    "close_vs_ema50_pct",
    "rsi_14",
    "positive_return_count_5m",
    "negative_return_count_5m",
    "target_vol_scale",
]

EPS = 1e-6
RELIABILITY_BINS = 10


# ============================================================
# SETUP AND DATA
# ============================================================

def create_directories():
    run_id = datetime.now().strftime("%Y%m%d_%H%M%S")
    model_dir = MODEL_ROOT / run_id
    report_dir = REPORT_ROOT / run_id

    model_dir.mkdir(parents=True, exist_ok=False)
    report_dir.mkdir(parents=True, exist_ok=False)

    return run_id, model_dir, report_dir


def load_data(path, name):
    if not path.exists():
        raise FileNotFoundError(f"Missing {name} file: {path}")

    df = pd.read_parquet(path)

    required = FEATURES + [
        "timestamp_ist",
        "trading_day",
        "label",
        "sample_eligible",
    ]

    missing = sorted(set(required) - set(df.columns))
    if missing:
        raise ValueError(f"{name} missing columns: {missing}")

    df["trading_day"] = pd.to_datetime(
        df["trading_day"]
    ).dt.date

    df["label"] = df["label"].astype(str).str.upper()

    df = df.loc[
        df["sample_eligible"].astype(bool)
        & df["label"].isin(LABELS)
        ].copy()

    for col in FEATURES:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    finite = np.isfinite(
        df[FEATURES].to_numpy(dtype=np.float64)
    ).all(axis=1)

    if not finite.all():
        raise ValueError(
            f"{name}: {int((~finite).sum())} rows have "
            "missing/non-finite features."
        )

    if df["timestamp_ist"].duplicated().any():
        raise ValueError(f"{name}: duplicate timestamps.")

    return df.sort_values(
        "timestamp_ist"
    ).reset_index(drop=True)


# ============================================================
# CLASSIFIER TRAINING
# ============================================================

def make_model(iterations):
    return lgb.LGBMClassifier(
        objective="binary",
        n_estimators=int(iterations),
        learning_rate=0.025,
        num_leaves=31,
        max_depth=-1,
        min_child_samples=100,
        subsample=0.8,
        subsample_freq=1,
        colsample_bytree=0.8,
        reg_lambda=2.0,
        random_state=SEED,
        n_jobs=-1,
        verbosity=-1,
    )


def fit_two_stage(train_df, description):
    x = train_df[FEATURES]

    # Stage 1: directional vs sideways.
    y1 = (train_df["label"] != "SIDEWAYS").astype(int)

    if y1.nunique() != 2:
        raise ValueError(f"{description}: Stage 1 needs both classes.")

    stage1 = make_model(STAGE1_ITERATIONS)
    stage1.fit(x, y1)

    # Stage 2: UP vs DOWN, only actual directional samples.
    directional = train_df[
        train_df["label"].isin(["DOWN", "UP"])
    ]

    y2 = (directional["label"] == "UP").astype(int)

    if y2.nunique() != 2:
        raise ValueError(f"{description}: Stage 2 needs both classes.")

    stage2 = make_model(STAGE2_ITERATIONS)
    stage2.fit(directional[FEATURES], y2)

    print(
        f"{description}: Stage1={len(train_df):,}; "
        f"Stage2={len(directional):,}"
    )

    return stage1, stage2


def predict_stages(stage1, stage2, df):
    x = df[FEATURES]

    p_directional = stage1.predict_proba(x)[:, 1]
    p_up_conditional = stage2.predict_proba(x)[:, 1]

    return pd.DataFrame({
        "timestamp_ist": df["timestamp_ist"].to_numpy(),
        "trading_day": df["trading_day"].to_numpy(),
        "actual_label": df["label"].to_numpy(),
        "target_vol_scale": df["target_vol_scale"].to_numpy(),
        "p_directional_raw": p_directional,
        "p_up_conditional_raw": p_up_conditional,
    })


# ============================================================
# PLATT CALIBRATION
# ============================================================

def to_logit(probability):
    p = np.clip(
        np.asarray(probability, dtype=float),
        EPS,
        1.0 - EPS,
        )
    return np.log(p / (1.0 - p)).reshape(-1, 1)


def fit_platt(probability, actual, name):
    actual = np.asarray(actual, dtype=int)

    if len(np.unique(actual)) != 2:
        raise ValueError(
            f"{name}: calibration data must contain both classes."
        )

    calibrator = LogisticRegression(
        C=1.0,
        solver="lbfgs",
        max_iter=2000,
        random_state=SEED,
    )

    calibrator.fit(
        to_logit(probability),
        actual,
    )

    return calibrator


def apply_platt(calibrator, probability):
    return calibrator.predict_proba(
        to_logit(probability)
    )[:, 1]


# ============================================================
# PROBABILITY METRICS
# ============================================================

def safe_auc(actual, probability):
    actual = np.asarray(actual, dtype=int)
    if len(np.unique(actual)) != 2:
        return None
    return float(roc_auc_score(actual, probability))


def expected_calibration_error(actual, probability, bins=10):
    actual = np.asarray(actual, dtype=float)
    probability = np.asarray(probability, dtype=float)

    edges = np.linspace(0.0, 1.0, bins + 1)
    bin_id = np.digitize(
        probability,
        edges[1:-1],
        right=False,
    )

    ece = 0.0
    rows = []

    for b in range(bins):
        mask = bin_id == b
        count = int(mask.sum())

        if count == 0:
            continue

        mean_probability = float(probability[mask].mean())
        observed_rate = float(actual[mask].mean())
        weight = count / len(actual)

        ece += weight * abs(
            observed_rate - mean_probability
        )

        rows.append({
            "bin": b + 1,
            "count": count,
            "mean_predicted_probability": mean_probability,
            "observed_rate": observed_rate,
            "absolute_calibration_error": abs(
                observed_rate - mean_probability
            ),
        })

    return float(ece), pd.DataFrame(rows)


def binary_probability_metrics(actual, probability, name):
    actual = np.asarray(actual, dtype=int)
    probability = np.clip(
        np.asarray(probability, dtype=float),
        EPS,
        1.0 - EPS,
        )

    ece, _ = expected_calibration_error(
        actual,
        probability,
        RELIABILITY_BINS,
    )

    return {
        "target": name,
        "observations": int(len(actual)),
        "prevalence_pct": float(actual.mean() * 100),
        "mean_predicted_probability_pct": float(
            probability.mean() * 100
        ),
        "brier_score": float(
            brier_score_loss(actual, probability)
        ),
        "log_loss": float(
            log_loss(actual, probability, labels=[0, 1])
        ),
        "roc_auc": safe_auc(actual, probability),
        "expected_calibration_error": ece,
    }


def multiclass_probability_metrics(actual, probabilities):
    actual = np.asarray(actual)
    probabilities = np.asarray(probabilities, dtype=float)

    class_to_id = {
        "DOWN": 0,
        "SIDEWAYS": 1,
        "UP": 2,
    }

    y = np.array([class_to_id[x] for x in actual])

    probabilities = np.clip(
        probabilities,
        EPS,
        1.0,
    )

    probabilities /= probabilities.sum(
        axis=1,
        keepdims=True,
    )

    one_hot = np.eye(3)[y]

    return {
        "multiclass_logloss": float(
            log_loss(y, probabilities, labels=[0, 1, 2])
        ),
        "multiclass_brier_score": float(
            np.mean(np.sum(
                (probabilities - one_hot) ** 2,
                axis=1,
                ))
        ),
    }


def build_combined_probabilities(df, calibrated):
    if calibrated:
        p_dir = df["p_directional_calibrated"].to_numpy()
        p_up_cond = df["p_up_conditional_calibrated"].to_numpy()
    else:
        p_dir = df["p_directional_raw"].to_numpy()
        p_up_cond = df["p_up_conditional_raw"].to_numpy()

    p_down = p_dir * (1.0 - p_up_cond)
    p_up = p_dir * p_up_cond
    p_side = 1.0 - p_dir

    result = np.column_stack([
        p_down,
        p_side,
        p_up,
    ])

    result = np.clip(result, EPS, 1.0)
    result /= result.sum(axis=1, keepdims=True)

    return result


# ============================================================
# CLASSIFICATION POLICY
# ============================================================

def apply_fixed_policy(df, calibrated):
    if calibrated:
        p_dir = df["p_directional_calibrated"].to_numpy()
        p_up = df["p_up_conditional_calibrated"].to_numpy()
    else:
        p_dir = df["p_directional_raw"].to_numpy()
        p_up = df["p_up_conditional_raw"].to_numpy()

    predicted = np.full(
        len(df),
        "SIDEWAYS",
        dtype=object,
    )

    directional = p_dir >= 0.600
    is_up = p_up >= 0.525

    predicted[directional & is_up] = "UP"
    predicted[directional & ~is_up] = "DOWN"

    return predicted


def classification_metrics(actual, predicted, name):
    actual = np.asarray(actual)
    predicted = np.asarray(predicted)

    actual_directional = actual != "SIDEWAYS"
    predicted_directional = predicted != "SIDEWAYS"

    return {
        "policy": name,
        "accuracy": float(
            accuracy_score(actual, predicted)
        ),
        "balanced_accuracy": float(
            balanced_accuracy_score(actual, predicted)
        ),
        "macro_f1": float(
            f1_score(
                actual,
                predicted,
                labels=LABELS,
                average="macro",
                zero_division=0,
            )
        ),
        "weighted_f1": float(
            f1_score(
                actual,
                predicted,
                labels=LABELS,
                average="weighted",
                zero_division=0,
            )
        ),
        "directional_precision": float(
            precision_score(
                actual_directional,
                predicted_directional,
                zero_division=0,
            )
        ),
        "directional_recall": float(
            recall_score(
                actual_directional,
                predicted_directional,
                zero_division=0,
            )
        ),
        "predicted_directional_pct": float(
            predicted_directional.mean() * 100
        ),
        "down_precision": float(
            precision_score(
                actual == "DOWN",
                predicted == "DOWN",
                zero_division=0,
                )
        ),
        "down_recall": float(
            recall_score(
                actual == "DOWN",
                predicted == "DOWN",
                zero_division=0,
                )
        ),
        "up_precision": float(
            precision_score(
                actual == "UP",
                predicted == "UP",
                zero_division=0,
                )
        ),
        "up_recall": float(
            recall_score(
                actual == "UP",
                predicted == "UP",
                zero_division=0,
                )
        ),
    }


# ============================================================
# MONTHLY / VOLATILITY ANALYSIS
# ============================================================

def add_period_columns(df):
    result = df.copy()

    result["month"] = pd.to_datetime(
        result["trading_day"].astype(str)
    ).dt.strftime("%Y-%m")

    return result


def reliability_report(df, probability_column, actual_column, name):
    actual = df[actual_column].astype(int).to_numpy()
    probability = df[probability_column].to_numpy()

    ece, bins = expected_calibration_error(
        actual,
        probability,
        RELIABILITY_BINS,
    )

    bins.insert(0, "target", name)
    bins["ece"] = ece

    return bins


def monthly_calibration_report(df):
    rows = []

    for month, group in df.groupby("month"):
        if len(group) < 500:
            continue

        actual_directional = (
                group["actual_label"] != "SIDEWAYS"
        ).astype(int)

        actual_up_cond = (
                group.loc[
                    group["actual_label"] != "SIDEWAYS",
                    "actual_label",
                ] == "UP"
        ).astype(int)

        p_dir_raw = group["p_directional_raw"].to_numpy()
        p_dir_cal = group["p_directional_calibrated"].to_numpy()

        rows.append({
            "month": month,
            "rows": len(group),
            "actual_directional_pct": (
                    actual_directional.mean() * 100
            ),
            "raw_directional_probability_pct": (
                    p_dir_raw.mean() * 100
            ),
            "calibrated_directional_probability_pct": (
                    p_dir_cal.mean() * 100
            ),
            "raw_directional_brier": brier_score_loss(
                actual_directional,
                p_dir_raw,
            ),
            "calibrated_directional_brier": brier_score_loss(
                actual_directional,
                p_dir_cal,
            ),
            "raw_directional_auc": safe_auc(
                actual_directional,
                p_dir_raw,
            ),
            "calibrated_directional_auc": safe_auc(
                actual_directional,
                p_dir_cal,
            ),
            "actual_up_share_of_directional_pct": (
                actual_up_cond.mean() * 100
                if len(actual_up_cond) else None
            ),
        })

    return pd.DataFrame(rows)


def volatility_regime_report(df, q_low, q_high):
    result = df.copy()

    result["volatility_regime"] = np.select(
        [
            result["target_vol_scale"] <= q_low,
            result["target_vol_scale"] <= q_high,
            ],
        [
            "LOW",
            "MEDIUM",
        ],
        default="HIGH",
    )

    rows = []

    for regime, group in result.groupby("volatility_regime"):
        actual = (
                group["actual_label"] != "SIDEWAYS"
        ).astype(int)

        for method, column in [
            ("RAW", "p_directional_raw"),
            ("CALIBRATED", "p_directional_calibrated"),
        ]:
            probability = group[column].to_numpy()

            rows.append({
                "volatility_regime": regime,
                "method": method,
                "rows": len(group),
                "actual_directional_pct": (
                        actual.mean() * 100
                ),
                "mean_predicted_directional_pct": (
                        probability.mean() * 100
                ),
                "brier_score": brier_score_loss(
                    actual,
                    probability,
                ),
                "roc_auc": safe_auc(
                    actual,
                    probability,
                ),
            })

    return pd.DataFrame(rows), result


# ============================================================
# MAIN
# ============================================================

def main():
    start = time.time()

    run_id, model_dir, report_dir = create_directories()

    print("=" * 75)
    print("NIFTY TWO-STAGE PROBABILITY CALIBRATION V1")
    print("=" * 75)
    print(f"Run ID: {run_id}")

    train = load_data(TRAIN_FILE, "training")
    validation = load_data(VALIDATION_FILE, "validation")

    d2023_start = pd.to_datetime("2023-01-01").date()
    d2023_end = pd.to_datetime("2023-12-31").date()
    d2024_start = pd.to_datetime("2024-01-01").date()
    d2024_end = pd.to_datetime("2024-12-31").date()

    train_2021_2022 = train[
        train["trading_day"] < d2023_start
        ].copy()

    calibration_2023 = train[
        (train["trading_day"] >= d2023_start)
        & (train["trading_day"] <= d2023_end)
        ].copy()

    final_train = train[
        train["trading_day"] <= d2023_end
        ].copy()

    evaluation_2024 = validation[
        (validation["trading_day"] >= d2024_start)
        & (validation["trading_day"] <= d2024_end)
        ].copy()

    for name, df in [
        ("2021-2022", train_2021_2022),
        ("2023", calibration_2023),
        ("2021-2023", final_train),
        ("2024", evaluation_2024),
    ]:
        if df.empty:
            raise ValueError(f"Empty date partition: {name}")

    print("\nPARTITIONS")
    print(f"2021-2022: {len(train_2021_2022):,}")
    print(f"2023 calibration: {len(calibration_2023):,}")
    print(f"2021-2023 final fit: {len(final_train):,}")
    print(f"2024 diagnostic: {len(evaluation_2024):,}")

    # --------------------------------------------------------
    # 1. Calibration models: train on 2021-2022.
    # --------------------------------------------------------

    print("\nFITTING CALIBRATION BASE MODELS")

    calibration_stage1, calibration_stage2 = fit_two_stage(
        train_2021_2022,
        "Calibration model",
    )

    calibration_predictions = predict_stages(
        calibration_stage1,
        calibration_stage2,
        calibration_2023,
    )

    # Stage 1 calibration target.
    y1_calibration = (
            calibration_predictions["actual_label"] != "SIDEWAYS"
    ).astype(int)

    # Stage 2 calibration target only on actual directional rows.
    directional_mask = (
            calibration_predictions["actual_label"] != "SIDEWAYS"
    )

    y2_calibration = (
            calibration_predictions.loc[
                directional_mask,
                "actual_label",
            ] == "UP"
    ).astype(int)

    print("\nFITTING PLATT CALIBRATORS")

    stage1_calibrator = fit_platt(
        calibration_predictions["p_directional_raw"],
        y1_calibration,
        "Stage 1",
    )

    stage2_calibrator = fit_platt(
        calibration_predictions.loc[
            directional_mask,
            "p_up_conditional_raw",
        ],
        y2_calibration,
        "Stage 2",
    )

    joblib.dump(
        stage1_calibrator,
        model_dir / "stage1_platt_calibrator.joblib",
        )

    joblib.dump(
        stage2_calibrator,
        model_dir / "stage2_platt_calibrator.joblib",
        )

    # Save calibration model and calibrator diagnostics.
    calibration_predictions[
        "p_directional_calibrated"
    ] = apply_platt(
        stage1_calibrator,
        calibration_predictions["p_directional_raw"],
    )

    calibration_predictions[
        "p_up_conditional_calibrated"
    ] = np.nan

    calibration_predictions.loc[
        directional_mask,
        "p_up_conditional_calibrated",
    ] = apply_platt(
        stage2_calibrator,
        calibration_predictions.loc[
            directional_mask,
            "p_up_conditional_raw",
        ],
    )

    # --------------------------------------------------------
    # 2. Final models: train through 2023.
    # --------------------------------------------------------

    print("\nFITTING FINAL CLASSIFIERS THROUGH 2023")

    final_stage1, final_stage2 = fit_two_stage(
        final_train,
        "Final model",
    )

    joblib.dump(
        final_stage1,
        model_dir / "stage1_directional_classifier.joblib",
        )

    joblib.dump(
        final_stage2,
        model_dir / "stage2_up_down_classifier.joblib",
        )

    # --------------------------------------------------------
    # 3. Generate 2024 predictions.
    # --------------------------------------------------------

    print("\nGENERATING 2024 PROBABILITIES")

    evaluation = predict_stages(
        final_stage1,
        final_stage2,
        evaluation_2024,
    )

    evaluation["p_directional_calibrated"] = apply_platt(
        stage1_calibrator,
        evaluation["p_directional_raw"],
    )

    # Stage 2 calibrator applies to all rows, although its fitting
    # sample consisted only of actual directional observations.
    evaluation["p_up_conditional_calibrated"] = apply_platt(
        stage2_calibrator,
        evaluation["p_up_conditional_raw"],
    )

    evaluation.to_parquet(
        report_dir / "2024_raw_and_calibrated_probabilities.parquet",
        index=False,
        )

    # --------------------------------------------------------
    # 4. Stage 1 and Stage 2 calibration metrics.
    # --------------------------------------------------------

    stage1_actual_2024 = (
            evaluation["actual_label"] != "SIDEWAYS"
    ).astype(int)

    stage1_metrics = []

    for method, column in [
        ("RAW", "p_directional_raw"),
        ("PLATT", "p_directional_calibrated"),
    ]:
        row = binary_probability_metrics(
            stage1_actual_2024,
            evaluation[column],
            "DIRECTIONAL_VS_SIDEWAYS",
        )
        row["method"] = method
        stage1_metrics.append(row)

    stage1_metrics_df = pd.DataFrame(stage1_metrics)

    stage2_directional_2024 = (
            evaluation["actual_label"] != "SIDEWAYS"
    )

    stage2_actual_2024 = (
            evaluation.loc[
                stage2_directional_2024,
                "actual_label",
            ] == "UP"
    ).astype(int)

    stage2_metrics = []

    for method, column in [
        ("RAW", "p_up_conditional_raw"),
        ("PLATT", "p_up_conditional_calibrated"),
    ]:
        row = binary_probability_metrics(
            stage2_actual_2024,
            evaluation.loc[
                stage2_directional_2024,
                column,
            ],
            "UP_VS_DOWN_CONDITIONAL",
        )
        row["method"] = method
        stage2_metrics.append(row)

    stage2_metrics_df = pd.DataFrame(stage2_metrics)

    stage1_metrics_df.to_csv(
        report_dir / "stage1_probability_metrics.csv",
        index=False,
        )

    stage2_metrics_df.to_csv(
        report_dir / "stage2_probability_metrics.csv",
        index=False,
        )

    # Reliability bins.
    reliability_files = []

    for method, column in [
        ("RAW", "p_directional_raw"),
        ("PLATT", "p_directional_calibrated"),
    ]:
        temp = evaluation.copy()
        temp["actual_directional"] = (
                temp["actual_label"] != "SIDEWAYS"
        ).astype(int)

        bins = reliability_report(
            temp,
            column,
            "actual_directional",
            f"STAGE1_{method}",
        )
        reliability_files.append(bins)

    reliability_df = pd.concat(
        reliability_files,
        ignore_index=True,
    )

    reliability_df.to_csv(
        report_dir / "stage1_reliability_bins.csv",
        index=False,
        )

    # Stage 2 reliability only on actual directional observations.
    stage2_reliability = []

    stage2_eval = evaluation.loc[
        stage2_directional_2024
    ].copy()

    stage2_eval["actual_up"] = (
            stage2_eval["actual_label"] == "UP"
    ).astype(int)

    for method, column in [
        ("RAW", "p_up_conditional_raw"),
        ("PLATT", "p_up_conditional_calibrated"),
    ]:
        bins = reliability_report(
            stage2_eval,
            column,
            "actual_up",
            f"STAGE2_{method}",
        )
        stage2_reliability.append(bins)

    pd.concat(
        stage2_reliability,
        ignore_index=True,
    ).to_csv(
        report_dir / "stage2_reliability_bins.csv",
        index=False,
        )

    # --------------------------------------------------------
    # 5. Combined three-class probability scores.
    # --------------------------------------------------------

    actual = evaluation["actual_label"].to_numpy()

    raw_combined = build_combined_probabilities(
        evaluation,
        calibrated=False,
    )

    calibrated_combined = build_combined_probabilities(
        evaluation,
        calibrated=True,
    )

    combined_metrics = []

    for method, probabilities in [
        ("RAW", raw_combined),
        ("PLATT", calibrated_combined),
    ]:
        row = {
            "method": method,
            **multiclass_probability_metrics(
                actual,
                probabilities,
            ),
        }
        combined_metrics.append(row)

    combined_metrics_df = pd.DataFrame(combined_metrics)

    combined_metrics_df.to_csv(
        report_dir / "combined_multiclass_probability_metrics.csv",
        index=False,
        )

    # --------------------------------------------------------
    # 6. Fixed threshold policy comparison.
    # --------------------------------------------------------

    policy_rows = []

    for method, calibrated in [
        ("RAW_FIXED_THRESHOLDS", False),
        ("PLATT_FIXED_THRESHOLDS", True),
    ]:
        predicted = apply_fixed_policy(
            evaluation,
            calibrated,
        )

        policy_rows.append(
            classification_metrics(
                actual,
                predicted,
                method,
            )
        )

        report = classification_report(
            actual,
            predicted,
            labels=LABELS,
            output_dict=True,
            zero_division=0,
        )

        pd.DataFrame(report).transpose().to_csv(
            report_dir / f"{method.lower()}_classification_report.csv"
        )

        cm = pd.crosstab(
            pd.Series(actual, name="actual"),
            pd.Series(predicted, name="predicted"),
        ).reindex(
            index=LABELS,
            columns=LABELS,
            fill_value=0,
        )

        cm.to_csv(
            report_dir / f"{method.lower()}_confusion_matrix.csv"
        )

    policy_df = pd.DataFrame(policy_rows)

    policy_df.to_csv(
        report_dir / "fixed_threshold_policy_comparison.csv",
        index=False,
        )

    # --------------------------------------------------------
    # 7. Monthly stability.
    # --------------------------------------------------------

    evaluation_periods = add_period_columns(evaluation)

    monthly = monthly_calibration_report(
        evaluation_periods
    )

    monthly.to_csv(
        report_dir / "monthly_directional_calibration.csv",
        index=False,
        )

    # --------------------------------------------------------
    # 8. Volatility regime analysis.
    # Boundaries estimated only from 2023 calibration period.
    # --------------------------------------------------------

    q_low = float(
        calibration_predictions["target_vol_scale"].quantile(1 / 3)
    )

    q_high = float(
        calibration_predictions["target_vol_scale"].quantile(2 / 3)
    )

    volatility_report, evaluation_with_regime = (
        volatility_regime_report(
            evaluation,
            q_low,
            q_high,
        )
    )

    volatility_report.to_csv(
        report_dir / "volatility_regime_calibration.csv",
        index=False,
        )

    evaluation_with_regime.to_parquet(
        report_dir / "2024_predictions_with_volatility_regime.parquet",
        index=False,
        )

    # --------------------------------------------------------
    # 9. Calibration parameter report.
    # --------------------------------------------------------

    calibrator_parameters = {
        "stage1": {
            "coefficient": float(
                stage1_calibrator.coef_[0][0]
            ),
            "intercept": float(
                stage1_calibrator.intercept_[0]
            ),
        },
        "stage2": {
            "coefficient": float(
                stage2_calibrator.coef_[0][0]
            ),
            "intercept": float(
                stage2_calibrator.intercept_[0]
            ),
        },
        "volatility_quantiles_from_2023": {
            "low_tercile_boundary": q_low,
            "high_tercile_boundary": q_high,
        },
    }

    with open(
            report_dir / "calibration_parameters.json",
            "w",
            encoding="utf-8",
    ) as f:
        json.dump(
            calibrator_parameters,
            f,
            indent=2,
        )

    manifest = {
        "run_id": run_id,
        "experiment": "two_stage_platt_calibration_v1",
        "fit_period_for_calibration_models": "2021-2022",
        "calibration_period": "2023",
        "final_classifier_fit_period": "2021-2023",
        "evaluation_period": "2024 diagnostic only",
        "excluded_periods": ["2025", "2026"],
        "calibration_method": "Platt sigmoid on probability logits",
        "stage1_iterations": STAGE1_ITERATIONS,
        "stage2_iterations": STAGE2_ITERATIONS,
        "fixed_directional_threshold": DIRECTIONAL_THRESHOLD,
        "fixed_conditional_up_threshold": CONDITIONAL_UP_THRESHOLD,
        "volatility_regime_boundaries_source": "2023 calibration set",
        "feature_count": len(FEATURES),
        "features": FEATURES,
        "warning": (
            "Calibrators are fitted on 2023 scores from models trained "
            "on 2021-2022, then applied to 2024 scores from models "
            "refitted through 2023. Calibration transfer may be imperfect. "
            "2024 is diagnostic, not an untouched test."
        ),
    }

    with open(
            report_dir / "run_manifest.json",
            "w",
            encoding="utf-8",
    ) as f:
        json.dump(manifest, f, indent=2)

    # --------------------------------------------------------
    # CONSOLE SUMMARY
    # --------------------------------------------------------

    print("\n" + "=" * 75)
    print("STAGE 1 PROBABILITY METRICS")
    print("=" * 75)
    print(stage1_metrics_df.to_string(index=False))

    print("\nSTAGE 2 PROBABILITY METRICS")
    print("=" * 75)
    print(stage2_metrics_df.to_string(index=False))

    print("\nCOMBINED MULTICLASS PROBABILITY METRICS")
    print("=" * 75)
    print(combined_metrics_df.to_string(index=False))

    print("\nFIXED THRESHOLD POLICY COMPARISON")
    print("=" * 75)
    print(policy_df.to_string(index=False))

    print("\nVOLATILITY REGIME CALIBRATION")
    print("=" * 75)
    print(volatility_report.to_string(index=False))

    print("\nMONTHLY CALIBRATION SAMPLE")
    print(monthly.head(12).to_string(index=False))

    print("\nOUTPUTS")
    print(f"Models: {model_dir}")
    print(f"Reports: {report_dir}")
    print(f"Elapsed seconds: {time.time() - start:.2f}")

    print("\nCompleted successfully.")


if __name__ == "__main__":
    main()
