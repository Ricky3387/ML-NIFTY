#!/usr/bin/env python3
"""
NIFTY target-label audit v3: exact-timestamp persistence and ATR comparison.

Save as:
  <project_root>/scripts/audit_nifty_target_labels_v3.py

Run from project root:
  python scripts/audit_nifty_target_labels_v3.py

Reads (does not modify):
  data/processed/nifty_features_v1/nifty_features_labels_long.parquet
  data/processed/nifty_index_cleaned/nifty_index_cleaned_final.parquet

Writes:
  reports/nifty_label_audit_v3/

Important:
- Persistence/transition comparisons use exact timestamp joins, never row shifts
  over a filtered eligible population.
- "Next horizon" means the label observed exactly h clock minutes later.
- ATR14 is a 14-bar SMA of true range within the same trading day.
- ATR labels are alternative descriptive labels; this script does not select
  thresholds, retrain models, or claim predictive performance.
- Assumes the current bar is complete at prediction time (end-of-bar).
"""
from pathlib import Path
import json
import time
import logging
import numpy as np
import pandas as pd

START = time.time()
HORIZONS = (5, 15, 30)
Z_THRESHOLDS = (0.50, 0.75, 1.00, 1.25)
ATR_THRESHOLDS = (0.25, 0.50, 0.75)
CLASSES = ("DOWN", "SIDEWAYS", "UP")


def classify(values, threshold):
    values = np.asarray(values, dtype=float)
    return np.select(
        [values <= -threshold, values >= threshold],
        ["DOWN", "UP"],
        default="SIDEWAYS"
    )


def class_stats(series, prefix=""):
    counts = series.value_counts()
    total = int(series.notna().sum())
    result = {"samples": total}
    for cls in CLASSES:
        result[f"{prefix}{cls.lower()}_count"] = int(counts.get(cls, 0))
        result[f"{prefix}{cls.lower()}_pct"] = (
            float(counts.get(cls, 0) / total * 100) if total else None
        )
    return result


def safe_pct(n, d):
    return float(n / d * 100) if d else None


def main():
    script_dir = Path(__file__).resolve().parent
    root = script_dir.parent if script_dir.name.lower() == "scripts" else script_dir
    feature_path = root / "data/processed/nifty_features_v1/nifty_features_labels_long.parquet"
    clean_path = root / "data/processed/nifty_index_cleaned/nifty_index_cleaned_final.parquet"
    out = root / "reports/nifty_label_audit_v3"
    out.mkdir(parents=True, exist_ok=True)

    logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(message)s")
    log = logging.getLogger("nifty_label_audit_v3")
    for path in (feature_path, clean_path):
        if not path.exists():
            raise FileNotFoundError(f"Required input missing: {path}")

    log.info("Loading v1 features and labels")
    features = pd.read_parquet(feature_path)
    required = {
        "timestamp_ist", "trading_day", "horizon_minutes", "close",
        "future_close", "target_z", "label", "sample_eligible",
        "realized_vol_60m"
    }
    missing = required - set(features.columns)
    if missing:
        raise RuntimeError(f"Feature file missing required columns: {sorted(missing)}")

    features["timestamp_ist"] = pd.to_datetime(features["timestamp_ist"])
    features["trading_day"] = pd.to_datetime(features["trading_day"]).dt.strftime("%Y-%m-%d")
    features["horizon_minutes"] = features["horizon_minutes"].astype(int)
    features = features[features["horizon_minutes"].isin(HORIZONS)].copy()
    features["year"] = pd.to_datetime(features["trading_day"]).dt.year
    eligible = features[features["sample_eligible"].astype(bool)].copy()
    if eligible.empty:
        raise RuntimeError("No eligible rows found.")
    if eligible.duplicated(["trading_day", "timestamp_ist", "horizon_minutes"]).any():
        raise RuntimeError("Duplicate eligible keys found for day/timestamp/horizon.")

    log.info("Calculating ATR14 from cleaned one-minute bars")
    bars = pd.read_parquet(clean_path, columns=[
        "timestamp_ist", "trading_day", "high", "low", "close", "is_synthetic"
    ])
    bars["timestamp_ist"] = pd.to_datetime(bars["timestamp_ist"])
    bars["trading_day"] = pd.to_datetime(bars["trading_day"]).dt.strftime("%Y-%m-%d")
    bars = bars.sort_values(["trading_day", "timestamp_ist"]).reset_index(drop=True)
    bars["prev_close"] = bars.groupby("trading_day", sort=False)["close"].shift(1)
    tr = pd.concat([
        bars["high"] - bars["low"],
        (bars["high"] - bars["prev_close"]).abs(),
        (bars["low"] - bars["prev_close"]).abs()
    ], axis=1).max(axis=1)
    bars["true_range"] = tr
    bars["atr14"] = bars.groupby("trading_day", sort=False)["true_range"].transform(
        lambda s: s.rolling(14, min_periods=14).mean()
    )
    atr = bars[["trading_day", "timestamp_ist", "atr14", "is_synthetic"]].rename(
        columns={"is_synthetic": "source_bar_synthetic"}
    )
    eligible = eligible.merge(
        atr, on=["trading_day", "timestamp_ist"], how="left", validate="many_to_one"
    )
    eligible["atr_normalized_move"] = (
        eligible["future_close"] - eligible["close"]
    ) / eligible["atr14"]
    if eligible["atr14"].isna().any() or (eligible["atr14"] <= 0).any():
        raise RuntimeError("Missing or non-positive ATR14 found among eligible samples.")
    if eligible["source_bar_synthetic"].fillna(True).any():
        raise RuntimeError("Eligible rows matched synthetic/missing source bars.")

    # Alternative ATR labels at the three thresholds, with same sample keys.
    for threshold in ATR_THRESHOLDS:
        eligible[f"atr_label_{threshold:.2f}"] = classify(
            eligible["atr_normalized_move"], threshold
        )

    log.info("Writing target distribution and threshold sensitivity")
    dist_rows, z_sens, atr_sens = [], [], []
    for h, g in eligible.groupby("horizon_minutes"):
        for metric in ("target_z", "atr_normalized_move"):
            s = g[metric].replace([np.inf, -np.inf], np.nan).dropna()
            qs = s.quantile([.001, .01, .05, .10, .25, .50, .75, .90, .95, .99, .999])
            row = {
                "horizon_minutes": int(h), "metric": metric, "samples": int(len(s)),
                "mean": float(s.mean()), "std": float(s.std()),
                "min": float(s.min()), "max": float(s.max())
            }
            for q, v in qs.items():
                row[f"p{q*100:g}"] = float(v)
            dist_rows.append(row)
        for threshold in Z_THRESHOLDS:
            labels = pd.Series(classify(g["target_z"], threshold), index=g.index)
            z_sens.append({
                "horizon_minutes": int(h), "threshold_abs_z": threshold,
                **class_stats(labels)
            })
        for threshold in ATR_THRESHOLDS:
            labels = g[f"atr_label_{threshold:.2f}"]
            atr_sens.append({
                "horizon_minutes": int(h), "threshold_atr": threshold,
                **class_stats(labels)
            })
    pd.DataFrame(dist_rows).to_csv(out / "target_distribution.csv", index=False)
    pd.DataFrame(z_sens).to_csv(out / "z_threshold_sensitivity.csv", index=False)
    pd.DataFrame(atr_sens).to_csv(out / "atr_threshold_sensitivity.csv", index=False)

    log.info("Comparing z-score and ATR labels on identical sample keys")
    comparison_rows, confusion_rows = [], []
    for h, g in eligible.groupby("horizon_minutes"):
        for threshold in ATR_THRESHOLDS:
            atr_col = f"atr_label_{threshold:.2f}"
            z_label = pd.Series(classify(g["target_z"], .50), index=g.index, name="z_label")
            compare = pd.DataFrame({
                "z_label": z_label,
                "atr_label": g[atr_col]
            })
            comparison_rows.append({
                "horizon_minutes": int(h), "z_threshold_abs": .50,
                "atr_threshold": threshold,
                "same_label_agreement_pct": safe_pct(
                    int((compare.z_label == compare.atr_label).sum()), len(compare)
                ),
                "z_label_samples": int(compare.z_label.notna().sum()),
                "atr_label_samples": int(compare.atr_label.notna().sum())
            })
            tab = pd.crosstab(compare["z_label"], compare["atr_label"], dropna=False)
            for from_label in CLASSES:
                for to_label in CLASSES:
                    confusion_rows.append({
                        "horizon_minutes": int(h), "z_threshold_abs": .50,
                        "atr_threshold": threshold, "z_label": from_label,
                        "atr_label": to_label, "samples": int(
                            tab.loc[from_label, to_label]
                            if from_label in tab.index and to_label in tab.columns else 0
                        )
                    })
    pd.DataFrame(comparison_rows).to_csv(out / "z_vs_atr_agreement.csv", index=False)
    pd.DataFrame(confusion_rows).to_csv(out / "z_vs_atr_confusion.csv", index=False)

    log.info("Checking class distribution by year and volatility regime")
    year_rows, regime_rows = [], []
    for h, g in eligible.groupby("horizon_minutes"):
        for year, gy in g.groupby("year"):
            for scheme, col in [
                ("z_0.50", "label"),
                ("atr_0.25", "atr_label_0.25"),
                ("atr_0.50", "atr_label_0.50"),
                ("atr_0.75", "atr_label_0.75")
            ]:
                stats = class_stats(gy[col])
                year_rows.append({
                    "horizon_minutes": int(h), "year": int(year),
                    "label_scheme": scheme, **stats
                })

        train_vol = g.loc[g["year"] <= 2023, "realized_vol_60m"].dropna()
        q1, q2 = train_vol.quantile([1/3, 2/3]).tolist()
        regime = pd.cut(
            g["realized_vol_60m"],
            bins=[-np.inf, q1, q2, np.inf],
            labels=["LOW", "MEDIUM", "HIGH"],
            include_lowest=True
        )
        g2 = g.assign(volatility_regime=regime)
        for bucket, gb in g2.groupby("volatility_regime", observed=False):
            for scheme, col in [
                ("z_0.50", "label"),
                ("atr_0.25", "atr_label_0.25"),
                ("atr_0.50", "atr_label_0.50"),
                ("atr_0.75", "atr_label_0.75")
            ]:
                regime_rows.append({
                    "horizon_minutes": int(h), "volatility_regime": str(bucket),
                    "label_scheme": scheme, "train_vol_q1": float(q1),
                    "train_vol_q2": float(q2), **class_stats(gb[col])
                })
    pd.DataFrame(year_rows).to_csv(out / "class_distribution_by_year.csv", index=False)
    pd.DataFrame(regime_rows).to_csv(out / "class_distribution_by_volatility.csv", index=False)

    log.info("Exact-timestamp persistence and transition calculations")
    persistence_rows, transition_rows = [], []
    # Lookup includes eligible labels only. Exact timestamp matching prevents
    # filtered-row shifts from silently skipping ineligible/missing minutes.
    lookup = eligible[[
        "trading_day", "timestamp_ist", "horizon_minutes", "label"
    ]].rename(columns={
        "timestamp_ist": "matched_timestamp",
        "label": "matched_label"
    })
    for h, g in eligible.groupby("horizon_minutes"):
        g = g.copy()
        for comparison, offset in (("next_minute_exact", 1), ("next_horizon_exact", int(h))):
            left = g[["trading_day", "timestamp_ist", "label"]].copy()
            left["requested_timestamp"] = left["timestamp_ist"] + pd.Timedelta(minutes=offset)
            matched = left.merge(
                lookup[lookup["horizon_minutes"] == h],
                left_on=["trading_day", "requested_timestamp"],
                right_on=["trading_day", "matched_timestamp"],
                how="inner",
                validate="one_to_one"
            )
            directional = matched[matched["label"].isin(["DOWN", "UP"])]
            directional_to_directional = directional["matched_label"].isin(["DOWN", "UP"])
            same_direction = directional["label"] == directional["matched_label"]
            persistence_rows.append({
                "horizon_minutes": int(h), "comparison": comparison,
                "exact_offset_minutes": int(offset),
                "compared_samples": int(len(matched)),
                "same_label_pct": safe_pct(
                    int((matched["label"] == matched["matched_label"]).sum()), len(matched)
                ),
                "starting_directional_samples": int(len(directional)),
                "directional_to_directional_pct": safe_pct(
                    int(directional_to_directional.sum()), len(directional)
                ),
                "same_direction_given_directional_to_directional_pct": safe_pct(
                    int(same_direction[directional_to_directional].sum()),
                    int(directional_to_directional.sum())
                )
            })
            if comparison == "next_minute_exact":
                trans = matched.groupby(["label", "matched_label"]).size()
                row_totals = matched.groupby("label").size().to_dict()
                for (a, b), n in trans.items():
                    transition_rows.append({
                        "horizon_minutes": int(h), "from_label": a,
                        "to_exact_next_minute_label": b, "transitions": int(n),
                        "from_label_total": int(row_totals[a]),
                        "transition_pct_of_from_label": safe_pct(int(n), int(row_totals[a]))
                    })
    pd.DataFrame(persistence_rows).to_csv(out / "directional_persistence_exact.csv", index=False)
    pd.DataFrame(transition_rows).to_csv(out / "label_transition_rates_exact.csv", index=False)

    log.info("Persistence by year and volatility regime (exact +1 minute)")
    persistence_segment_rows = []
    for h, g in eligible.groupby("horizon_minutes"):
        left = g[["trading_day", "timestamp_ist", "year", "realized_vol_60m", "label"]].copy()
        left["requested_timestamp"] = left["timestamp_ist"] + pd.Timedelta(minutes=1)
        right = lookup[lookup["horizon_minutes"] == h]
        matched = left.merge(
            right, left_on=["trading_day", "requested_timestamp"],
            right_on=["trading_day", "matched_timestamp"],
            how="inner", validate="one_to_one"
        )
        train_vol = g.loc[g["year"] <= 2023, "realized_vol_60m"].dropna()
        q1, q2 = train_vol.quantile([1/3, 2/3]).tolist()
        matched["volatility_regime"] = pd.cut(
            matched["realized_vol_60m"],
            bins=[-np.inf, q1, q2, np.inf],
            labels=["LOW", "MEDIUM", "HIGH"], include_lowest=True
        )
        matched["same_label"] = matched["label"] == matched["matched_label"]
        matched["directional_start"] = matched["label"].isin(["DOWN", "UP"])
        matched["directional_end"] = matched["matched_label"].isin(["DOWN", "UP"])
        for dimension in ("year", "volatility_regime"):
            for bucket, gb in matched.groupby(dimension, observed=False):
                persistence_segment_rows.append({
                    "horizon_minutes": int(h), "segment_type": dimension,
                    "segment": str(bucket), "samples": int(len(gb)),
                    "same_label_pct": float(gb["same_label"].mean() * 100) if len(gb) else None,
                    "starting_directional_samples": int(gb["directional_start"].sum()),
                    "directional_to_directional_pct": safe_pct(
                        int((gb["directional_start"] & gb["directional_end"]).sum()),
                        int(gb["directional_start"].sum())
                    ),
                    "same_direction_given_directional_pct": safe_pct(
                        int(((gb["label"] == gb["matched_label"]) &
                             gb["directional_start"] & gb["directional_end"]).sum()),
                        int((gb["directional_start"] & gb["directional_end"]).sum())
                    )
                })
    pd.DataFrame(persistence_segment_rows).to_csv(
        out / "persistence_by_year_and_volatility.csv", index=False
    )

    log.info("Cross-horizon agreement")
    wide = eligible.pivot_table(
        index=["trading_day", "timestamp_ist"], columns="horizon_minutes",
        values="label", aggfunc="first"
    ).dropna()
    cross = {
        "common_timestamp_count": int(len(wide)),
        "agreement_5m_15m_pct": safe_pct(int((wide[5] == wide[15]).sum()), len(wide)),
        "agreement_5m_30m_pct": safe_pct(int((wide[5] == wide[30]).sum()), len(wide)),
        "agreement_15m_30m_pct": safe_pct(int((wide[15] == wide[30]).sum()), len(wide)),
        "all_three_agree_pct": safe_pct(
            int(((wide[5] == wide[15]) & (wide[15] == wide[30])).sum()), len(wide)
        )
    }
    pd.DataFrame([cross]).to_csv(out / "cross_horizon_label_agreement.csv", index=False)

    summary = {
        "status": "LABEL_AUDIT_V3_COMPLETED_REVIEW_REQUIRED",
        "feature_rows": int(len(features)),
        "eligible_rows": int(len(eligible)),
        "eligible_rows_by_horizon": {
            str(int(h)): int(len(g)) for h, g in eligible.groupby("horizon_minutes")
        },
        "persistence_method": "Exact same-trading-day timestamp joins; no filtered-row shift.",
        "next_minute_definition": "timestamp_ist + exactly 1 clock minute",
        "next_horizon_definition": "timestamp_ist + exactly horizon_minutes clock minutes",
        "atr_definition": "14-bar simple moving average of true range within each trading day",
        "atr_target": "(future_close - current_close) / ATR14",
        "atr_thresholds_tested": list(ATR_THRESHOLDS),
        "z_thresholds_tested": list(Z_THRESHOLDS),
        "cross_horizon_agreement": cross,
        "prediction_timing_assumption": "Current one-minute bar is complete; prediction is made at its close.",
        "caveats": [
            "Threshold comparisons are descriptive, not a threshold selection or optimization result.",
            "ATR labels and z-score labels are compared on the same eligible sample keys.",
            "Persistence is descriptive and adjacent forward targets overlap; it is not independent evidence of predictability.",
            "Exact timestamp joins require a target timestamp to exist and be eligible; missing/ineligible minutes are not bridged.",
            "Volatility regime cutoffs are estimated from 2021-2023 TRAIN data and then applied to all years.",
            "2024 has already been used for model diagnostics; do not repeatedly optimize on it and call it untouched test.",
            "No model training, threshold selection, trading recommendation, or profitability claim is performed."
        ],
        "elapsed_seconds": round(time.time() - START, 2)
    }
    (out / "audit_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))
    print(f"REPORTS: {out}")


if __name__ == "__main__":
    main()
