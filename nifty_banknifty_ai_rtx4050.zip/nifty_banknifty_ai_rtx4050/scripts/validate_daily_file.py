
from pathlib import Path
import pandas as pd
import pyarrow.parquet as pq
import sys
import gc
import csv

# --------------------------------------------------
# CONFIGURATION
# --------------------------------------------------

DEFAULT_PATH = Path("data/raw/india-index-options-1m")
REPORT_DIR = Path("data/reports")

REPORT_DIR.mkdir(parents=True, exist_ok=True)

REQUIRED_COLUMNS = {
    "timestamp",
    "symbol",
    "trading_day",
    "open",
    "high",
    "low",
    "close",
    "volume",
    "open_interest",
    "expiry",
    "strike",
    "option_type",
}

CONTRACT_KEY = [
    "symbol",
    "expiry",
    "strike",
    "option_type",
]

# --------------------------------------------------
# INPUT PATH
# --------------------------------------------------

INPUT_PATH = Path(sys.argv[1]) if len(sys.argv) > 1 else DEFAULT_PATH

if not INPUT_PATH.exists():
    raise SystemExit(f"Path not found: {INPUT_PATH.resolve()}")

if INPUT_PATH.is_file():
    if INPUT_PATH.suffix.lower() != ".parquet":
        raise SystemExit("Input file must be a Parquet file.")
    files = [INPUT_PATH]

elif INPUT_PATH.is_dir():
    files = sorted(INPUT_PATH.rglob("*.parquet"))

else:
    raise SystemExit("Input must be a Parquet file or folder.")

if not files:
    raise SystemExit(f"No Parquet files found in {INPUT_PATH.resolve()}")

print("=" * 80)
print("NIFTY / BANKNIFTY DATA VALIDATION")
print("=" * 80)
print("Input:", INPUT_PATH.resolve())
print("Files found:", len(files))

# --------------------------------------------------
# VALIDATE ONE FILE
# --------------------------------------------------

def validate_file(file_path):

    result = {
        "file": str(file_path),
        "status": "SUCCESS",
        "rows": 0,
        "missing_columns": "",
        "null_cells": 0,
        "duplicate_rows": 0,
        "invalid_ohlc_rows": 0,
        "negative_volume_rows": 0,
        "negative_oi_rows": 0,
        "timestamp_min": "",
        "timestamp_max": "",
        "unique_symbols": 0,
        "unique_expiries": 0,
        "unique_strikes": 0,
        "option_types": "",
        "gaps_gt_1min": 0,
        "error": "",
    }

    df = None

    try:
        print("\n" + "-" * 80)
        print("Processing:", file_path)

        # Read only the current file
        df = pq.read_table(file_path).to_pandas()

        result["rows"] = len(df)

        # Schema validation
        missing = REQUIRED_COLUMNS - set(df.columns)
        result["missing_columns"] = ",".join(sorted(missing))

        if missing:
            result["status"] = "SCHEMA_WARNING"
            print("Missing columns:", sorted(missing))

        if "timestamp" not in df.columns:
            raise ValueError("timestamp column is missing")

        # Null validation
        result["null_cells"] = int(df.isna().sum().sum())

        # Timestamp validation
        df["timestamp"] = pd.to_datetime(
            df["timestamp"],
            errors="coerce"
        )

        invalid_timestamps = int(df["timestamp"].isna().sum())

        result["null_cells"] += invalid_timestamps

        valid_timestamps = df["timestamp"].dropna()

        if not valid_timestamps.empty:
            result["timestamp_min"] = str(valid_timestamps.min())
            result["timestamp_max"] = str(valid_timestamps.max())

        # Symbol statistics
        if "symbol" in df.columns:
            result["unique_symbols"] = df["symbol"].nunique()

        if "expiry" in df.columns:
            result["unique_expiries"] = df["expiry"].nunique()

        if "strike" in df.columns:
            result["unique_strikes"] = df["strike"].nunique()

        if "option_type" in df.columns:
            result["option_types"] = ",".join(
                sorted(df["option_type"].dropna().astype(str).unique())
            )

        # Duplicate contract candles
        duplicate_key = [
            col for col in
            ["timestamp"] + CONTRACT_KEY
            if col in df.columns
        ]

        if len(duplicate_key) == 5:
            result["duplicate_rows"] = int(
                df.duplicated(
                    subset=duplicate_key,
                    keep=False
                ).sum()
            )

        # OHLC validation
        ohlc_columns = {"open", "high", "low", "close"}

        if ohlc_columns.issubset(df.columns):

            prices = df[
                ["open", "high", "low", "close"]
            ]

            # Convert values to numeric safely
            prices = prices.apply(
                pd.to_numeric,
                errors="coerce"
            )

            invalid_ohlc = (
                prices.isna().any(axis=1) |
                (prices <= 0).any(axis=1) |
                (df["high"] < df["low"]) |
                (df["high"] < prices[["open", "close"]].max(axis=1)) |
                (df["low"] > prices[["open", "close"]].min(axis=1))
            )

            result["invalid_ohlc_rows"] = int(
                invalid_ohlc.sum()
            )


        # Negative volume
        if "volume" in df.columns:
            result["negative_volume_rows"] = int(
                (df["volume"] < 0).sum()
            )

        # Negative open interest
        if "open_interest" in df.columns:
            result["negative_oi_rows"] = int(
                (df["open_interest"] < 0).sum()
            )

        # Missing one-minute intervals
        # Calculated separately for each contract.
        if all(col in df.columns for col in CONTRACT_KEY):

            options = df.dropna(
                subset=["timestamp"] + CONTRACT_KEY
            )

            options = options.sort_values(
                CONTRACT_KEY + ["timestamp"]
            )

            gaps = (
                options.groupby(
                    CONTRACT_KEY,
                    dropna=False
                )["timestamp"]
                .diff()
            )

            result["gaps_gt_1min"] = int(
                (gaps > pd.Timedelta(minutes=1)).sum()
            )

        print("Rows:", f"{result['rows']:,}")
        print("Null cells:", result["null_cells"])
        print("Duplicates:", result["duplicate_rows"])
        print("Invalid OHLC:", result["invalid_ohlc_rows"])
        print("Negative volume:", result["negative_volume_rows"])
        print("Negative OI:", result["negative_oi_rows"])
        print("Timestamp range:",
              result["timestamp_min"], "to",
              result["timestamp_max"])
        print("Gaps > 1 minute:", result["gaps_gt_1min"])
        print("Status:", result["status"])

    except Exception as exc:
        result["status"] = "FAILED"
        result["error"] = str(exc)
        print("ERROR:", exc)

    finally:
        if df is not None:
            del df
        gc.collect()

    return result


# --------------------------------------------------
# PROCESS ALL FILES
# --------------------------------------------------

results = []

for index, file_path in enumerate(files, start=1):

    print(f"\nFILE {index}/{len(files)}")

    result = validate_file(file_path)
    results.append(result)


# --------------------------------------------------
# SAVE CONSOLIDATED REPORT
# --------------------------------------------------

report_file = REPORT_DIR / "validation_summary.csv"

with open(
    report_file,
    "w",
    newline="",
    encoding="utf-8"
) as output:

    writer = csv.DictWriter(
        output,
        fieldnames=list(results[0].keys())
    )

    writer.writeheader()
    writer.writerows(results)


# --------------------------------------------------
# FINAL SUMMARY
# --------------------------------------------------

summary = pd.DataFrame(results)

print("\n" + "=" * 80)
print("FINAL VALIDATION SUMMARY")
print("=" * 80)

print("Total files:", len(results))
print("Successful:", int((summary["status"] == "SUCCESS").sum()))
print("Schema warnings:", int((summary["status"] == "SCHEMA_WARNING").sum()))
print("Failed:", int((summary["status"] == "FAILED").sum()))

print("Total rows:", f"{summary['rows'].sum():,}")
print("Total duplicate rows:", f"{summary['duplicate_rows'].sum():,}")
print("Total invalid OHLC:", f"{summary['invalid_ohlc_rows'].sum():,}")
print("Total null cells:", f"{summary['null_cells'].sum():,}")
print("Total gaps:", f"{summary['gaps_gt_1min'].sum():,}")

print("\nReport saved:", report_file.resolve())
print("VALIDATION COMPLETED")
