
"""
NIFTY PREDICTION PROBABILITY AUDIT V1

Reads existing prediction parquet files.
Does NOT retrain or modify any model.

Outputs:
- one_vs_rest_metrics.csv
- actual_class_probability_means.csv
- actual_class_probability_quantiles.csv
- directional_threshold_analysis.csv
- confidence_margin_summary.csv
- probability_audit_summary.json
"""

from pathlib import Path
import json
import sys

import numpy as np
import pandas as pd

from sklearn.metrics import (
    roc_auc_score,
    average_precision_score,
    brier_score_loss,
    log_loss,
)

ROOT = Path(__file__).resolve().parents[1]

REPORT_ROOT = ROOT / "reports" / "nifty_feature_ablation_v1"

CLASSES = ["DOWN", "SIDEWAYS", "UP"]

PROB_COLS = [
    "prob_down",
    "prob_sideways",
    "prob_up",
]

# Primary models for the detailed audit.
SELECTED_MODELS = {
    "B_combined_5m": 5,
    "C_experimental_15m": 15,
    "C_experimental_30m": 30,
}

# Also inspect all nine models.
AUDIT_ALL_NINE_MODELS = True

THRESHOLDS = [
    0.30,
    0.35,
    0.40,
    0.45,
    0.50,
    0.55,
    0.60,
    0.65,
    0.70,
    0.75,
    0.80,
]

EPS = 1e-12


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def find_latest_run():
    require(
        REPORT_ROOT.exists(),
        f"Report directory missing: {REPORT_ROOT}",
    )

    runs = [
        p for p in REPORT_ROOT.iterdir()
        if p.is_dir()
    ]

    require(runs, "No ablation run folders found")

    runs.sort(
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )

    for run in runs:
        if list(run.glob("*_predictions.parquet")):
            return run

    raise RuntimeError(
        "No prediction parquet files found"
    )


def load_predictions(path):
    df = pd.read_parquet(path)

    required = [
                   "timestamp_ist",
                   "trading_day",
                   "label",
                   "predicted_label",
               ] + PROB_COLS

    missing = set(required) - set(df.columns)

    require(
        not missing,
        f"{path.name}: missing columns {sorted(missing)}",
    )

    require(
        df["label"].isin(CLASSES).all(),
        "Unexpected actual labels",
    )

    probabilities = df[PROB_COLS].to_numpy(
        dtype=np.float64
    )

    require(
        np.isfinite(probabilities).all(),
        "Invalid probability values",
    )

    require(
        (probabilities >= 0).all()
        and (probabilities <= 1).all(),
        "Probability outside [0,1]",
        )

    sums = probabilities.sum(axis=1)

    require(
        np.allclose(sums, 1.0, atol=1e-5),
        "Class probabilities do not sum to one",
    )

    require(
        df["predicted_label"].isin(CLASSES).all(),
        "Unexpected predicted labels",
    )

    return df


def calculate_model_audit(name, df):
    y = df["label"].to_numpy()
    p = df[PROB_COLS].to_numpy(dtype=np.float64)

    rows = []
    mean_rows = []
    quantile_rows = []
    threshold_rows = []

    one_hot = np.column_stack([
        (y == cls).astype(int)
        for cls in CLASSES
    ])

    # Probability quality and ranking
    for index, cls in enumerate(CLASSES):
        target = one_hot[:, index]
        scores = p[:, index]

        auc = roc_auc_score(target, scores)
        ap = average_precision_score(target, scores)
        brier = brier_score_loss(target, scores)

        rows.append({
            "model": name,
            "class": cls,
            "actual_prevalence": float(target.mean()),
            "roc_auc": float(auc),
            "average_precision": float(ap),
            "brier_score": float(brier),
        })

        # Probability by actual class
        for actual_cls in CLASSES:
            values = scores[y == actual_cls]

            mean_rows.append({
                "model": name,
                "probability_class": cls,
                "actual_class": actual_cls,
                "count": len(values),
                "mean_probability": float(values.mean()),
                "median_probability": float(
                    np.median(values)
                ),
            })

            for quantile in [
                0.05, 0.10, 0.25, 0.50,
                0.75, 0.90, 0.95,
            ]:
                quantile_rows.append({
                    "model": name,
                    "probability_class": cls,
                    "actual_class": actual_cls,
                    "quantile": quantile,
                    "probability": float(
                        np.quantile(values, quantile)
                    ),
                })

        # One-vs-rest threshold analysis
        for threshold in THRESHOLDS:
            selected = scores >= threshold

            tp = int(
                np.sum(selected & (target == 1))
            )
            fp = int(
                np.sum(selected & (target == 0))
            )
            fn = int(
                np.sum(~selected & (target == 1))
            )

            coverage = float(selected.mean())

            precision = (
                tp / (tp + fp)
                if tp + fp else 0.0
            )

            recall = (
                tp / (tp + fn)
                if tp + fn else 0.0
            )

            threshold_rows.append({
                "model": name,
                "class": cls,
                "threshold": threshold,
                "selected_count": int(selected.sum()),
                "coverage_pct": 100 * coverage,
                "precision": precision,
                "recall": recall,
            })

    # Overall multiclass log-loss
    class_to_index = {
        cls: i for i, cls in enumerate(CLASSES)
    }

    y_encoded = np.array([
        class_to_index[x] for x in y
    ])

    overall_logloss = log_loss(
        y_encoded,
        p,
        labels=[0, 1, 2],
    )

    # Top probability and second-best margin
    sorted_p = np.sort(p, axis=1)

    max_probability = sorted_p[:, -1]
    second_probability = sorted_p[:, -2]

    margins = max_probability - second_probability

    predicted = np.array([
        CLASSES[i] for i in np.argmax(p, axis=1)
    ])

    confidence_rows = []

    for correct in [True, False]:
        mask = (predicted == y) == correct

        if mask.sum() == 0:
            continue

        confidence_rows.append({
            "model": name,
            "prediction_status": (
                "correct" if correct else "incorrect"
            ),
            "count": int(mask.sum()),
            "mean_max_probability": float(
                max_probability[mask].mean()
            ),
            "median_max_probability": float(
                np.median(max_probability[mask])
            ),
            "mean_probability_margin": float(
                margins[mask].mean()
            ),
            "median_probability_margin": float(
                np.median(margins[mask])
            ),
        })

    # Directional ranking comparison
    directional_rows = []

    for cls in ["DOWN", "UP"]:
        idx = CLASSES.index(cls)
        scores = p[:, idx]
        positive = y == cls

        directional_rows.append({
            "model": name,
            "class": cls,
            "positive_mean_probability": float(
                scores[positive].mean()
            ),
            "negative_mean_probability": float(
                scores[~positive].mean()
            ),
            "mean_probability_difference": float(
                scores[positive].mean()
                - scores[~positive].mean()
            ),
            "positive_median_probability": float(
                np.median(scores[positive])
            ),
            "negative_median_probability": float(
                np.median(scores[~positive])
            ),
        })

    return {
        "one_vs_rest": rows,
        "means": mean_rows,
        "quantiles": quantile_rows,
        "thresholds": threshold_rows,
        "confidence": confidence_rows,
        "directional": directional_rows,
        "summary": {
            "model": name,
            "rows": len(df),
            "logloss": float(overall_logloss),
            "accuracy": float(
                np.mean(predicted == y)
            ),
            "argmax_sideways_pct": float(
                100 * np.mean(predicted == "SIDEWAYS")
            ),
            "mean_max_probability": float(
                max_probability.mean()
            ),
            "mean_probability_margin": float(
                margins.mean()
            ),
        },
    }


def main():
    run_dir = find_latest_run()

    audit_dir = run_dir / "probability_audit_v1"
    audit_dir.mkdir(
        parents=True,
        exist_ok=False,
    )

    print("=" * 80)
    print("NIFTY PROBABILITY DISCRIMINATION AUDIT")
    print("=" * 80)
    print(f"Source run: {run_dir}")

    files = sorted(
        run_dir.glob("*_predictions.parquet")
    )

    if not AUDIT_ALL_NINE_MODELS:
        required_names = set(SELECTED_MODELS)

        files = [
            f for f in files
            if f.stem.replace(
                "_predictions", ""
            ) in required_names
        ]

    require(
        len(files) > 0,
        "No prediction files found",
        )

    results = []

    for path in files:
        model_name = path.stem.replace(
            "_predictions", ""
        )

        print(f"\nAuditing {model_name}...")

        df = load_predictions(path)

        result = calculate_model_audit(
            model_name,
            df,
        )

        results.append(result)

        print(
            f"Rows: {result['summary']['rows']:,} | "
            f"Logloss: {result['summary']['logloss']:.5f} | "
            f"Mean margin: "
            f"{result['summary']['mean_probability_margin']:.5f}"
        )

    def flatten(key):
        return [
            row
            for result in results
            for row in result[key]
        ]

    outputs = {
        "one_vs_rest_metrics.csv": "one_vs_rest",
        "actual_class_probability_means.csv": "means",
        "actual_class_probability_quantiles.csv": "quantiles",
        "directional_threshold_analysis.csv": "thresholds",
        "confidence_margin_summary.csv": "confidence",
        "directional_probability_separation.csv": "directional",
    }

    for filename, key in outputs.items():
        pd.DataFrame(
            flatten(key)
        ).to_csv(
            audit_dir / filename,
            index=False,
            )

    summary = {
        "source_run": str(run_dir),
        "models_audited": len(results),
        "models": [
            result["summary"]
            for result in results
        ],
        "interpretation_notes": [
            "ROC-AUC measures ranking discrimination, not profitability.",
            "Average precision depends on class prevalence.",
            "Threshold analysis is diagnostic, not a trading rule.",
            "2024 remains a previously used diagnostic period.",
            "No thresholds were optimized for deployment.",
        ],
    }

    (audit_dir / "probability_audit_summary.json").write_text(
        json.dumps(summary, indent=2),
        encoding="utf-8",
    )

    print("\n" + "=" * 80)
    print("AUDIT COMPLETE")
    print("=" * 80)
    print(f"Output: {audit_dir}")

    print("\nOne-vs-rest ROC-AUC:")
    print(
        pd.DataFrame(flatten("one_vs_rest"))[
            ["model", "class", "roc_auc", "average_precision"]
        ].to_string(index=False)
    )


if __name__ == "__main__":
    main()
