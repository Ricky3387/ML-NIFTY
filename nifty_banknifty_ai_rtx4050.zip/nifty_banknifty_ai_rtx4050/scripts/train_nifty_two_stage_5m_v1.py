
from pathlib import Path
from datetime import datetime
import json
import time
import warnings

import joblib
import lightgbm as lgb
import numpy as np
import pandas as pd

from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    log_loss,
    roc_auc_score,
    average_precision_score,
)

warnings.filterwarnings("ignore", category=UserWarning)

# ============================================================
# CONFIGURATION
# ============================================================

ROOT = Path(__file__).resolve().parents[1]

DATA_DIR = ROOT / "data" / "processed" / "nifty_walkforward_v1"
MODEL_ROOT = ROOT / "models" / "nifty_two_stage_5m_v1"
REPORT_ROOT = ROOT / "reports" / "nifty_two_stage_5m_v1"

TRAIN_FILE = DATA_DIR / "train_5m.parquet"
VALIDATION_FILE = DATA_DIR / "validation_5m.parquet"

SEED = 42
MAX_ESTIMATORS = 1800
LEARNING_RATE = 0.025
NUM_LEAVES = 31
MIN_CHILD_SAMPLES = 100
EARLY_STOPPING_ROUNDS = 100

LABELS = ["DOWN", "SIDEWAYS", "UP"]

FEATURES = [
    "ret_1m",
    "logret_1m",
    "range_pct",
    "body_pct",
    "upper_wick_pct",
    "lower_wick_pct",
    "return_5m",
    "return_15m",
    "return_30m",
    "return_60m",
    "realized_vol_5m",
    "realized_vol_15m",
    "realized_vol_30m",
    "realized_vol_60m",
    "high_low_range_5m",
    "high_low_range_15m",
    "high_low_range_30m",
    "high_low_range_60m",
    "close_vs_ema9_pct",
    "close_vs_ema21_pct",
    "close_vs_ema50_pct",
    "rsi_14",
    "positive_return_count_5m",
    "negative_return_count_5m",
    "target_vol_scale",
]


# ============================================================
# HELPERS
# ============================================================

def create_run_directories():
    run_id = datetime.now().strftime("%Y%m%d_%H%M%S")
    model_dir = MODEL_ROOT / run_id
    report_dir = REPORT_ROOT / run_id

    model_dir.mkdir(parents=True, exist_ok=False)
    report_dir.mkdir(parents=True, exist_ok=False)

    return run_id, model_dir, report_dir


def load_data():
    if not TRAIN_FILE.exists():
        raise FileNotFoundError(f"Missing file: {TRAIN_FILE}")

    if not VALIDATION_FILE.exists():
        raise FileNotFoundError(f"Missing file: {VALIDATION_FILE}")

    train = pd.read_parquet(TRAIN_FILE)
    validation = pd.read_parquet(VALIDATION_FILE)

    required = (
            FEATURES
            + [
                "timestamp_ist",
                "trading_day",
                "label",
                "sample_eligible",
            ]
    )

    for name, df in [
        ("train", train),
        ("validation", validation),
    ]:
        missing = sorted(set(required) - set(df.columns))
        if missing:
            raise ValueError(
                f"{name} dataset missing columns: {missing}"
            )

        df["trading_day"] = pd.to_datetime(
            df["trading_day"]
        ).dt.date

        df["label"] = df["label"].astype(str).str.upper()

        df = df.loc[
            df["sample_eligible"].astype(bool)
            & df["label"].isin(LABELS)
            ].copy()

        if name == "train":
            train = df
        else:
            validation = df

    if train.empty or validation.empty:
        raise ValueError("Training or validation dataset is empty.")

    if train["timestamp_ist"].duplicated().any():
        raise ValueError("Duplicate timestamps found in training data.")

    if validation["timestamp_ist"].duplicated().any():
        raise ValueError("Duplicate timestamps found in validation data.")

    return train, validation


def make_model():
    return lgb.LGBMClassifier(
        objective="binary",
        n_estimators=MAX_ESTIMATORS,
        learning_rate=LEARNING_RATE,
        num_leaves=NUM_LEAVES,
        max_depth=-1,
        min_child_samples=MIN_CHILD_SAMPLES,
        subsample=0.8,
        subsample_freq=1,
        colsample_bytree=0.8,
        reg_lambda=2.0,
        random_state=SEED,
        n_jobs=-1,
        verbosity=-1,
    )


def binary_target(series, positive_label):
    return (series.astype(str) == positive_label).astype(int)


def fit_with_early_stopping(
        x_fit,
        y_fit,
        x_early,
        y_early,
        model_name,
):
    if y_fit.nunique() != 2:
        raise ValueError(
            f"{model_name}: fitting data does not contain both classes."
        )

    if y_early.nunique() != 2:
        raise ValueError(
            f"{model_name}: early-stopping data does not contain both classes."
        )

    model = make_model()

    model.fit(
        x_fit,
        y_fit,
        eval_set=[(x_early, y_early)],
        callbacks=[
            lgb.early_stopping(
                EARLY_STOPPING_ROUNDS,
                verbose=False,
            ),
            lgb.log_evaluation(period=0),
        ],
    )

    best_iteration = model.best_iteration_

    if not best_iteration or best_iteration < 1:
        best_iteration = MAX_ESTIMATORS

    print(
        f"{model_name}: best iteration = {best_iteration}"
    )

    return int(best_iteration)


def fit_final_model(x, y, iterations, model_name):
    if y.nunique() != 2:
        raise ValueError(
            f"{model_name}: final training data does not contain both classes."
        )

    model = make_model()
    model.set_params(n_estimators=iterations)
    model.fit(x, y)

    return model


def safe_auc(y_true, probability):
    if len(np.unique(y_true)) != 2:
        return None

    return float(roc_auc_score(y_true, probability))


def safe_average_precision(y_true, probability):
    if len(np.unique(y_true)) != 2:
        return None

    return float(average_precision_score(y_true, probability))


def evaluate_predictions(predictions):
    y_true = predictions["actual_label"].to_numpy()
    y_pred = predictions["predicted_label"].to_numpy()

    probabilities = predictions[
        ["prob_down", "prob_sideways", "prob_up"]
    ].to_numpy()

    label_to_number = {
        "DOWN": 0,
        "SIDEWAYS": 1,
        "UP": 2,
    }

    y_true_num = np.array(
        [label_to_number[x] for x in y_true]
    )

    y_pred_num = np.array(
        [label_to_number[x] for x in y_pred]
    )

    metrics = {
        "evaluation_rows": int(len(predictions)),
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "balanced_accuracy": float(
            balanced_accuracy_score(y_true, y_pred)
        ),
        "macro_f1": float(
            f1_score(
                y_true,
                y_pred,
                labels=LABELS,
                average="macro",
                zero_division=0,
            )
        ),
        "weighted_f1": float(
            f1_score(
                y_true,
                y_pred,
                labels=LABELS,
                average="weighted",
                zero_division=0,
            )
        ),
        "multiclass_logloss": float(
            log_loss(
                y_true_num,
                probabilities,
                labels=[0, 1, 2],
            )
        ),
        "directional_binary_auc": safe_auc(
            (y_true != "SIDEWAYS").astype(int),
            1.0 - predictions["prob_sideways"].to_numpy(),
            ),
        "down_vs_rest_auc": safe_auc(
            (y_true == "DOWN").astype(int),
            predictions["prob_down"].to_numpy(),
        ),
        "up_vs_rest_auc": safe_auc(
            (y_true == "UP").astype(int),
            predictions["prob_up"].to_numpy(),
        ),
        "conditional_down_vs_up_auc": safe_auc(
            (y_true[y_true != "SIDEWAYS"] == "DOWN").astype(int),
            predictions.loc[
                predictions["actual_label"] != "SIDEWAYS",
                "conditional_down_probability",
            ].to_numpy(),
        ),
        "predicted_class_distribution_pct": (
            predictions["predicted_label"]
            .value_counts(normalize=True)
            .mul(100)
            .to_dict()
        ),
        "actual_class_distribution_pct": (
            predictions["actual_label"]
            .value_counts(normalize=True)
            .mul(100)
            .to_dict()
        ),
        "mean_probability": {
            "DOWN": float(predictions["prob_down"].mean()),
            "SIDEWAYS": float(predictions["prob_sideways"].mean()),
            "UP": float(predictions["prob_up"].mean()),
        },
    }

    return metrics


# ============================================================
# MAIN
# ============================================================

def main():
    start = time.time()

    run_id, model_dir, report_dir = create_run_directories()

    print("=" * 75)
    print("NIFTY 5-MINUTE TWO-STAGE CLASSIFIER V1")
    print("=" * 75)
    print(f"Run ID: {run_id}")
    print(f"Project root: {ROOT}")

    train, validation = load_data()

    # --------------------------------------------------------
    # Chronological partitions
    # --------------------------------------------------------

    fit_train = train[
        train["trading_day"] < pd.to_datetime("2023-01-01").date()
        ].copy()

    early_stop = train[
        (train["trading_day"] >= pd.to_datetime("2023-01-01").date())
        & (train["trading_day"] <= pd.to_datetime("2023-12-31").date())
        ].copy()

    final_train = train[
        train["trading_day"] <= pd.to_datetime("2023-12-31").date()
        ].copy()

    if fit_train.empty or early_stop.empty or final_train.empty:
        raise ValueError("Chronological training partition is empty.")

    print("\nDATA PARTITIONS")
    print(f"Fit 2021-2022: {len(fit_train):,}")
    print(f"Early stop 2023: {len(early_stop):,}")
    print(f"Final train 2021-2023: {len(final_train):,}")
    print(f"Diagnostic evaluation 2024: {len(validation):,}")

    # --------------------------------------------------------
    # Stage 1: DIRECTIONAL vs SIDEWAYS
    # --------------------------------------------------------

    print("\n" + "=" * 75)
    print("STAGE 1: DIRECTIONAL VS SIDEWAYS")
    print("=" * 75)

    y1_fit = binary_target(
        fit_train["label"], "DOWN"
    )
    y1_fit = (
            fit_train["label"] != "SIDEWAYS"
    ).astype(int)

    y1_early = (
            early_stop["label"] != "SIDEWAYS"
    ).astype(int)

    y1_final = (
            final_train["label"] != "SIDEWAYS"
    ).astype(int)

    x_fit = fit_train[FEATURES]
    x_early = early_stop[FEATURES]
    x_final = final_train[FEATURES]
    x_validation = validation[FEATURES]

    stage1_best = fit_with_early_stopping(
        x_fit,
        y1_fit,
        x_early,
        y1_early,
        "Stage 1",
    )

    stage1 = fit_final_model(
        x_final,
        y1_final,
        stage1_best,
        "Stage 1",
    )

    # --------------------------------------------------------
    # Stage 2: DOWN vs UP, directional rows only
    # --------------------------------------------------------

    print("\n" + "=" * 75)
    print("STAGE 2: DOWN VS UP")
    print("=" * 75)

    fit_directional = fit_train[
        fit_train["label"].isin(["DOWN", "UP"])
    ]

    early_directional = early_stop[
        early_stop["label"].isin(["DOWN", "UP"])
    ]

    final_directional = final_train[
        final_train["label"].isin(["DOWN", "UP"])
    ]

    print(
        f"Stage 2 fit rows: {len(fit_directional):,}"
    )
    print(
        f"Stage 2 early-stop rows: {len(early_directional):,}"
    )
    print(
        f"Stage 2 final rows: {len(final_directional):,}"
    )

    y2_fit = (
            fit_directional["label"] == "UP"
    ).astype(int)

    y2_early = (
            early_directional["label"] == "UP"
    ).astype(int)

    y2_final = (
            final_directional["label"] == "UP"
    ).astype(int)

    stage2_best = fit_with_early_stopping(
        fit_directional[FEATURES],
        y2_fit,
        early_directional[FEATURES],
        y2_early,
        "Stage 2",
    )

    stage2 = fit_final_model(
        x=final_directional[FEATURES],
        y=y2_final,
        iterations=stage2_best,
        model_name="Stage 2",
    )

    # --------------------------------------------------------
    # Combine probabilities on 2024
    # --------------------------------------------------------

    print("\n" + "=" * 75)
    print("GENERATING 2024 DIAGNOSTIC PREDICTIONS")
    print("=" * 75)

    directional_probability = stage1.predict_proba(
        x_validation
    )[:, 1]

    up_given_directional = stage2.predict_proba(
        x_validation
    )[:, 1]

    down_given_directional = 1.0 - up_given_directional

    prob_down = (
            directional_probability * down_given_directional
    )

    prob_up = (
            directional_probability * up_given_directional
    )

    prob_sideways = 1.0 - directional_probability

    # Normalize for floating-point safety.
    probability_matrix = np.column_stack(
        [prob_down, prob_sideways, prob_up]
    )

    probability_matrix = np.clip(
        probability_matrix,
        0.0,
        1.0,
    )

    probability_matrix = (
            probability_matrix
            / probability_matrix.sum(axis=1, keepdims=True)
    )

    prob_down = probability_matrix[:, 0]
    prob_sideways = probability_matrix[:, 1]
    prob_up = probability_matrix[:, 2]

    class_names = np.array(LABELS)

    predicted_label = class_names[
        np.argmax(probability_matrix, axis=1)
    ]

    predictions = validation[
        ["timestamp_ist", "trading_day", "label"]
    ].copy()

    predictions = predictions.rename(
        columns={"label": "actual_label"}
    )

    predictions["prob_down"] = prob_down
    predictions["prob_sideways"] = prob_sideways
    predictions["prob_up"] = prob_up
    predictions["directional_probability"] = (
        directional_probability
    )
    predictions["conditional_down_probability"] = (
        down_given_directional
    )
    predictions["conditional_up_probability"] = (
        up_given_directional
    )
    predictions["predicted_label"] = predicted_label

    predictions = predictions.sort_values(
        "timestamp_ist"
    ).reset_index(drop=True)

    # --------------------------------------------------------
    # Evaluation
    # --------------------------------------------------------

    metrics = evaluate_predictions(predictions)

    metrics.update({
        "run_id": run_id,
        "experiment": "two_stage_5m",
        "feature_count": len(FEATURES),
        "features": FEATURES,
        "stage1_best_iteration": stage1_best,
        "stage2_best_iteration": stage2_best,
        "fit_rows_2021_2022": int(len(fit_train)),
        "early_stop_rows_2023": int(len(early_stop)),
        "final_train_rows_2021_2023": int(len(final_train)),
        "validation_rows_2024": int(len(validation)),
        "evaluation_period": "2024 diagnostic only",
        "future_data_used": False,
        "training_seconds": round(time.time() - start, 2),
    })

    # --------------------------------------------------------
    # Save models and predictions
    # --------------------------------------------------------

    joblib.dump(
        stage1,
        model_dir / "stage1_directional_vs_sideways.joblib",
        )

    joblib.dump(
        stage2,
        model_dir / "stage2_down_vs_up.joblib",
        )

    predictions.to_parquet(
        report_dir / "two_stage_5m_predictions.parquet",
        index=False,
        )

    with open(
            report_dir / "two_stage_5m_metrics.json",
            "w",
            encoding="utf-8",
    ) as f:
        json.dump(metrics, f, indent=2, default=str)

    # Classification report
    report = classification_report(
        predictions["actual_label"],
        predictions["predicted_label"],
        labels=LABELS,
        output_dict=True,
        zero_division=0,
    )

    pd.DataFrame(report).transpose().to_csv(
        report_dir / "classification_report.csv"
    )

    # Confusion matrix
    matrix = confusion_matrix(
        predictions["actual_label"],
        predictions["predicted_label"],
        labels=LABELS,
    )

    pd.DataFrame(
        matrix,
        index=[f"actual_{x}" for x in LABELS],
        columns=[f"predicted_{x}" for x in LABELS],
    ).to_csv(
        report_dir / "confusion_matrix.csv"
    )

    # Class distributions
    distribution = pd.concat(
        [
            predictions["actual_label"]
            .value_counts(normalize=True)
            .mul(100)
            .rename("actual_pct"),
            predictions["predicted_label"]
            .value_counts(normalize=True)
            .mul(100)
            .rename("predicted_pct"),
        ],
        axis=1,
            ).fillna(0)

    distribution.to_csv(
        report_dir / "class_distribution.csv"
    )

    # Probability summary by actual class
    probability_by_actual = (
        predictions.groupby("actual_label")[
            [
                "prob_down",
                "prob_sideways",
                "prob_up",
                "directional_probability",
            ]
        ]
        .mean()
    )

    probability_by_actual.to_csv(
        report_dir / "probability_by_actual_class.csv"
    )

    # Stage-specific validation diagnostics
    stage_diagnostics = {
        "stage1_directional_auc": safe_auc(
            (
                    predictions["actual_label"] != "SIDEWAYS"
            ).astype(int),
            predictions["directional_probability"],
        ),
        "stage1_directional_average_precision": (
            safe_average_precision(
                (
                        predictions["actual_label"] != "SIDEWAYS"
                ).astype(int),
                predictions["directional_probability"],
            )
        ),
        "stage2_down_vs_up_auc_on_directional_actuals": (
            safe_auc(
                (
                        predictions.loc[
                            predictions["actual_label"] != "SIDEWAYS",
                            "actual_label",
                        ] == "UP"
                ).astype(int),
                predictions.loc[
                    predictions["actual_label"] != "SIDEWAYS",
                    "conditional_up_probability",
                ],
            )
        ),
        "stage1_actual_directional_rate_pct": float(
            (
                    predictions["actual_label"] != "SIDEWAYS"
            ).mean() * 100
        ),
        "stage1_mean_predicted_directional_probability_pct": (
            float(directional_probability.mean() * 100)
        ),
    }

    with open(
            report_dir / "stage_diagnostics.json",
            "w",
            encoding="utf-8",
    ) as f:
        json.dump(
            stage_diagnostics,
            f,
            indent=2,
            default=str,
        )

    # Run manifest
    manifest = {
        "run_id": run_id,
        "training_period": "2021-2023",
        "fit_period": "2021-2022",
        "early_stopping_period": "2023",
        "diagnostic_period": "2024",
        "excluded_periods": ["2025", "2026"],
        "timezone": "Asia/Kolkata",
        "features": FEATURES,
        "labels": LABELS,
        "stage1_best_iteration": stage1_best,
        "stage2_best_iteration": stage2_best,
        "model_directory": str(model_dir),
        "report_directory": str(report_dir),
        "warning": (
            "2024 was previously used for model and feature research. "
            "It is diagnostic, not an untouched test."
        ),
    }

    with open(
            report_dir / "run_manifest.json",
            "w",
            encoding="utf-8",
    ) as f:
        json.dump(manifest, f, indent=2, default=str)

    # --------------------------------------------------------
    # Console summary
    # --------------------------------------------------------

    print("\n" + "=" * 75)
    print("TWO-STAGE MODEL SUMMARY")
    print("=" * 75)

    print(json.dumps(metrics, indent=2, default=str))

    print("\nSTAGE DIAGNOSTICS")
    print(json.dumps(stage_diagnostics, indent=2))

    print("\nCONFUSION MATRIX")
    print(
        pd.DataFrame(
            matrix,
            index=LABELS,
            columns=LABELS,
        )
    )

    print("\nCLASS DISTRIBUTION")
    print(distribution.round(4))

    print("\nPROBABILITY BY ACTUAL CLASS")
    print(probability_by_actual.round(5))

    print("\nOUTPUTS")
    print(f"Models: {model_dir}")
    print(f"Reports: {report_dir}")

    print("\nCompleted successfully.")


if __name__ == "__main__":
    main()
