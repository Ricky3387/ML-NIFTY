
from pathlib import Path
from datetime import date
import json
import sys
import traceback

import duckdb
import pandas as pd


# ============================================================
# CONFIGURATION
# ============================================================

ROOT = Path(__file__).resolve().parents[1]

INPUT_FILE = (
        ROOT / "data" / "processed"
        / "nifty_index_options_features_v1"
        / "nifty_index_options_features_v1.parquet"
)

OUTPUT_DIR = (
        ROOT / "data" / "processed"
        / "nifty_matched_datasets_v1"
)

REPORT_DIR = (
        ROOT / "reports"
        / "nifty_matched_datasets_v1"
)

TRAIN_START = "2021-05-24"
TRAIN_END = "2023-12-31"

VALIDATION_START = "2024-01-01"
VALIDATION_END = "2024-12-31"

HORIZONS = [5, 15, 30]

OPTIONS_FEATURES = [
    "selected_dte",
    "atm_distance_pct",
    "atm_straddle_premium",
    "atm_ce_log_return_1m",
    "atm_pe_log_return_1m",
    "atm_ce_pe_return_spread_1m",
    "atm_straddle_weighted_log_return_1m",
    "atm_ce_oi_change_1m",
    "atm_pe_oi_change_1m",
    "near_atm_pcr_oi",
    "near_atm_pcr_volume",
    "near_atm_oi_imbalance",
    "near_atm_volume_imbalance",
    "paired_strike_count",
]

EXCLUDED_COLUMNS = {
    "timestamp",
    "timestamp_ist",
    "trading_day",
    "date",
    "year",
    "month",
    "day",
    "horizon_minutes",
    "sample_eligible",
    "is_synthetic",
    "split",
    "training_day_eligible",
    "label",
    "forward_return",
    "future_close",
    "future_timestamp",
    "target_z",
    "target_vol_scale",
}

OPTIONS_PREFIXES = (
    "atm_",
    "near_atm_",
    "selected_",
    "paired_",
    "pcr_",
    "ce_",
    "pe_",
    "options_",
)

MEMORY_LIMIT = "5GB"
THREADS = 4


# ============================================================
# HELPERS
# ============================================================

def log(message):
    print(message, flush=True)


def qid(name):
    return '"' + str(name).replace('"', '""') + '"'


def qstr(value):
    return "'" + str(value).replace("'", "''") + "'"


def qpath(path):
    return qstr(str(path.resolve()).replace("\\", "/"))


def date_literal(value):
    date.fromisoformat(value)
    return f"DATE {qstr(value)}"


def ensure_input():
    if not INPUT_FILE.exists():
        raise FileNotFoundError(
            f"Input file does not exist:\n{INPUT_FILE}"
        )


def ensure_no_existing_files():
    # Empty folders from a previous failed run are harmless.
    # Existing output files are never overwritten.

    if OUTPUT_DIR.exists():
        existing = list(OUTPUT_DIR.rglob("*.parquet"))
        if existing:
            raise FileExistsError(
                "Existing output Parquet files found. "
                "Move/rename the incomplete output folder first:\n"
                + "\n".join(str(p) for p in existing)
            )

    if REPORT_DIR.exists():
        expected = [
            REPORT_DIR / "matched_dataset_summary.json",
            REPORT_DIR / "matched_feature_manifest.csv",
            REPORT_DIR / "matched_dataset_audit.csv",
            ]

        existing = [p for p in expected if p.exists()]

        if existing:
            raise FileExistsError(
                "Existing report files found. "
                "Move/rename the incomplete report folder first:\n"
                + "\n".join(str(p) for p in existing)
            )


def create_directories():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    REPORT_DIR.mkdir(parents=True, exist_ok=True)

    for name in ("index_only", "index_plus_options"):
        (OUTPUT_DIR / name).mkdir(
            parents=True,
            exist_ok=True
        )


def get_schema(con):
    rows = con.execute(
        f"DESCRIBE SELECT * FROM read_parquet({qpath(INPUT_FILE)})"
    ).fetchall()

    return {row[0]: row[1] for row in rows}


def check_required_columns(schema):
    required = {
        "timestamp_ist",
        "trading_day",
        "horizon_minutes",
        "sample_eligible",
        "label",
        "forward_return",
        "target_z",
    }

    missing = sorted(required - set(schema))

    if missing:
        raise RuntimeError(
            "Missing required columns:\n"
            + "\n".join(missing)
            + "\n\nAvailable columns:\n"
            + ", ".join(schema.keys())
        )

    missing_options = [
        c for c in OPTIONS_FEATURES if c not in schema
    ]

    if missing_options:
        raise RuntimeError(
            "Missing O1 options features:\n"
            + "\n".join(missing_options)
        )


def is_numeric_or_boolean(dtype):
    dtype = dtype.upper()

    prefixes = (
        "BOOLEAN",
        "TINYINT",
        "SMALLINT",
        "INTEGER",
        "BIGINT",
        "UTINYINT",
        "USMALLINT",
        "UINTEGER",
        "UBIGINT",
        "FLOAT",
        "DOUBLE",
        "REAL",
        "DECIMAL",
    )

    return dtype.startswith(prefixes)


def is_options_column(name):
    return (
            name in OPTIONS_FEATURES
            or name.startswith(OPTIONS_PREFIXES)
    )


def discover_index_features(schema):
    features = []

    for name, dtype in schema.items():

        if name in EXCLUDED_COLUMNS:
            continue

        if is_options_column(name):
            continue

        if is_numeric_or_boolean(dtype):
            features.append(name)

    if not features:
        raise RuntimeError(
            "No numeric index predictor features discovered."
        )

    return sorted(features)


def output_file(dataset, split, horizon):
    return (
            OUTPUT_DIR
            / dataset
            / f"{split}_{horizon}m.parquet"
    )


def write_parquet(con, query, path):
    path.parent.mkdir(parents=True, exist_ok=True)

    con.execute(
        f"COPY ({query}) TO {qpath(path)} "
        "(FORMAT PARQUET, COMPRESSION ZSTD)"
    )


def count_rows(con, view_name):
    return con.execute(
        f"SELECT COUNT(*) FROM {view_name}"
    ).fetchone()[0]


# ============================================================
# MAIN
# ============================================================

def main():

    log("=" * 75)
    log("NIFTY MATCHED DATASET BUILDER V1 - DATE FIX")
    log("=" * 75)

    ensure_input()
    ensure_no_existing_files()
    create_directories()

    log(f"Project root : {ROOT}")
    log(f"Input        : {INPUT_FILE}")
    log(f"Output       : {OUTPUT_DIR}")
    log(f"Reports      : {REPORT_DIR}")

    con = duckdb.connect(":memory:")

    con.execute(f"SET memory_limit = {qstr(MEMORY_LIMIT)}")
    con.execute(f"SET threads = {THREADS}")

    # --------------------------------------------------------
    # 1. Schema
    # --------------------------------------------------------

    log("\nReading input schema...")

    schema = get_schema(con)
    check_required_columns(schema)

    log(f"Schema columns : {len(schema)}")
    log(f"trading_day type: {schema['trading_day']}")
    log(f"horizon column : horizon_minutes")

    index_features = discover_index_features(schema)

    log(f"\nIndex predictor features   : {len(index_features)}")
    log(f"Options O1 predictor count : {len(OPTIONS_FEATURES)}")

    log("\nIndex features:")
    for feature in index_features:
        log(f"  {feature}")

    log("\nOptions O1 features:")
    for feature in OPTIONS_FEATURES:
        log(f"  {feature}")

    # --------------------------------------------------------
    # 2. Source view
    # --------------------------------------------------------

    con.execute(f"""
        CREATE VIEW merged AS
        SELECT *
        FROM read_parquet({qpath(INPUT_FILE)})
    """)

    options_nonnull = " AND ".join(
        f"{qid(c)} IS NOT NULL"
        for c in OPTIONS_FEATURES
    )

    # --------------------------------------------------------
    # 3. Matched sample
    #
    # FIX:
    # trading_day is VARCHAR.
    # Explicitly cast it to DATE before comparison.
    # --------------------------------------------------------

    con.execute(f"""
        CREATE TEMP VIEW matched AS
        SELECT *
        FROM merged
        WHERE sample_eligible = TRUE
          AND ({options_nonnull})
          AND (
                (
                    CAST(trading_day AS DATE)
                    >= {date_literal(TRAIN_START)}
                    AND CAST(trading_day AS DATE)
                    <= {date_literal(TRAIN_END)}
                )
                OR
                (
                    CAST(trading_day AS DATE)
                    >= {date_literal(VALIDATION_START)}
                    AND CAST(trading_day AS DATE)
                    <= {date_literal(VALIDATION_END)}
                )
          )
    """)

    matched_count = count_rows(con, "matched")

    log(
        f"\nMatched rows across all horizons: "
        f"{matched_count:,}"
    )

    observed_horizons = [
        row[0]
        for row in con.execute("""
                               SELECT DISTINCT horizon_minutes
                               FROM matched
                               ORDER BY horizon_minutes
                               """).fetchall()
    ]

    if observed_horizons != HORIZONS:
        raise RuntimeError(
            f"Unexpected horizon values: {observed_horizons}; "
            f"expected {HORIZONS}"
        )

    # --------------------------------------------------------
    # 4. Output projections
    # --------------------------------------------------------

    metadata_targets = [
        "timestamp_ist",
        "trading_day",
        "horizon_minutes",
        "label",
        "forward_return",
        "target_z",
    ]

    if "target_vol_scale" in schema:
        metadata_targets.append("target_vol_scale")

    if "future_close" in schema:
        metadata_targets.append("future_close")

    index_projection = metadata_targets + index_features

    combined_projection = (
            metadata_targets
            + index_features
            + OPTIONS_FEATURES
    )

    index_projection_sql = ", ".join(
        qid(c) for c in index_projection
    )

    combined_projection_sql = ", ".join(
        qid(c) for c in combined_projection
    )

    audit_rows = []
    manifest_rows = []
    summary_rows = []

    # --------------------------------------------------------
    # 5. Build datasets
    # --------------------------------------------------------

    for horizon in HORIZONS:

        log("\n" + "=" * 75)
        log(f"HORIZON: {horizon} MINUTES")
        log("=" * 75)

        for split in ("train", "validation"):

            if split == "train":
                start_date = TRAIN_START
                end_date = TRAIN_END
            else:
                start_date = VALIDATION_START
                end_date = VALIDATION_END

            # FIX: CAST trading_day VARCHAR to DATE.
            split_filter = f"""
                CAST(trading_day AS DATE) >= {date_literal(start_date)}
                AND CAST(trading_day AS DATE) <= {date_literal(end_date)}
            """

            source_query = f"""
                SELECT *
                FROM matched
                WHERE horizon_minutes = {horizon}
                  AND {split_filter}
            """

            expected_count = con.execute(
                f"SELECT COUNT(*) FROM ({source_query}) s"
            ).fetchone()[0]

            if expected_count == 0:
                raise RuntimeError(
                    f"No rows for {split}, {horizon}m"
                )

            index_path = output_file(
                "index_only", split, horizon
            )

            combined_path = output_file(
                "index_plus_options", split, horizon
            )

            index_query = f"""
                SELECT {index_projection_sql}
                FROM ({source_query}) s
                ORDER BY timestamp_ist
            """

            combined_query = f"""
                SELECT {combined_projection_sql}
                FROM ({source_query}) s
                ORDER BY timestamp_ist
            """

            write_parquet(con, index_query, index_path)
            write_parquet(con, combined_query, combined_path)

            log(
                f"PASS | {split.upper():10s} | "
                f"{horizon:2d}m | {expected_count:,} rows"
            )

            # ------------------------------------------------
            # 6. Read outputs back for validation
            # ------------------------------------------------

            index_view = f"idx_{split}_{horizon}"
            combined_view = f"comb_{split}_{horizon}"

            con.execute(f"""
                CREATE OR REPLACE TEMP VIEW {index_view} AS
                SELECT *
                FROM read_parquet({qpath(index_path)})
            """)

            con.execute(f"""
                CREATE OR REPLACE TEMP VIEW {combined_view} AS
                SELECT *
                FROM read_parquet({qpath(combined_path)})
            """)

            index_count = count_rows(con, index_view)
            combined_count = count_rows(con, combined_view)

            if (
                    index_count != expected_count
                    or combined_count != expected_count
            ):
                raise RuntimeError(
                    f"Row count mismatch: {split}, {horizon}m"
                )

            duplicate_index = con.execute(f"""
                SELECT COUNT(*)
                FROM (
                    SELECT timestamp_ist, horizon_minutes
                    FROM {index_view}
                    GROUP BY timestamp_ist, horizon_minutes
                    HAVING COUNT(*) > 1
                ) d
            """).fetchone()[0]

            duplicate_combined = con.execute(f"""
                SELECT COUNT(*)
                FROM (
                    SELECT timestamp_ist, horizon_minutes
                    FROM {combined_view}
                    GROUP BY timestamp_ist, horizon_minutes
                    HAVING COUNT(*) > 1
                ) d
            """).fetchone()[0]

            if duplicate_index or duplicate_combined:
                raise RuntimeError(
                    f"Duplicate keys found: {split}, {horizon}m"
                )

            compare_columns = [
                "timestamp_ist",
                "trading_day",
                "horizon_minutes",
                "label",
                "forward_return",
                "target_z",
            ]

            compare_sql = ", ".join(
                qid(c) for c in compare_columns
            )

            mismatch_count = con.execute(f"""
                SELECT COUNT(*)
                FROM (
                    (
                        SELECT {compare_sql}
                        FROM {index_view}
                        EXCEPT ALL
                        SELECT {compare_sql}
                        FROM {combined_view}
                    )
                    UNION ALL
                    (
                        SELECT {compare_sql}
                        FROM {combined_view}
                        EXCEPT ALL
                        SELECT {compare_sql}
                        FROM {index_view}
                    )
                ) d
            """).fetchone()[0]

            if mismatch_count:
                raise RuntimeError(
                    f"Index/combined target mismatch: "
                    f"{split}, {horizon}m"
                )

            null_options = con.execute(f"""
                SELECT COUNT(*)
                FROM {combined_view}
                WHERE NOT ({options_nonnull})
            """).fetchone()[0]

            if null_options:
                raise RuntimeError(
                    f"Null O1 features: {split}, {horizon}m"
                )

            log(
                "  OUTPUT AUDIT PASS | "
                "duplicates=0 | target mismatches=0 | "
                "O1 null rows=0"
            )

            audit_rows.append({
                "split": split.upper(),
                "horizon_minutes": horizon,
                "expected_rows": expected_count,
                "index_only_rows": index_count,
                "index_plus_options_rows": combined_count,
                "duplicate_index_keys": duplicate_index,
                "duplicate_combined_keys": duplicate_combined,
                "target_key_mismatches": mismatch_count,
                "rows_with_null_o1_features": null_options,
                "status": "PASS",
            })

            summary_rows.append({
                "split": split.upper(),
                "horizon_minutes": horizon,
                "rows": expected_count,
                "start_date": start_date,
                "end_date": end_date,
            })

    # --------------------------------------------------------
    # 7. Feature manifest
    # --------------------------------------------------------

    for split in ("TRAIN", "VALIDATION"):
        for horizon in HORIZONS:

            manifest_rows.append({
                "dataset": "index_only",
                "split": split,
                "horizon_minutes": horizon,
                "predictor_count": len(index_features),
                "predictors": "|".join(index_features),
            })

            manifest_rows.append({
                "dataset": "index_plus_options",
                "split": split,
                "horizon_minutes": horizon,
                "predictor_count": (
                        len(index_features) + len(OPTIONS_FEATURES)
                ),
                "predictors": "|".join(
                    index_features + OPTIONS_FEATURES
                ),
            })

    # --------------------------------------------------------
    # 8. Reports
    # --------------------------------------------------------

    summary = {
        "project": "NIFTY matched index/options datasets",
        "version": "v1",
        "status": "SUCCESS",
        "input_file": str(INPUT_FILE),
        "output_directory": str(OUTPUT_DIR),
        "train_period": {
            "start": TRAIN_START,
            "end": TRAIN_END,
        },
        "validation_period": {
            "start": VALIDATION_START,
            "end": VALIDATION_END,
        },
        "trading_day_source_type": schema["trading_day"],
        "trading_day_filter": "CAST(trading_day AS DATE)",
        "horizon_column": "horizon_minutes",
        "horizons": HORIZONS,
        "index_predictor_count": len(index_features),
        "options_o1_predictor_count": len(OPTIONS_FEATURES),
        "combined_predictor_count": (
                len(index_features) + len(OPTIONS_FEATURES)
        ),
        "index_features": index_features,
        "options_o1_features": OPTIONS_FEATURES,
        "matched_rows_across_horizons": matched_count,
        "row_counts": summary_rows,
        "methodology": {
            "matched_population": (
                "sample_eligible rows with all 14 O1 options "
                "features non-null"
            ),
            "index_only": (
                "Index predictors using the matched population"
            ),
            "index_plus_options": (
                "Same matched population with index and O1 options predictors"
            ),
            "matching_key": [
                "timestamp_ist",
                "horizon_minutes",
            ],
            "no_forward_fill": True,
            "source_modified": False,
            "validation_2024_is_final_untouched_test": False,
        },
    }

    summary_path = REPORT_DIR / "matched_dataset_summary.json"
    manifest_path = REPORT_DIR / "matched_feature_manifest.csv"
    audit_path = REPORT_DIR / "matched_dataset_audit.csv"

    with open(summary_path, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, default=str)

    pd.DataFrame(manifest_rows).to_csv(
        manifest_path,
        index=False
    )

    pd.DataFrame(audit_rows).to_csv(
        audit_path,
        index=False
    )

    # --------------------------------------------------------
    # 9. Final summary
    # --------------------------------------------------------

    log("\n" + "=" * 75)
    log("MATCHED DATASET BUILD COMPLETED")
    log("=" * 75)

    for row in summary_rows:
        log(
            f"{row['split']:10s} | "
            f"{row['horizon_minutes']:2d}m | "
            f"{row['rows']:,} rows"
        )

    log("\nPredictor counts:")
    log(f"  Index-only : {len(index_features)}")
    log(f"  Options O1 : {len(OPTIONS_FEATURES)}")
    log(
        f"  Combined  : "
        f"{len(index_features) + len(OPTIONS_FEATURES)}"
    )

    log("\nReports:")
    log(f"  {summary_path}")
    log(f"  {manifest_path}")
    log(f"  {audit_path}")

    log("\nSUCCESS: All six datasets passed output audits.")
    log("Original source data was not modified.")

    con.close()


if __name__ == "__main__":
    try:
        main()
    except Exception:
        log("\nBUILD FAILED")
        traceback.print_exc()
        sys.exit(1)
