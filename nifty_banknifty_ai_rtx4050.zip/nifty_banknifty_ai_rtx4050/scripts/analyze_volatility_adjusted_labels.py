
from pathlib import Path
import math
import duckdb
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]

INPUT_DIR = ROOT / "data" / "training" / "index_features"
OUTPUT_DIR = ROOT / "data" / "training" / "volatility_label_analysis"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

DATABASE = ROOT / "data" / "database" / "nifty_options.duckdb"

INDEX_FILES = {
    "NIFTY": INPUT_DIR / "nifty_index_features.parquet",
    "BANKNIFTY": INPUT_DIR / "banknifty_index_features.parquet",
}

# The volatility columns are rolling standard deviations of
# past 1-minute returns, not standard deviations of aggregated
# 5/15/30-minute returns.
HORIZONS = {
    5: "volatility_5m",
    15: "volatility_15m",
    30: "volatility_30m",
}

# Candidate movement thresholds measured in estimated
# horizon standard deviations.
Z_BANDS = [0.25, 0.50, 0.75, 1.00, 1.25, 1.50]

PERCENTILES = [
    0.01, 0.05, 0.10, 0.25, 0.50,
    0.75, 0.90, 0.95, 0.99
]

con = duckdb.connect(str(DATABASE))
con.execute("SET TimeZone = 'Asia/Calcutta'")
con.execute("SET memory_limit = '4GB'")
con.execute("SET threads = 4")


def safe_path(path):
    return str(path.resolve()).replace("\\", "/").replace("'", "''")


def analyze_index(index_name, parquet_path):
    print("\n" + "=" * 85)
    print(f"VOLATILITY-ADJUSTED LABEL ANALYSIS: {index_name}")
    print("=" * 85)

    if not parquet_path.exists():
        raise FileNotFoundError(parquet_path)

    view = f"{index_name.lower()}_volatility_analysis"

    con.execute(f"""
        CREATE OR REPLACE VIEW {view} AS
        SELECT *
        FROM read_parquet('{safe_path(parquet_path)}')
    """)

    schema = con.execute(
        f"DESCRIBE SELECT * FROM {view}"
    ).fetchdf()

    columns = set(schema["column_name"].tolist())

    required = {
        "trading_day",
        "eligible_for_index_model",
    }

    for horizon, vol_col in HORIZONS.items():
        required.update({
            f"future_return_{horizon}m",
            f"label_valid_{horizon}m",
            vol_col,
        })

    missing = required - columns

    if missing:
        raise ValueError(f"Missing columns: {sorted(missing)}")

    percentile_rows = []
    band_rows = []
    quality_rows = []
    yearly_rows = []

    for horizon, vol_col in HORIZONS.items():

        return_col = f"future_return_{horizon}m"
        valid_col = f"label_valid_{horizon}m"

        horizon_scale = math.sqrt(horizon)

        # ----------------------------------------------------
        # 1. Validate future-return labels and validity flags
        # ----------------------------------------------------

        quality = con.execute(f"""
            SELECT
                '{index_name}' AS index_name,
                {horizon} AS horizon_minutes,

                COUNT(*) AS total_rows,

                COUNT(*) FILTER (
                    WHERE {return_col} IS NOT NULL
                ) AS non_null_returns,

                COUNT(*) FILTER (
                    WHERE {valid_col} IS TRUE
                ) AS valid_flags,

                COUNT(*) FILTER (
                    WHERE {return_col} IS NOT NULL
                      AND {valid_col} IS TRUE
                ) AS valid_both,

                COUNT(*) FILTER (
                    WHERE ({return_col} IS NOT NULL)
                      <> ({valid_col} IS TRUE)
                ) AS flag_return_mismatches,

                COUNT(*) FILTER (
                    WHERE eligible_for_index_model IS TRUE
                ) AS eligible_rows,

                COUNT(*) FILTER (
                    WHERE eligible_for_index_model IS TRUE
                      AND {return_col} IS NOT NULL
                      AND {vol_col} > 0
                      AND ISFINITE({vol_col})
                ) AS rows_with_valid_volatility

            FROM {view}
        """).fetchdf()

        quality_rows.append(quality)

        # ----------------------------------------------------
        # 2. Create volatility-normalised return distribution
        # ----------------------------------------------------

        normalized_view = f"{view}_{horizon}m"

        con.execute(f"""
            CREATE OR REPLACE TEMP VIEW {normalized_view} AS
            SELECT
                CAST(trading_day AS DATE) AS trading_day,
                {return_col} AS future_return,
                {vol_col} AS past_minute_volatility,

                {vol_col} * {horizon_scale}
                    AS estimated_horizon_volatility,

                {return_col} /
                    NULLIF({vol_col} * {horizon_scale}, 0)
                    AS normalized_return

            FROM {view}

            WHERE eligible_for_index_model IS TRUE
              AND {return_col} IS NOT NULL
              AND {valid_col} IS TRUE
              AND {vol_col} > 0
              AND ISFINITE({vol_col})
              AND ISFINITE({return_col})
        """)

        # ----------------------------------------------------
        # 3. Normalised return percentiles
        # ----------------------------------------------------

        percentile_expressions = []

        for p in PERCENTILES:
            label = f"p{int(p * 100):02d}"

            percentile_expressions.append(
                f"quantile_cont(normalized_return, {p}) "
                f"AS {label}"
            )

        percentile_sql = ",\n".join(percentile_expressions)

        stats = con.execute(f"""
            SELECT
                '{index_name}' AS index_name,
                {horizon} AS horizon_minutes,

                COUNT(*) AS valid_rows,

                AVG(normalized_return) AS average_z,
                STDDEV_SAMP(normalized_return) AS std_z,

                {percentile_sql},

                quantile_cont(
                    ABS(normalized_return), 0.50
                ) AS abs_p50,

                quantile_cont(
                    ABS(normalized_return), 0.90
                ) AS abs_p90,

                quantile_cont(
                    ABS(normalized_return), 0.99
                ) AS abs_p99

            FROM {normalized_view}
        """).fetchdf()

        percentile_rows.append(stats)

        # ----------------------------------------------------
        # 4. Class balance for different Z thresholds
        # ----------------------------------------------------

        for band in Z_BANDS:

            result = con.execute(f"""
                SELECT
                    COUNT(*) AS total_rows,

                    COUNT(*) FILTER (
                        WHERE ABS(normalized_return) <= {band}
                    ) AS sideways_rows,

                    COUNT(*) FILTER (
                        WHERE normalized_return > {band}
                    ) AS up_rows,

                    COUNT(*) FILTER (
                        WHERE normalized_return < -{band}
                    ) AS down_rows

                FROM {normalized_view}
            """).fetchdf().iloc[0]

            total = int(result["total_rows"])
            sideways = int(result["sideways_rows"])
            up = int(result["up_rows"])
            down = int(result["down_rows"])

            band_rows.append({
                "index_name": index_name,
                "horizon_minutes": horizon,
                "z_threshold": band,
                "total_rows": total,
                "sideways_rows": sideways,
                "up_rows": up,
                "down_rows": down,
                "sideways_pct": sideways / total * 100,
                "up_pct": up / total * 100,
                "down_pct": down / total * 100,
            })

        # ----------------------------------------------------
        # 5. Year-wise normalised distribution
        # ----------------------------------------------------

        yearly = con.execute(f"""
            SELECT
                '{index_name}' AS index_name,
                {horizon} AS horizon_minutes,

                YEAR(trading_day) AS year,

                COUNT(*) AS valid_rows,

                AVG(normalized_return) AS average_z,

                STDDEV_SAMP(normalized_return) AS std_z,

                quantile_cont(
                    ABS(normalized_return), 0.50
                ) AS abs_median_z,

                quantile_cont(
                    ABS(normalized_return), 0.90
                ) AS abs_p90_z

            FROM {normalized_view}

            GROUP BY YEAR(trading_day)
            ORDER BY year
        """).fetchdf()

        yearly_rows.append(yearly)

    # --------------------------------------------------------
    # Save reports
    # --------------------------------------------------------

    percentile_df = pd.concat(
        percentile_rows, ignore_index=True
    )

    bands_df = pd.DataFrame(band_rows)

    quality_df = pd.concat(
        quality_rows, ignore_index=True
    )

    yearly_df = pd.concat(
        yearly_rows, ignore_index=True
    )

    outputs = {
        "normalized_percentiles":
            percentile_df,

        "normalized_class_balance":
            bands_df,

        "label_volatility_quality":
            quality_df,

        "normalized_yearly_distribution":
            yearly_df,
    }

    for report_name, dataframe in outputs.items():
        output_file = (
                OUTPUT_DIR /
                f"{index_name.lower()}_{report_name}.csv"
        )

        dataframe.to_csv(output_file, index=False)
        print(f"Generated: {output_file}")

    # --------------------------------------------------------
    # Console output
    # --------------------------------------------------------

    print("\nNORMALISED RETURN PERCENTILES (Z-SCORES)")
    print(percentile_df.to_string(index=False))

    print("\nVOLATILITY-ADJUSTED CLASS BALANCE")
    print(bands_df.to_string(index=False))

    print("\nLABEL / VOLATILITY QUALITY")
    print(quality_df.to_string(index=False))

    print("\nYEARLY NORMALISED DISTRIBUTION")
    print(yearly_df.to_string(index=False))


try:
    for name, path in INDEX_FILES.items():
        analyze_index(name, path)

    print("\n" + "=" * 85)
    print("VOLATILITY-ADJUSTED LABEL ANALYSIS COMPLETED")
    print("=" * 85)

finally:
    con.close()
