"""
FAST calendar-aware NIFTY index cleaner (vectorized pandas implementation).

Run from project root:
    python clean_nifty_index_calendar_aware_fast.py

This replaces the slower iterrows-based cleaner.
It reads DuckDB read-only and does not modify source data.

Assumptions:
- Source timestamps are naive UTC; convert to Asia/Kolkata.
- Minute-start bars: normal session 09:15 through 15:29 (375 bars).
- Muhurat dates are excluded.
- Jan 20, 2024 is full-day; Mar 2 and May 18, 2024 are split sessions.
- Missing expected bars are forward-filled from the latest previous eligible
  close. Synthetic O=H=L=C=previous close, volume=0.
- No backward fill/look-ahead. If first expected bar lacks a prior close,
  the script stops.
"""

from pathlib import Path
import json
import sys
import time

import duckdb
import numpy as np
import pandas as pd


DB_PATH = Path("data/database/nifty_options.duckdb")
SOURCE_VIEW = "nifty_index"
START_DATE = "2021-05-24"
END_DATE = "2024-12-31"
TIMEZONE = "Asia/Kolkata"
OUTPUT_DIR = Path("data/processed/nifty_index_cleaned")

NORMAL_START = "09:15"
NORMAL_MINUTES = 375

HOLIDAYS = set("""
2021-05-13 2021-07-21 2021-08-19 2021-09-10 2021-10-15
2021-11-05 2021-11-19
2022-01-26 2022-03-01 2022-03-18 2022-04-14 2022-04-15
2022-05-03 2022-08-09 2022-08-15 2022-08-31 2022-10-05
2022-10-26 2022-11-08
2023-01-26 2023-03-07 2023-03-30 2023-04-04 2023-04-07
2023-04-14 2023-05-01 2023-06-29 2023-08-15 2023-09-19
2023-10-02 2023-10-24 2023-11-14 2023-11-27 2023-12-25
2024-01-22 2024-01-26 2024-03-08 2024-03-25 2024-03-29
2024-04-11 2024-04-17 2024-05-01 2024-05-20 2024-06-17
2024-07-17 2024-08-15 2024-10-02 2024-11-15 2024-12-25
""".split())

MUHURAT_DATES = {
    "2021-11-04", "2022-10-24", "2023-11-12", "2024-11-01"
}

SPECIAL_SESSIONS = {
    "2024-01-20": ("SPECIAL_FULL_DAY", [("09:15", 375)]),
    "2024-03-02": ("SPECIAL_SPLIT_SESSION", [("09:15", 45), ("11:30", 60)]),
    "2024-05-18": ("SPECIAL_SPLIT_SESSION", [("09:15", 45), ("11:30", 60)]),
}


def log(message):
    print(time.strftime("[%H:%M:%S]"), message, flush=True)


def fail(message):
    raise RuntimeError(message)


def make_expected_calendar():
    records = []
    dates = pd.date_range(START_DATE, END_DATE, freq="D")

    for date in dates:
        day = date.strftime("%Y-%m-%d")
        if day in MUHURAT_DATES or day in HOLIDAYS:
            continue
        if day not in SPECIAL_SESSIONS and date.weekday() >= 5:
            continue

        if day in SPECIAL_SESSIONS:
            session_type, windows = SPECIAL_SESSIONS[day]
        else:
            session_type, windows = "NORMAL_SESSION", [(NORMAL_START, NORMAL_MINUTES)]

        for start_text, minutes in windows:
            start = pd.Timestamp(f"{day} {start_text}", tz=TIMEZONE)
            stamps = pd.date_range(start, periods=minutes, freq="min")
            records.extend(
                {
                    "timestamp_ist": stamp,
                    "trading_day": day,
                    "session_type": session_type,
                }
                for stamp in stamps
            )

    expected = pd.DataFrame.from_records(records)
    if expected.empty:
        fail("Expected calendar is empty.")
    if expected["timestamp_ist"].duplicated().any():
        fail("Duplicate timestamps generated in expected calendar.")
    return expected.sort_values("timestamp_ist").reset_index(drop=True)


def main():
    started = time.time()
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    if not DB_PATH.exists():
        fail(f"DuckDB not found: {DB_PATH.resolve()}")

    log("Step 1/7: Reading NIFTY source view (read-only)...")
    con = duckdb.connect(str(DB_PATH), read_only=True)
    try:
        desc = con.execute(f"DESCRIBE SELECT * FROM {SOURCE_VIEW}").fetchdf()
        cols = {str(c).lower() for c in desc["column_name"]}
        required = {"timestamp", "open", "high", "low", "close", "volume"}
        missing = required - cols
        if missing:
            fail(f"Missing columns in {SOURCE_VIEW}: {sorted(missing)}")

        symbol_expr = "CAST(symbol AS VARCHAR)" if "symbol" in cols else "'NIFTY'"
        query = f"""
            SELECT
                CAST(timestamp AS VARCHAR) AS source_timestamp,
                {symbol_expr} AS symbol,
                TRY_CAST(open AS DOUBLE) AS open,
                TRY_CAST(high AS DOUBLE) AS high,
                TRY_CAST(low AS DOUBLE) AS low,
                TRY_CAST(close AS DOUBLE) AS close,
                TRY_CAST(volume AS DOUBLE) AS volume
            FROM {SOURCE_VIEW}
            WHERE CAST(timestamp AS DATE)
                BETWEEN DATE '{START_DATE}' AND DATE '{END_DATE}'
        """
        source = con.execute(query).fetchdf()
    finally:
        con.close()

    if source.empty:
        fail("No NIFTY rows found in the configured period.")

    if set(source["symbol"].dropna().unique()) != {"NIFTY"}:
        fail(f"Expected only NIFTY; found {source['symbol'].dropna().unique()}")

    log(f"Loaded {len(source):,} source rows.")

    log("Step 2/7: Converting source timestamps to IST...")
    source["timestamp_ist"] = (
        pd.to_datetime(source["source_timestamp"], errors="coerce", utc=True)
        .dt.tz_convert(TIMEZONE)
    )
    if source["timestamp_ist"].isna().any():
        fail("Invalid source timestamps found.")

    source["trading_day"] = source["timestamp_ist"].dt.strftime("%Y-%m-%d")

    if source["timestamp_ist"].duplicated().any():
        n = int(source["timestamp_ist"].duplicated(keep=False).sum())
        fail(f"Found {n} rows in duplicate timestamp groups; resolve before cleaning.")

    numeric = ["open", "high", "low", "close", "volume"]
    for col in numeric:
        source[col] = pd.to_numeric(source[col], errors="coerce")

    invalid = (
            source[["open", "high", "low", "close"]].isna().any(axis=1)
            | (source[["open", "high", "low", "close"]] <= 0).any(axis=1)
            | (source["high"] < source["low"])
            | (source["high"] < source[["open", "close"]].max(axis=1))
            | (source["low"] > source[["open", "close"]].min(axis=1))
    )
    if invalid.any():
        fail(f"{int(invalid.sum())} source rows have invalid OHLC; stop and inspect.")

    log("Step 3/7: Building expected exchange-session calendar...")
    expected = make_expected_calendar()
    log(f"Expected {len(expected):,} minute bars across {expected['trading_day'].nunique()} sessions.")

    log("Step 4/7: Matching observations to expected timestamps...")
    # Use a left merge from expected slots. This naturally excludes extra,
    # weekend, holiday and Muhurat observations from the cleaned output.
    source_cols = [
        "timestamp_ist", "source_timestamp", "symbol",
        "open", "high", "low", "close", "volume"
    ]
    matched = expected.merge(
        source[source_cols],
        on="timestamp_ist",
        how="left",
        validate="one_to_one",
        indicator=True,
    )

    matched["is_synthetic"] = matched["_merge"].eq("left_only")
    matched.drop(columns=["_merge"], inplace=True)

    # Build removal report from source observations not present in expected slots.
    expected_keys = expected[["timestamp_ist"]].drop_duplicates()
    removed = source.merge(
        expected_keys,
        on="timestamp_ist",
        how="left",
        indicator=True,
    )
    removed = removed[removed["_merge"] == "left_only"].drop(columns=["_merge"])
    removed["removal_reason"] = np.where(
        removed["trading_day"].isin(MUHURAT_DATES),
        "MUHURAT_SESSION_EXCLUDED",
        "OUTSIDE_CONFIGURED_SESSION_OR_NON_TRADING_DATE",
    )

    # Muhurat records get their own audit file.
    muhurat = source[source["trading_day"].isin(MUHURAT_DATES)].copy()

    log("Step 5/7: Forward-filling missing expected bars...")
    # Source closes are the only fill seeds. Synthetic rows get their close
    # from the latest earlier real close; no backward fill is performed.
    matched["source_close"] = matched["close"]
    matched["source_timestamp_ist"] = matched["timestamp_ist"].where(
        matched["source_close"].notna()
    )

    matched["fill_close"] = matched["source_close"].ffill()
    matched["fill_source_timestamp_ist"] = (
        matched["source_timestamp_ist"].ffill()
    )

    no_seed = matched["fill_close"].isna()
    if no_seed.any():
        first_missing = matched.loc[
            no_seed, ["trading_day", "timestamp_ist"]
        ].head(10)
        fail(
            "Cannot forward-fill initial missing expected bars without a prior "
            "observed close. No future-price backfill is allowed.\n"
            + first_missing.to_string(index=False)
        )

    synthetic_mask = matched["is_synthetic"]
    for col in ["open", "high", "low", "close"]:
        matched.loc[synthetic_mask, col] = matched.loc[synthetic_mask, "fill_close"]

    matched.loc[synthetic_mask, "volume"] = 0.0
    matched["volume"] = matched["volume"].fillna(0.0)
    matched["data_origin"] = np.where(
        matched["is_synthetic"],
        "FORWARD_FILLED_LAST_OBSERVED_CLOSE",
        "SOURCE",
    )

    # Store UTC timestamp as timezone-aware UTC, plus IST audit timestamp.
    matched["timestamp"] = matched["timestamp_ist"].dt.tz_convert("UTC")
    matched["trading_day"] = pd.to_datetime(matched["trading_day"]).dt.date
    matched["is_synthetic"] = matched["is_synthetic"].astype(bool)

    cleaned_cols = [
        "symbol", "timestamp", "timestamp_ist", "trading_day",
        "open", "high", "low", "close", "volume",
        "is_synthetic", "data_origin", "fill_source_timestamp_ist",
        "session_type",
    ]
    cleaned = matched[cleaned_cols].copy()

    # Verify continuity/uniqueness.
    if cleaned["timestamp"].duplicated().any():
        fail("Duplicate timestamps remain in cleaned output.")
    if len(cleaned) != len(expected):
        fail(f"Row count mismatch: cleaned={len(cleaned)} expected={len(expected)}")
    if cleaned[["open", "high", "low", "close"]].isna().any().any():
        fail("Null OHLC values remain after filling.")

    log("Step 6/7: Writing Parquet and audit files...")
    parquet_path = OUTPUT_DIR / "nifty_index_cleaned.parquet"
    con_out = duckdb.connect()
    try:
        con_out.register("cleaned_df", cleaned)
        path_sql = str(parquet_path.resolve()).replace("\\", "/").replace("'", "''")
        con_out.execute(
            f"COPY cleaned_df TO '{path_sql}' (FORMAT PARQUET, COMPRESSION ZSTD)"
        )
    finally:
        con_out.close()

    # Daily summary: vectorized groupby.
    daily = (
        matched.assign(source_bar=~matched["is_synthetic"])
        .groupby(["trading_day", "session_type"], as_index=False)
        .agg(
            expected_bars=("timestamp_ist", "size"),
            source_bars_kept=("source_bar", "sum"),
            synthetic_bars_created=("is_synthetic", "sum"),
        )
    )
    daily["cleaned_bars"] = daily["expected_bars"]
    daily["session_complete_after_fill"] = True

    synthetic = matched.loc[synthetic_mask, [
        "symbol", "trading_day", "timestamp_ist", "fill_close",
        "fill_source_timestamp_ist", "session_type"
    ]].copy()
    synthetic = synthetic.rename(columns={"fill_close": "filled_ohlc_value"})
    synthetic["volume"] = 0.0
    synthetic["fill_method"] = "FORWARD_FILL_PREVIOUS_OBSERVED_CLOSE"

    # Removed includes Muhurat; separate Muhurat audit retained as requested.
    daily.to_csv(OUTPUT_DIR / "nifty_daily_cleaning_audit.csv", index=False)
    synthetic.to_csv(OUTPUT_DIR / "nifty_synthetic_filled_bars.csv", index=False)
    removed.to_csv(OUTPUT_DIR / "nifty_removed_extra_timestamps.csv", index=False)
    muhurat.to_csv(OUTPUT_DIR / "nifty_muhurat_excluded_rows.csv", index=False)

    summary = {
        "dataset": "NIFTY index",
        "period": {"start": START_DATE, "end": END_DATE},
        "timezone_assumption": "Naive source timestamps interpreted as UTC and converted to Asia/Kolkata.",
        "session_convention": "Provisional minute-start labels; normal 09:15-15:29.",
        "muhurat_dates_excluded": sorted(MUHURAT_DATES),
        "source_rows_loaded": int(len(source)),
        "expected_trading_dates": int(expected["trading_day"].nunique()),
        "expected_session_bars": int(len(expected)),
        "cleaned_rows": int(len(cleaned)),
        "source_bars_kept": int((~cleaned["is_synthetic"]).sum()),
        "synthetic_bars_created": int(cleaned["is_synthetic"].sum()),
        "extra_or_non_session_rows_removed": int(len(removed)),
        "muhurat_rows_excluded": int(len(muhurat)),
        "cleaned_duplicate_timestamps": int(cleaned["timestamp"].duplicated().sum()),
        "cleaned_null_ohlc_rows": int(cleaned[["open", "high", "low", "close"]].isna().any(axis=1).sum()),
        "lookahead_backfill_used": False,
        "source_database_modified": False,
        "note": "Synthetic rows are carried-forward prices, not trades. Preserve is_synthetic in all training datasets.",
        "elapsed_seconds": round(time.time() - started, 2),
    }
    with open(OUTPUT_DIR / "nifty_index_cleaning_summary.json", "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)

    log("Step 7/7: Complete.")
    log(f"Cleaned rows: {len(cleaned):,}")
    log(f"Original bars kept: {summary['source_bars_kept']:,}")
    log(f"Synthetic bars: {summary['synthetic_bars_created']:,}")
    log(f"Extra/non-session rows removed: {len(removed):,}")
    log(f"Muhurat rows excluded: {len(muhurat):,}")
    log(f"Elapsed seconds: {summary['elapsed_seconds']}")
    log(f"Output folder: {OUTPUT_DIR.resolve()}")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"\nFAILED: {exc}", file=sys.stderr)
        sys.exit(1)
