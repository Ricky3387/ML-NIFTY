
from pathlib import Path
import gc
import json
import warnings

import numpy as np
import pandas as pd
import lightgbm as lgb

from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    log_loss,
    mean_absolute_error,
    mean_squared_error,
    r2_score,
)

warnings.filterwarnings("ignore", category=UserWarning)

# ============================================================
# CONFIGURATION
# ============================================================

ROOT = Path(__file__).resolve().parents[1]

INPUT_DIR = ROOT / "data" / "training" / "supervised"
OUTPUT_DIR = ROOT / "data" / "training" / "model_results"
MODEL_DIR = ROOT / "models" / "index_models"

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
MODEL_DIR.mkdir(parents=True, exist_ok=True)

DATASETS = [
    ("nifty", "5m"),
    ("nifty", "15m"),
    ("nifty", "30m"),
    ("banknifty", "5m"),
    ("banknifty", "15m"),
    ("banknifty", "30m"),
]

# Approved feature set. Do not add target-derived fields.
FEATURES = [
    "minute_of_day",
    "day_of_week",
    "month_of_year",

    "return_1m",
    "return_5m",
    "return_15m",
    "return_30m",

    "volatility_5m",
    "volatility_15m",
    "volatility_30m",
    "volatility_60m",

    "candle_range_pct",
    "candle_body_pct",
    "upper_wick_pct",
    "lower_wick_pct",
    "close_location",

    "vwap_deviation_pct",

    "volume_ratio_30",
    "volume_zscore_30",

    "range_position_15",
    "range_position_30",
]

# Chronological split.
TRAIN_START = 2021
TRAIN_END = 2023
VALIDATION_YEAR = 2024
TEST_YEAR = 2025

# 2026 is deliberately not loaded into training/evaluation.
CPU_THREADS = 4

# LightGBM configuration.
CLASSIFIER_PARAMS = {
    "objective": "multiclass",
    "num_class": 3,
    "n_estimators": 3000,
    "learning_rate": 0.03,
    "num_leaves": 31,
    "max_depth": -1,
    "min_child_samples": 100,
    "subsample": 0.8,
    "subsample_freq": 1,
    "colsample_bytree": 0.8,
    "reg_lambda": 2.0,
    "reg_alpha": 0.1,
    "random_state": 42,
    "n_jobs": CPU_THREADS,
    "verbosity": -1,
    "device_type": "cpu",
}

REGRESSOR_PARAMS = {
    "objective": "regression",
    "n_estimators": 3000,
    "learning_rate": 0.03,
    "num_leaves": 31,
    "max_depth": -1,
    "min_child_samples": 100,
    "subsample": 0.8,
    "subsample_freq": 1,
    "colsample_bytree": 0.8,
    "reg_lambda": 2.0,
    "reg_alpha": 0.1,
    "random_state": 42,
    "n_jobs": CPU_THREADS,
    "verbosity": -1,
    "device_type": "cpu",
}

CLASS_NAMES = {
    0: "DOWN",
    1: "SIDEWAYS",
    2: "UP",
}

# ============================================================
# HELPERS
# ============================================================

def prepare_class_target(series):
    """Accept either numeric classes or named classes."""

    if pd.api.types.is_numeric_dtype(series):
        result = pd.to_numeric(series, errors="coerce")
    else:
        mapping = {
            "DOWN": 0,
            "SIDEWAYS": 1,
            "UP": 2,
        }
        result = (
            series.astype(str)
            .str.upper()
            .map(mapping)
        )

    return result


def save_json(path, data):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, default=str)


def classification_metrics(y_true, y_pred, probabilities):
    result = {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "balanced_accuracy": float(
            balanced_accuracy_score(y_true, y_pred)
        ),
        "macro_f1": float(
            f1_score(
                y_true,
                y_pred,
                average="macro",
                zero_division=0
            )
        ),
        "log_loss": float(
            log_loss(
                y_true,
                probabilities,
                labels=[0, 1, 2]
            )
        ),
    }

    report = classification_report(
        y_true,
        y_pred,
        labels=[0, 1, 2],
        target_names=["DOWN", "SIDEWAYS", "UP"],
        output_dict=True,
        zero_division=0,
    )

    result["per_class"] = report

    matrix = confusion_matrix(
        y_true,
        y_pred,
        labels=[0, 1, 2]
    )

    result["confusion_matrix"] = matrix.tolist()

    return result


def regression_metrics(y_true, predictions, baseline):
    result = {
        "mae": float(mean_absolute_error(y_true, predictions)),
        "rmse": float(
            np.sqrt(mean_squared_error(y_true, predictions))
        ),
        "r2": float(r2_score(y_true, predictions)),
        "directional_agreement": float(
            np.mean(np.sign(y_true) == np.sign(predictions))
        ),
        "baseline_mean_mae": float(
            mean_absolute_error(y_true, baseline)
        ),
        "baseline_mean_rmse": float(
            np.sqrt(mean_squared_error(y_true, baseline))
        ),
    }

    return result


def write_feature_importance(model, dataset_name, model_type):
    importance = pd.DataFrame({
        "feature": FEATURES,
        "gain": model.booster_.feature_importance(
            importance_type="gain"
        ),
        "split": model.booster_.feature_importance(
            importance_type="split"
        ),
    })

    importance = importance.sort_values(
        "gain",
        ascending=False
    )

    path = OUTPUT_DIR / (
        f"{dataset_name}_{model_type}_feature_importance.csv"
    )

    importance.to_csv(path, index=False)


# ============================================================
# MAIN TRAINING LOOP
# ============================================================

all_metrics = []

for index_name, horizon in DATASETS:

    dataset_name = f"{index_name}_{horizon}"
    input_path = INPUT_DIR / f"{dataset_name}_supervised.parquet"

    print("\n" + "=" * 78)
    print(f"TRAINING {dataset_name.upper()}")
    print("=" * 78)

    if not input_path.exists():
        raise FileNotFoundError(input_path)

    # --------------------------------------------------------
    # Load only the required columns.
    # 2026 rows are excluded from this first experiment.
    # --------------------------------------------------------

    required_columns = (
            FEATURES
            + [
                "trading_day",
                "target_class",
                "target_z",
            ]
    )

    df = pd.read_parquet(
        input_path,
        columns=required_columns
    )

    df["trading_day"] = pd.to_datetime(
        df["trading_day"]
    )

    df["year"] = df["trading_day"].dt.year

    df["target_class"] = prepare_class_target(
        df["target_class"]
    )

    df["target_z"] = pd.to_numeric(
        df["target_z"],
        errors="coerce"
    )

    # Convert infinite values to missing values.
    df[FEATURES] = df[FEATURES].replace(
        [np.inf, -np.inf],
        np.nan
    )

    df["target_z"] = df["target_z"].replace(
        [np.inf, -np.inf],
        np.nan
    )

    # Require valid classification and regression targets.
    df = df.dropna(
        subset=["target_class", "target_z"]
    ).copy()

    df["target_class"] = df["target_class"].astype(int)

    if not set(df["target_class"].unique()).issubset({0, 1, 2}):
        raise ValueError(
            f"{dataset_name}: Unexpected target classes "
            f"{sorted(df['target_class'].unique())}"
        )

    train = df[
        (df["year"] >= TRAIN_START)
        & (df["year"] <= TRAIN_END)
        ].copy()

    validation = df[
        df["year"] == VALIDATION_YEAR
        ].copy()

    test = df[
        df["year"] == TEST_YEAR
        ].copy()

    print("Training rows   :", f"{len(train):,}")
    print("Validation rows :", f"{len(validation):,}")
    print("Test rows       :", f"{len(test):,}")
    print("Features        :", len(FEATURES))

    if min(len(train), len(validation), len(test)) == 0:
        raise RuntimeError(
            f"{dataset_name}: One or more chronological splits are empty."
        )

    X_train = train[FEATURES]
    X_valid = validation[FEATURES]
    X_test = test[FEATURES]

    y_train_class = train["target_class"]
    y_valid_class = validation["target_class"]
    y_test_class = test["target_class"]

    y_train_z = train["target_z"]
    y_valid_z = validation["target_z"]
    y_test_z = test["target_z"]

    dataset_model_dir = MODEL_DIR / dataset_name
    dataset_model_dir.mkdir(parents=True, exist_ok=True)

    # --------------------------------------------------------
    # CLASSIFICATION MODEL
    # --------------------------------------------------------

    print("\nTraining LightGBM classifier...")

    classifier = lgb.LGBMClassifier(
        **CLASSIFIER_PARAMS
    )

    classifier.fit(
        X_train,
        y_train_class,
        eval_set=[
            (X_valid, y_valid_class)
        ],
        eval_metric="multi_logloss",
        callbacks=[
            lgb.early_stopping(
                stopping_rounds=100,
                verbose=True
            ),
            lgb.log_evaluation(period=100),
        ],
    )

    best_iteration = classifier.best_iteration_

    if not best_iteration:
        best_iteration = classifier.n_estimators

    # Validation metrics.
    valid_prob = classifier.predict_proba(
        X_valid,
        num_iteration=best_iteration
    )

    valid_pred = np.argmax(valid_prob, axis=1)

    validation_class_metrics = classification_metrics(
        y_valid_class,
        valid_pred,
        valid_prob
    )

    # Out-of-time test metrics.
    test_prob = classifier.predict_proba(
        X_test,
        num_iteration=best_iteration
    )

    test_pred = np.argmax(test_prob, axis=1)

    test_class_metrics = classification_metrics(
        y_test_class,
        test_pred,
        test_prob
    )

    # Majority-class baseline.
    majority_class = int(
        y_train_class.value_counts().idxmax()
    )

    baseline_predictions = np.full(
        len(y_test_class),
        majority_class
    )

    baseline_accuracy = accuracy_score(
        y_test_class,
        baseline_predictions
    )

    baseline_balanced_accuracy = balanced_accuracy_score(
        y_test_class,
        baseline_predictions
    )

    # Save classifier.
    classifier.booster_.save_model(
        str(dataset_model_dir / "classifier.txt")
    )

    save_json(
        dataset_model_dir / "classifier_metadata.json",
        {
            "dataset": dataset_name,
            "features": FEATURES,
            "class_mapping": CLASS_NAMES,
            "best_iteration": best_iteration,
            "training_years": [2021, 2022, 2023],
            "validation_year": 2024,
            "test_year": 2025,
            "test_metrics": test_class_metrics,
            "validation_metrics": validation_class_metrics,
            "majority_baseline": {
                "class": CLASS_NAMES[majority_class],
                "accuracy": float(baseline_accuracy),
                "balanced_accuracy": float(
                    baseline_balanced_accuracy
                ),
            },
        }
    )

    write_feature_importance(
        classifier,
        dataset_name,
        "classifier"
    )

    print("\nCLASSIFICATION RESULTS - 2025 TEST")
    print(
        "Accuracy          :",
        f"{test_class_metrics['accuracy']:.4f}"
    )
    print(
        "Balanced accuracy :",
        f"{test_class_metrics['balanced_accuracy']:.4f}"
    )
    print(
        "Macro F1          :",
        f"{test_class_metrics['macro_f1']:.4f}"
    )
    print(
        "Log loss          :",
        f"{test_class_metrics['log_loss']:.4f}"
    )
    print(
        "Majority baseline :",
        f"{baseline_accuracy:.4f}"
    )

    # --------------------------------------------------------
    # REGRESSION MODEL
    # --------------------------------------------------------

    print("\nTraining LightGBM regressor...")

    regressor = lgb.LGBMRegressor(
        **REGRESSOR_PARAMS
    )

    regressor.fit(
        X_train,
        y_train_z,
        eval_set=[
            (X_valid, y_valid_z)
        ],
        eval_metric="l2",
        callbacks=[
            lgb.early_stopping(
                stopping_rounds=100,
                verbose=True
            ),
            lgb.log_evaluation(period=100),
        ],
    )

    regression_best_iteration = regressor.best_iteration_

    if not regression_best_iteration:
        regression_best_iteration = regressor.n_estimators

    # Validation regression metrics.
    valid_z_pred = regressor.predict(
        X_valid,
        num_iteration=regression_best_iteration
    )

    valid_regression_metrics = regression_metrics(
        y_valid_z.to_numpy(),
        valid_z_pred,
        np.full(
            len(y_valid_z),
            y_train_z.mean()
        )
    )

    # Out-of-time test regression metrics.
    test_z_pred = regressor.predict(
        X_test,
        num_iteration=regression_best_iteration
    )

    test_regression_metrics = regression_metrics(
        y_test_z.to_numpy(),
        test_z_pred,
        np.full(
            len(y_test_z),
            y_train_z.mean()
        )
    )

    # Save regressor.
    regressor.booster_.save_model(
        str(dataset_model_dir / "regressor.txt")
    )

    save_json(
        dataset_model_dir / "regressor_metadata.json",
        {
            "dataset": dataset_name,
            "features": FEATURES,
            "target": "target_z",
            "best_iteration": regression_best_iteration,
            "training_years": [2021, 2022, 2023],
            "validation_year": 2024,
            "test_year": 2025,
            "validation_metrics": valid_regression_metrics,
            "test_metrics": test_regression_metrics,
        }
    )

    write_feature_importance(
        regressor,
        dataset_name,
        "regressor"
    )

    print("\nREGRESSION RESULTS - 2025 TEST")
    print(
        "MAE               :",
        f"{test_regression_metrics['mae']:.4f}"
    )
    print(
        "RMSE              :",
        f"{test_regression_metrics['rmse']:.4f}"
    )
    print(
        "R2                :",
        f"{test_regression_metrics['r2']:.4f}"
    )
    print(
        "Directional agree :",
        f"{test_regression_metrics['directional_agreement']:.4f}"
    )
    print(
        "Baseline MAE      :",
        f"{test_regression_metrics['baseline_mean_mae']:.4f}"
    )

    # --------------------------------------------------------
    # SAVE TEST PREDICTIONS
    # --------------------------------------------------------

    predictions = pd.DataFrame({
        "trading_day": test["trading_day"].to_numpy(),
        "actual_class": y_test_class.to_numpy(),
        "predicted_class": test_pred,
        "actual_z": y_test_z.to_numpy(),
        "predicted_z": test_z_pred,
        "prob_down": test_prob[:, 0],
        "prob_sideways": test_prob[:, 1],
        "prob_up": test_prob[:, 2],
    })

    predictions_path = (
            OUTPUT_DIR / f"{dataset_name}_test_predictions.parquet"
    )

    predictions.to_parquet(
        predictions_path,
        index=False
    )

    # --------------------------------------------------------
    # COLLECT SUMMARY
    # --------------------------------------------------------

    all_metrics.append({
        "dataset": dataset_name,
        "train_rows": len(train),
        "validation_rows": len(validation),
        "test_rows": len(test),
        "classifier_best_iteration": best_iteration,
        "test_accuracy": test_class_metrics["accuracy"],
        "test_balanced_accuracy": (
            test_class_metrics["balanced_accuracy"]
        ),
        "test_macro_f1": test_class_metrics["macro_f1"],
        "test_log_loss": test_class_metrics["log_loss"],
        "majority_baseline_accuracy": float(
            baseline_accuracy
        ),
        "regressor_best_iteration": regression_best_iteration,
        "test_mae": test_regression_metrics["mae"],
        "test_rmse": test_regression_metrics["rmse"],
        "test_r2": test_regression_metrics["r2"],
        "test_directional_agreement": (
            test_regression_metrics["directional_agreement"]
        ),
    })

    print("\nSaved models:", dataset_model_dir)
    print("Saved predictions:", predictions_path)

    del df, train, validation, test
    del X_train, X_valid, X_test
    del classifier, regressor
    gc.collect()


# ============================================================
# FINAL SUMMARY
# ============================================================

summary = pd.DataFrame(all_metrics)

summary_path = OUTPUT_DIR / "training_summary.csv"

summary.to_csv(
    summary_path,
    index=False
)

print("\n" + "=" * 78)
print("ALL SIX DATASETS TRAINED")
print("=" * 78)

print(summary.to_string(index=False))

print("\nSummary:", summary_path)
print("Models :", MODEL_DIR)
print("Reports:", OUTPUT_DIR)
