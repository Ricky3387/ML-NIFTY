
from pathlib import Path
from datetime import datetime, timezone
import json
import re

import duckdb
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]

MERGED_FILE = (
        ROOT / "data/processed/nifty_index_options_features_v1/"
               "nifty_index_options_features_v1.parquet"
)

OPTIONS_FILE = (
        ROOT / "data/processed/nifty_options_features_v4/"
               "nifty_options_features_v4.parquet"
)

REPORT_DIR = ROOT / "reports/nifty_index_options_features_v1"
REPORT_DIR.mkdir(parents=True, exist_ok=True)

SUMMARY_FILE = REPORT_DIR / "feature_eligibility_leakage_summary.json"
INVENTORY_FILE = REPORT_DIR / "options_feature_inventory.csv"
COVERAGE_FILE = REPORT_DIR / "options_feature_coverage_by_split.csv"
REVIEW_FILE = REPORT_DIR / "feature_leakage_review.csv"


def qi(name):
    return '"' + name.replace('"', '""') + '"'


def sql_path(path):
    return "'" + str(path).replace("\\", "/").replace("'", "''") + "'"


def main():
    if not MERGED_FILE.exists():
        raise FileNotFoundError(MERGED_FILE)

    if not OPTIONS_FILE.exists():
        raise FileNotFoundError(OPTIONS_FILE)

    con = duckdb.connect(":memory:")
    con.execute("SET TimeZone='Asia/Kolkata'")
    con.execute("SET threads=4")

    con.execute(f"""
        CREATE VIEW merged AS
        SELECT * FROM read_parquet({sql_path(MERGED_FILE)})
    """)

    con.execute(f"""
        CREATE VIEW options_source AS
        SELECT * FROM read_parquet({sql_path(OPTIONS_FILE)})
    """)

    merged_schema = con.execute(
        "DESCRIBE SELECT * FROM merged"
    ).fetchdf()

    options_schema = con.execute(
        "DESCRIBE SELECT * FROM options_source"
    ).fetchdf()

    merged_cols = merged_schema["column_name"].tolist()
    options_cols = options_schema["column_name"].tolist()

    required = [
        "timestamp_ist",
        "trading_day",
        "horizon_minutes",
        "label",
        "sample_eligible",
        "options_trading_date",
        "options_spot_close"
    ]

    missing = [c for c in required if c not in merged_cols]
    if missing:
        raise RuntimeError(f"Missing required merged columns: {missing}")

    # Options columns carried into the merged dataset.
    source_metadata = {
        "timestamp_ist",
        "trading_date",
        "spot_close"
    }

    options_features = [
        c for c in options_cols
        if c not in source_metadata
    ]

    absent = [
        c for c in options_features
        if c not in merged_cols
    ]

    if absent:
        raise RuntimeError(
            f"Options source columns missing from merged file: {absent}"
        )

    # Metadata/redundant columns are audited but not recommended
    # as model predictors.
    excluded_from_candidates = {
        "timestamp",
        "options_trading_date",
        "options_spot_close",
        "selected_expiry"
    }

    # selected_expiry is retained in inventory for review.
    # It is excluded from the initial numeric model candidate list.
    candidate_features = [
        c for c in options_features
        if c not in excluded_from_candidates
    ]

    # ---------------------------------------------------------
    # 1. Core dataset and date/split checks
    # ---------------------------------------------------------

    core = con.execute("""
                       SELECT
                           COUNT(*) AS total_rows,
                           COUNT(DISTINCT timestamp_ist) AS unique_timestamps,
                           COUNT(DISTINCT horizon_minutes) AS horizon_count,

                           COUNT(*) FILTER (
                WHERE sample_eligible
            ) AS eligible_rows,

                           COUNT(*) FILTER (
                WHERE NOT sample_eligible
            ) AS ineligible_rows,

                           COUNT(*) FILTER (
                WHERE CAST(trading_day AS DATE)
                    BETWEEN DATE '2021-05-24' AND DATE '2023-12-31'
                  AND sample_eligible
            ) AS train_eligible_rows,

                           COUNT(*) FILTER (
                WHERE CAST(trading_day AS DATE)
                    BETWEEN DATE '2024-01-01' AND DATE '2024-12-31'
                  AND sample_eligible
            ) AS validation_eligible_rows,

                           COUNT(*) FILTER (
                WHERE CAST(trading_day AS DATE) > DATE '2024-12-31'
            ) AS rows_after_2024,

                           MIN(CAST(trading_day AS DATE)) AS first_trading_day,
                           MAX(CAST(trading_day AS DATE)) AS last_trading_day

                       FROM merged
                       """).fetchdf().iloc[0].to_dict()

    duplicate_keys = con.execute("""
                                 SELECT COUNT(*)
                                 FROM (
                                          SELECT timestamp_ist, horizon_minutes
                                          FROM merged
                                          GROUP BY timestamp_ist, horizon_minutes
                                          HAVING COUNT(*) > 1
                                      )
                                 """).fetchone()[0]

    horizon_counts = con.execute("""
                                 SELECT
                                     horizon_minutes,
                                     COUNT(*) AS total_rows,
                                     COUNT(*) FILTER (
                WHERE sample_eligible
            ) AS eligible_rows
                                 FROM merged
                                 GROUP BY horizon_minutes
                                 ORDER BY horizon_minutes
                                 """).fetchdf()

    # ---------------------------------------------------------
    # 2. Feature inventory and NULL rates
    # ---------------------------------------------------------

    schema_type = dict(zip(
        options_schema["column_name"],
        options_schema["column_type"]
    ))

    inventory = []

    for col in options_features:
        dtype = schema_type[col]

        result = con.execute(f"""
            SELECT
                COUNT(*) FILTER (
                    WHERE sample_eligible
                ) AS eligible_rows,

                COUNT({qi(col)}) FILTER (
                    WHERE sample_eligible
                ) AS eligible_nonnull,

                COUNT(*) FILTER (
                    WHERE sample_eligible
                      AND {qi(col)} IS NULL
                ) AS eligible_null,

                COUNT({qi(col)}) AS all_rows_nonnull

            FROM merged
        """).fetchone()

        eligible_rows, nonnull, nulls, all_nonnull = result

        null_pct = (
            100.0 * nulls / eligible_rows
            if eligible_rows else None
        )

        inventory.append({
            "feature": col,
            "data_type": dtype,
            "eligible_rows": eligible_rows,
            "eligible_nonnull": nonnull,
            "eligible_null": nulls,
            "eligible_null_pct": round(null_pct, 4)
            if null_pct is not None else None,
            "all_rows_nonnull": all_nonnull,
            "model_candidate": col in candidate_features,
            "candidate_exclusion_reason": (
                "metadata_or_redundant"
                if col in excluded_from_candidates
                else ""
            )
        })

    inventory_df = pd.DataFrame(inventory)
    inventory_df.to_csv(INVENTORY_FILE, index=False)

    # ---------------------------------------------------------
    # 3. Coverage by train/validation and horizon
    # ---------------------------------------------------------

    coverage_rows = []

    for col in candidate_features:
        for split_name, start_date, end_date in [
            ("TRAIN", "2021-05-24", "2023-12-31"),
            ("VALIDATION", "2024-01-01", "2024-12-31")
        ]:
            result = con.execute(f"""
                SELECT
                    horizon_minutes,
                    COUNT(*) AS eligible_rows,
                    COUNT({qi(col)}) AS nonnull_rows,
                    COUNT(*) - COUNT({qi(col)}) AS null_rows,
                    ROUND(
                        100.0 * COUNT({qi(col)})
                        / NULLIF(COUNT(*), 0),
                        4
                    ) AS nonnull_pct
                FROM merged
                WHERE sample_eligible
                  AND CAST(trading_day AS DATE)
                      BETWEEN DATE '{start_date}'
                          AND DATE '{end_date}'
                GROUP BY horizon_minutes
                ORDER BY horizon_minutes
            """).fetchall()

            for row in result:
                coverage_rows.append({
                    "feature": col,
                    "split": split_name,
                    "horizon_minutes": row[0],
                    "eligible_rows": row[1],
                    "nonnull_rows": row[2],
                    "null_rows": row[3],
                    "nonnull_pct": row[4]
                })

    coverage_df = pd.DataFrame(coverage_rows)
    coverage_df.to_csv(COVERAGE_FILE, index=False)

    # ---------------------------------------------------------
    # 4. Leakage-name review
    # ---------------------------------------------------------

    suspicious_patterns = [
        r"future",
        r"forward",
        r"target",
        r"label",
        r"lead",
        r"next_",
        r"t\+",
        r"lookahead",
        r"outcome"
    ]

    review_rows = []

    # Review all options columns and selected index target columns.
    columns_to_review = list(options_features)

    index_target_columns = [
        c for c in merged_cols
        if re.search(
            r"future|forward|target|label|lead|next_|lookahead|outcome",
            c,
            re.IGNORECASE
        )
    ]

    for col in sorted(set(columns_to_review + index_target_columns)):
        matches = [
            pattern for pattern in suspicious_patterns
            if re.search(pattern, col, re.IGNORECASE)
        ]

        review_rows.append({
            "column": col,
            "source": (
                "options"
                if col in options_features
                else "index_or_label"
            ),
            "suspicious_name_match": bool(matches),
            "matched_patterns": ",".join(matches),
            "manual_review_required": bool(matches),
            "initial_recommendation": (
                "EXCLUDE_PENDING_REVIEW"
                if matches
                else (
                    "TARGET_OR_LABEL_NOT_A_PREDICTOR"
                    if col in index_target_columns
                    else "REVIEW_TEMPORAL_AVAILABILITY"
                )
            )
        })

    review_df = pd.DataFrame(review_rows)
    review_df.to_csv(REVIEW_FILE, index=False)

    # ---------------------------------------------------------
    # 5. Options join and synthetic-row checks
    # ---------------------------------------------------------

    options_date_mismatches = con.execute("""
                                          SELECT COUNT(*)
                                          FROM merged
                                          WHERE options_trading_date IS NOT NULL
                                            AND CAST(options_trading_date AS DATE)
                                              <> CAST(trading_day AS DATE)
                                          """).fetchone()[0]

    missing_join_with_nonnull_feature = {}

    for col in options_features:
        count = con.execute(f"""
            SELECT COUNT(*)
            FROM merged
            WHERE options_trading_date IS NULL
              AND {qi(col)} IS NOT NULL
        """).fetchone()[0]

        missing_join_with_nonnull_feature[col] = count

    join_leakage_violations = sum(
        missing_join_with_nonnull_feature.values()
    )

    synthetic_rows = None
    eligible_synthetic_rows = None

    if "is_synthetic" in merged_cols:
        synthetic_rows = con.execute("""
                                     SELECT COUNT(*)
                                     FROM merged
                                     WHERE COALESCE(is_synthetic, FALSE)
                                     """).fetchone()[0]

        eligible_synthetic_rows = con.execute("""
                                              SELECT COUNT(*)
                                              FROM merged
                                              WHERE COALESCE(is_synthetic, FALSE)
                                                AND sample_eligible
                                              """).fetchone()[0]

    eligible_missing_targets = con.execute("""
                                           SELECT COUNT(*)
                                           FROM merged
                                           WHERE sample_eligible
                                             AND (
                                               label IS NULL
                                                   OR horizon_minutes IS NULL
                                                   OR target_z IS NULL
                                               )
                                           """).fetchone()[0] if "target_z" in merged_cols else con.execute("""
                                                                                                            SELECT COUNT(*)
                                                                                                            FROM merged
                                                                                                            WHERE sample_eligible
                                                                                                              AND label IS NULL
                                                                                                            """).fetchone()[0]

    # ---------------------------------------------------------
    # 6. Checks and summary
    # ---------------------------------------------------------

    checks = {
        "expected_merged_row_count": core["total_rows"] == 1003005,
        "no_duplicate_timestamp_horizon_keys": duplicate_keys == 0,
        "three_prediction_horizons": core["horizon_count"] == 3,
        "no_rows_after_2024": core["rows_after_2024"] == 0,
        "no_options_date_mismatches": options_date_mismatches == 0,
        "no_options_features_without_join": join_leakage_violations == 0,
        "eligible_rows_have_targets": eligible_missing_targets == 0,
    }

    if eligible_synthetic_rows is not None:
        checks["no_synthetic_eligible_rows"] = (
                eligible_synthetic_rows == 0
        )

    suspicious_options = [
        row["column"]
        for row in review_rows
        if row["source"] == "options"
           and row["suspicious_name_match"]
    ]

    summary = {
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "merged_file": str(MERGED_FILE),
        "options_source_file": str(OPTIONS_FILE),
        "core": core,
        "horizon_counts": horizon_counts.to_dict(orient="records"),
        "options_source_feature_count": len(options_features),
        "initial_options_model_candidate_count": len(candidate_features),
        "duplicate_timestamp_horizon_groups": duplicate_keys,
        "options_date_mismatches": options_date_mismatches,
        "options_feature_nonnull_without_join_violations":
            join_leakage_violations,
        "eligible_missing_target_rows": eligible_missing_targets,
        "synthetic_rows": synthetic_rows,
        "eligible_synthetic_rows": eligible_synthetic_rows,
        "suspicious_options_feature_names": suspicious_options,
        "checks": checks,
        "passed_checks": sum(checks.values()),
        "total_checks": len(checks),
        "overall_status": (
            "PASS" if all(checks.values()) else "REVIEW_REQUIRED"
        ),
        "important_limitations": [
            "Name-based leakage scanning cannot prove temporal safety.",
            "Source timestamps and provider publication semantics must be verified.",
            "Features using the current completed bar assume end-of-bar prediction.",
            "Options feature missingness must be handled without forward filling.",
            "The initial candidate list is an audit list, not final model approval."
        ],
        "reports": {
            "feature_inventory": str(INVENTORY_FILE),
            "coverage_by_split": str(COVERAGE_FILE),
            "leakage_review": str(REVIEW_FILE)
        }
    }

    SUMMARY_FILE.write_text(
        json.dumps(summary, indent=2, default=str),
        encoding="utf-8"
    )

    print("\n" + "=" * 75)
    print("NIFTY FEATURE ELIGIBILITY AND LEAKAGE AUDIT")
    print("=" * 75)

    print(json.dumps(summary, indent=2, default=str))

    print("\nOPTIONS FEATURE INVENTORY")
    print(inventory_df.to_string(index=False))

    print("\nGenerated reports:")
    print(SUMMARY_FILE)
    print(INVENTORY_FILE)
    print(COVERAGE_FILE)
    print(REVIEW_FILE)

    con.close()


if __name__ == "__main__":
    main()
