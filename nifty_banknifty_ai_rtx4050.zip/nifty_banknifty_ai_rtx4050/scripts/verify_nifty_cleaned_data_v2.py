
from pathlib import Path
import duckdb
import json

ROOT = Path(__file__).resolve().parents[1]

DB_PATH = ROOT / "data/database/nifty_options.duckdb"

CLEAN_PATH = (
        ROOT / "data/processed/nifty_index_cleaned/"
        / "nifty_index_cleaned_final.parquet"
)

OUT_DIR = ROOT / "reports/nifty_final_data_verification_v2"
OUT_DIR.mkdir(parents=True, exist_ok=True)

START_DATE = "2021-05-24"
END_DATE = "2024-12-31"

# Special sessions excluded from the normal-session dataset.
SPECIAL_DATES = [
    "2021-11-04",
    "2022-10-24",
    "2023-11-12",
    "2024-11-01",
    "2024-01-20",
    "2024-03-02",
    "2024-05-18",
]

if not DB_PATH.exists():
    raise FileNotFoundError(DB_PATH)

if not CLEAN_PATH.exists():
    raise FileNotFoundError(CLEAN_PATH)

con = duckdb.connect(str(DB_PATH), read_only=True)

print("=" * 90)
print("NIFTY CLEANED DATA VERIFICATION V2")
print("=" * 90)

# ------------------------------------------------------------
# 1. Inspect cleaned Parquet schema
# ------------------------------------------------------------

path_sql = str(CLEAN_PATH).replace("\\", "/").replace("'", "''")

desc = con.execute(
    f"DESCRIBE SELECT * FROM read_parquet('{path_sql}')"
).fetchdf()

print("\nCLEANED PARQUET SCHEMA")
print(desc.to_string(index=False))

columns = {
    row["column_name"].lower(): row["column_name"]
    for _, row in desc.iterrows()
}

required = ["timestamp", "open", "high", "low", "close"]

missing = [c for c in required if c not in columns]

if missing:
    raise ValueError(
        f"Required columns missing from cleaned Parquet: {missing}"
    )

timestamp_col = columns["timestamp"]

# Determine whether cleaned timestamps are timezone-aware.
timestamp_type = next(
    row["column_type"]
    for _, row in desc.iterrows()
    if row["column_name"] == timestamp_col
).upper()

if "TIMESTAMPTZ" in timestamp_type:
    cleaned_timestamp_expr = (
        f"timezone('Asia/Kolkata', c.{timestamp_col})"
    )
else:
    # Existing cleaned Parquet timestamps are expected to be
    # naive IST clock values if they are not timezone-aware.
    cleaned_timestamp_expr = (
        f"CAST(c.{timestamp_col} AS TIMESTAMP)"
    )

synthetic_col = columns.get("is_synthetic")

if synthetic_col:
    synthetic_expr = (
        f"COALESCE(CAST(c.{synthetic_col} AS BOOLEAN), FALSE)"
    )
else:
    synthetic_expr = "FALSE"

volume_col = columns.get("volume")

if volume_col:
    cleaned_volume_expr = f"CAST(c.{volume_col} AS DOUBLE)"
else:
    cleaned_volume_expr = "NULL::DOUBLE"

special_sql = ", ".join(
    f"DATE '{d}'" for d in SPECIAL_DATES
)

# ------------------------------------------------------------
# 2. Original source rows converted to IST
# ------------------------------------------------------------

con.execute(f"""
CREATE OR REPLACE TEMP VIEW source_normal AS
SELECT
    timezone('Asia/Kolkata', timestamp) AS ist_timestamp,
    CAST(trading_day AS DATE) AS trading_day,
    CAST(open AS DOUBLE) AS open,
    CAST(high AS DOUBLE) AS high,
    CAST(low AS DOUBLE) AS low,
    CAST(close AS DOUBLE) AS close,
    CAST(volume AS DOUBLE) AS volume
FROM nifty_index
WHERE CAST(trading_day AS DATE)
      BETWEEN DATE '{START_DATE}' AND DATE '{END_DATE}'
  AND CAST(timezone('Asia/Kolkata', timestamp) AS TIME)
      BETWEEN TIME '09:15:00' AND TIME '15:29:00'
  AND CAST(trading_day AS DATE) NOT IN ({special_sql})
""")

# ------------------------------------------------------------
# 3. Cleaned real rows
# ------------------------------------------------------------

con.execute(f"""
CREATE OR REPLACE TEMP VIEW cleaned_normal AS
SELECT
    CAST({cleaned_timestamp_expr} AS TIMESTAMP)
        AS ist_timestamp,

    CAST(c.trading_day AS DATE) AS trading_day,

    CAST(c.open AS DOUBLE) AS open,
    CAST(c.high AS DOUBLE) AS high,
    CAST(c.low AS DOUBLE) AS low,
    CAST(c.close AS DOUBLE) AS close,

    {cleaned_volume_expr} AS volume,

    {synthetic_expr} AS is_synthetic

FROM read_parquet('{path_sql}') c

WHERE CAST(c.trading_day AS DATE)
      BETWEEN DATE '{START_DATE}' AND DATE '{END_DATE}'
  AND CAST({cleaned_timestamp_expr} AS TIME)
      BETWEEN TIME '09:15:00' AND TIME '15:29:00'
  AND CAST(c.trading_day AS DATE) NOT IN ({special_sql})
""")

# ------------------------------------------------------------
# 4. Basic row counts
# ------------------------------------------------------------

print("\n" + "=" * 90)
print("BASIC DATA COUNTS")
print("=" * 90)

counts = con.execute("""
                     SELECT
                             (SELECT COUNT(*) FROM source_normal)
                             AS source_normal_rows,

                             (SELECT COUNT(*) FROM cleaned_normal)
                             AS cleaned_rows_in_session,

                             (SELECT COUNT(*) FROM cleaned_normal
                              WHERE NOT is_synthetic)
                             AS cleaned_real_rows,

                             (SELECT COUNT(*) FROM cleaned_normal
                              WHERE is_synthetic)
                             AS cleaned_synthetic_rows,

                             (SELECT COUNT(DISTINCT ist_timestamp)
                              FROM source_normal)
                             AS source_unique_timestamps,

                             (SELECT COUNT(DISTINCT ist_timestamp)
                              FROM cleaned_normal)
                             AS cleaned_unique_timestamps
                     """).fetchdf()

print(counts.to_string(index=False))

counts.to_csv(
    OUT_DIR / "basic_counts.csv",
    index=False
)

# ------------------------------------------------------------
# 5. Detect duplicate timestamps
# ------------------------------------------------------------

duplicates = con.execute("""
                         SELECT
                             'SOURCE' AS dataset,
                             ist_timestamp,
                             COUNT(*) AS duplicate_count
                         FROM source_normal
                         GROUP BY ist_timestamp
                         HAVING COUNT(*) > 1

                         UNION ALL

                         SELECT
                             'CLEANED_REAL' AS dataset,
                             ist_timestamp,
                             COUNT(*) AS duplicate_count
                         FROM cleaned_normal
                         WHERE NOT is_synthetic
                         GROUP BY ist_timestamp
                         HAVING COUNT(*) > 1
                         ORDER BY dataset, ist_timestamp
                         """).fetchdf()

print("\nDUPLICATE TIMESTAMPS:", len(duplicates))

duplicates.to_csv(
    OUT_DIR / "duplicate_timestamps.csv",
    index=False
)

# ------------------------------------------------------------
# 6. Compare source and cleaned timestamps and OHLC
# ------------------------------------------------------------

con.execute("""
            CREATE OR REPLACE TEMP VIEW source_grouped AS
            SELECT
                ist_timestamp,
                COUNT(*) AS source_count,
                MAX(open) AS open,
    MAX(high) AS high,
    MAX(low) AS low,
    MAX(close) AS close,
    MAX(volume) AS volume
            FROM source_normal
            GROUP BY ist_timestamp
            """)

con.execute("""
            CREATE OR REPLACE TEMP VIEW cleaned_grouped AS
            SELECT
                ist_timestamp,
                COUNT(*) AS cleaned_count,
                MAX(open) AS open,
    MAX(high) AS high,
    MAX(low) AS low,
    MAX(close) AS close,
    MAX(volume) AS volume
            FROM cleaned_normal
            WHERE NOT is_synthetic
            GROUP BY ist_timestamp
            """)

comparison = con.execute("""
                         SELECT
                             COALESCE(s.ist_timestamp, c.ist_timestamp)
                                 AS ist_timestamp,

                             CASE
                                 WHEN s.ist_timestamp IS NULL THEN 'CLEANED_ONLY'
                                 WHEN c.ist_timestamp IS NULL THEN 'SOURCE_ONLY'

                                 WHEN s.source_count <> c.cleaned_count
                                     THEN 'DUPLICATE_COUNT_MISMATCH'

                                 WHEN s.open IS DISTINCT FROM c.open
                             OR s.high IS DISTINCT FROM c.high
                             OR s.low IS DISTINCT FROM c.low
                             OR s.close IS DISTINCT FROM c.close
                             OR s.volume IS DISTINCT FROM c.volume
                             THEN 'OHLCV_MISMATCH'

                             ELSE 'MATCH'
                         END AS comparison_status,

    s.open AS source_open,
    c.open AS cleaned_open,

    s.high AS source_high,
    c.high AS cleaned_high,

    s.low AS source_low,
    c.low AS cleaned_low,

    s.close AS source_close,
    c.close AS cleaned_close,

    s.volume AS source_volume,
    c.volume AS cleaned_volume

FROM source_grouped s
FULL OUTER JOIN cleaned_grouped c
    ON s.ist_timestamp = c.ist_timestamp

ORDER BY ist_timestamp
                         """).fetchdf()

print("\nCOMPARISON STATUS")
print(
    comparison["comparison_status"]
    .value_counts(dropna=False)
    .to_string()
)

comparison.to_csv(
    OUT_DIR / "source_cleaned_comparison.csv",
    index=False
)

# ------------------------------------------------------------
# 7. Synthetic bar profile
# ------------------------------------------------------------

synthetic = con.execute("""
                        SELECT
                            trading_day,
                            COUNT(*) AS synthetic_rows,
                            MIN(ist_timestamp) AS first_timestamp,
                            MAX(ist_timestamp) AS last_timestamp
                        FROM cleaned_normal
                        WHERE is_synthetic
                        GROUP BY trading_day
                        ORDER BY trading_day
                        """).fetchdf()

synthetic.to_csv(
    OUT_DIR / "synthetic_bar_profile.csv",
    index=False
)

print("\nSYNTHETIC ROWS:", len(synthetic))
print(synthetic.head(20).to_string(index=False))

# ------------------------------------------------------------
# 8. Daily coverage comparison
# ------------------------------------------------------------

daily = con.execute("""
                    WITH s AS (
                        SELECT
                            trading_day,
                            COUNT(*) AS source_rows
                        FROM source_normal
                        GROUP BY trading_day
                    ),
                         c AS (
                             SELECT
                                 trading_day,
                                 COUNT(*) AS cleaned_rows,
                                 SUM(CASE WHEN is_synthetic THEN 1 ELSE 0 END)
                                          AS synthetic_rows
                             FROM cleaned_normal
                             GROUP BY trading_day
                         )
                    SELECT
                        COALESCE(s.trading_day, c.trading_day) AS trading_day,
                        COALESCE(s.source_rows, 0) AS source_rows,
                        COALESCE(c.cleaned_rows, 0) AS cleaned_rows,
                        COALESCE(c.synthetic_rows, 0) AS synthetic_rows
                    FROM s
                             FULL OUTER JOIN c USING (trading_day)
                    WHERE COALESCE(s.source_rows, 0)
                        <> COALESCE(c.cleaned_rows, 0)
                       OR COALESCE(c.synthetic_rows, 0) > 0
                    ORDER BY trading_day
                    """).fetchdf()

daily.to_csv(
    OUT_DIR / "daily_coverage_differences.csv",
    index=False
)

# ------------------------------------------------------------
# 9. Summary
# ------------------------------------------------------------

status_counts = (
    comparison["comparison_status"]
    .value_counts()
    .to_dict()
)

summary = {
    "start_date": START_DATE,
    "end_date": END_DATE,
    "special_dates_excluded": SPECIAL_DATES,
    "cleaned_timestamp_type": timestamp_type,
    "source_rows": int(counts.iloc[0]["source_normal_rows"]),
    "cleaned_rows": int(counts.iloc[0]["cleaned_rows_in_session"]),
    "cleaned_real_rows": int(counts.iloc[0]["cleaned_real_rows"]),
    "synthetic_rows": int(counts.iloc[0]["cleaned_synthetic_rows"]),
    "duplicate_timestamp_groups": len(duplicates),
    "comparison_status": {
        str(k): int(v) for k, v in status_counts.items()
    },
    "daily_coverage_difference_rows": len(daily)
}

with open(
        OUT_DIR / "verification_summary.json",
        "w",
        encoding="utf-8"
) as f:
    json.dump(summary, f, indent=2, default=str)

print("\n" + "=" * 90)
print("VERIFICATION SUMMARY")
print("=" * 90)
print(json.dumps(summary, indent=2, default=str))

con.close()

print("\nVerification completed.")
print("Output directory:", OUT_DIR)
print("Original database and cleaned Parquet were not modified.")
