
from pathlib import Path
import sys
import pandas as pd
import duckdb

# ============================================================
# CONFIGURATION
# ============================================================

ROOT = Path(__file__).resolve().parents[1]

DB_PATH = ROOT / "data" / "database" / "nifty_options.duckdb"
ELIGIBILITY_DIR = ROOT / "data" / "training" / "eligibility"
OUTPUT_DIR = ROOT / "data" / "training" / "index_features"

CONFIG = {
    "NIFTY": {
        "view": "nifty_index",
        "eligibility": "nifty_daily_eligibility.csv",
    },
    "BANKNIFTY": {
        "view": "banknifty_index",
        "eligibility": "banknifty_daily_eligibility.csv",
    },
}

# DuckDB memory limit. Adjust only if required.
MEMORY_LIMIT = "6GB"
THREADS = 4

HORIZONS = [5, 15, 30]


# ============================================================
# FEATURE SQL
# ============================================================

def build_feature_query(view_name):

    return f"""
    WITH base AS (
        SELECT
            timestamp,
            CAST(trading_day AS DATE) AS trading_day,
            symbol,
            open,
            high,
            low,
            close,
            volume,

            epoch(CAST(timestamp AS TIMESTAMPTZ))
                AS epoch_seconds,

            -- Historical closes for features
            LAG(close, 1) OVER w AS close_lag_1,
            LAG(close, 5) OVER w AS close_lag_5,
            LAG(close, 15) OVER w AS close_lag_15,
            LAG(close, 30) OVER w AS close_lag_30,

            -- Historical timestamps for continuity checks
            LAG(epoch(CAST(timestamp AS TIMESTAMPTZ)), 1)
                OVER w AS epoch_lag_1,

            LAG(epoch(CAST(timestamp AS TIMESTAMPTZ)), 5)
                OVER w AS epoch_lag_5,

            LAG(epoch(CAST(timestamp AS TIMESTAMPTZ)), 15)
                OVER w AS epoch_lag_15,

            LAG(epoch(CAST(timestamp AS TIMESTAMPTZ)), 30)
                OVER w AS epoch_lag_30,

            LAG(epoch(CAST(timestamp AS TIMESTAMPTZ)), 60)
                OVER w AS epoch_lag_60,

            -- Future closes for target labels
            LEAD(close, 5) OVER w AS future_close_5,
            LEAD(close, 15) OVER w AS future_close_15,
            LEAD(close, 30) OVER w AS future_close_30,

            LEAD(epoch(CAST(timestamp AS TIMESTAMPTZ)), 5)
                OVER w AS future_epoch_5,

            LEAD(epoch(CAST(timestamp AS TIMESTAMPTZ)), 15)
                OVER w AS future_epoch_15,

            LEAD(epoch(CAST(timestamp AS TIMESTAMPTZ)), 30)
                OVER w AS future_epoch_30

        FROM {view_name}

        WINDOW w AS (
            PARTITION BY trading_day
            ORDER BY timestamp
        )
    ),

    returns AS (
        SELECT
            *,

            CASE
                WHEN epoch_seconds - epoch_lag_1 = 60
                THEN close / NULLIF(close_lag_1, 0) - 1
            END AS return_1m,

            CASE
                WHEN epoch_seconds - epoch_lag_5 = 300
                THEN close / NULLIF(close_lag_5, 0) - 1
            END AS return_5m,

            CASE
                WHEN epoch_seconds - epoch_lag_15 = 900
                THEN close / NULLIF(close_lag_15, 0) - 1
            END AS return_15m,

            CASE
                WHEN epoch_seconds - epoch_lag_30 = 1800
                THEN close / NULLIF(close_lag_30, 0) - 1
            END AS return_30m,

            CASE
                WHEN epoch_seconds - epoch_lag_1 = 60
                THEN LN(close / NULLIF(close_lag_1, 0))
            END AS log_return_1m

        FROM base
    ),

    rolling AS (
        SELECT
            *,

            -- Realized volatility from consecutive 1-minute returns
            CASE
                WHEN epoch_seconds - epoch_lag_5 = 300
                   AND COUNT(log_return_1m) OVER (
                       PARTITION BY trading_day
                       ORDER BY timestamp
                       ROWS BETWEEN 4 PRECEDING AND CURRENT ROW
                   ) = 5
                THEN STDDEV_SAMP(log_return_1m) OVER (
                    PARTITION BY trading_day
                    ORDER BY timestamp
                    ROWS BETWEEN 4 PRECEDING AND CURRENT ROW
                )
            END AS volatility_5m,

            CASE
                WHEN epoch_seconds - epoch_lag_15 = 900
                   AND COUNT(log_return_1m) OVER (
                       PARTITION BY trading_day
                       ORDER BY timestamp
                       ROWS BETWEEN 14 PRECEDING AND CURRENT ROW
                   ) = 15
                THEN STDDEV_SAMP(log_return_1m) OVER (
                    PARTITION BY trading_day
                    ORDER BY timestamp
                    ROWS BETWEEN 14 PRECEDING AND CURRENT ROW
                )
            END AS volatility_15m,

            CASE
                WHEN epoch_seconds - epoch_lag_30 = 1800
                   AND COUNT(log_return_1m) OVER (
                       PARTITION BY trading_day
                       ORDER BY timestamp
                       ROWS BETWEEN 29 PRECEDING AND CURRENT ROW
                   ) = 30
                THEN STDDEV_SAMP(log_return_1m) OVER (
                    PARTITION BY trading_day
                    ORDER BY timestamp
                    ROWS BETWEEN 29 PRECEDING AND CURRENT ROW
                )
            END AS volatility_30m,

            CASE
                WHEN epoch_seconds - epoch_lag_60 = 3600
                   AND COUNT(log_return_1m) OVER (
                       PARTITION BY trading_day
                       ORDER BY timestamp
                       ROWS BETWEEN 59 PRECEDING AND CURRENT ROW
                   ) = 60
                THEN STDDEV_SAMP(log_return_1m) OVER (
                    PARTITION BY trading_day
                    ORDER BY timestamp
                    ROWS BETWEEN 59 PRECEDING AND CURRENT ROW
                )
            END AS volatility_60m,

            -- Volume statistics
            AVG(volume) OVER (
                PARTITION BY trading_day
                ORDER BY timestamp
                ROWS BETWEEN 29 PRECEDING AND CURRENT ROW
            ) AS avg_volume_30,

            STDDEV_SAMP(volume) OVER (
                PARTITION BY trading_day
                ORDER BY timestamp
                ROWS BETWEEN 29 PRECEDING AND CURRENT ROW
            ) AS std_volume_30,

            COUNT(*) OVER (
                PARTITION BY trading_day
                ORDER BY timestamp
                ROWS BETWEEN 29 PRECEDING AND CURRENT ROW
            ) AS volume_window_count,

            -- Rolling price range
            MAX(high) OVER (
                PARTITION BY trading_day
                ORDER BY timestamp
                ROWS BETWEEN 14 PRECEDING AND CURRENT ROW
            ) AS rolling_high_15,

            MIN(low) OVER (
                PARTITION BY trading_day
                ORDER BY timestamp
                ROWS BETWEEN 14 PRECEDING AND CURRENT ROW
            ) AS rolling_low_15,

            MAX(high) OVER (
                PARTITION BY trading_day
                ORDER BY timestamp
                ROWS BETWEEN 29 PRECEDING AND CURRENT ROW
            ) AS rolling_high_30,

            MIN(low) OVER (
                PARTITION BY trading_day
                ORDER BY timestamp
                ROWS BETWEEN 29 PRECEDING AND CURRENT ROW
            ) AS rolling_low_30,

            -- Intraday cumulative VWAP
            SUM(((high + low + close) / 3.0) * volume) OVER (
                PARTITION BY trading_day
                ORDER BY timestamp
                ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
            ) AS cumulative_price_volume,

            SUM(volume) OVER (
                PARTITION BY trading_day
                ORDER BY timestamp
                ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
            ) AS cumulative_volume

        FROM returns
    ),

    derived AS (
        SELECT
            *,

            -- Candle structure
            (high - low) / NULLIF(close, 0)
                AS candle_range_pct,

            (close - open) / NULLIF(open, 0)
                AS candle_body_pct,

            (high - GREATEST(open, close))
                / NULLIF(close, 0)
                AS upper_wick_pct,

            (LEAST(open, close) - low)
                / NULLIF(close, 0)
                AS lower_wick_pct,

            (close - low) / NULLIF(high - low, 0)
                AS close_location,

            -- VWAP
            cumulative_price_volume
                / NULLIF(cumulative_volume, 0)
                AS intraday_vwap,

            (
                close -
                cumulative_price_volume
                / NULLIF(cumulative_volume, 0)
            ) / NULLIF(
                cumulative_price_volume
                / NULLIF(cumulative_volume, 0), 0
            ) AS vwap_deviation_pct,

            -- Volume
            LN(1.0 + GREATEST(volume, 0))
                AS log_volume,

            volume / NULLIF(avg_volume_30, 0)
                AS volume_ratio_30,

            (volume - avg_volume_30)
                / NULLIF(std_volume_30, 0)
                AS volume_zscore_30,

            -- Rolling range position
            (close - rolling_low_15)
                / NULLIF(rolling_high_15 - rolling_low_15, 0)
                AS range_position_15,

            (close - rolling_low_30)
                / NULLIF(rolling_high_30 - rolling_low_30, 0)
                AS range_position_30,

            -- Time features
            CAST(strftime(timestamp, '%H') AS INTEGER) * 60
                + CAST(strftime(timestamp, '%M') AS INTEGER)
                AS minute_of_day,

            EXTRACT(ISODOW FROM trading_day)
                AS day_of_week,

            EXTRACT(MONTH FROM trading_day)
                AS month_of_year

        FROM rolling
    ),

    labels AS (
        SELECT
            *,

            -- Forward returns only if exact target minute exists
            CASE
                WHEN future_epoch_5 - epoch_seconds = 300
                THEN future_close_5 / NULLIF(close, 0) - 1
            END AS future_return_5m,

            CASE
                WHEN future_epoch_15 - epoch_seconds = 900
                THEN future_close_15 / NULLIF(close, 0) - 1
            END AS future_return_15m,

            CASE
                WHEN future_epoch_30 - epoch_seconds = 1800
                THEN future_close_30 / NULLIF(close, 0) - 1
            END AS future_return_30m

        FROM derived
    )

    SELECT
        timestamp,
        trading_day,
        symbol,

        open,
        high,
        low,
        close,
        volume,

        -- Time
        minute_of_day,
        day_of_week,
        month_of_year,

        -- Returns
        return_1m,
        return_5m,
        return_15m,
        return_30m,

        -- Volatility
        volatility_5m,
        volatility_15m,
        volatility_30m,
        volatility_60m,

        -- Candle features
        candle_range_pct,
        candle_body_pct,
        upper_wick_pct,
        lower_wick_pct,
        close_location,

        -- VWAP
        intraday_vwap,
        vwap_deviation_pct,

        -- Volume
        log_volume,
        avg_volume_30,
        volume_ratio_30,
        volume_zscore_30,

        -- Price range
        rolling_high_15,
        rolling_low_15,
        rolling_high_30,
        rolling_low_30,
        range_position_15,
        range_position_30,

        -- Continuous prediction labels
        future_return_5m,
        future_return_15m,
        future_return_30m,

        future_return_5m IS NOT NULL AS label_valid_5m,
        future_return_15m IS NOT NULL AS label_valid_15m,
        future_return_30m IS NOT NULL AS label_valid_30m

    FROM labels
    """


# ============================================================
# PROCESS ONE INDEX
# ============================================================

def process_index(con, index_name, config):

    print("\n" + "=" * 75)
    print("BUILDING INDEX FEATURES:", index_name)
    print("=" * 75)

    eligibility_path = (
            ELIGIBILITY_DIR / config["eligibility"]
    )

    if not eligibility_path.exists():
        raise FileNotFoundError(eligibility_path)

    eligibility = pd.read_csv(eligibility_path)

    eligibility["trading_day"] = pd.to_datetime(
        eligibility["trading_day"]
    ).dt.date

    if eligibility["trading_day"].duplicated().any():
        raise ValueError(
            f"Duplicate trading days in {eligibility_path}"
        )

    eligibility = eligibility[
        ["trading_day", "eligible_for_index_model"]
    ].copy()

    eligibility["eligible_for_index_model"] = (
        eligibility["eligible_for_index_model"].astype(bool)
    )

    registration_name = f"{index_name.lower()}_eligibility"

    con.register(registration_name, eligibility)

    query = build_feature_query(config["view"])

    output_path = (
            OUTPUT_DIR / f"{index_name.lower()}_index_features.parquet"
    )

    output_sql_path = str(output_path).replace("\\", "/")

    final_query = f"""
        SELECT
            f.*,
            COALESCE(
                e.eligible_for_index_model,
                FALSE
            ) AS eligible_for_index_model

        FROM ({query}) f

        LEFT JOIN {registration_name} e
            ON f.trading_day = e.trading_day
    """

    print("Generating feature dataset...")
    print("This may take a few minutes.")

    con.execute(f"""
        COPY ({final_query})
        TO '{output_sql_path}'
        (FORMAT PARQUET, COMPRESSION ZSTD)
    """)

    print("Generated:", output_path)

    # --------------------------------------------------------
    # Dataset summary
    # --------------------------------------------------------

    path_for_sql = output_sql_path.replace("'", "''")

    summary = con.execute(f"""
        SELECT
            COUNT(*) AS total_rows,

            COUNT(DISTINCT trading_day)
                AS trading_days,

            COUNT(*) FILTER (
                WHERE eligible_for_index_model
            ) AS index_eligible_rows,

            COUNT(*) FILTER (
                WHERE eligible_for_index_model
                  AND label_valid_5m
            ) AS valid_5m_labels,

            COUNT(*) FILTER (
                WHERE eligible_for_index_model
                  AND label_valid_15m
            ) AS valid_15m_labels,

            COUNT(*) FILTER (
                WHERE eligible_for_index_model
                  AND label_valid_30m
            ) AS valid_30m_labels,

            COUNT(*) FILTER (
                WHERE future_return_5m IS NULL
            ) AS missing_5m_labels,

            COUNT(*) FILTER (
                WHERE future_return_15m IS NULL
            ) AS missing_15m_labels,

            COUNT(*) FILTER (
                WHERE future_return_30m IS NULL
            ) AS missing_30m_labels,

            AVG(future_return_5m)
                AS average_future_return_5m,

            STDDEV_SAMP(future_return_5m)
                AS std_future_return_5m,

            AVG(future_return_15m)
                AS average_future_return_15m,

            STDDEV_SAMP(future_return_15m)
                AS std_future_return_15m,

            AVG(future_return_30m)
                AS average_future_return_30m,

            STDDEV_SAMP(future_return_30m)
                AS std_future_return_30m

        FROM read_parquet('{path_for_sql}')
    """).fetchdf()

    summary.insert(0, "index_name", index_name)

    print("\nDATASET SUMMARY")
    print(summary.to_string(index=False))

    # Save summary
    return summary


# ============================================================
# MAIN
# ============================================================

def main():

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    if not DB_PATH.exists():
        raise FileNotFoundError(DB_PATH)

    con = duckdb.connect(
        str(DB_PATH),
        read_only=True,
    )

    try:
        con.execute("SET TimeZone = 'Asia/Calcutta'")
        con.execute(f"SET memory_limit = '{MEMORY_LIMIT}'")
        con.execute(f"SET threads = {THREADS}")

        summaries = []

        for index_name, config in CONFIG.items():

            summary = process_index(
                con,
                index_name,
                config,
            )

            summaries.append(summary)

        combined_summary = pd.concat(
            summaries,
            ignore_index=True,
        )

        summary_path = (
                OUTPUT_DIR / "index_feature_dataset_summary.csv"
        )

        combined_summary.to_csv(
            summary_path,
            index=False,
        )

        print("\n" + "=" * 75)
        print("INDEX FEATURE GENERATION COMPLETED")
        print("=" * 75)
        print("Summary:", summary_path)

    finally:
        con.close()


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print("\nERROR:", exc)
        sys.exit(1)
