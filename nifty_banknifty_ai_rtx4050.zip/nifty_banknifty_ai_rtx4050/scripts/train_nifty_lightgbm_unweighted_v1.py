
from __future__ import annotations

import json
import gc
import sys
import traceback
from pathlib import Path
from datetime import datetime, timezone

import numpy as np
import pandas as pd
import lightgbm as lgb
import pyarrow.parquet as pq

from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    f1_score,
    precision_score,
    recall_score,
    log_loss,
    confusion_matrix,
    classification_report,
    roc_auc_score,
)

# ============================================================
# CONFIGURATION
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parents[1]

INPUT_ROOT = (
        PROJECT_ROOT
        / "data"
        / "processed"
        / "nifty_matched_datasets_v1"
)

MODEL_ROOT = (
        PROJECT_ROOT
        / "models"
        / "nifty_lightgbm_matched_unweighted_v1"
)

REPORT_ROOT = (
        PROJECT_ROOT
        / "reports"
        / "nifty_lightgbm_matched_unweighted_v1"
)

HORIZONS = [5, 15, 30]
DATASETS = ["index_only", "index_plus_options"]

# Preserve the exact feature definitions from the matched v1 experiment.
INDEX_FEATURES = [
    "body_pct",
    "close",
    "close_vs_ema21_pct",
    "close_vs_ema50_pct",
    "close_vs_ema9_pct",
    "high",
    "high_low_range_15m",
    "high_low_range_30m",
    "high_low_range_5m",
    "high_low_range_60m",
    "logret_1m",
    "low",
    "lower_wick_pct",
    "negative_return_count_5m",
    "open",
    "positive_return_count_5m",
    "range_pct",
    "realized_vol_15m",
    "realized_vol_30m",
    "realized_vol_5m",
    "realized_vol_60m",
    "ret_1m",
    "return_15m",
    "return_30m",
    "return_5m",
    "return_60m",
    "rsi_14",
    "upper_wick_pct",
]

OPTIONS_FEATURES = [
    "selected_dte",
    "atm_distance_pct",
    "atm_straddle_premium",
    "atm_ce_log_return_1m",
    "atm_pe_log_return_1m",
    "atm_ce_pe_return_spread_1m",
    "atm_straddle_weighted_log_return_1m",
    "atm_ce_oi_change_1m",
    "atm_pe_oi_change_1m",
    "near_atm_pcr_oi",
    "near_atm_pcr_volume",
    "near_atm_oi_imbalance",
    "near_atm_volume_imbalance",
    "paired_strike_count",
]

FEATURES = {
    "index_only": INDEX_FEATURES,
    "index_plus_options": INDEX_FEATURES + OPTIONS_FEATURES,
}

# Chronological split within the training parquet.
FIT_END_DATE = "2022-12-31"
EARLY_STOP_START_DATE = "2023-01-01"
EARLY_STOP_END_DATE = "2023-12-31"

# The separate validation parquet is the 2024 diagnostic period.
SAVE_PREDICTIONS = True

RANDOM_STATE = 42
N_JOBS = 4

# Same core model settings as the balanced experiment.
LGBM_PARAMS = {
    "objective": "multiclass",
    "num_class": 3,
    "learning_rate": 0.03,
    "num_leaves": 31,
    "max_depth": -1,
    "min_child_samples": 100,
    "subsample": 0.8,
    "subsample_freq": 1,
    "colsample_bytree": 0.8,
    "reg_alpha": 0.1,
    "reg_lambda": 2.0,
    "random_state": RANDOM_STATE,
    "n_jobs": N_JOBS,
    "verbosity": -1,
    "metric": "multi_logloss",
}

MAX_ESTIMATORS = 3000
EARLY_STOPPING_ROUNDS = 100

CLASS_NAMES = ["DOWN", "SIDEWAYS", "UP"]
CLASS_TO_ID = {
    "DOWN": 0,
    "SIDEWAYS": 1,
    "UP": 2,
}

DATE_CANDIDATES = [
    "trading_day",
    "date",
    "trading_date",
]

TARGET_CANDIDATES = [
    "target_class",
    "target_label",
    "target_direction",
    "direction_label",
    "class_label",
    "label",
    "class",
    "direction",
    "target",
    "y",
]

# Numeric label encodings accepted explicitly:
# 0,1,2 -> DOWN,SIDEWAYS,UP
# -1,0,1 -> DOWN,SIDEWAYS,UP
NUMERIC_LABEL_MAPS = [
    {-1: 0, 0: 1, 1: 2},
    {0: 0, 1: 1, 2: 2},
]


# ============================================================
# HELPERS
# ============================================================

def log(message: str) -> None:
    print(
        f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] "
        f"{message}",
        flush=True,
    )


def ensure_directories() -> None:
    MODEL_ROOT.mkdir(parents=True, exist_ok=True)
    REPORT_ROOT.mkdir(parents=True, exist_ok=True)


def detect_column(columns, candidates, column_type):
    column_set = set(columns)

    for candidate in candidates:
        if candidate in column_set:
            return candidate

    raise RuntimeError(
        f"Could not detect {column_type} column.\n"
        f"Candidates checked: {candidates}\n"
        f"Available columns: {list(columns)}"
    )


def encode_target(series: pd.Series) -> pd.Series:
    """
    Convert target labels to:
      DOWN=0, SIDEWAYS=1, UP=2

    Does not infer arbitrary numeric encodings.
    """

    values = series.dropna().unique()

    if len(values) == 0:
        raise RuntimeError("Target column contains no non-null values.")

    # String labels.
    normalized = series.astype("string").str.strip().str.upper()

    string_map = {
        "DOWN": 0,
        "BEARISH": 0,
        "SIDEWAYS": 1,
        "NEUTRAL": 1,
        "FLAT": 1,
        "UP": 2,
        "BULLISH": 2,
    }

    normalized_values = set(normalized.dropna().unique())

    if normalized_values.issubset(set(string_map.keys())):
        encoded = normalized.map(string_map)
        if encoded.isna().any():
            raise RuntimeError("Unexpected nulls after string target encoding.")
        return encoded.astype("int8")

    # Numeric labels.
    numeric = pd.to_numeric(series, errors="coerce")

    if numeric.isna().any():
        raise RuntimeError(
            "Target contains values that are neither recognized "
            "class names nor supported numeric encodings. "
            f"Observed values: {list(values[:20])}"
        )

    numeric_values = set(numeric.astype(int).unique())

    for mapping in NUMERIC_LABEL_MAPS:
        if numeric_values.issubset(set(mapping.keys())):
            encoded = numeric.astype(int).map(mapping)
            if encoded.isna().any():
                continue
            return encoded.astype("int8")

    raise RuntimeError(
        "Unsupported numeric target encoding. "
        f"Observed numeric values: {sorted(numeric_values)}. "
        "Expected either {-1,0,1} or {0,1,2}. "
        "Review the target encoding before training."
    )


def load_dataset(dataset_name: str, horizon: int):
    train_path = (
            INPUT_ROOT
            / dataset_name
            / f"train_{horizon}m.parquet"
    )

    validation_path = (
            INPUT_ROOT
            / dataset_name
            / f"validation_{horizon}m.parquet"
    )

    if not train_path.exists():
        raise FileNotFoundError(train_path)

    if not validation_path.exists():
        raise FileNotFoundError(validation_path)

    # Read schema first so that we only load the columns required.
    train_schema = pq.read_schema(train_path).names

    target_col = detect_column(
        train_schema,
        TARGET_CANDIDATES,
        "target",
    )

    date_col = detect_column(
        train_schema,
        DATE_CANDIDATES,
        "date",
    )

    feature_cols = FEATURES[dataset_name]

    missing_features = [
        col for col in feature_cols if col not in train_schema
    ]

    if missing_features:
        raise RuntimeError(
            f"{dataset_name} {horizon}m is missing features: "
            f"{missing_features}"
        )

    required_columns = list(
        dict.fromkeys(feature_cols + [target_col, date_col])
    )

    # Read only the needed columns.
    train_df = pd.read_parquet(
        train_path,
        columns=required_columns,
    )

    validation_schema = pq.read_schema(validation_path).names

    missing_validation_columns = [
        col for col in required_columns
        if col not in validation_schema
    ]

    if missing_validation_columns:
        raise RuntimeError(
            f"Validation parquet missing columns: "
            f"{missing_validation_columns}"
        )

    validation_df = pd.read_parquet(
        validation_path,
        columns=required_columns,
    )

    train_df[date_col] = pd.to_datetime(
        train_df[date_col],
        errors="coerce",
    )

    validation_df[date_col] = pd.to_datetime(
        validation_df[date_col],
        errors="coerce",
    )

    if train_df[date_col].isna().any():
        raise RuntimeError("Training data contains invalid trading dates.")

    if validation_df[date_col].isna().any():
        raise RuntimeError("Validation data contains invalid trading dates.")

    train_df[target_col] = encode_target(train_df[target_col])
    validation_df[target_col] = encode_target(validation_df[target_col])

    return (
        train_df,
        validation_df,
        feature_cols,
        target_col,
        date_col,
    )


def prepare_matrix(
        df: pd.DataFrame,
        feature_cols: list[str],
        dataset_name: str,
        split_name: str,
):
    """
    Convert predictors to numeric and replace +/- infinity with NaN.
    LightGBM supports NaN natively.
    No target or sample weighting is applied here.
    """

    X = df[feature_cols].copy()

    for col in feature_cols:
        if not pd.api.types.is_numeric_dtype(X[col]):
            X[col] = pd.to_numeric(X[col], errors="coerce")

    infinity_count = int(
        np.isinf(X.to_numpy(dtype=np.float64)).sum()
    )

    if infinity_count:
        log(
            f"{dataset_name} {split_name}: replacing "
            f"{infinity_count} infinite feature values with NaN"
        )
        X = X.replace([np.inf, -np.inf], np.nan)

    # All-NaN columns cannot provide a usable predictor.
    all_null = X.columns[X.isna().all()].tolist()

    if all_null:
        raise RuntimeError(
            f"{dataset_name} {split_name}: all-null feature columns: "
            f"{all_null}"
        )

    return X, infinity_count


def calculate_metrics(
        y_true: np.ndarray,
        probabilities: np.ndarray,
):
    predictions = np.argmax(probabilities, axis=1)

    metrics = {
        "accuracy": float(accuracy_score(y_true, predictions)),
        "balanced_accuracy": float(
            balanced_accuracy_score(y_true, predictions)
        ),
        "macro_f1": float(
            f1_score(
                y_true,
                predictions,
                labels=[0, 1, 2],
                average="macro",
                zero_division=0,
            )
        ),
        "weighted_f1": float(
            f1_score(
                y_true,
                predictions,
                labels=[0, 1, 2],
                average="weighted",
                zero_division=0,
            )
        ),
        "macro_precision": float(
            precision_score(
                y_true,
                predictions,
                labels=[0, 1, 2],
                average="macro",
                zero_division=0,
            )
        ),
        "macro_recall": float(
            recall_score(
                y_true,
                predictions,
                labels=[0, 1, 2],
                average="macro",
                zero_division=0,
            )
        ),
        "log_loss": float(
            log_loss(
                y_true,
                probabilities,
                labels=[0, 1, 2],
            )
        ),
    }

    try:
        metrics["macro_roc_auc_ovr"] = float(
            roc_auc_score(
                y_true,
                probabilities,
                labels=[0, 1, 2],
                multi_class="ovr",
                average="macro",
            )
        )
    except ValueError:
        metrics["macro_roc_auc_ovr"] = None

    matrix = confusion_matrix(
        y_true,
        predictions,
        labels=[0, 1, 2],
    )

    report = classification_report(
        y_true,
        predictions,
        labels=[0, 1, 2],
        target_names=CLASS_NAMES,
        output_dict=True,
        zero_division=0,
    )

    actual_counts = np.bincount(y_true, minlength=3)
    predicted_counts = np.bincount(predictions, minlength=3)

    distribution = {
        "actual": {
            CLASS_NAMES[i]: float(
                actual_counts[i] / len(y_true) * 100
            )
            for i in range(3)
        },
        "predicted": {
            CLASS_NAMES[i]: float(
                predicted_counts[i] / len(predictions) * 100
            )
            for i in range(3)
        },
    }

    return metrics, matrix, report, distribution, predictions


def save_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)

    with path.open("w", encoding="utf-8") as file:
        json.dump(
            payload,
            file,
            indent=2,
            default=str,
        )


# ============================================================
# TRAIN ONE MODEL
# ============================================================

def train_one(dataset_name: str, horizon: int) -> dict:
    log("=" * 80)
    log(f"START: {dataset_name} | {horizon}m | UNWEIGHTED")
    log("=" * 80)

    (
        train_df,
        validation_df,
        feature_cols,
        target_col,
        date_col,
    ) = load_dataset(dataset_name, horizon)

    log(f"Target column: {target_col}")
    log(f"Date column: {date_col}")
    log(f"Feature count: {len(feature_cols)}")
    log(f"Training parquet rows: {len(train_df):,}")
    log(f"Validation parquet rows: {len(validation_df):,}")

    fit_start = pd.Timestamp("2021-01-01")
    fit_end = pd.Timestamp(FIT_END_DATE)
    early_start = pd.Timestamp(EARLY_STOP_START_DATE)
    early_end = pd.Timestamp(EARLY_STOP_END_DATE)

    fit_df = train_df[
        (train_df[date_col] >= fit_start)
        & (train_df[date_col] <= fit_end)
        ].copy()

    early_df = train_df[
        (train_df[date_col] >= early_start)
        & (train_df[date_col] <= early_end)
        ].copy()

    if fit_df.empty:
        raise RuntimeError("2021-2022 fit dataset is empty.")

    if early_df.empty:
        raise RuntimeError("2023 early-stopping dataset is empty.")

    if validation_df.empty:
        raise RuntimeError("2024 validation dataset is empty.")

    # Check chronological boundaries.
    if fit_df[date_col].max() >= early_df[date_col].min():
        raise RuntimeError("Fit and early-stopping periods overlap.")

    if early_df[date_col].max() >= validation_df[date_col].min():
        raise RuntimeError("Early-stopping and validation periods overlap.")

    y_fit = fit_df[target_col].to_numpy(dtype=np.int8)
    y_early = early_df[target_col].to_numpy(dtype=np.int8)
    y_train_full = train_df[target_col].to_numpy(dtype=np.int8)
    y_validation = validation_df[target_col].to_numpy(dtype=np.int8)

    for name, y in [
        ("fit", y_fit),
        ("early_stop", y_early),
        ("train_full", y_train_full),
        ("validation", y_validation),
    ]:
        if set(np.unique(y)) != {0, 1, 2}:
            raise RuntimeError(
                f"{name} does not contain all three classes. "
                f"Observed: {np.unique(y).tolist()}"
            )

    log(
        f"Fit rows (2021-2022): {len(fit_df):,}; "
        f"early-stop rows (2023): {len(early_df):,}; "
        f"full train rows (2021-2023): {len(train_df):,}; "
        f"validation rows (2024): {len(validation_df):,}"
    )

    # Class distributions are recorded, but NOT used as weights.
    class_distribution = {}

    for name, y in [
        ("fit_2021_2022", y_fit),
        ("early_stop_2023", y_early),
        ("train_2021_2023", y_train_full),
        ("validation_2024", y_validation),
    ]:
        counts = np.bincount(y, minlength=3)
        class_distribution[name] = {
            CLASS_NAMES[i]: {
                "count": int(counts[i]),
                "percentage": float(counts[i] / len(y) * 100),
            }
            for i in range(3)
        }

    # Build matrices.
    X_fit, inf_fit = prepare_matrix(
        fit_df, feature_cols, dataset_name, "fit"
    )

    X_early, inf_early = prepare_matrix(
        early_df, feature_cols, dataset_name, "early_stop"
    )

    # --------------------------------------------------------
    # Stage 1: early stopping on 2023
    # --------------------------------------------------------

    log("Stage 1: fitting model on 2021-2022; early stopping on 2023.")

    early_model = lgb.LGBMClassifier(
        n_estimators=MAX_ESTIMATORS,
        **LGBM_PARAMS,
    )

    # IMPORTANT:
    # No sample_weight.
    # No class_weight.
    # No eval_sample_weight.
    early_model.fit(
        X_fit,
        y_fit,
        eval_set=[(X_early, y_early)],
        eval_names=["early_stop_2023"],
        eval_metric="multi_logloss",
        callbacks=[
            lgb.early_stopping(
                stopping_rounds=EARLY_STOPPING_ROUNDS,
                first_metric_only=True,
                verbose=True,
            ),
            lgb.log_evaluation(period=100),
        ],
    )

    best_iteration = int(
        early_model.best_iteration_
        if early_model.best_iteration_
        else MAX_ESTIMATORS
    )

    log(f"Selected best iteration: {best_iteration}")

    del early_model
    del X_fit, X_early
    gc.collect()

    # --------------------------------------------------------
    # Stage 2: refit on all 2021-2023 data
    # --------------------------------------------------------

    log(
        "Stage 2: refitting from scratch on all 2021-2023 "
        f"rows using {best_iteration} estimators."
    )

    X_train_full, inf_train_full = prepare_matrix(
        train_df,
        feature_cols,
        dataset_name,
        "train_full",
    )

    X_validation, inf_validation = prepare_matrix(
        validation_df,
        feature_cols,
        dataset_name,
        "validation",
    )

    final_model = lgb.LGBMClassifier(
        n_estimators=best_iteration,
        **LGBM_PARAMS,
    )

    # IMPORTANT: intentionally no sample_weight.
    final_model.fit(
        X_train_full,
        y_train_full,
    )

    log("Final model fit completed.")

    # --------------------------------------------------------
    # Stage 3: evaluate on 2024 diagnostic validation
    # --------------------------------------------------------

    log("Evaluating on 2024 validation data.")

    probabilities = final_model.predict_proba(X_validation)

    (
        metrics,
        matrix,
        class_report,
        distribution,
        predictions,
    ) = calculate_metrics(
        y_validation,
        probabilities,
    )

    model_dir = MODEL_ROOT / dataset_name
    report_dir = REPORT_ROOT / dataset_name

    model_dir.mkdir(parents=True, exist_ok=True)
    report_dir.mkdir(parents=True, exist_ok=True)

    model_path = model_dir / f"lightgbm_{horizon}m.txt"

    final_model.booster_.save_model(str(model_path))

    # Feature importance.
    importance_df = pd.DataFrame({
        "feature": feature_cols,
        "importance_gain": final_model.booster_.feature_importance(
            importance_type="gain"
        ),
        "importance_split": final_model.booster_.feature_importance(
            importance_type="split"
        ),
    }).sort_values(
        "importance_gain",
        ascending=False,
    )

    importance_path = (
            report_dir / f"feature_importance_{horizon}m.csv"
    )
    importance_df.to_csv(importance_path, index=False)

    # Predictions.
    if SAVE_PREDICTIONS:
        prediction_df = pd.DataFrame({
            "actual_class": [
                CLASS_NAMES[int(value)] for value in y_validation
            ],
            "predicted_class": [
                CLASS_NAMES[int(value)] for value in predictions
            ],
            "prob_down": probabilities[:, 0],
            "prob_sideways": probabilities[:, 1],
            "prob_up": probabilities[:, 2],
        })

        prediction_df.to_csv(
            report_dir / f"validation_predictions_{horizon}m.csv",
            index=False,
            )

        del prediction_df

    result = {
        "experiment": "nifty_lightgbm_matched_unweighted_v1",
        "dataset": dataset_name,
        "horizon_minutes": horizon,
        "target_column": target_col,
        "date_column": date_col,
        "feature_count": len(feature_cols),
        "features": feature_cols,
        "train_rows": int(len(train_df)),
        "fit_rows_2021_2022": int(len(fit_df)),
        "early_stop_rows_2023": int(len(early_df)),
        "validation_rows_2024": int(len(validation_df)),
        "fit_date_min": str(fit_df[date_col].min().date()),
        "fit_date_max": str(fit_df[date_col].max().date()),
        "early_stop_date_min": str(early_df[date_col].min().date()),
        "early_stop_date_max": str(early_df[date_col].max().date()),
        "validation_date_min": str(validation_df[date_col].min().date()),
        "validation_date_max": str(validation_df[date_col].max().date()),
        "best_iteration": best_iteration,
        "class_distribution": class_distribution,
        "metrics_2024": metrics,
        "confusion_matrix": {
            "labels": CLASS_NAMES,
            "matrix": matrix.tolist(),
        },
        "classification_report": class_report,
        "class_distribution_2024": distribution,
        "infinity_values_replaced": {
            "fit_2021_2022": int(inf_fit),
            "early_stop_2023": int(inf_early),
            "train_2021_2023": int(inf_train_full),
            "validation_2024": int(inf_validation),
        },
        "sample_weighting": False,
        "class_weighting": False,
        "early_stopping_metric": "multi_logloss",
        "model_parameters": {
            **LGBM_PARAMS,
            "n_estimators": best_iteration,
        },
        "model_path": str(model_path),
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
    }

    metrics_path = report_dir / f"metrics_{horizon}m.json"
    save_json(metrics_path, result)

    log(
        f"RESULT {dataset_name} {horizon}m | "
        f"Accuracy={metrics['accuracy']:.5f} | "
        f"BalancedAcc={metrics['balanced_accuracy']:.5f} | "
        f"MacroF1={metrics['macro_f1']:.5f} | "
        f"LogLoss={metrics['log_loss']:.5f} | "
        f"AUC={metrics['macro_roc_auc_ovr']}"
    )

    log(f"Model saved: {model_path}")
    log(f"Metrics saved: {metrics_path}")

    comparison_row = {
        "dataset": dataset_name,
        "horizon_minutes": horizon,
        "train_rows": len(train_df),
        "fit_rows": len(fit_df),
        "early_stop_rows": len(early_df),
        "validation_rows": len(validation_df),
        "feature_count": len(feature_cols),
        "best_iteration": best_iteration,
        **metrics,
        "predicted_down_pct": distribution["predicted"]["DOWN"],
        "predicted_sideways_pct": distribution["predicted"]["SIDEWAYS"],
        "predicted_up_pct": distribution["predicted"]["UP"],
        "total_infinity_values_replaced": (
                inf_fit + inf_early + inf_train_full + inf_validation
        ),
        "sample_weighting": False,
    }

    # Release memory before the next model.
    del final_model
    del X_train_full, X_validation
    del train_df, validation_df
    del fit_df, early_df
    del probabilities, predictions
    gc.collect()

    return comparison_row


# ============================================================
# MAIN
# ============================================================

def main():
    ensure_directories()

    log("NIFTY MATCHED UNWEIGHTED LIGHTGBM EXPERIMENT")
    log(f"Project root: {PROJECT_ROOT}")
    log(f"Input root: {INPUT_ROOT}")
    log(f"Model output: {MODEL_ROOT}")
    log(f"Report output: {REPORT_ROOT}")
    log("Class weighting: DISABLED")
    log("Sample weighting: DISABLED")

    results = []
    failures = []

    for dataset_name in DATASETS:
        for horizon in HORIZONS:
            try:
                result = train_one(dataset_name, horizon)
                results.append(result)

            except Exception as exc:
                error_text = traceback.format_exc()

                log(
                    f"FAILED: {dataset_name} {horizon}m: "
                    f"{type(exc).__name__}: {exc}"
                )

                failures.append({
                    "dataset": dataset_name,
                    "horizon_minutes": horizon,
                    "error": str(exc),
                    "traceback": error_text,
                })

                save_json(
                    REPORT_ROOT
                    / f"failure_{dataset_name}_{horizon}m.json",
                    failures[-1],
                    )

                # Continue with the remaining independent models.
                gc.collect()

    if results:
        comparison_df = pd.DataFrame(results)

        comparison_path = (
                REPORT_ROOT / "unweighted_model_comparison.csv"
        )
        comparison_df.to_csv(comparison_path, index=False)

        # Optional side-by-side comparison against the balanced run.
        balanced_path = (
                PROJECT_ROOT
                / "reports"
                / "nifty_lightgbm_matched_v1"
                / "model_comparison.csv"
        )

        if balanced_path.exists():
            balanced_df = pd.read_csv(balanced_path)

            merged = comparison_df.merge(
                balanced_df,
                on=["dataset", "horizon_minutes"],
                how="left",
                suffixes=("_unweighted", "_balanced"),
            )

            for metric in [
                "accuracy",
                "balanced_accuracy",
                "macro_f1",
                "weighted_f1",
                "macro_precision",
                "macro_recall",
                "log_loss",
                "macro_roc_auc_ovr",
            ]:
                unweighted_col = f"{metric}_unweighted"
                balanced_col = f"{metric}_balanced"

                if (
                        unweighted_col in merged.columns
                        and balanced_col in merged.columns
                ):
                    merged[f"{metric}_unweighted_minus_balanced"] = (
                            merged[unweighted_col] - merged[balanced_col]
                    )

            merged.to_csv(
                REPORT_ROOT / "balanced_vs_unweighted_comparison.csv",
                index=False,
                )

            log(
                "Balanced vs unweighted comparison saved: "
                f"{REPORT_ROOT / 'balanced_vs_unweighted_comparison.csv'}"
            )
        else:
            log(
                "Balanced comparison file not found at expected path. "
                "Unweighted results were still saved."
            )

        log(f"Comparison saved: {comparison_path}")

    summary = {
        "experiment": "nifty_lightgbm_matched_unweighted_v1",
        "successful_models": len(results),
        "failed_models": len(failures),
        "results": results,
        "failures": failures,
        "sample_weighting": False,
        "class_weighting": False,
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
    }

    save_json(
        REPORT_ROOT / "experiment_summary.json",
        summary,
        )

    log("=" * 80)
    log(
        f"EXPERIMENT FINISHED | "
        f"Success: {len(results)} | Failed: {len(failures)}"
    )
    log(f"Summary: {REPORT_ROOT / 'experiment_summary.json'}")
    log("=" * 80)

    if failures:
        sys.exit(1)


if __name__ == "__main__":
    main()
