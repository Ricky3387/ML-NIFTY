
#!/usr/bin/env python3
"""
Build NIFTY experimental feature set v1.

Save:
  scripts/build_nifty_features_experimental_v1.py

Run from project root:
  python scripts/build_nifty_features_experimental_v1.py

Inputs:
  data/processed/nifty_index_cleaned/nifty_index_cleaned_final.parquet
  data/processed/nifty_features_v1/nifty_features_labels_long.parquet

Output:
  data/processed/nifty_features_experimental_v1/
"""

from pathlib import Path
import json
import time
import logging

import numpy as np
import pandas as pd


START = time.time()


def rolling_efficiency(close, window):
    """Net movement divided by total absolute price movement."""
    net = (close - close.shift(window)).abs()
    path = close.diff().abs().rolling(
        window, min_periods=window
    ).sum()

    return net / path.replace(0, np.nan)


def build_features(bars):

    bars = bars.sort_values(
        ["trading_day", "timestamp_ist"]
    ).copy()

    grouped = bars.groupby("trading_day", sort=False)

    close = bars["close"].astype("float64")
    high = bars["high"].astype("float64")
    low = bars["low"].astype("float64")
    open_ = bars["open"].astype("float64")

    # --------------------------------------------------
    # TRUE RANGE AND ATR
    # --------------------------------------------------

    prev_close = grouped["close"].shift(1).astype("float64")

    tr = pd.concat([
        high - low,
        (high - prev_close).abs(),
        (low - prev_close).abs()
    ], axis=1).max(axis=1)

    bars["exp_atr14"] = tr.groupby(
        bars["trading_day"], sort=False
    ).transform(
        lambda s: s.rolling(14, min_periods=14).mean()
    )

    atr = bars["exp_atr14"].replace(0, np.nan)

    # --------------------------------------------------
    # 1. TREND FEATURES
    # --------------------------------------------------

    for span, lag in ((9, 5), (21, 10), (50, 10)):

        ema = close.groupby(
            bars["trading_day"], sort=False
        ).transform(
            lambda s: s.ewm(
                span=span,
                adjust=False,
                min_periods=span
            ).mean()
        )

        ema_lag = ema.groupby(
            bars["trading_day"], sort=False
        ).shift(lag)

        bars[f"exp_ema{span}_slope_atr"] = (
                                                   ema - ema_lag
                                           ) / atr

    ema9 = close.groupby(
        bars["trading_day"], sort=False
    ).transform(
        lambda s: s.ewm(
            span=9, adjust=False, min_periods=9
        ).mean()
    )

    ema21 = close.groupby(
        bars["trading_day"], sort=False
    ).transform(
        lambda s: s.ewm(
            span=21, adjust=False, min_periods=21
        ).mean()
    )

    ema50 = close.groupby(
        bars["trading_day"], sort=False
    ).transform(
        lambda s: s.ewm(
            span=50, adjust=False, min_periods=50
        ).mean()
    )

    bars["exp_ema9_21_spread_atr"] = (
                                             ema9 - ema21
                                     ) / atr

    bars["exp_ema21_50_spread_atr"] = (
                                              ema21 - ema50
                                      ) / atr

    bars["exp_trend_alignment"] = (
            (ema9 > ema21).astype("int8")
            + (ema21 > ema50).astype("int8")
            - (ema9 < ema21).astype("int8")
            - (ema21 < ema50).astype("int8")
    ).astype("float32")

    # --------------------------------------------------
    # 2. VOLATILITY FEATURES
    # --------------------------------------------------

    logret = np.log(close / prev_close)

    logret = logret.replace(
        [np.inf, -np.inf], np.nan
    )

    for window in (5, 15, 30, 60):

        rv = logret.groupby(
            bars["trading_day"], sort=False
        ).transform(
            lambda s: s.rolling(
                window, min_periods=window
            ).std()
        )

        bars[f"exp_realized_vol_{window}m"] = rv

    bars["exp_vol_ratio_5m_60m"] = (
            bars["exp_realized_vol_5m"]
            / bars["exp_realized_vol_60m"].replace(0, np.nan)
    )

    bars["exp_vol_ratio_15m_60m"] = (
            bars["exp_realized_vol_15m"]
            / bars["exp_realized_vol_60m"].replace(0, np.nan)
    )

    # --------------------------------------------------
    # 3. RANGE EXPANSION FEATURES
    # --------------------------------------------------

    for window in (5, 15, 30):

        rolling_high = high.groupby(
            bars["trading_day"], sort=False
        ).transform(
            lambda s: s.rolling(
                window, min_periods=window
            ).max()
        )

        rolling_low = low.groupby(
            bars["trading_day"], sort=False
        ).transform(
            lambda s: s.rolling(
                window, min_periods=window
            ).min()
        )

        bars[f"exp_range_{window}m_atr"] = (
                                                   rolling_high - rolling_low
                                           ) / atr

    # --------------------------------------------------
    # 4. CLOSE LOCATION FEATURES
    # --------------------------------------------------

    for window in (20, 60):

        rolling_high = high.groupby(
            bars["trading_day"], sort=False
        ).transform(
            lambda s: s.rolling(
                window, min_periods=window
            ).max()
        )

        rolling_low = low.groupby(
            bars["trading_day"], sort=False
        ).transform(
            lambda s: s.rolling(
                window, min_periods=window
            ).min()
        )

        denominator = (
                rolling_high - rolling_low
        ).replace(0, np.nan)

        bars[f"exp_close_location_{window}m"] = (
                                                        close - rolling_low
                                                ) / denominator

    # --------------------------------------------------
    # 5. MARKET EFFICIENCY FEATURES
    # --------------------------------------------------

    for window in (10, 20):

        bars[f"exp_efficiency_ratio_{window}m"] = (
            close.groupby(
                bars["trading_day"], sort=False
            ).transform(
                lambda s: rolling_efficiency(s, window)
            )
        )

    # --------------------------------------------------
    # 6. CANDLE PRESSURE FEATURES
    # --------------------------------------------------

    bar_range = (high - low).replace(0, np.nan)

    bars["exp_close_location_in_bar"] = (
            (close - low) / bar_range
    ).clip(0, 1)

    bars["exp_body_to_range"] = (
            (close - open_).abs() / bar_range
    ).clip(0, 1)

    return bars


def main():

    # --------------------------------------------------
    # PROJECT PATHS
    # --------------------------------------------------

    script_dir = Path(__file__).resolve().parent

    root = (
        script_dir.parent
        if script_dir.name.lower() == "scripts"
        else script_dir
    )

    clean_path = (
            root
            / "data/processed/nifty_index_cleaned/"
              "nifty_index_cleaned_final.parquet"
    )

    base_path = (
            root
            / "data/processed/nifty_features_v1/"
              "nifty_features_labels_long.parquet"
    )

    out_dir = (
            root
            / "data/processed/nifty_features_experimental_v1"
    )

    out_dir.mkdir(parents=True, exist_ok=True)

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(message)s"
    )

    log = logging.getLogger(
        "nifty_experimental_features_v1"
    )

    for path in (clean_path, base_path):

        if not path.exists():
            raise FileNotFoundError(
                f"Required input missing: {path}"
            )

    # --------------------------------------------------
    # LOAD CLEANED BARS
    # --------------------------------------------------

    log.info("Loading cleaned bars")

    bars = pd.read_parquet(clean_path)

    required_bars = {
        "timestamp_ist",
        "trading_day",
        "open",
        "high",
        "low",
        "close",
        "is_synthetic"
    }

    missing = required_bars - set(bars.columns)

    if missing:
        raise RuntimeError(
            f"Cleaned bars missing columns: {sorted(missing)}"
        )

    bars["timestamp_ist"] = pd.to_datetime(
        bars["timestamp_ist"]
    )

    bars["trading_day"] = pd.to_datetime(
        bars["trading_day"]
    ).dt.strftime("%Y-%m-%d")

    bars = bars.sort_values(
        ["trading_day", "timestamp_ist"]
    ).reset_index(drop=True)

    # --------------------------------------------------
    # BUILD EXPERIMENTAL FEATURES
    # --------------------------------------------------

    log.info("Calculating experimental causal features")

    enriched = build_features(bars)

    new_features = [
        c for c in enriched.columns
        if c.startswith("exp_")
    ]

    if not new_features:
        raise RuntimeError(
            "No experimental features were generated."
        )

    # --------------------------------------------------
    # LOAD BASELINE FEATURES
    # --------------------------------------------------

    log.info("Loading baseline feature/label rows")

    base = pd.read_parquet(base_path)

    base["timestamp_ist"] = pd.to_datetime(
        base["timestamp_ist"]
    )

    base["trading_day"] = pd.to_datetime(
        base["trading_day"]
    ).dt.strftime("%Y-%m-%d")

    keys = ["trading_day", "timestamp_ist"]

    if enriched.duplicated(keys).any():
        raise RuntimeError(
            "Duplicate timestamp/day keys in cleaned bars."
        )

    if base.duplicated(
            keys + ["horizon_minutes"]
    ).any():
        raise RuntimeError(
            "Duplicate timestamp/day/horizon keys "
            "in baseline features."
        )

    # --------------------------------------------------
    # MERGE EXPERIMENTAL FEATURES
    # --------------------------------------------------

    feature_table = enriched[
        keys + new_features
        ].copy()

    result = base.merge(
        feature_table,
        on=keys,
        how="left",
        validate="many_to_one"
    )

    # --------------------------------------------------
    # VALIDATE SYNTHETIC BAR ELIGIBILITY
    # --------------------------------------------------

    # IMPORTANT:
    # Use a distinct column name to avoid collisions
    # if baseline data already contains is_synthetic.

    synthetic_lookup = enriched[
        keys + ["is_synthetic"]
        ].rename(
        columns={
            "is_synthetic": "__source_bar_is_synthetic"
        }
    )

    result = result.merge(
        synthetic_lookup,
        on=keys,
        how="left",
        validate="many_to_one"
    )

    if result["__source_bar_is_synthetic"].isna().any():
        raise RuntimeError(
            "Some baseline timestamps did not match cleaned bars."
        )

    bad_eligible = (
            result["sample_eligible"].astype(bool)
            & result["__source_bar_is_synthetic"].astype(bool)
    )

    if bad_eligible.any():
        raise RuntimeError(
            f"Found {int(bad_eligible.sum())} "
            "eligible samples on synthetic bars."
        )

    result = result.drop(
        columns=["__source_bar_is_synthetic"]
    )

    # --------------------------------------------------
    # WRITE PARQUET
    # --------------------------------------------------

    output_path = (
            out_dir
            / "nifty_features_labels_experimental_v1.parquet"
    )

    log.info("Writing %s", output_path)

    result.to_parquet(
        output_path,
        index=False,
        compression="zstd"
    )

    # --------------------------------------------------
    # FEATURE MANIFEST
    # --------------------------------------------------

    manifest = []

    for col in new_features:

        s = pd.to_numeric(
            result[col],
            errors="coerce"
        )

        eligible_mask = (
            result["sample_eligible"].astype(bool)
        )

        eligible_values = s[eligible_mask]

        manifest.append({
            "feature": col,

            "description": (
                col.replace("exp_", "").replace("_", " ")
            ),

            "eligible_non_null": int(
                eligible_values.notna().sum()
            ),

            "eligible_missing_pct": float(
                eligible_values.isna().mean() * 100
            ),

            "unique_values": int(
                eligible_values.nunique(dropna=True)
            ),

            "min": (
                float(s.min())
                if s.notna().any() else None
            ),

            "p01": (
                float(s.quantile(.01))
                if s.notna().any() else None
            ),

            "median": (
                float(s.median())
                if s.notna().any() else None
            ),

            "p99": (
                float(s.quantile(.99))
                if s.notna().any() else None
            ),

            "max": (
                float(s.max())
                if s.notna().any() else None
            )
        })

    pd.DataFrame(manifest).to_csv(
        out_dir / "experimental_feature_manifest.csv",
        index=False
    )

    # --------------------------------------------------
    # SUMMARY
    # --------------------------------------------------

    eligible_mask = (
        result["sample_eligible"].astype(bool)
    )

    summary = {

        "status": "EXPERIMENTAL_FEATURE_SET_V1_BUILT",

        "baseline_rows": int(len(base)),

        "output_rows": int(len(result)),

        "baseline_eligible_rows": int(
            eligible_mask.sum()
        ),

        "new_feature_count": int(
            len(new_features)
        ),

        "new_features": new_features,

        "eligible_rows_with_all_new_features": int(
            result.loc[
                eligible_mask, new_features
            ].notna().all(axis=1).sum()
        ),

        "eligible_rows_with_any_new_feature_missing": int(
            result.loc[
                eligible_mask, new_features
            ].isna().any(axis=1).sum()
        ),

        "sample_eligible_changed": False,

        "labels_changed": False,

        "inputs_modified": False,

        "prediction_timing": (
            "Features use the current completed bar "
            "and prior bars only."
        ),

        "caveats": [
            "Experimental features are appended to "
            "the existing baseline rows.",

            "Warm-up nulls are retained and do not "
            "change sample_eligible.",

            "No future bars are used in feature calculations.",

            "All rolling calculations reset at each trading_day.",

            "Synthetic source bars remain ineligible under "
            "the existing guard.",

            "No feature selection or model training is performed."
        ],

        "output_file": str(output_path),

        "elapsed_seconds": round(
            time.time() - START, 2
        )
    }

    summary_path = (
            out_dir / "experimental_feature_summary.json"
    )

    summary_path.write_text(
        json.dumps(summary, indent=2),
        encoding="utf-8"
    )

    print(json.dumps(summary, indent=2))

    print(f"OUTPUT: {out_dir}")


if __name__ == "__main__":
    main()
