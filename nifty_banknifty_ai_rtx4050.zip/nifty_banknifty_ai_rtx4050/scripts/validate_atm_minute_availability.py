
from pathlib import Path
import duckdb
import time

ROOT = Path(__file__).resolve().parents[1]
DB_PATH = ROOT / "data" / "database" / "nifty_options.duckdb"
REPORT_DIR = ROOT / "data" / "reports"
TEMP_DIR = ROOT / "data" / "duckdb_temp"

REPORT_DIR.mkdir(parents=True, exist_ok=True)
TEMP_DIR.mkdir(parents=True, exist_ok=True)

CONFIG = {
    "NIFTY": {
        "options": "nifty_options",
        "index": "nifty_index",
    },
    "BANKNIFTY": {
        "options": "banknifty_options",
        "index": "banknifty_index",
    },
}

BANDS = (0.5, 1.0, 2.0)
MAX_DTE = 14


def export_query(con, query, filename):
    path = (REPORT_DIR / filename).as_posix().replace("'", "''")
    con.execute(
        f"COPY ({query}) TO '{path}' (HEADER, DELIMITER ',')"
    )
    print("Generated:", filename)


def validate_index(con, name, options_view, index_view):
    started = time.time()
    prefix = name.lower()

    print("\n" + "=" * 90)
    print(f"{name}: MINUTE-LEVEL ATM AVAILABILITY")
    print("=" * 90)

    # --------------------------------------------------------
    # 1. Nearest expiry actually observed in the option dataset
    # --------------------------------------------------------

    print("Finding nearest observed expiry...")

    con.execute(f"""
        CREATE OR REPLACE TEMP TABLE {prefix}_minute_nearest_expiry AS
        SELECT
            CAST(trading_day AS DATE) AS trading_day,
            MIN(CAST(expiry AS DATE)) AS nearest_expiry
        FROM {options_view}
        WHERE expiry IS NOT NULL
          AND CAST(expiry AS DATE) >= CAST(trading_day AS DATE)
        GROUP BY CAST(trading_day AS DATE)
    """)

    con.execute(f"""
        CREATE OR REPLACE TEMP TABLE {prefix}_minute_expiry_days AS
        SELECT
            trading_day,
            nearest_expiry,
            DATE_DIFF(
                'day',
                trading_day,
                nearest_expiry
            ) AS days_to_expiry,

            CASE
                WHEN DATE_DIFF('day', trading_day, nearest_expiry)
                     BETWEEN 0 AND 7
                    THEN '0-7'
                WHEN DATE_DIFF('day', trading_day, nearest_expiry)
                     BETWEEN 8 AND 14
                    THEN '8-14'
                ELSE 'ABOVE_14'
            END AS dte_bucket

        FROM {prefix}_minute_nearest_expiry
    """)

    # --------------------------------------------------------
    # 2. Actual index-minute denominator
    #
    # Keep the actual observed index timestamps. This naturally
    # includes shortened/special sessions represented in data.
    # --------------------------------------------------------

    print("Building index-minute denominator...")

    con.execute(f"""
        CREATE OR REPLACE TEMP TABLE {prefix}_minute_index AS

        SELECT
            CAST(trading_day AS DATE) AS trading_day,
            timestamp AS ts,
            close AS spot_close

        FROM {index_view}

        WHERE close > 0
    """)

    con.execute(f"""
        CREATE OR REPLACE TEMP TABLE {prefix}_minute_day_denominator AS

        SELECT
            i.trading_day,
            e.nearest_expiry,
            e.days_to_expiry,
            e.dte_bucket,

            COUNT(DISTINCT i.ts) AS total_index_minutes,

            MIN(STRFTIME(i.ts, '%H:%M:%S'))
                AS first_index_time,

            MAX(STRFTIME(i.ts, '%H:%M:%S'))
                AS last_index_time

        FROM {prefix}_minute_index i

        INNER JOIN {prefix}_minute_expiry_days e
            ON i.trading_day = e.trading_day

        WHERE e.days_to_expiry BETWEEN 0 AND {MAX_DTE}

        GROUP BY
            i.trading_day,
            e.nearest_expiry,
            e.days_to_expiry,
            e.dte_bucket
    """)

    # --------------------------------------------------------
    # 3. Match options to exact index timestamps and nearest
    # expiry. Find same-strike CE/PE pairs at each timestamp.
    # --------------------------------------------------------

    print("Matching exact-timestamp option pairs...")

    con.execute(f"""
        CREATE OR REPLACE TEMP TABLE {prefix}_minute_option_pairs AS

        WITH matched AS (
            SELECT
                CAST(o.trading_day AS DATE) AS trading_day,
                CAST(o.expiry AS DATE) AS expiry,
                o.strike,
                o.timestamp AS ts,
                i.spot_close,

                ABS(o.strike - i.spot_close) * 100.0
                    / NULLIF(i.spot_close, 0) AS distance_pct,

                MAX(
                    CASE WHEN UPPER(o.option_type) = 'CE'
                         THEN 1 ELSE 0 END
                ) AS has_ce,

                MAX(
                    CASE WHEN UPPER(o.option_type) = 'PE'
                         THEN 1 ELSE 0 END
                ) AS has_pe

            FROM {options_view} o

            INNER JOIN {prefix}_minute_expiry_days e
                ON CAST(o.trading_day AS DATE) = e.trading_day
               AND CAST(o.expiry AS DATE) = e.nearest_expiry

            INNER JOIN {prefix}_minute_index i
                ON o.timestamp = i.ts
               AND CAST(o.trading_day AS DATE) = i.trading_day

            WHERE e.days_to_expiry BETWEEN 0 AND {MAX_DTE}
              AND UPPER(o.option_type) IN ('CE', 'PE')
              AND o.strike > 0
              AND o.close > 0
              AND i.spot_close > 0

            GROUP BY
                CAST(o.trading_day AS DATE),
                CAST(o.expiry AS DATE),
                o.strike,
                o.timestamp,
                i.spot_close
        )

        SELECT
            trading_day,
            expiry,
            strike,
            ts,
            distance_pct

        FROM matched

        WHERE has_ce = 1
          AND has_pe = 1
    """)

    # --------------------------------------------------------
    # 4. Expand valid paired timestamps into ATM bands.
    # One timestamp counts once per band, even if several
    # strikes have valid CE/PE pairs at that timestamp.
    # --------------------------------------------------------

    print("Calculating ATM band availability...")

    con.execute(f"""
        CREATE OR REPLACE TEMP TABLE {prefix}_minute_band_pairs AS

        SELECT
            p.trading_day,
            p.expiry,
            p.strike,
            p.ts,
            bands.band_pct

        FROM {prefix}_minute_option_pairs p

        CROSS JOIN (
            VALUES (0.5), (1.0), (2.0)
        ) AS bands(band_pct)

        WHERE p.distance_pct <= bands.band_pct
    """)

    # --------------------------------------------------------
    # 5. Daily coverage.
    #
    # Denominator = all actual index timestamps on an eligible
    # trading day.
    #
    # Numerator = index timestamps with at least one same-strike
    # CE/PE pair inside the selected ATM band.
    # --------------------------------------------------------

    print("Calculating daily coverage...")

    daily_query = f"""
        WITH band_counts AS (
            SELECT
                trading_day,
                band_pct,
                COUNT(DISTINCT ts) AS paired_index_minutes,
                COUNT(DISTINCT strike) AS unique_paired_strikes,
                COUNT(*) AS paired_strike_minute_records

            FROM {prefix}_minute_band_pairs

            GROUP BY trading_day, band_pct
        ),

        all_bands AS (
            SELECT band_pct
            FROM (VALUES (0.5), (1.0), (2.0)) AS b(band_pct)
        )

        SELECT
            '{name}' AS index_name,
            d.trading_day,
            d.nearest_expiry,
            d.days_to_expiry,
            d.dte_bucket,
            b.band_pct,

            d.total_index_minutes,

            COALESCE(c.paired_index_minutes, 0)
                AS paired_index_minutes,

            d.total_index_minutes
              - COALESCE(c.paired_index_minutes, 0)
                AS unavailable_index_minutes,

            ROUND(
                100.0 * COALESCE(c.paired_index_minutes, 0)
                    / NULLIF(d.total_index_minutes, 0),
                2
            ) AS atm_minute_coverage_pct,

            COALESCE(c.unique_paired_strikes, 0)
                AS unique_paired_strikes,

            COALESCE(c.paired_strike_minute_records, 0)
                AS paired_strike_minute_records,

            d.first_index_time,
            d.last_index_time

        FROM {prefix}_minute_day_denominator d

        CROSS JOIN all_bands b

        LEFT JOIN band_counts c
            ON d.trading_day = c.trading_day
           AND b.band_pct = c.band_pct

        ORDER BY d.trading_day, b.band_pct
    """

    export_query(
        con,
        daily_query,
        f"{prefix}_atm_minute_daily_coverage.csv"
    )

    # --------------------------------------------------------
    # 6. Summary by DTE bucket and ATM band.
    # Includes both unweighted daily average and weighted
    # coverage across all observed index minutes.
    # --------------------------------------------------------

    print("Calculating DTE bucket summaries...")

    summary_query = f"""
        SELECT
            index_name,
            dte_bucket,
            band_pct,

            COUNT(*) AS trading_days,

            SUM(total_index_minutes) AS total_index_minutes,

            SUM(paired_index_minutes) AS paired_index_minutes,

            ROUND(AVG(atm_minute_coverage_pct), 2)
                AS average_daily_coverage_pct,

            ROUND(MEDIAN(atm_minute_coverage_pct), 2)
                AS median_daily_coverage_pct,

            ROUND(
                100.0 * SUM(paired_index_minutes)
                    / NULLIF(SUM(total_index_minutes), 0),
                2
            ) AS weighted_minute_coverage_pct,

            SUM(
                CASE WHEN atm_minute_coverage_pct >= 95
                     THEN 1 ELSE 0 END
            ) AS days_at_least_95pct,

            SUM(
                CASE WHEN atm_minute_coverage_pct < 80
                     THEN 1 ELSE 0 END
            ) AS days_below_80pct

        FROM (
            {daily_query}
        ) daily

        GROUP BY index_name, dte_bucket, band_pct
        ORDER BY dte_bucket, band_pct
    """

    export_query(
        con,
        summary_query,
        f"{prefix}_atm_minute_dte_summary.csv"
    )

    # --------------------------------------------------------
    # 7. Yearly coverage by DTE bucket and band.
    # --------------------------------------------------------

    print("Calculating yearly coverage...")

    yearly_query = f"""
        SELECT
            index_name,
            YEAR(trading_day) AS year,
            dte_bucket,
            band_pct,

            COUNT(*) AS trading_days,

            SUM(total_index_minutes) AS total_index_minutes,

            SUM(paired_index_minutes) AS paired_index_minutes,

            ROUND(AVG(atm_minute_coverage_pct), 2)
                AS average_daily_coverage_pct,

            ROUND(MEDIAN(atm_minute_coverage_pct), 2)
                AS median_daily_coverage_pct,

            ROUND(
                100.0 * SUM(paired_index_minutes)
                    / NULLIF(SUM(total_index_minutes), 0),
                2
            ) AS weighted_minute_coverage_pct

        FROM (
            {daily_query}
        ) daily

        GROUP BY
            index_name,
            YEAR(trading_day),
            dte_bucket,
            band_pct

        ORDER BY year, dte_bucket, band_pct
    """

    export_query(
        con,
        yearly_query,
        f"{prefix}_atm_minute_yearly_coverage.csv"
    )

    # --------------------------------------------------------
    # 8. Report days excluded because no observed expiry was
    # available within 14 calendar days.
    # --------------------------------------------------------

    excluded_query = f"""
        SELECT
            '{name}' AS index_name,
            i.trading_day,
            e.nearest_expiry,
            e.days_to_expiry,
            COUNT(DISTINCT i.ts) AS index_minutes

        FROM {prefix}_minute_index i

        LEFT JOIN {prefix}_minute_expiry_days e
            ON i.trading_day = e.trading_day

        WHERE e.trading_day IS NULL
           OR e.days_to_expiry > {MAX_DTE}

        GROUP BY
            i.trading_day,
            e.nearest_expiry,
            e.days_to_expiry

        ORDER BY i.trading_day
    """

    export_query(
        con,
        excluded_query,
        f"{prefix}_atm_minute_excluded_days.csv"
    )

    # --------------------------------------------------------
    # 9. Console summaries.
    # --------------------------------------------------------

    print("\nDTE BUCKET SUMMARY")

    print(
        con.execute(summary_query).fetchdf().to_string(
            index=False
        )
    )

    print("\nYEARLY COVERAGE")

    print(
        con.execute(yearly_query).fetchdf().to_string(
            index=False
        )
    )

    print("\nEXPIRY ELIGIBILITY COUNTS")

    eligibility = con.execute(f"""
        SELECT
            dte_bucket,
            COUNT(*) AS trading_days,
            ROUND(AVG(total_index_minutes), 2)
                AS avg_index_minutes
        FROM {prefix}_minute_day_denominator
        GROUP BY dte_bucket
        ORDER BY dte_bucket
    """).fetchdf()

    print(eligibility.to_string(index=False))

    print(
        f"\n{name} completed in "
        f"{(time.time() - started) / 60:.2f} minutes"
    )


def main():
    if not DB_PATH.exists():
        raise FileNotFoundError(DB_PATH)

    con = duckdb.connect(str(DB_PATH))

    try:
        con.execute("SET memory_limit = '6GB'")
        con.execute("SET threads = 4")
        con.execute(
            f"SET temp_directory = '{TEMP_DIR.as_posix()}'"
        )
        con.execute("SET preserve_insertion_order = false")
        con.execute("SET TimeZone = 'Asia/Calcutta'")

        print("=" * 90)
        print("MINUTE-LEVEL ATM AVAILABILITY VALIDATION")
        print("=" * 90)
        print("DuckDB:", con.execute(
            "SELECT version()"
        ).fetchone()[0])
        print("Timezone:", con.execute(
            "SELECT current_setting('TimeZone')"
        ).fetchone()[0])
        print("ATM bands:", BANDS)
        print("DTE buckets: 0-7 and 8-14")
        print("Maximum DTE:", MAX_DTE)

        for name, views in CONFIG.items():
            validate_index(
                con,
                name,
                views["options"],
                views["index"]
            )

        print("\n" + "=" * 90)
        print("MINUTE-LEVEL ATM AVAILABILITY FINISHED")
        print("Reports:", REPORT_DIR)
        print("=" * 90)

    finally:
        con.close()


if __name__ == "__main__":
    main()
