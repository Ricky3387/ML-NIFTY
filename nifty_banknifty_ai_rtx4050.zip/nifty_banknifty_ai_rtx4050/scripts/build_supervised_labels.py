
from pathlib import Path
import duckdb
import csv

ROOT = Path(__file__).resolve().parents[1]

INPUTS = {
    "NIFTY": ROOT / "data/training/index_features/nifty_index_features.parquet",
    "BANKNIFTY": ROOT / "data/training/index_features/banknifty_index_features.parquet",
}

OUTPUT_DIR = ROOT / "data/training/supervised"

HORIZONS = [5, 15, 30]
THRESHOLDS = [0.50, 0.75, 1.00]

DB_PATH = ROOT / "data/database/nifty_options.duckdb"

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

con = duckdb.connect(str(DB_PATH))

con.execute("SET memory_limit = '6GB'")
con.execute("SET threads = 4")

summary = []

def sql_path(path):
    return str(path.resolve()).replace("\\", "/").replace("'", "''")

for index_name, input_path in INPUTS.items():

    print("\n" + "=" * 75)
    print(f"BUILDING SUPERVISED LABELS: {index_name}")
    print("=" * 75)

    if not input_path.exists():
        raise FileNotFoundError(input_path)

    source = sql_path(input_path)

    for horizon in HORIZONS:

        future_col = f"future_return_{horizon}m"
        valid_col = f"label_valid_{horizon}m"

        output_path = (
                OUTPUT_DIR /
                f"{index_name.lower()}_{horizon}m_supervised.parquet"
        )

        output = sql_path(output_path)

        sigma_expression = (
            f"volatility_60m * sqrt({horizon}.0)"
        )

        z_expression = (
            f"future_return_{horizon}m / "
            f"NULLIF({sigma_expression}, 0)"
        )

        query = f"""
        COPY (
            SELECT
                * EXCLUDE (
                    future_return_5m,
                    future_return_15m,
                    future_return_30m,
                    label_valid_5m,
                    label_valid_15m,
                    label_valid_30m
                ),

                {future_col} AS target_return,

                {sigma_expression} AS target_sigma,

                {z_expression} AS target_z,

                CASE
                    WHEN {z_expression} > 0.50 THEN 2
                    WHEN {z_expression} < -0.50 THEN 0
                    ELSE 1
                END AS target_class,

                CASE
                    WHEN {z_expression} > 0.75 THEN 2
                    WHEN {z_expression} < -0.75 THEN 0
                    ELSE 1
                END AS target_class_z075,

                CASE
                    WHEN {z_expression} > 1.00 THEN 2
                    WHEN {z_expression} < -1.00 THEN 0
                    ELSE 1
                END AS target_class_z100

            FROM read_parquet('{source}')

            WHERE
                eligible_for_index_model = TRUE
                AND {valid_col} = TRUE
                AND {future_col} IS NOT NULL
                AND volatility_60m IS NOT NULL
                AND volatility_60m > 0
                AND isfinite(volatility_60m)
                AND isfinite({future_col})
        )
        TO '{output}'
        (FORMAT PARQUET, COMPRESSION ZSTD)
        """

        con.execute(query)

        result = con.execute(f"""
            SELECT
                COUNT(*) AS observations,
                COUNT(DISTINCT trading_day) AS trading_days,

                AVG(CASE WHEN target_class = 0
                    THEN 1.0 ELSE 0.0 END) * 100 AS down_pct,

                AVG(CASE WHEN target_class = 1
                    THEN 1.0 ELSE 0.0 END) * 100 AS sideways_pct,

                AVG(CASE WHEN target_class = 2
                    THEN 1.0 ELSE 0.0 END) * 100 AS up_pct,

                AVG(target_z) AS mean_z,
                STDDEV_SAMP(target_z) AS std_z

            FROM read_parquet('{output}')
        """).fetchone()

        record = {
            "index_name": index_name,
            "horizon_minutes": horizon,
            "observations": result[0],
            "trading_days": result[1],
            "down_pct": result[2],
            "sideways_pct": result[3],
            "up_pct": result[4],
            "mean_z": result[5],
            "std_z": result[6],
            "output_file": str(output_path)
        }

        summary.append(record)

        print(f"\n{index_name} - {horizon} minutes")
        print(f"Observations : {result[0]:,}")
        print(f"Trading days : {result[1]:,}")
        print(f"DOWN         : {result[2]:.2f}%")
        print(f"SIDEWAYS     : {result[3]:.2f}%")
        print(f"UP           : {result[4]:.2f}%")
        print(f"Mean Z       : {result[5]:.4f}")
        print(f"Std Z        : {result[6]:.4f}")
        print(f"Generated    : {output_path}")

summary_path = OUTPUT_DIR / "supervised_label_summary.csv"

with open(summary_path, "w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=summary[0].keys())
    writer.writeheader()
    writer.writerows(summary)

con.close()

print("\n" + "=" * 75)
print("SUPERVISED LABEL GENERATION COMPLETED")
print(f"Summary: {summary_path}")
print("=" * 75)
