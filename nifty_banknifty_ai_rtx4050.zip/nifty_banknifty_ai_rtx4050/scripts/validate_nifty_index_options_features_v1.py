
from pathlib import Path
import json
from datetime import datetime, timezone

import duckdb

ROOT = Path(__file__).resolve().parents[1]

MERGED_FILE = (
        ROOT / "data/processed/nifty_index_options_features_v1/"
               "nifty_index_options_features_v1.parquet"
)
OPTIONS_FILE = (
        ROOT / "data/processed/nifty_options_features_v4/"
               "nifty_options_features_v4.parquet"
)
REPORT_DIR = ROOT / "reports/nifty_index_options_features_v1"

REPORT_DIR.mkdir(parents=True, exist_ok=True)

SUMMARY_FILE = REPORT_DIR / "merged_quality_audit_summary.json"
NULL_REPORT = REPORT_DIR / "options_feature_null_rates.csv"
YEAR_REPORT = REPORT_DIR / "coverage_by_year_horizon.csv"
FLAG_REPORT = REPORT_DIR / "availability_flag_audit.csv"


def qi(name):
    return '"' + name.replace('"', '""') + '"'


def sql_path(path):
    return "'" + str(path).replace("\\", "/").replace("'", "''") + "'"


def main():
    if not MERGED_FILE.exists():
        raise FileNotFoundError(MERGED_FILE)
    if not OPTIONS_FILE.exists():
        raise FileNotFoundError(OPTIONS_FILE)

    con = duckdb.connect(":memory:")
    con.execute("SET TimeZone='Asia/Kolkata'")
    con.execute("SET threads=4")

    merged_path = sql_path(MERGED_FILE)
    options_path = sql_path(OPTIONS_FILE)

    con.execute(f"""
        CREATE VIEW merged AS
        SELECT * FROM read_parquet({merged_path})
    """)
    con.execute(f"""
        CREATE VIEW options_source AS
        SELECT * FROM read_parquet({options_path})
    """)

    merged_cols = [
        r[0] for r in con.execute(
            "DESCRIBE SELECT * FROM merged"
        ).fetchall()
    ]
    option_cols = [
        r[0] for r in con.execute(
            "DESCRIBE SELECT * FROM options_source"
        ).fetchall()
    ]

    required = [
        "timestamp_ist", "trading_day", "horizon_minutes",
        "label", "sample_eligible", "options_trading_date",
        "options_spot_close"
    ]
    missing = [c for c in required if c not in merged_cols]
    if missing:
        raise RuntimeError(f"Missing required merged columns: {missing}")

    # Determine options columns using the original v4 schema.
    options_feature_cols = [
        c for c in option_cols
        if c not in ("timestamp_ist", "trading_date", "spot_close")
    ]

    # Include the two renamed options metadata columns.
    options_merged_cols = (
            ["options_trading_date", "options_spot_close"]
            + options_feature_cols
    )

    absent = [c for c in options_merged_cols if c not in merged_cols]
    if absent:
        raise RuntimeError(
            f"Options columns missing from merged dataset: {absent}"
        )

    # Core row and eligibility counts.
    core = con.execute("""
                       SELECT
                           COUNT(*) AS total_rows,
                           COUNT(DISTINCT timestamp_ist) AS unique_timestamps,
                           COUNT(DISTINCT horizon_minutes) AS horizons,
                           COUNT(*) FILTER (WHERE sample_eligible) AS eligible_rows,
                           COUNT(*) FILTER (WHERE NOT sample_eligible) AS ineligible_rows,
                           COUNT(*) FILTER (WHERE options_trading_date IS NOT NULL)
                AS rows_with_options,
                           COUNT(*) FILTER (WHERE options_trading_date IS NULL)
                AS rows_without_options,
                           COUNT(*) FILTER (
                WHERE options_trading_date IS NOT NULL
                  AND CAST(options_trading_date AS DATE)
                      <> CAST(trading_day AS DATE)
            ) AS options_date_mismatches
                       FROM merged
                       """).fetchdf().iloc[0].to_dict()

    duplicate_keys = con.execute("""
                                 SELECT COUNT(*)
                                 FROM (
                                          SELECT timestamp_ist, horizon_minutes
                                          FROM merged
                                          GROUP BY timestamp_ist, horizon_minutes
                                          HAVING COUNT(*) > 1
                                      )
                                 """).fetchone()[0]

    horizon_counts = con.execute("""
                                 SELECT horizon_minutes, COUNT(*) AS rows
                                 FROM merged
                                 GROUP BY horizon_minutes
                                 ORDER BY horizon_minutes
                                 """).fetchdf()

    # Missingness by options feature.
    null_rows = []
    for col in options_merged_cols:
        result = con.execute(f"""
            SELECT
                COUNT(*) AS total_rows,
                COUNT({qi(col)}) AS nonnull_rows,
                COUNT(*) - COUNT({qi(col)}) AS null_rows,
                ROUND(
                    100.0 * (COUNT(*) - COUNT({qi(col)}))
                    / NULLIF(COUNT(*), 0), 4
                ) AS null_pct
            FROM merged
        """).fetchone()

        null_rows.append({
            "feature": col,
            "total_rows": result[0],
            "nonnull_rows": result[1],
            "null_rows": result[2],
            "null_pct": result[3]
        })

    import pandas as pd
    pd.DataFrame(null_rows).to_csv(NULL_REPORT, index=False)

    # Coverage by calendar year and prediction horizon.
    coverage_expressions = [
        """
        COUNT(*) FILTER (
            WHERE options_trading_date IS NOT NULL
        ) AS rows_with_options
        """,
        """
        COUNT(*) FILTER (
            WHERE options_trading_date IS NULL
        ) AS rows_without_options
        """
    ]

    for flag, alias in [
        ("atm_pair_available", "atm_pair_rows"),
        ("atm_pair_return_available", "atm_return_rows"),
        ("atm_pair_oi_change_available", "atm_oi_change_rows"),
        ("pcr_available", "pcr_rows")
    ]:
        if flag in merged_cols:
            coverage_expressions.append(f"""
                COUNT(*) FILTER (
                    WHERE COALESCE({qi(flag)}, FALSE)
                ) AS {alias}
            """)

    year_coverage_sql = f"""
        SELECT
            EXTRACT(YEAR FROM CAST(trading_day AS DATE)) AS year,
            horizon_minutes,
            COUNT(*) AS total_rows,
            {','.join(coverage_expressions)}
        FROM merged
        GROUP BY year, horizon_minutes
        ORDER BY year, horizon_minutes
    """

    year_coverage = con.execute(year_coverage_sql).fetchdf()
    year_coverage.to_csv(YEAR_REPORT, index=False)

    # Check availability flags against their underlying values.
    flag_checks = []

    flag_to_values = {
        "atm_pair_available": [
            "atm_ce_close",
            "atm_pe_close"
        ],
        "atm_pair_return_available": [
            "atm_ce_log_return_1m",
            "atm_pe_log_return_1m"
        ],
        "atm_pair_oi_change_available": [
            "atm_ce_oi_change_1m",
            "atm_pe_oi_change_1m"
        ],
        "pcr_available": [
            "near_atm_pcr_oi",
            "near_atm_pcr_volume"
        ]
    }

    for flag, value_cols in flag_to_values.items():
        if flag not in merged_cols:
            continue

        existing_values = [
            c for c in value_cols if c in merged_cols
        ]
        if not existing_values:
            continue

        all_nonnull = " AND ".join(
            f"{qi(c)} IS NOT NULL" for c in existing_values
        )

        mismatch_count = con.execute(f"""
            SELECT COUNT(*)
            FROM merged
            WHERE COALESCE({qi(flag)}, FALSE)
              AND NOT ({all_nonnull})
        """).fetchone()[0]

        flag_checks.append({
            "availability_flag": flag,
            "value_columns_checked": ",".join(existing_values),
            "true_flag_rows_missing_values": mismatch_count,
            "status": "PASS" if mismatch_count == 0 else "FAIL"
        })

    pd.DataFrame(flag_checks).to_csv(FLAG_REPORT, index=False)

    # If no options join exists, all options-derived fields must be NULL.
    nonnull_without_join = {}
    for col in options_merged_cols:
        count = con.execute(f"""
            SELECT COUNT(*)
            FROM merged
            WHERE options_trading_date IS NULL
              AND {qi(col)} IS NOT NULL
        """).fetchone()[0]
        nonnull_without_join[col] = count

    no_join_value_violations = sum(nonnull_without_join.values())

    # Check synthetic and eligibility fields if available.
    synthetic_rows = None
    eligible_synthetic_rows = None

    if "is_synthetic" in merged_cols:
        synthetic_rows = con.execute("""
                                     SELECT COUNT(*) FROM merged
                                     WHERE COALESCE(is_synthetic, FALSE)
                                     """).fetchone()[0]

        eligible_synthetic_rows = con.execute("""
                                              SELECT COUNT(*) FROM merged
                                              WHERE COALESCE(is_synthetic, FALSE)
                                                AND sample_eligible
                                              """).fetchone()[0]

    # Check labels and eligible rows are present.
    eligible_missing_label = con.execute("""
                                         SELECT COUNT(*)
                                         FROM merged
                                         WHERE sample_eligible
                                           AND (label IS NULL OR horizon_minutes IS NULL)
                                         """).fetchone()[0]

    # Confirm no unexpected options values on missing join rows.
    checks = {
        "expected_total_rows": core["total_rows"] == 1003005,
        "no_duplicate_timestamp_horizon_keys": duplicate_keys == 0,
        "no_options_date_mismatches": core["options_date_mismatches"] == 0,
        "no_options_values_without_join": no_join_value_violations == 0,
        "eligible_rows_have_labels": eligible_missing_label == 0,
        "availability_flags_consistent": all(
            x["status"] == "PASS" for x in flag_checks
        ),
    }

    if eligible_synthetic_rows is not None:
        checks["no_synthetic_eligible_rows"] = (
                eligible_synthetic_rows == 0
        )

    summary = {
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "merged_file": str(MERGED_FILE),
        "options_source_file": str(OPTIONS_FILE),
        "merged_columns": len(merged_cols),
        "options_columns_audited": len(options_merged_cols),
        "core_counts": core,
        "duplicate_timestamp_horizon_groups": duplicate_keys,
        "eligible_rows_missing_label": eligible_missing_label,
        "synthetic_rows": synthetic_rows,
        "eligible_synthetic_rows": eligible_synthetic_rows,
        "options_nonnull_values_without_join": nonnull_without_join,
        "options_nonnull_value_violation_total":
            no_join_value_violations,
        "availability_flag_checks": flag_checks,
        "checks": checks,
        "passed_checks": sum(checks.values()),
        "total_checks": len(checks),
        "overall_status": (
            "PASS" if all(checks.values()) else "REVIEW_REQUIRED"
        ),
        "reports": {
            "null_rates": str(NULL_REPORT),
            "coverage_by_year_horizon": str(YEAR_REPORT),
            "availability_flags": str(FLAG_REPORT)
        }
    }

    SUMMARY_FILE.write_text(
        json.dumps(summary, indent=2, default=str),
        encoding="utf-8"
    )

    print("\n" + "=" * 75)
    print("MERGED INDEX + OPTIONS FEATURE QUALITY AUDIT")
    print("=" * 75)
    print(json.dumps(summary, indent=2, default=str))
    print("\nHorizon counts:")
    print(horizon_counts.to_string(index=False))
    print("\nGenerated reports:")
    print(SUMMARY_FILE)
    print(NULL_REPORT)
    print(YEAR_REPORT)
    print(FLAG_REPORT)

    con.close()


if __name__ == "__main__":
    main()
