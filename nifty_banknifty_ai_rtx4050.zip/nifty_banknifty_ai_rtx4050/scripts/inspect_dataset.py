
from pathlib import Path
import pyarrow.parquet as pq

ROOT = Path("data/raw/india-index-options-1m")

# Find all downloaded Parquet files
files = sorted(ROOT.rglob("*.parquet"))

if not files:
    raise SystemExit(
        f"No Parquet files found under: {ROOT.resolve()}\n"
        "Run the download script first."
    )

base_columns = {
    "timestamp",
    "open",
    "high",
    "low",
    "close",
    "volume",
    "trading_day",
    "symbol",
}

print(f"Found {len(files)} Parquet files")

for path in files:
    print("\n" + "=" * 75)
    print("FILE:", path)

    parquet = pq.ParquetFile(path)
    schema = parquet.schema_arrow
    columns = set(schema.names)

    print("Rows:", parquet.metadata.num_rows)
    print("Row groups:", parquet.num_row_groups)
    print("Columns:", schema.names)

    # Different validation rules for index and option files
    expected = set(base_columns)

    if "options" in path.parts:
        expected.update({
            "open_interest",
            "strike",
            "option_type",
            "expiry",
        })

    missing = expected - columns

    if missing:
        print("WARNING: Missing expected columns:", sorted(missing))
    else:
        print("Schema validation: PASSED")

    # Read only five rows from the first row group
    if parquet.num_row_groups > 0:
        sample = parquet.read_row_group(0).slice(0, 5)
        print("\nSample data:")
        print(sample.to_pandas().to_string(index=False))

print("\nInspection completed.")
