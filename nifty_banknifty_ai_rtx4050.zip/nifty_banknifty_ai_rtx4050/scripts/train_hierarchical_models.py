
from pathlib import Path
import json
import warnings

import numpy as np
import pandas as pd

from lightgbm import LGBMClassifier, early_stopping, log_evaluation

from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    f1_score,
    log_loss,
    classification_report,
    confusion_matrix,
)

warnings.filterwarnings("ignore")

ROOT = Path(__file__).resolve().parents[1]

INPUT_DIR = ROOT / "data" / "training" / "supervised"
MODEL_DIR = ROOT / "models" / "hierarchical_models"
RESULT_DIR = ROOT / "data" / "training" / "hierarchical_results"

MODEL_DIR.mkdir(parents=True, exist_ok=True)
RESULT_DIR.mkdir(parents=True, exist_ok=True)

DATASETS = [
    ("nifty", "5m"),
    ("nifty", "15m"),
    ("nifty", "30m"),
    ("banknifty", "5m"),
    ("banknifty", "15m"),
    ("banknifty", "30m"),
]

FEATURES = [
    "minute_of_day",
    "day_of_week",
    "month_of_year",
    "return_1m",
    "return_5m",
    "return_15m",
    "return_30m",
    "volatility_5m",
    "volatility_15m",
    "volatility_30m",
    "volatility_60m",
    "candle_range_pct",
    "candle_body_pct",
    "upper_wick_pct",
    "lower_wick_pct",
    "close_location",
    "vwap_deviation_pct",
    "volume_ratio_30",
    "volume_zscore_30",
    "range_position_15",
    "range_position_30",
]

PARAMS = {
    "n_estimators": 3000,
    "learning_rate": 0.03,
    "num_leaves": 31,
    "max_depth": -1,
    "min_child_samples": 100,
    "subsample": 0.8,
    "subsample_freq": 1,
    "colsample_bytree": 0.8,
    "reg_alpha": 0.1,
    "reg_lambda": 1.0,
    "random_state": 42,
    "n_jobs": 4,
    "verbosity": -1,
}

CLASS_NAMES = ["DOWN", "SIDEWAYS", "UP"]


def get_probability(model, X, class_value):
    """Return probability for a particular binary class."""
    probabilities = model.predict_proba(X)
    position = list(model.classes_).index(class_value)
    return probabilities[:, position]


def calculate_metrics(y_true, probabilities):
    predictions = np.argmax(probabilities, axis=1)

    return {
        "observations": len(y_true),
        "accuracy": accuracy_score(y_true, predictions),
        "balanced_accuracy": balanced_accuracy_score(
            y_true, predictions
        ),
        "macro_f1": f1_score(
            y_true, predictions, average="macro",
            zero_division=0
        ),
        "log_loss": log_loss(
            y_true,
            probabilities,
            labels=[0, 1, 2]
        ),
    }


def train_one(index_name, horizon):

    name = f"{index_name}_{horizon}"

    print("\n" + "=" * 80)
    print("TRAINING HIERARCHICAL MODEL:", name.upper())
    print("=" * 80)

    path = INPUT_DIR / f"{name}_supervised.parquet"

    df = pd.read_parquet(path)

    df["trading_day"] = pd.to_datetime(df["trading_day"])
    df["target_class"] = df["target_class"].astype(int)

    required = FEATURES + [
        "trading_day",
        "target_class",
        "target_z",
    ]

    missing = [c for c in required if c not in df.columns]

    if missing:
        raise ValueError(
            f"{name}: Missing required columns: {missing}"
        )

    # Only training and validation periods.
    # 2025 and 2026 are not used here.
    train = df[
        df["trading_day"].dt.year.isin([2021, 2022, 2023])
    ].copy()

    valid = df[
        df["trading_day"].dt.year == 2024
        ].copy()

    if train.empty or valid.empty:
        raise ValueError(f"{name}: Empty train or validation data")

    X_train = train[FEATURES]
    X_valid = valid[FEATURES]

    y_train = train["target_class"].to_numpy()
    y_valid = valid["target_class"].to_numpy()

    # --------------------------------------------------------
    # STAGE 1: MOVE versus SIDEWAYS
    # --------------------------------------------------------

    print("\nSTAGE 1: MOVE DETECTION")

    y_train_move = (y_train != 1).astype(int)
    y_valid_move = (y_valid != 1).astype(int)

    move_model = LGBMClassifier(
        objective="binary",
        **PARAMS
    )

    move_model.fit(
        X_train,
        y_train_move,
        eval_set=[(X_valid, y_valid_move)],
        eval_metric="binary_logloss",
        callbacks=[
            early_stopping(100, verbose=False),
            log_evaluation(0),
        ],
    )

    p_move = get_probability(
        move_model,
        X_valid,
        1
    )

    move_predictions = (p_move >= 0.5).astype(int)

    move_accuracy = accuracy_score(
        y_valid_move,
        move_predictions
    )

    move_balanced_accuracy = balanced_accuracy_score(
        y_valid_move,
        move_predictions
    )

    move_logloss = log_loss(
        y_valid_move,
        np.column_stack([1 - p_move, p_move]),
        labels=[0, 1]
    )

    print("Move accuracy:", round(move_accuracy, 4))
    print(
        "Move balanced accuracy:",
        round(move_balanced_accuracy, 4)
    )
    print("Move log loss:", round(move_logloss, 4))
    print("Move best iteration:", move_model.best_iteration_)

    # --------------------------------------------------------
    # STAGE 2: DOWN versus UP
    # Train only on meaningful movements.
    # --------------------------------------------------------

    print("\nSTAGE 2: DIRECTION DETECTION")

    train_move_mask = y_train != 1
    valid_move_mask = y_valid != 1

    X_train_direction = X_train.loc[train_move_mask]
    X_valid_direction = X_valid.loc[valid_move_mask]

    # DOWN = 0, UP = 1
    y_train_direction = (
            y_train[train_move_mask] == 2
    ).astype(int)

    y_valid_direction = (
            y_valid[valid_move_mask] == 2
    ).astype(int)

    direction_model = LGBMClassifier(
        objective="binary",
        **PARAMS
    )

    direction_model.fit(
        X_train_direction,
        y_train_direction,
        eval_set=[
            (X_valid_direction, y_valid_direction)
        ],
        eval_metric="binary_logloss",
        callbacks=[
            early_stopping(100, verbose=False),
            log_evaluation(0),
        ],
    )

    direction_accuracy = accuracy_score(
        y_valid_direction,
        direction_model.predict(X_valid_direction)
    )

    direction_balanced_accuracy = balanced_accuracy_score(
        y_valid_direction,
        direction_model.predict(X_valid_direction)
    )

    print(
        "Conditional direction accuracy:",
        round(direction_accuracy, 4)
    )

    print(
        "Conditional direction balanced accuracy:",
        round(direction_balanced_accuracy, 4)
    )

    print(
        "Direction best iteration:",
        direction_model.best_iteration_
    )

    # --------------------------------------------------------
    # COMBINE THE TWO STAGES
    # --------------------------------------------------------

    p_up_conditional = get_probability(
        direction_model,
        X_valid,
        1
    )

    p_down_conditional = 1.0 - p_up_conditional

    p_down = p_move * p_down_conditional
    p_sideways = 1.0 - p_move
    p_up = p_move * p_up_conditional

    probabilities = np.column_stack([
        p_down,
        p_sideways,
        p_up,
    ])

    # Numerical safety.
    probabilities = np.clip(
        probabilities,
        1e-8,
        1.0
    )

    probabilities /= probabilities.sum(
        axis=1,
        keepdims=True
    )

    metrics = calculate_metrics(
        y_valid,
        probabilities
    )

    print("\nCOMBINED THREE-CLASS VALIDATION")

    for key, value in metrics.items():
        print(key, ":", round(value, 5))

    predictions = np.argmax(probabilities, axis=1)

    print("\nClassification report:")

    print(
        classification_report(
            y_valid,
            predictions,
            labels=[0, 1, 2],
            target_names=CLASS_NAMES,
            zero_division=0
        )
    )

    print("Confusion matrix:")

    print(
        confusion_matrix(
            y_valid,
            predictions,
            labels=[0, 1, 2]
        )
    )

    # --------------------------------------------------------
    # SAVE MODELS
    # --------------------------------------------------------

    output_model_dir = MODEL_DIR / name
    output_model_dir.mkdir(parents=True, exist_ok=True)

    move_model.booster_.save_model(
        str(output_model_dir / "move_model.txt")
    )

    direction_model.booster_.save_model(
        str(output_model_dir / "direction_model.txt")
    )

    metadata = {
        "dataset": name,
        "features": FEATURES,
        "train_years": [2021, 2022, 2023],
        "validation_year": 2024,
        "test_years_used": [],
        "stage1_best_iteration": int(
            move_model.best_iteration_
        ),
        "stage2_best_iteration": int(
            direction_model.best_iteration_
        ),
        "stage1_move_accuracy": float(move_accuracy),
        "stage1_move_balanced_accuracy": float(
            move_balanced_accuracy
        ),
        "stage1_move_logloss": float(move_logloss),
        "stage2_direction_accuracy": float(
            direction_accuracy
        ),
        "stage2_direction_balanced_accuracy": float(
            direction_balanced_accuracy
        ),
        "combined_metrics": {
            k: float(v) for k, v in metrics.items()
        },
    }

    with open(
            output_model_dir / "metadata.json",
            "w"
    ) as f:
        json.dump(metadata, f, indent=2)

    # --------------------------------------------------------
    # SAVE VALIDATION PREDICTIONS
    # --------------------------------------------------------

    prediction_df = pd.DataFrame({
        "trading_day": valid["trading_day"].to_numpy(),
        "actual_class": y_valid,
        "predicted_class": predictions,
        "actual_z": valid["target_z"].to_numpy(),
        "prob_down": p_down,
        "prob_sideways": p_sideways,
        "prob_up": p_up,
        "prob_move": p_move,
        "prob_up_given_move": p_up_conditional,
    })

    prediction_df.to_parquet(
        RESULT_DIR / f"{name}_validation_predictions.parquet",
        index=False
    )

    summary = {
        "dataset": name,
        **metrics,
        "move_accuracy": move_accuracy,
        "move_balanced_accuracy": move_balanced_accuracy,
        "move_log_loss": move_logloss,
        "direction_accuracy": direction_accuracy,
        "direction_balanced_accuracy": direction_balanced_accuracy,
        "pred_down_pct": (predictions == 0).mean() * 100,
        "pred_sideways_pct": (predictions == 1).mean() * 100,
        "pred_up_pct": (predictions == 2).mean() * 100,
        "best_move_iteration": move_model.best_iteration_,
        "best_direction_iteration": direction_model.best_iteration_,
    }

    return summary


def main():

    summaries = []

    for index_name, horizon in DATASETS:

        try:
            result = train_one(index_name, horizon)
            summaries.append(result)

        except Exception as exc:
            print(
                f"\nERROR training {index_name}_{horizon}: {exc}"
            )
            raise

    summary_df = pd.DataFrame(summaries)

    summary_path = (
            RESULT_DIR / "hierarchical_validation_summary.csv"
    )

    summary_df.to_csv(
        summary_path,
        index=False
    )

    print("\n" + "=" * 80)
    print("ALL HIERARCHICAL MODELS COMPLETED")
    print("=" * 80)

    print(summary_df.to_string(index=False))

    print("\nSummary saved:", summary_path)
    print("Models saved:", MODEL_DIR)
    print("Predictions saved:", RESULT_DIR)


if __name__ == "__main__":
    main()
