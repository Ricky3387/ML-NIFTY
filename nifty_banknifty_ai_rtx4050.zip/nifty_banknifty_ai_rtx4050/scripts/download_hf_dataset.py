
from pathlib import Path
from huggingface_hub import snapshot_download

REPO_ID = "thetrademarkk/india-index-options-1m"
LOCAL_DIR = Path("data/raw/india-index-options-1m")

# Only download the two indices and their option-contract files.
ALLOW_PATTERNS = [
    "index/NIFTY.parquet",
    "index/BANKNIFTY.parquet",
    "options/NIFTY/*.parquet",
    "options/BANKNIFTY/*.parquet",
    "README.md",
]

def main():
    LOCAL_DIR.mkdir(parents=True, exist_ok=True)

    print(f"Downloading selected files from {REPO_ID}")
    print(f"Destination: {LOCAL_DIR.resolve()}")

    downloaded_path = snapshot_download(
        repo_id=REPO_ID,
        repo_type="dataset",
        allow_patterns=ALLOW_PATTERNS,
        local_dir=str(LOCAL_DIR),
        max_workers=4,
    )

    print("\nDownload completed.")
    print(f"Local path: {downloaded_path}")

    parquet_files = list(LOCAL_DIR.rglob("*.parquet"))
    print(f"Parquet files downloaded: {len(parquet_files)}")

    for file in sorted(parquet_files):
        size_mb = file.stat().st_size / (1024 * 1024)
        print(f"{file} | {size_mb:.2f} MB")

if __name__ == "__main__":
    main()
