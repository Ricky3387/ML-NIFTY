
from pathlib import Path
import duckdb

ROOT = Path(__file__).resolve().parents[1]
DB = ROOT / "data" / "database" / "nifty_options.duckdb"
OUT = ROOT / "reports" / "out_of_session_audit_v1"

OUT.mkdir(parents=True, exist_ok=True)

con = duckdb.connect(str(DB), read_only=True)

# All timestamp classification uses IST.
IST = "timezone('Asia/Kolkata', timestamp)"

def export_query(name, query):
    df = con.execute(query).fetchdf()
    path = OUT / f"{name}.csv"
    df.to_csv(path, index=False)
    print(f"\n{name}: {len(df):,} rows")
    print(df.head(20).to_string(index=False))
    return df

# ------------------------------------------------------------
# 1. NIFTY INDEX: SESSION CLASSIFICATION
# ------------------------------------------------------------

index_classification = f"""
WITH x AS (
    SELECT
        timestamp,
        trading_day,
        {IST} AS ist_timestamp,
        CAST({IST} AS TIME) AS ist_clock
    FROM nifty_index
)
SELECT
    CASE
        WHEN ist_clock BETWEEN TIME '09:00:00'
                           AND TIME '09:14:00'
            THEN 'PREOPEN'
        WHEN ist_clock BETWEEN TIME '09:15:00'
                           AND TIME '15:29:00'
            THEN 'REGULAR'
        WHEN ist_clock < TIME '09:00:00'
            THEN 'BEFORE_PREOPEN'
        ELSE 'AFTER_REGULAR'
    END AS session_category,
    COUNT(*) AS rows,
    COUNT(DISTINCT trading_day) AS trading_days,
    MIN(ist_timestamp) AS first_ist_timestamp,
    MAX(ist_timestamp) AS last_ist_timestamp
FROM x
GROUP BY session_category
ORDER BY session_category
"""

export_query("nifty_index_session_classification",
             index_classification)

# ------------------------------------------------------------
# 2. INDEX: OUT-OF-SESSION CLOCK DISTRIBUTION
# ------------------------------------------------------------

index_clock = f"""
WITH x AS (
    SELECT
        trading_day,
        {IST} AS ist_timestamp,
        CAST({IST} AS TIME) AS ist_clock
    FROM nifty_index
)
SELECT
    CAST(ist_clock AS VARCHAR) AS ist_clock,
    COUNT(*) AS rows,
    COUNT(DISTINCT trading_day) AS trading_days,
    MIN(ist_timestamp) AS first_timestamp,
    MAX(ist_timestamp) AS last_timestamp
FROM x
WHERE NOT (
    ist_clock BETWEEN TIME '09:15:00'
                  AND TIME '15:29:00'
)
GROUP BY ist_clock
ORDER BY rows DESC, ist_clock
"""

export_query("nifty_index_out_of_session_clock",
             index_clock)

# ------------------------------------------------------------
# 3. INDEX: UNUSUAL OBSERVATIONS
# ------------------------------------------------------------

index_samples = f"""
WITH x AS (
    SELECT
        timestamp,
        trading_day,
        {IST} AS ist_timestamp,
        CAST({IST} AS TIME) AS ist_clock,
        open, high, low, close, volume
    FROM nifty_index
)
SELECT *
FROM x
WHERE NOT (
    ist_clock BETWEEN TIME '09:15:00'
                  AND TIME '15:29:00'
)
ORDER BY ist_timestamp
LIMIT 500
"""

export_query("nifty_index_out_of_session_samples",
             index_samples)

# ------------------------------------------------------------
# 4. OPTIONS: SESSION CLASSIFICATION
# ------------------------------------------------------------

options_classification = f"""
WITH x AS (
    SELECT
        timestamp,
        trading_day,
        {IST} AS ist_timestamp,
        CAST({IST} AS TIME) AS ist_clock
    FROM nifty_options
)
SELECT
    CASE
        WHEN ist_clock BETWEEN TIME '09:00:00'
                           AND TIME '09:14:00'
            THEN 'PREOPEN'
        WHEN ist_clock BETWEEN TIME '09:15:00'
                           AND TIME '15:29:00'
            THEN 'REGULAR'
        WHEN ist_clock < TIME '09:00:00'
            THEN 'BEFORE_PREOPEN'
        ELSE 'AFTER_REGULAR'
    END AS session_category,
    COUNT(*) AS rows,
    COUNT(DISTINCT trading_day) AS trading_days,
    MIN(ist_timestamp) AS first_ist_timestamp,
    MAX(ist_timestamp) AS last_ist_timestamp
FROM x
GROUP BY session_category
ORDER BY session_category
"""

export_query("nifty_options_session_classification",
             options_classification)

# ------------------------------------------------------------
# 5. OPTIONS: OUT-OF-SESSION CLOCK DISTRIBUTION
# ------------------------------------------------------------

options_clock = f"""
WITH x AS (
    SELECT
        trading_day,
        {IST} AS ist_timestamp,
        CAST({IST} AS TIME) AS ist_clock
    FROM nifty_options
)
SELECT
    CAST(ist_clock AS VARCHAR) AS ist_clock,
    COUNT(*) AS rows,
    COUNT(DISTINCT trading_day) AS trading_days,
    MIN(ist_timestamp) AS first_timestamp,
    MAX(ist_timestamp) AS last_timestamp
FROM x
WHERE NOT (
    ist_clock BETWEEN TIME '09:15:00'
                  AND TIME '15:29:00'
)
GROUP BY ist_clock
ORDER BY rows DESC, ist_clock
"""

export_query("nifty_options_out_of_session_clock",
             options_clock)

# ------------------------------------------------------------
# 6. OPTIONS: OUT-OF-SESSION SAMPLE
# ------------------------------------------------------------

options_samples = f"""
WITH x AS (
    SELECT
        timestamp,
        trading_day,
        {IST} AS ist_timestamp,
        CAST({IST} AS TIME) AS ist_clock,
        symbol,
        strike,
        option_type,
        expiry,
        open, high, low, close,
        volume,
        open_interest
    FROM nifty_options
)
SELECT *
FROM x
WHERE NOT (
    ist_clock BETWEEN TIME '09:15:00'
                  AND TIME '15:29:00'
)
ORDER BY ist_timestamp
LIMIT 500
"""

export_query("nifty_options_out_of_session_samples",
             options_samples)

con.close()

print("\n" + "=" * 80)
print("OUT-OF-SESSION AUDIT COMPLETED")
print("=" * 80)
print("Output:", OUT)
print("Original database was not modified.")
