
from pathlib import Path
from datetime import datetime
import json
import duckdb
import pandas as pd

# ============================================================
# NIFTY OPTIONS FEATURE BUILDER V1
#
# Scope:
#   2021-05-24 to 2024-12-31
#   NIFTY only
#   Normal NSE session: 09:15-15:29 IST
#
# Features:
#   1. ATM CE/PE premiums and returns
#   2. ATM straddle premium and return
#   3. CE/PE relative premium strength
#   4. ATM CE/PE OI and OI changes
#   5. Near-ATM paired OI PCR
#   6. Near-ATM paired volume PCR
#   7. Near-ATM OI/volume imbalance
#   8. Rolling volume aggregates
#   9. Data quality and availability flags
#
# Rules:
#   - No forward filling
#   - No fabricated bid/ask, IV or Greeks
#   - Same contract required for lagged changes
#   - Consecutive minute required for 1-minute changes
#   - Same expiry for CE/PE comparisons
#   - Paired strikes only for PCR
#   - Original database is read-only
# ============================================================

ROOT = Path(__file__).resolve().parent.parent

DB_PATH = ROOT / "data" / "database" / "nifty_options.duckdb"

OUTPUT_DIR = (
        ROOT / "data" / "processed" / "nifty_options_features_v1"
)

REPORT_DIR = (
        ROOT / "reports" / "nifty_options_features_v1"
)

OUTPUT_FILE = (
        OUTPUT_DIR / "nifty_options_features_v1.parquet"
)

START_DATE = "2021-05-24"
END_DATE = "2024-12-31"

TIMEZONE = "Asia/Kolkata"
SESSION_START = "09:15:00"
SESSION_END = "15:29:00"

SPECIAL_DATES = [
    "2021-11-04",
    "2022-10-24",
    "2023-11-12",
    "2024-11-01",
    "2024-01-20",
    "2024-03-02",
    "2024-05-18",
]

MAX_DTE = 7
ATM_BAND_PCT = 2.0

THREADS = 4
MEMORY_LIMIT = "8GB"

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
REPORT_DIR.mkdir(parents=True, exist_ok=True)


def write_csv(df, filename):
    path = REPORT_DIR / filename
    df.to_csv(path, index=False)
    print(f"Generated: {path} ({len(df):,} rows)")


def save_json(data, filename):
    path = REPORT_DIR / filename
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, default=str)
    print(f"Generated: {path}")


def qid(value):
    return '"' + str(value).replace('"', '""') + '"'


def main():
    if not DB_PATH.exists():
        raise FileNotFoundError(DB_PATH)

    print("=" * 85)
    print("NIFTY OPTIONS FEATURE BUILDER V1")
    print("=" * 85)

    print("Database:", DB_PATH)
    print("Output:", OUTPUT_FILE)
    print("Date range:", START_DATE, "to", END_DATE)
    print("ATM band:", ATM_BAND_PCT, "%")
    print("Maximum DTE:", MAX_DTE)

    con = duckdb.connect(str(DB_PATH), read_only=True)

    try:
        con.execute(f"SET threads = {THREADS}")
        con.execute(f"SET memory_limit = '{MEMORY_LIMIT}'")

        temp_dir = str(
            REPORT_DIR / "duckdb_temp"
        ).replace("\\", "/")

        con.execute(
            f"SET temp_directory = '{temp_dir}'"
        )

        special_sql = ", ".join(
            f"DATE '{d}'" for d in SPECIAL_DATES
        )

        # ----------------------------------------------------
        # 1. Validate source schema
        # ----------------------------------------------------
        option_schema = con.execute(
            "DESCRIBE SELECT * FROM nifty_options"
        ).df()

        option_columns = set(
            option_schema["column_name"].astype(str)
        )

        required_options = {
            "timestamp",
            "expiry",
            "strike",
            "option_type",
            "underlying",
            "close",
            "volume",
            "open_interest",
        }

        missing = sorted(required_options - option_columns)

        if missing:
            raise RuntimeError(
                "Missing options columns: " + ", ".join(missing)
            )

        index_schema = con.execute(
            "DESCRIBE SELECT * FROM nifty_index"
        ).df()

        index_columns = set(
            index_schema["column_name"].astype(str)
        )

        required_index = {"timestamp", "close"}

        missing_index = sorted(
            required_index - index_columns
        )

        if missing_index:
            raise RuntimeError(
                "Missing index columns: " + ", ".join(missing_index)
            )

        # ----------------------------------------------------
        # 2. Build index minute universe
        # ----------------------------------------------------
        synthetic_filter = ""

        if "is_synthetic" in index_columns:
            synthetic_filter = """
                AND COALESCE(is_synthetic, FALSE) = FALSE
            """

        print("\n[1/8] Building NIFTY index minute universe...")

        con.execute(f"""
            CREATE OR REPLACE TEMP TABLE index_scope AS
            SELECT
                timestamp,
                timezone('{TIMEZONE}', timestamp) AS timestamp_ist,
                CAST(timezone('{TIMEZONE}', timestamp) AS DATE)
                    AS trading_date,
                CAST(close AS DOUBLE) AS spot_close
            FROM nifty_index
            WHERE CAST(timezone('{TIMEZONE}', timestamp) AS DATE)
                    BETWEEN DATE '{START_DATE}' AND DATE '{END_DATE}'
              AND CAST(timezone('{TIMEZONE}', timestamp) AS TIME)
                    BETWEEN TIME '{SESSION_START}' AND TIME '{SESSION_END}'
              AND CAST(timezone('{TIMEZONE}', timestamp) AS DATE)
                    NOT IN ({special_sql})
              AND close > 0
              {synthetic_filter}
        """)

        index_count = con.execute(
            "SELECT COUNT(*) FROM index_scope"
        ).fetchone()[0]

        index_days = con.execute(
            "SELECT COUNT(DISTINCT trading_date) FROM index_scope"
        ).fetchone()[0]

        print("Index rows:", f"{index_count:,}")
        print("Index trading days:", index_days)

        # ----------------------------------------------------
        # 3. Find nearest eligible expiry for each index minute
        #
        # The nearest expiry is selected independently for
        # each timestamp. DTE must be 0 through MAX_DTE.
        # ----------------------------------------------------
        print("\n[2/8] Finding nearest eligible expiry...")

        con.execute(f"""
            CREATE OR REPLACE TEMP TABLE nearest_expiry AS
            SELECT
                i.timestamp,
                i.timestamp_ist,
                i.trading_date,
                i.spot_close,
                MIN(CAST(o.expiry AS DATE)) AS selected_expiry
            FROM index_scope i
            INNER JOIN nifty_options o
                ON o.timestamp = i.timestamp
            WHERE UPPER(TRIM(CAST(o.underlying AS VARCHAR))) = 'NIFTY'
              AND UPPER(TRIM(CAST(o.option_type AS VARCHAR)))
                    IN ('CE', 'PE')
              AND o.strike > 0
              AND o.close > 0
              AND DATE_DIFF(
                    'day',
                    i.trading_date,
                    CAST(o.expiry AS DATE)
                  ) BETWEEN 0 AND {MAX_DTE}
            GROUP BY
                i.timestamp,
                i.timestamp_ist,
                i.trading_date,
                i.spot_close
        """)

        expiry_count = con.execute(
            "SELECT COUNT(*) FROM nearest_expiry"
        ).fetchone()[0]

        print("Minutes with eligible expiry:", f"{expiry_count:,}")

        # ----------------------------------------------------
        # 4. Select all contracts in selected expiry and
        #    within ATM_BAND_PCT around spot.
        #
        # This table is the main reusable working dataset.
        # ----------------------------------------------------
        print("\n[3/8] Materializing near-ATM options observations...")

        con.execute(f"""
            CREATE OR REPLACE TEMP TABLE near_options AS
            SELECT
                o.timestamp,
                i.timestamp_ist,
                i.trading_date,
                i.spot_close,
                CAST(o.expiry AS DATE) AS expiry_date,
                CAST(o.strike AS DOUBLE) AS strike,
                UPPER(TRIM(CAST(o.option_type AS VARCHAR)))
                    AS option_type,
                CAST(o.close AS DOUBLE) AS option_close,
                CAST(o.volume AS DOUBLE) AS option_volume,
                CAST(o.open_interest AS DOUBLE) AS option_oi,

                ABS(CAST(o.strike AS DOUBLE) - i.spot_close)
                    / NULLIF(i.spot_close, 0) * 100.0
                    AS strike_distance_pct,

                DATE_DIFF(
                    'day',
                    i.trading_date,
                    CAST(o.expiry AS DATE)
                ) AS dte

            FROM index_scope i
            INNER JOIN nearest_expiry e
                ON i.timestamp = e.timestamp
            INNER JOIN nifty_options o
                ON o.timestamp = i.timestamp
               AND CAST(o.expiry AS DATE) = e.selected_expiry

            WHERE UPPER(TRIM(CAST(o.underlying AS VARCHAR))) = 'NIFTY'
              AND UPPER(TRIM(CAST(o.option_type AS VARCHAR)))
                    IN ('CE', 'PE')
              AND o.strike > 0
              AND o.close > 0
              AND ABS(CAST(o.strike AS DOUBLE) - i.spot_close)
                    / NULLIF(i.spot_close, 0) * 100.0
                    <= {ATM_BAND_PCT}
        """)

        near_count = con.execute(
            "SELECT COUNT(*) FROM near_options"
        ).fetchone()[0]

        near_contracts = con.execute("""
                                     SELECT COUNT(DISTINCT expiry_date || ':' ||
                                                           CAST(strike AS VARCHAR) || ':' || option_type)
                                     FROM near_options
                                     """).fetchone()[0]

        print("Near-ATM rows:", f"{near_count:,}")
        print("Distinct contract identities:", f"{near_contracts:,}")

        # ----------------------------------------------------
        # 5. Calculate contract-level previous observations.
        #
        # We require exact one-minute continuity for changes.
        # This prevents gaps from being interpreted as 1m data.
        # ----------------------------------------------------
        print("\n[4/8] Calculating same-contract changes...")

        con.execute("""
                    CREATE OR REPLACE TEMP TABLE near_options_lagged AS
                    SELECT
                        *,

                        LAG(option_close) OVER (
                    PARTITION BY
                        trading_date,
                        expiry_date,
                        strike,
                        option_type
                    ORDER BY timestamp
                ) AS previous_close,

                        LAG(option_oi) OVER (
                    PARTITION BY
                        trading_date,
                        expiry_date,
                        strike,
                        option_type
                    ORDER BY timestamp
                ) AS previous_oi,

                        LAG(timestamp_ist) OVER (
                    PARTITION BY
                        trading_date,
                        expiry_date,
                        strike,
                        option_type
                    ORDER BY timestamp
                ) AS previous_timestamp

                    FROM near_options
                    """)

        con.execute("""
                    CREATE OR REPLACE TEMP TABLE near_options_changes AS
                    SELECT
                        *,

                        DATE_DIFF(
                                'minute',
                                previous_timestamp,
                                timestamp_ist
                        ) AS previous_gap_minutes,

                        CASE
                            WHEN previous_timestamp IS NOT NULL
                                AND DATE_DIFF(
                                            'minute',
                                            previous_timestamp,
                                            timestamp_ist
                                    ) = 1
                                AND previous_close > 0
                                THEN LN(option_close / previous_close)
                            ELSE NULL
                            END AS option_log_return_1m,

                        CASE
                            WHEN previous_timestamp IS NOT NULL
                                AND DATE_DIFF(
                                            'minute',
                                            previous_timestamp,
                                            timestamp_ist
                                    ) = 1
                                AND previous_oi IS NOT NULL
                                AND option_oi IS NOT NULL
                                THEN option_oi - previous_oi
                            ELSE NULL
                            END AS option_oi_change_1m

                    FROM near_options_lagged
                    """)

        # ----------------------------------------------------
        # 6. Pivot CE/PE values at same strike/expiry/minute.
        #
        # Each row is one timestamp + expiry + strike.
        # ----------------------------------------------------
        print("\n[5/8] Building paired contract observations...")

        con.execute("""
                    CREATE OR REPLACE TEMP TABLE paired_strikes AS
                    SELECT
                        timestamp,
                        timestamp_ist,
                        trading_date,
                        spot_close,
                        expiry_date,
                        strike,
                        MIN(dte) AS dte,
                        MIN(strike_distance_pct) AS strike_distance_pct,

                        COUNT(*) FILTER (
                        WHERE option_type = 'CE'
                        ) AS ce_count,

                        COUNT(*) FILTER (
                        WHERE option_type = 'PE'
                        ) AS pe_count,

                        MAX(option_close) FILTER (
                        WHERE option_type = 'CE'
                        ) AS ce_close,

                        MAX(option_close) FILTER (
                        WHERE option_type = 'PE'
                        ) AS pe_close,

                        MAX(option_volume) FILTER (
                        WHERE option_type = 'CE'
                        ) AS ce_volume,

                        MAX(option_volume) FILTER (
                        WHERE option_type = 'PE'
                        ) AS pe_volume,

                        MAX(option_oi) FILTER (
                        WHERE option_type = 'CE'
                        ) AS ce_oi,

                        MAX(option_oi) FILTER (
                        WHERE option_type = 'PE'
                        ) AS pe_oi,

                        MAX(option_log_return_1m) FILTER (
                        WHERE option_type = 'CE'
                        ) AS ce_log_return_1m,

                        MAX(option_log_return_1m) FILTER (
                        WHERE option_type = 'PE'
                        ) AS pe_log_return_1m,

                        MAX(option_oi_change_1m) FILTER (
                        WHERE option_type = 'CE'
                        ) AS ce_oi_change_1m,

                        MAX(option_oi_change_1m) FILTER (
                        WHERE option_type = 'PE'
                        ) AS pe_oi_change_1m,

                        MAX(previous_gap_minutes) FILTER (
                        WHERE option_type = 'CE'
                        ) AS ce_previous_gap_minutes,

                        MAX(previous_gap_minutes) FILTER (
                        WHERE option_type = 'PE'
                        ) AS pe_previous_gap_minutes

                    FROM near_options_changes
                    GROUP BY
                        timestamp,
                        timestamp_ist,
                        trading_date,
                        spot_close,
                        expiry_date,
                        strike

                    HAVING
                        COUNT(*) FILTER (
                        WHERE option_type = 'CE'
                        ) = 1
                       AND
                        COUNT(*) FILTER (
                        WHERE option_type = 'PE'
                        ) = 1
                    """)

        paired_count = con.execute(
            "SELECT COUNT(*) FROM paired_strikes"
        ).fetchone()[0]

        print("Paired strike observations:", f"{paired_count:,}")

        # ----------------------------------------------------
        # 7. Select nearest ATM strike and calculate PCR
        #
        # ATM:
        #   nearest strike to spot within selected expiry.
        #
        # PCR:
        #   all paired strikes within ATM_BAND_PCT,
        #   same timestamp and same selected expiry.
        # ----------------------------------------------------
        print("\n[6/8] Building ATM and paired PCR features...")

        con.execute("""
                    CREATE OR REPLACE TEMP TABLE atm_features AS
                    SELECT *
                    FROM paired_strikes
                             QUALIFY ROW_NUMBER() OVER (
                PARTITION BY timestamp
                ORDER BY
                    strike_distance_pct ASC,
                    strike ASC
            ) = 1
                    """)

        con.execute("""
                    CREATE OR REPLACE TEMP TABLE pcr_features AS
                    SELECT
                        timestamp,
                        timestamp_ist,
                        trading_date,
                        expiry_date,

                        COUNT(*) AS paired_strike_count,

                        SUM(ce_oi) AS near_atm_ce_oi_sum,
                        SUM(pe_oi) AS near_atm_pe_oi_sum,

                        SUM(ce_volume) AS near_atm_ce_volume_sum,
                        SUM(pe_volume) AS near_atm_pe_volume_sum,

                        SUM(ce_oi_change_1m)
                        AS near_atm_ce_oi_change_sum_1m,

                        SUM(pe_oi_change_1m)
                        AS near_atm_pe_oi_change_sum_1m,

                        COUNT(*) FILTER (
                        WHERE ce_oi_change_1m IS NOT NULL
                        AND pe_oi_change_1m IS NOT NULL
                        ) AS paired_oi_change_strike_count

                    FROM paired_strikes
                    GROUP BY
                        timestamp,
                        timestamp_ist,
                        trading_date,
                        expiry_date
                    """)

        # ----------------------------------------------------
        # 8. Combine into one row per index minute.
        # ----------------------------------------------------
        print("\n[7/8] Combining options features with NIFTY index...")

        con.execute("""
                    CREATE OR REPLACE TEMP TABLE options_features_base AS
                    SELECT
                        i.timestamp,
                        i.timestamp_ist,
                        i.trading_date,
                        i.spot_close,

                        a.expiry_date AS selected_expiry,
                        a.dte AS selected_dte,
                        a.strike AS atm_strike,
                        a.strike_distance_pct AS atm_distance_pct,

                        a.ce_close AS atm_ce_close,
                        a.pe_close AS atm_pe_close,

                        CASE
                            WHEN a.ce_close IS NOT NULL
                                AND a.pe_close IS NOT NULL
                                THEN a.ce_close + a.pe_close
                            ELSE NULL
                            END AS atm_straddle_premium,

                        a.ce_log_return_1m AS atm_ce_log_return_1m,
                        a.pe_log_return_1m AS atm_pe_log_return_1m,

                        CASE
                            WHEN a.ce_log_return_1m IS NOT NULL
                                AND a.pe_log_return_1m IS NOT NULL
                                THEN a.ce_log_return_1m - a.pe_log_return_1m
                            ELSE NULL
                            END AS atm_ce_pe_return_spread_1m,

                        CASE
                            WHEN a.ce_close > 0
                                AND a.pe_close > 0
                                AND a.ce_log_return_1m IS NOT NULL
                                AND a.pe_log_return_1m IS NOT NULL
                                THEN
                                (
                                    a.ce_close * a.ce_log_return_1m
                                        + a.pe_close * a.pe_log_return_1m
                                    ) / (a.ce_close + a.pe_close)
                            ELSE NULL
                            END AS atm_straddle_weighted_log_return_1m,

                        a.ce_oi AS atm_ce_oi,
                        a.pe_oi AS atm_pe_oi,
                        a.ce_oi_change_1m AS atm_ce_oi_change_1m,
                        a.pe_oi_change_1m AS atm_pe_oi_change_1m,

                        a.ce_volume AS atm_ce_volume,
                        a.pe_volume AS atm_pe_volume,

                        p.paired_strike_count,

                        p.near_atm_ce_oi_sum,
                        p.near_atm_pe_oi_sum,
                        p.near_atm_ce_volume_sum,
                        p.near_atm_pe_volume_sum,

                        p.near_atm_ce_oi_change_sum_1m,
                        p.near_atm_pe_oi_change_sum_1m,
                        p.paired_oi_change_strike_count,

                        CASE
                            WHEN p.near_atm_ce_oi_sum > 0
                                AND p.near_atm_pe_oi_sum IS NOT NULL
                                THEN p.near_atm_pe_oi_sum
                                / p.near_atm_ce_oi_sum
                            ELSE NULL
                            END AS near_atm_pcr_oi,

                        CASE
                            WHEN p.near_atm_ce_volume_sum > 0
                                AND p.near_atm_pe_volume_sum IS NOT NULL
                                THEN p.near_atm_pe_volume_sum
                                / p.near_atm_ce_volume_sum
                            ELSE NULL
                            END AS near_atm_pcr_volume,

                        CASE
                            WHEN p.near_atm_ce_oi_sum IS NOT NULL
                                AND p.near_atm_pe_oi_sum IS NOT NULL
                                AND (
                                        p.near_atm_ce_oi_sum
                                            + p.near_atm_pe_oi_sum
                                        ) > 0
                                THEN
                                (
                                    p.near_atm_pe_oi_sum
                                        - p.near_atm_ce_oi_sum
                                    )
                                    /
                                (
                                    p.near_atm_pe_oi_sum
                                        + p.near_atm_ce_oi_sum
                                    )
                            ELSE NULL
                            END AS near_atm_oi_imbalance,

                        CASE
                            WHEN p.near_atm_ce_volume_sum IS NOT NULL
                                AND p.near_atm_pe_volume_sum IS NOT NULL
                                AND (
                                        p.near_atm_ce_volume_sum
                                            + p.near_atm_pe_volume_sum
                                        ) > 0
                                THEN
                                (
                                    p.near_atm_pe_volume_sum
                                        - p.near_atm_ce_volume_sum
                                    )
                                    /
                                (
                                    p.near_atm_pe_volume_sum
                                        + p.near_atm_ce_volume_sum
                                    )
                            ELSE NULL
                            END AS near_atm_volume_imbalance,

                        CASE
                            WHEN a.ce_close IS NOT NULL
                                AND a.pe_close IS NOT NULL
                                THEN TRUE ELSE FALSE
                            END AS atm_pair_available,

                        CASE
                            WHEN a.ce_log_return_1m IS NOT NULL
                                AND a.pe_log_return_1m IS NOT NULL
                                THEN TRUE ELSE FALSE
                            END AS atm_pair_return_available,

                        CASE
                            WHEN a.ce_oi_change_1m IS NOT NULL
                                AND a.pe_oi_change_1m IS NOT NULL
                                THEN TRUE ELSE FALSE
                            END AS atm_pair_oi_change_available,

                        CASE
                            WHEN p.paired_strike_count > 0
                                THEN TRUE ELSE FALSE
                            END AS pcr_available

                    FROM index_scope i

                             LEFT JOIN atm_features a
                                       ON i.timestamp = a.timestamp

                             LEFT JOIN pcr_features p
                                       ON i.timestamp = p.timestamp
                    """)

        # ----------------------------------------------------
        # 9. Rolling volume features.
        #
        # No zero filling. A rolling sum is emitted only when
        # every index minute in that window has valid values.
        # ----------------------------------------------------
        print("\n[8/8] Building rolling volume features and output...")

        con.execute("""
                    CREATE OR REPLACE TEMP TABLE options_features_final AS
            WITH rolling AS (
                SELECT
                    *,

                    COUNT(atm_ce_volume) OVER (
                        PARTITION BY trading_date
                        ORDER BY timestamp
                        ROWS BETWEEN 4 PRECEDING AND CURRENT ROW
                    ) AS ce_volume_count_5m,

                    COUNT(atm_pe_volume) OVER (
                        PARTITION BY trading_date
                        ORDER BY timestamp
                        ROWS BETWEEN 4 PRECEDING AND CURRENT ROW
                    ) AS pe_volume_count_5m,

                    SUM(atm_ce_volume) OVER (
                        PARTITION BY trading_date
                        ORDER BY timestamp
                        ROWS BETWEEN 4 PRECEDING AND CURRENT ROW
                    ) AS ce_volume_sum_5m_raw,

                    SUM(atm_pe_volume) OVER (
                        PARTITION BY trading_date
                        ORDER BY timestamp
                        ROWS BETWEEN 4 PRECEDING AND CURRENT ROW
                    ) AS pe_volume_sum_5m_raw,

                    COUNT(atm_ce_volume) OVER (
                        PARTITION BY trading_date
                        ORDER BY timestamp
                        ROWS BETWEEN 14 PRECEDING AND CURRENT ROW
                    ) AS ce_volume_count_15m,

                    COUNT(atm_pe_volume) OVER (
                        PARTITION BY trading_date
                        ORDER BY timestamp
                        ROWS BETWEEN 14 PRECEDING AND CURRENT ROW
                    ) AS pe_volume_count_15m,

                    SUM(atm_ce_volume) OVER (
                        PARTITION BY trading_date
                        ORDER BY timestamp
                        ROWS BETWEEN 14 PRECEDING AND CURRENT ROW
                    ) AS ce_volume_sum_15m_raw,

                    SUM(atm_pe_volume) OVER (
                        PARTITION BY trading_date
                        ORDER BY timestamp
                        ROWS BETWEEN 14 PRECEDING AND CURRENT ROW
                    ) AS pe_volume_sum_15m_raw,

                    COUNT(atm_ce_volume) OVER (
                        PARTITION BY trading_date
                        ORDER BY timestamp
                        ROWS BETWEEN 29 PRECEDING AND CURRENT ROW
                    ) AS ce_volume_count_30m,

                    COUNT(atm_pe_volume) OVER (
                        PARTITION BY trading_date
                        ORDER BY timestamp
                        ROWS BETWEEN 29 PRECEDING AND CURRENT ROW
                    ) AS pe_volume_count_30m,

                    SUM(atm_ce_volume) OVER (
                        PARTITION BY trading_date
                        ORDER BY timestamp
                        ROWS BETWEEN 29 PRECEDING AND CURRENT ROW
                    ) AS ce_volume_sum_30m_raw,

                    SUM(atm_pe_volume) OVER (
                        PARTITION BY trading_date
                        ORDER BY timestamp
                        ROWS BETWEEN 29 PRECEDING AND CURRENT ROW
                    ) AS pe_volume_sum_30m_raw

                FROM options_features_base
            )
                    SELECT
                        *,

                        CASE
                            WHEN ce_volume_count_5m = 5
                                THEN ce_volume_sum_5m_raw
                            ELSE NULL
                            END AS atm_ce_volume_sum_5m,

                        CASE
                            WHEN pe_volume_count_5m = 5
                                THEN pe_volume_sum_5m_raw
                            ELSE NULL
                            END AS atm_pe_volume_sum_5m,

                        CASE
                            WHEN ce_volume_count_15m = 15
                                THEN ce_volume_sum_15m_raw
                            ELSE NULL
                            END AS atm_ce_volume_sum_15m,

                        CASE
                            WHEN pe_volume_count_15m = 15
                                THEN pe_volume_sum_15m_raw
                            ELSE NULL
                            END AS atm_pe_volume_sum_15m,

                        CASE
                            WHEN ce_volume_count_30m = 30
                                THEN ce_volume_sum_30m_raw
                            ELSE NULL
                            END AS atm_ce_volume_sum_30m,

                        CASE
                            WHEN pe_volume_count_30m = 30
                                THEN pe_volume_sum_30m_raw
                            ELSE NULL
                            END AS atm_pe_volume_sum_30m,

                        CASE
                            WHEN ce_volume_count_5m = 5
                                AND pe_volume_count_5m = 5
                                AND (
                                        ce_volume_sum_5m_raw
                                            + pe_volume_sum_5m_raw
                                        ) > 0
                                THEN
                                (
                                    pe_volume_sum_5m_raw
                                        - ce_volume_sum_5m_raw
                                    )
                                    /
                                (
                                    pe_volume_sum_5m_raw
                                        + ce_volume_sum_5m_raw
                                    )
                            ELSE NULL
                            END AS atm_volume_imbalance_5m,

                        CASE
                            WHEN ce_volume_count_15m = 15
                                AND pe_volume_count_15m = 15
                                AND (
                                        ce_volume_sum_15m_raw
                                            + pe_volume_sum_15m_raw
                                        ) > 0
                                THEN
                                (
                                    pe_volume_sum_15m_raw
                                        - ce_volume_sum_15m_raw
                                    )
                                    /
                                (
                                    pe_volume_sum_15m_raw
                                        + ce_volume_sum_15m_raw
                                    )
                            ELSE NULL
                            END AS atm_volume_imbalance_15m,

                        CASE
                            WHEN ce_volume_count_30m = 30
                                AND pe_volume_count_30m = 30
                                AND (
                                        ce_volume_sum_30m_raw
                                            + pe_volume_sum_30m_raw
                                        ) > 0
                                THEN
                                (
                                    pe_volume_sum_30m_raw
                                        - ce_volume_sum_30m_raw
                                    )
                                    /
                                (
                                    pe_volume_sum_30m_raw
                                        + ce_volume_sum_30m_raw
                                    )
                            ELSE NULL
                            END AS atm_volume_imbalance_30m

                    FROM rolling
                    """)

        # ----------------------------------------------------
        # 10. Write Parquet
        #
        # New output only. Existing output is not overwritten.
        # ----------------------------------------------------
        if OUTPUT_FILE.exists():
            raise FileExistsError(
                f"Output already exists; refusing to overwrite: {OUTPUT_FILE}"
            )

        output_path_sql = str(OUTPUT_FILE).replace("\\", "/")

        con.execute(f"""
            COPY (
                SELECT *
                FROM options_features_final
                ORDER BY timestamp
            )
            TO '{output_path_sql}'
            (FORMAT PARQUET, COMPRESSION ZSTD)
        """)

        # ----------------------------------------------------
        # 11. Output quality and coverage
        # ----------------------------------------------------
        coverage = con.execute("""
                               SELECT
                                   COUNT(*) AS output_rows,
                                   COUNT(DISTINCT trading_date) AS trading_days,

                                   COUNT(*) FILTER (
                    WHERE atm_pair_available
                ) AS atm_pair_rows,

                                   COUNT(*) FILTER (
                    WHERE atm_pair_return_available
                ) AS atm_pair_return_rows,

                                   COUNT(*) FILTER (
                    WHERE atm_pair_oi_change_available
                ) AS atm_pair_oi_change_rows,

                                   COUNT(*) FILTER (
                    WHERE pcr_available
                ) AS pcr_rows,

                                   COUNT(*) FILTER (
                    WHERE near_atm_pcr_oi IS NOT NULL
                ) AS pcr_oi_valid_rows,

                                   COUNT(*) FILTER (
                    WHERE near_atm_pcr_volume IS NOT NULL
                ) AS pcr_volume_valid_rows,

                                   COUNT(*) FILTER (
                    WHERE atm_volume_imbalance_5m IS NOT NULL
                ) AS rolling_volume_5m_rows,

                                   COUNT(*) FILTER (
                    WHERE atm_volume_imbalance_15m IS NOT NULL
                ) AS rolling_volume_15m_rows,

                                   COUNT(*) FILTER (
                    WHERE atm_volume_imbalance_30m IS NOT NULL
                ) AS rolling_volume_30m_rows,

                                   COUNT(*) FILTER (
                    WHERE selected_expiry IS NULL
                ) AS missing_expiry_rows,

                                   COUNT(*) FILTER (
                    WHERE atm_straddle_premium IS NULL
                ) AS missing_straddle_rows

                               FROM options_features_final
                               """).df()

        write_csv(coverage, "options_feature_coverage.csv")

        feature_schema = con.execute(f"""
            DESCRIBE SELECT * FROM read_parquet('{output_path_sql}')
        """).df()

        write_csv(feature_schema, "options_feature_schema.csv")

        # Feature null percentages.
        null_quality = con.execute(f"""
            SELECT
                COUNT(*) AS rows,
                COUNT(*) - COUNT(atm_ce_close)
                    AS null_atm_ce_close,
                COUNT(*) - COUNT(atm_pe_close)
                    AS null_atm_pe_close,
                COUNT(*) - COUNT(atm_ce_log_return_1m)
                    AS null_atm_ce_return,
                COUNT(*) - COUNT(atm_pe_log_return_1m)
                    AS null_atm_pe_return,
                COUNT(*) - COUNT(atm_ce_oi_change_1m)
                    AS null_atm_ce_oi_change,
                COUNT(*) - COUNT(atm_pe_oi_change_1m)
                    AS null_atm_pe_oi_change,
                COUNT(*) - COUNT(near_atm_pcr_oi)
                    AS null_pcr_oi,
                COUNT(*) - COUNT(near_atm_pcr_volume)
                    AS null_pcr_volume
            FROM read_parquet('{output_path_sql}')
        """).df()

        write_csv(
            null_quality,
            "options_feature_null_quality.csv"
        )

        summary = {
            "generated_at": datetime.now().isoformat(),
            "source_database": str(DB_PATH),
            "output_parquet": str(OUTPUT_FILE),
            "date_scope": {
                "start": START_DATE,
                "end": END_DATE
            },
            "session": {
                "timezone": TIMEZONE,
                "start": SESSION_START,
                "end": SESSION_END,
                "special_dates_excluded": SPECIAL_DATES
            },
            "selection_policy": {
                "underlying": "NIFTY",
                "expiry": f"nearest expiry with DTE 0-{MAX_DTE}",
                "atm": "nearest strike to spot within selected expiry",
                "pcr": (
                    "paired CE/PE strikes within "
                    f"{ATM_BAND_PCT}% of spot in selected expiry"
                ),
                "contract_return": (
                    "same contract, exact consecutive minute only"
                ),
                "oi_change": (
                    "same contract, exact consecutive minute only"
                ),
                "missing_values": "preserved as NULL; no forward fill"
            },
            "index_rows": int(index_count),
            "index_trading_days": int(index_days),
            "minutes_with_eligible_expiry": int(expiry_count),
            "near_atm_option_rows": int(near_count),
            "distinct_near_atm_contract_identities": int(near_contracts),
            "paired_strike_observations": int(paired_count),
            "coverage": coverage.iloc[0].to_dict(),
            "features_created": [
                "selected_expiry",
                "selected_dte",
                "atm_strike",
                "atm_distance_pct",
                "atm_ce_close",
                "atm_pe_close",
                "atm_straddle_premium",
                "atm_ce_log_return_1m",
                "atm_pe_log_return_1m",
                "atm_ce_pe_return_spread_1m",
                "atm_straddle_weighted_log_return_1m",
                "atm_ce_oi",
                "atm_pe_oi",
                "atm_ce_oi_change_1m",
                "atm_pe_oi_change_1m",
                "atm_ce_volume",
                "atm_pe_volume",
                "paired_strike_count",
                "near_atm_ce_oi_sum",
                "near_atm_pe_oi_sum",
                "near_atm_pcr_oi",
                "near_atm_pcr_volume",
                "near_atm_oi_imbalance",
                "near_atm_volume_imbalance",
                "near_atm_ce_oi_change_sum_1m",
                "near_atm_pe_oi_change_sum_1m",
                "atm_ce_volume_sum_5m",
                "atm_pe_volume_sum_5m",
                "atm_ce_volume_sum_15m",
                "atm_pe_volume_sum_15m",
                "atm_ce_volume_sum_30m",
                "atm_pe_volume_sum_30m",
                "atm_volume_imbalance_5m",
                "atm_volume_imbalance_15m",
                "atm_volume_imbalance_30m",
                "atm_pair_available",
                "atm_pair_return_available",
                "atm_pair_oi_change_available",
                "pcr_available"
            ],
            "source_modified": False,
            "model_training_performed": False,
            "limitations": [
                "Volume is treated as per-observation volume based on observed decreases; provider semantics are not independently verified.",
                "PCR is limited to paired strikes within the selected expiry and ATM band.",
                "ATM is selected by nearest strike; missing CE/PE is not replaced with a farther strike.",
                "Rolling volume windows require complete observations at each index minute.",
                "No IV, Greeks, bid/ask or order-book features are created.",
                "No labels are created or modified."
            ]
        }

        save_json(
            summary,
            "options_feature_builder_summary.json"
        )

        print("\n" + "=" * 85)
        print("FEATURE BUILD COMPLETED")
        print("=" * 85)
        print("Output:", OUTPUT_FILE)
        print("Rows:", f"{index_count:,}")
        print("Output directory:", REPORT_DIR)
        print("Source database opened read-only.")
        print("Existing files were not overwritten.")
        print("No model training performed.")

    finally:
        con.close()


if __name__ == "__main__":
    main()
