
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
INPUT_DIR = ROOT / "data" / "training" / "supervised"
OUTPUT_DIR = ROOT / "data" / "training" / "label_audit"

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

DATASETS = [
    ("nifty", "5m"),
    ("nifty", "15m"),
    ("nifty", "30m"),
    ("banknifty", "5m"),
    ("banknifty", "15m"),
    ("banknifty", "30m"),
]

# Expected target definition:
# 0 = DOWN       when Z < -0.5
# 1 = SIDEWAYS   when -0.5 <= Z <= 0.5
# 2 = UP         when Z > 0.5

def expected_class(z):
    return np.where(
        z < -0.5,
        0,
        np.where(z > 0.5, 2, 1)
    )


year_rows = []
distribution_rows = []
consistency_rows = []
z_rows = []

for index_name, horizon in DATASETS:

    name = f"{index_name}_{horizon}"
    path = INPUT_DIR / f"{name}_supervised.parquet"

    print("\n" + "=" * 75)
    print("AUDITING", name.upper())
    print("=" * 75)

    df = pd.read_parquet(
        path,
        columns=[
            "trading_day",
            "target_class",
            "target_z"
        ]
    )

    df["trading_day"] = pd.to_datetime(df["trading_day"])
    df["year"] = df["trading_day"].dt.year

    df["target_class"] = pd.to_numeric(
        df["target_class"],
        errors="coerce"
    )

    df["target_z"] = pd.to_numeric(
        df["target_z"],
        errors="coerce"
    )

    df = df.dropna(
        subset=["target_class", "target_z"]
    ).copy()

    df["target_class"] = df["target_class"].astype(int)

    # --------------------------------------------------------
    # Verify label formula
    # --------------------------------------------------------

    expected = expected_class(
        df["target_z"].to_numpy()
    )

    mismatch = (
            df["target_class"].to_numpy() != expected
    )

    mismatch_count = int(mismatch.sum())

    consistency_rows.append({
        "dataset": name,
        "observations": len(df),
        "threshold": 0.5,
        "mismatches": mismatch_count,
        "mismatch_pct": mismatch.mean() * 100,
        "minimum_z": df["target_z"].min(),
        "maximum_z": df["target_z"].max(),
    })

    print("Label mismatches:", mismatch_count)
    print("Mismatch percentage:", round(mismatch.mean() * 100, 5))

    # --------------------------------------------------------
    # Class balance by year
    # --------------------------------------------------------

    for year, group in df.groupby("year"):

        counts = group["target_class"].value_counts()

        total = len(group)

        down = counts.get(0, 0)
        sideways = counts.get(1, 0)
        up = counts.get(2, 0)

        row = {
            "dataset": name,
            "year": int(year),
            "observations": total,
            "down_count": int(down),
            "sideways_count": int(sideways),
            "up_count": int(up),
            "down_pct": down / total * 100,
            "sideways_pct": sideways / total * 100,
            "up_pct": up / total * 100,
            "mean_z": group["target_z"].mean(),
            "std_z": group["target_z"].std(),
        }

        year_rows.append(row)

        if year in [2021, 2022, 2023, 2024, 2025, 2026]:
            distribution_rows.append(row)

    # --------------------------------------------------------
    # Overall Z distribution
    # --------------------------------------------------------

    z_rows.append({
        "dataset": name,
        "observations": len(df),
        "mean_z": df["target_z"].mean(),
        "std_z": df["target_z"].std(),
        "median_z": df["target_z"].median(),
        "p01_z": df["target_z"].quantile(0.01),
        "p05_z": df["target_z"].quantile(0.05),
        "p95_z": df["target_z"].quantile(0.95),
        "p99_z": df["target_z"].quantile(0.99),
        "mean_abs_z": df["target_z"].abs().mean(),
    })

    print("\nYearly class distribution:")
    print(
        pd.DataFrame([
            row for row in year_rows
            if row["dataset"] == name
        ])[
            [
                "year",
                "observations",
                "down_pct",
                "sideways_pct",
                "up_pct",
                "mean_z",
                "std_z",
            ]
        ].round(3).to_string(index=False)
    )

# ------------------------------------------------------------
# Write reports
# ------------------------------------------------------------

pd.DataFrame(year_rows).to_csv(
    OUTPUT_DIR / "yearly_class_distribution.csv",
    index=False
)

pd.DataFrame(distribution_rows).to_csv(
    OUTPUT_DIR / "class_distribution_by_period.csv",
    index=False
)

pd.DataFrame(consistency_rows).to_csv(
    OUTPUT_DIR / "label_consistency.csv",
    index=False
)

pd.DataFrame(z_rows).to_csv(
    OUTPUT_DIR / "z_distribution.csv",
    index=False
)

print("\n" + "=" * 75)
print("LABEL AUDIT COMPLETED")
print("Output:", OUTPUT_DIR)
print("=" * 75)
