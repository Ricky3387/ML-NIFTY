
from pathlib import Path
from datetime import datetime
import json
import warnings

import numpy as np
import pandas as pd

from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    brier_score_loss,
    confusion_matrix,
    f1_score,
    log_loss,
    precision_score,
    recall_score,
    roc_auc_score,
)

warnings.filterwarnings("ignore", category=FutureWarning)

# ============================================================
# CONFIGURATION
# ============================================================

ROOT = Path(__file__).resolve().parent.parent

RUN_ID = "20261111_203135"

INPUT_FILE = (
        ROOT / "reports" / "nifty_direction_aware_v1"
        / RUN_ID / "2024_direction_aware_predictions.parquet"
)

OUTPUT_DIR = (
        ROOT / "reports" / "nifty_direction_aware_probability_audit_v1"
        / RUN_ID
)

LABELS = ["DOWN", "SIDEWAYS", "UP"]

# Fixed sensitivity policies.
# These are diagnostic comparisons, not threshold optimization.

POLICIES = {
    "ARGMAX": {
        "type": "argmax",
    },
    "D050_U050": {
        "directional": 0.50,
        "conditional_up": 0.50,
    },
    "D055_U050": {
        "directional": 0.55,
        "conditional_up": 0.50,
    },
    "D060_U050": {
        "directional": 0.60,
        "conditional_up": 0.50,
    },
    "D065_U050": {
        "directional": 0.65,
        "conditional_up": 0.50,
    },
    "D060_U045": {
        "directional": 0.60,
        "conditional_up": 0.45,
    },
    "D060_U055": {
        "directional": 0.60,
        "conditional_up": 0.55,
    },
}

REQUIRED_COLUMNS = [
    "timestamp_ist",
    "trading_day",
    "actual_label",
    "p_directional",
    "p_up_conditional",
    "p_down",
    "p_sideways",
    "p_up",
]


# ============================================================
# HELPERS
# ============================================================

def require_file(path):
    if not path.exists():
        raise FileNotFoundError(f"Input file not found: {path}")


def normalize_label(series):
    return series.astype(str).str.strip().str.upper()


def safe_auc(actual, probability):
    actual = np.asarray(actual, dtype=int)
    probability = np.asarray(probability, dtype=float)

    valid = np.isfinite(probability)

    actual = actual[valid]
    probability = probability[valid]

    if len(actual) == 0 or len(np.unique(actual)) < 2:
        return np.nan

    return float(roc_auc_score(actual, probability))


def safe_logloss(actual, probability):
    try:
        return float(
            log_loss(
                np.asarray(actual, dtype=int),
                np.asarray(probability, dtype=float),
                labels=[0, 1],
            )
        )
    except Exception:
        return np.nan


def expected_calibration_error(actual, probability, bins=10):
    actual = np.asarray(actual, dtype=float)
    probability = np.asarray(probability, dtype=float)

    valid = np.isfinite(actual) & np.isfinite(probability)

    actual = actual[valid]
    probability = probability[valid]

    if len(actual) == 0:
        return np.nan

    edges = np.linspace(0, 1, bins + 1)
    ece = 0.0

    for i in range(bins):
        if i == bins - 1:
            mask = (
                    (probability >= edges[i])
                    & (probability <= edges[i + 1])
            )
        else:
            mask = (
                    (probability >= edges[i])
                    & (probability < edges[i + 1])
            )

        if mask.sum() == 0:
            continue

        avg_probability = probability[mask].mean()
        avg_actual = actual[mask].mean()

        ece += (
                mask.mean()
                * abs(avg_probability - avg_actual)
        )

    return float(ece)


def multiclass_metrics(actual, predicted, probabilities):
    actual = normalize_label(pd.Series(actual))
    predicted = normalize_label(pd.Series(predicted))

    probabilities = np.asarray(probabilities, dtype=float)

    return {
        "rows": int(len(actual)),
        "accuracy": float(
            accuracy_score(actual, predicted)
        ),
        "balanced_accuracy": float(
            balanced_accuracy_score(actual, predicted)
        ),
        "macro_f1": float(
            f1_score(
                actual,
                predicted,
                labels=LABELS,
                average="macro",
                zero_division=0,
            )
        ),
        "weighted_f1": float(
            f1_score(
                actual,
                predicted,
                labels=LABELS,
                average="weighted",
                zero_division=0,
            )
        ),
        "multiclass_log_loss": float(
            log_loss(
                actual,
                probabilities,
                labels=LABELS,
            )
        ),
        "actual_directional_pct": float(
            100 * actual.isin(["DOWN", "UP"]).mean()
        ),
        "predicted_directional_pct": float(
            100 * predicted.isin(["DOWN", "UP"]).mean()
        ),
        "down_precision": float(
            precision_score(
                actual.eq("DOWN"),
                predicted.eq("DOWN"),
                zero_division=0,
            )
        ),
        "down_recall": float(
            recall_score(
                actual.eq("DOWN"),
                predicted.eq("DOWN"),
                zero_division=0,
            )
        ),
        "up_precision": float(
            precision_score(
                actual.eq("UP"),
                predicted.eq("UP"),
                zero_division=0,
            )
        ),
        "up_recall": float(
            recall_score(
                actual.eq("UP"),
                predicted.eq("UP"),
                zero_division=0,
            )
        ),
    }


def predict_policy(df, policy):
    if policy.get("type") == "argmax":
        matrix = df[
            ["p_down", "p_sideways", "p_up"]
        ].to_numpy(dtype=float)

        return np.asarray(LABELS)[np.argmax(matrix, axis=1)]

    directional_threshold = policy["directional"]
    up_threshold = policy["conditional_up"]

    directional = (
            df["p_directional"].to_numpy(dtype=float)
            >= directional_threshold
    )

    up = (
            df["p_up_conditional"].to_numpy(dtype=float)
            >= up_threshold
    )

    result = np.full(
        len(df),
        "SIDEWAYS",
        dtype=object,
    )

    result[directional & ~up] = "DOWN"
    result[directional & up] = "UP"

    return result


def make_probability_matrix(df):
    return df[
        ["p_down", "p_sideways", "p_up"]
    ].to_numpy(dtype=float)


def validate_probabilities(df):
    probability_columns = [
        "p_directional",
        "p_up_conditional",
        "p_down",
        "p_sideways",
        "p_up",
    ]

    for column in probability_columns:
        values = pd.to_numeric(
            df[column],
            errors="coerce",
        )

        if values.isna().any():
            raise ValueError(
                f"Null/non-numeric probability values in {column}"
            )

        if not np.isfinite(values).all():
            raise ValueError(
                f"Non-finite probability values in {column}"
            )

        if ((values < 0) | (values > 1)).any():
            raise ValueError(
                f"Probability outside [0,1] in {column}"
            )

    combined_sum = (
            df["p_down"] + df["p_sideways"] + df["p_up"]
    )

    if not np.allclose(
            combined_sum.to_numpy(),
            1.0,
            atol=1e-5,
    ):
        raise ValueError(
            "Combined class probabilities do not sum to 1."
        )

    reconstructed_down = (
            df["p_directional"]
            * (1 - df["p_up_conditional"])
    )

    reconstructed_up = (
            df["p_directional"]
            * df["p_up_conditional"]
    )

    reconstructed_sideways = (
            1 - df["p_directional"]
    )

    checks = {
        "p_down": reconstructed_down,
        "p_up": reconstructed_up,
        "p_sideways": reconstructed_sideways,
    }

    for column, reconstructed in checks.items():
        difference = np.abs(
            df[column].to_numpy()
            - reconstructed.to_numpy()
        )

        maximum_difference = float(difference.max())

        print(
            f"{column} reconstruction max difference: "
            f"{maximum_difference:.10f}"
        )

        if maximum_difference > 1e-5:
            raise ValueError(
                f"{column} does not match the two-stage "
                "probability reconstruction."
            )


# ============================================================
# LOAD DATA
# ============================================================

def main():

    print("=" * 75)
    print("NIFTY DIRECTION-AWARE PROBABILITY AUDIT V1")
    print("=" * 75)

    require_file(INPUT_FILE)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    df = pd.read_parquet(INPUT_FILE)

    missing = [
        c for c in REQUIRED_COLUMNS
        if c not in df.columns
    ]

    if missing:
        raise ValueError(
            f"Input file missing columns: {missing}\n"
            f"Available columns: {df.columns.tolist()}"
        )

    df = df.copy()

    df["actual_label"] = normalize_label(df["actual_label"])

    unexpected = sorted(
        set(df["actual_label"].unique()) - set(LABELS)
    )

    if unexpected:
        raise ValueError(
            f"Unexpected actual labels: {unexpected}"
        )

    df["timestamp_ist"] = pd.to_datetime(
        df["timestamp_ist"],
        utc=True,
        errors="coerce",
    )

    if df["timestamp_ist"].isna().any():
        raise ValueError("Invalid timestamps in prediction file.")

    if df.duplicated(
            ["timestamp_ist", "trading_day"]
    ).any():
        raise ValueError(
            "Duplicate timestamp/trading_day rows found."
        )

    for column in REQUIRED_COLUMNS:
        if column.startswith("p_"):
            df[column] = pd.to_numeric(
                df[column],
                errors="coerce",
            )

    validate_probabilities(df)

    df["month"] = df["timestamp_ist"].dt.strftime("%Y-%m")

    print(f"\nRows loaded: {len(df):,}")
    print(
        "Date range:",
        df["timestamp_ist"].min(),
        "to",
        df["timestamp_ist"].max(),
    )

    # ========================================================
    # 1. STAGE 1 PROBABILITY AUDIT
    # ========================================================

    print("\n" + "=" * 75)
    print("STAGE 1: DIRECTIONAL VS SIDEWAYS")
    print("=" * 75)

    stage1_actual = (
        df["actual_label"].isin(["DOWN", "UP"])
    ).astype(int).to_numpy()

    stage1_probability = df[
        "p_directional"
    ].to_numpy(dtype=float)

    stage1_rows = []

    for actual_class, group in df.groupby("actual_label"):
        probability = group["p_directional"]

        stage1_rows.append({
            "actual_class": actual_class,
            "rows": len(group),
            "mean_p_directional": probability.mean(),
            "median_p_directional": probability.median(),
            "p10": probability.quantile(0.10),
            "p25": probability.quantile(0.25),
            "p75": probability.quantile(0.75),
            "p90": probability.quantile(0.90),
            "actual_directional_rate": (
                group["actual_label"]
                .isin(["DOWN", "UP"])
                .mean()
            ),
        })

    stage1_distribution = pd.DataFrame(stage1_rows)

    stage1_metrics = {
        "rows": len(df),
        "actual_directional_pct": float(
            100 * stage1_actual.mean()
        ),
        "mean_probability_pct": float(
            100 * stage1_probability.mean()
        ),
        "roc_auc": safe_auc(
            stage1_actual,
            stage1_probability,
        ),
        "log_loss": safe_logloss(
            stage1_actual,
            stage1_probability,
        ),
        "brier_score": float(
            brier_score_loss(
                stage1_actual,
                stage1_probability,
            )
        ),
        "ece_10_bins": expected_calibration_error(
            stage1_actual,
            stage1_probability,
            bins=10,
        ),
    }

    stage1_distribution.to_csv(
        OUTPUT_DIR / "stage1_probability_by_actual_class.csv",
        index=False,
        )

    # ========================================================
    # 2. STAGE 2 CONDITIONAL PROBABILITY AUDIT
    # ========================================================

    print("\n" + "=" * 75)
    print("STAGE 2: CONDITIONAL DOWN VS UP")
    print("=" * 75)

    directional_mask = df["actual_label"].isin(
        ["DOWN", "UP"]
    )

    directional_df = df.loc[directional_mask].copy()

    # Correct target:
    # 0 = DOWN, 1 = UP.
    stage2_actual = (
            directional_df["actual_label"] == "UP"
    ).astype(int).to_numpy()

    # IMPORTANT:
    # Use p_up_conditional, NOT combined p_up.
    stage2_probability = directional_df[
        "p_up_conditional"
    ].to_numpy(dtype=float)

    stage2_prediction = (
            stage2_probability >= 0.50
    ).astype(int)

    stage2_metrics = {
        "rows": len(directional_df),
        "actual_up_pct": float(
            100 * stage2_actual.mean()
        ),
        "mean_conditional_up_probability_pct": float(
            100 * stage2_probability.mean()
        ),
        "roc_auc": safe_auc(
            stage2_actual,
            stage2_probability,
        ),
        "accuracy_at_050": float(
            accuracy_score(
                stage2_actual,
                stage2_prediction,
            )
        ),
        "balanced_accuracy_at_050": float(
            balanced_accuracy_score(
                stage2_actual,
                stage2_prediction,
            )
        ),
        "up_precision_at_050": float(
            precision_score(
                stage2_actual,
                stage2_prediction,
                zero_division=0,
            )
        ),
        "up_recall_at_050": float(
            recall_score(
                stage2_actual,
                stage2_prediction,
                zero_division=0,
            )
        ),
        "log_loss": safe_logloss(
            stage2_actual,
            stage2_probability,
        ),
        "brier_score": float(
            brier_score_loss(
                stage2_actual,
                stage2_probability,
            )
        ),
        "ece_10_bins": expected_calibration_error(
            stage2_actual,
            stage2_probability,
            bins=10,
        ),
    }

    stage2_distribution = (
        directional_df.groupby("actual_label")[
            "p_up_conditional"
        ]
        .agg(
            rows="count",
            mean="mean",
            median="median",
            p10=lambda s: s.quantile(0.10),
            p25=lambda s: s.quantile(0.25),
            p75=lambda s: s.quantile(0.75),
            p90=lambda s: s.quantile(0.90),
        )
        .reset_index()
    )

    stage2_distribution.to_csv(
        OUTPUT_DIR / "stage2_conditional_probability_by_actual_class.csv",
        index=False,
        )

    # ========================================================
    # 3. FIXED THRESHOLD SENSITIVITY
    # ========================================================

    print("\n" + "=" * 75)
    print("FIXED DECISION POLICY SENSITIVITY")
    print("=" * 75)

    actual = df["actual_label"].to_numpy()
    probability_matrix = make_probability_matrix(df)

    policy_rows = []
    policy_predictions = {}

    for policy_name, policy in POLICIES.items():

        predicted = predict_policy(df, policy)

        policy_predictions[policy_name] = predicted

        metrics = multiclass_metrics(
            actual,
            predicted,
            probability_matrix,
        )

        metrics["policy"] = policy_name
        metrics["directional_threshold"] = policy.get(
            "directional",
            np.nan,
        )
        metrics["conditional_up_threshold"] = policy.get(
            "conditional_up",
            np.nan,
        )

        policy_rows.append(metrics)

    policy_comparison = pd.DataFrame(policy_rows)

    policy_comparison = policy_comparison[
        [
            "policy",
            "directional_threshold",
            "conditional_up_threshold",
            "rows",
            "accuracy",
            "balanced_accuracy",
            "macro_f1",
            "weighted_f1",
            "multiclass_log_loss",
            "actual_directional_pct",
            "predicted_directional_pct",
            "down_precision",
            "down_recall",
            "up_precision",
            "up_recall",
        ]
    ]

    policy_comparison.to_csv(
        OUTPUT_DIR / "fixed_policy_comparison.csv",
        index=False,
        )

    # Save policy confusion matrices.
    confusion_rows = []

    for policy_name, predicted in policy_predictions.items():

        matrix = confusion_matrix(
            actual,
            predicted,
            labels=LABELS,
        )

        matrix_df = pd.DataFrame(
            matrix,
            index=[f"ACTUAL_{x}" for x in LABELS],
            columns=[f"PREDICTED_{x}" for x in LABELS],
        )

        matrix_df.to_csv(
            OUTPUT_DIR / f"confusion_{policy_name}.csv"
        )

        for i, actual_class in enumerate(LABELS):
            for j, predicted_class in enumerate(LABELS):
                confusion_rows.append({
                    "policy": policy_name,
                    "actual_class": actual_class,
                    "predicted_class": predicted_class,
                    "count": int(matrix[i, j]),
                })

    pd.DataFrame(confusion_rows).to_csv(
        OUTPUT_DIR / "all_policy_confusion_matrices.csv",
        index=False,
        )

    # ========================================================
    # 4. MONTHLY POLICY STABILITY
    # ========================================================

    print("\nCalculating monthly policy stability...")

    monthly_rows = []

    for month, group in df.groupby("month"):

        for policy_name, policy in POLICIES.items():

            predicted = predict_policy(group, policy)

            metrics = multiclass_metrics(
                group["actual_label"],
                predicted,
                make_probability_matrix(group),
            )

            metrics.update({
                "month": month,
                "policy": policy_name,
            })

            monthly_rows.append(metrics)

    monthly = pd.DataFrame(monthly_rows)

    monthly.to_csv(
        OUTPUT_DIR / "monthly_policy_stability.csv",
        index=False,
        )

    # ========================================================
    # 5. STAGE 1 MONTHLY PROBABILITY QUALITY
    # ========================================================

    monthly_probability_rows = []

    for month, group in df.groupby("month"):

        y = group["actual_label"].isin(
            ["DOWN", "UP"]
        ).astype(int)

        p = group["p_directional"]

        monthly_probability_rows.append({
            "month": month,
            "rows": len(group),
            "actual_directional_pct": 100 * y.mean(),
            "mean_probability_pct": 100 * p.mean(),
            "roc_auc": safe_auc(y, p),
            "log_loss": safe_logloss(y, p),
            "brier_score": brier_score_loss(y, p),
            "ece_10_bins": expected_calibration_error(
                y,
                p,
                bins=10,
            ),
        })

    pd.DataFrame(monthly_probability_rows).to_csv(
        OUTPUT_DIR / "monthly_stage1_probability_quality.csv",
        index=False,
        )

    # ========================================================
    # 6. STAGE 2 MONTHLY CONDITIONAL QUALITY
    # ========================================================

    monthly_stage2_rows = []

    for month, group in directional_df.groupby("month"):

        y = (
                group["actual_label"] == "UP"
        ).astype(int)

        p = group["p_up_conditional"]

        monthly_stage2_rows.append({
            "month": month,
            "directional_rows": len(group),
            "actual_up_pct": 100 * y.mean(),
            "mean_conditional_up_probability_pct": 100 * p.mean(),
            "roc_auc": safe_auc(y, p),
            "log_loss": safe_logloss(y, p),
            "brier_score": brier_score_loss(y, p),
            "ece_10_bins": expected_calibration_error(
                y,
                p,
                bins=10,
            ),
        })

    pd.DataFrame(monthly_stage2_rows).to_csv(
        OUTPUT_DIR / "monthly_stage2_conditional_quality.csv",
        index=False,
        )

    # ========================================================
    # 7. REGIME POLICY STABILITY
    # ========================================================

    regime_columns = [
        "regime_trend_up",
        "regime_trend_down",
        "regime_trend_range",
        "regime_vol_low",
        "regime_vol_medium",
        "regime_vol_high",
        "regime_vol_contracting",
        "regime_vol_expanding",
        "regime_vol_stable",
    ]

    regime_rows = []

    for column in regime_columns:

        if column not in df.columns:
            continue

        for regime_value, group in df.groupby(
                column,
                dropna=False,
        ):

            if str(regime_value) not in ["1", "1.0", "True"]:
                continue

            for policy_name, policy in POLICIES.items():

                predicted = predict_policy(group, policy)

                metrics = multiclass_metrics(
                    group["actual_label"],
                    predicted,
                    make_probability_matrix(group),
                )

                metrics.update({
                    "regime_feature": column,
                    "regime_value": regime_value,
                    "policy": policy_name,
                })

                regime_rows.append(metrics)

    regime_metrics = pd.DataFrame(regime_rows)

    regime_metrics.to_csv(
        OUTPUT_DIR / "regime_policy_stability.csv",
        index=False,
        )

    # ========================================================
    # 8. REGIME PROBABILITY QUALITY
    # ========================================================

    regime_probability_rows = []

    for column in regime_columns:

        if column not in df.columns:
            continue

        group = df.loc[df[column] == 1].copy()

        if group.empty:
            continue

        directional_actual = (
            group["actual_label"].isin(["DOWN", "UP"])
        ).astype(int)

        regime_probability_rows.append({
            "regime_feature": column,
            "rows": len(group),
            "actual_directional_pct": (
                    100 * directional_actual.mean()
            ),
            "mean_p_directional_pct": (
                    100 * group["p_directional"].mean()
            ),
            "stage1_auc": safe_auc(
                directional_actual,
                group["p_directional"],
            ),
            "stage1_brier": brier_score_loss(
                directional_actual,
                group["p_directional"],
            ),
        })

        directional_group = group.loc[
            group["actual_label"].isin(["DOWN", "UP"])
        ]

        if len(directional_group):
            y_up = (
                    directional_group["actual_label"] == "UP"
            ).astype(int)

            p_up = directional_group["p_up_conditional"]

            regime_probability_rows[-1].update({
                "stage2_directional_rows": len(directional_group),
                "actual_up_pct_conditional": (
                        100 * y_up.mean()
                ),
                "mean_p_up_conditional_pct": (
                        100 * p_up.mean()
                ),
                "stage2_conditional_auc": safe_auc(
                    y_up,
                    p_up,
                ),
                "stage2_conditional_brier": (
                    brier_score_loss(y_up, p_up)
                ),
            })

    pd.DataFrame(regime_probability_rows).to_csv(
        OUTPUT_DIR / "regime_probability_quality.csv",
        index=False,
        )

    # ========================================================
    # 9. SAVE PROBABILITY AUDIT SUMMARY
    # ========================================================

    summary = {
        "generated_at": datetime.now().isoformat(),
        "source_run_id": RUN_ID,
        "source_file": str(INPUT_FILE),
        "rows": int(len(df)),
        "date_start": str(df["timestamp_ist"].min()),
        "date_end": str(df["timestamp_ist"].max()),
        "stage1_metrics": stage1_metrics,
        "stage2_conditional_metrics": stage2_metrics,
        "policies_tested": POLICIES,
        "policy_comparison": policy_comparison.to_dict(
            orient="records"
        ),
        "important_methodology": [
            "Stage 1 evaluates directional versus sideways.",
            "Stage 2 evaluates DOWN versus UP only on actual directional rows.",
            "Stage 2 uses p_up_conditional, not combined p_up.",
            "Combined multiclass probabilities are checked against stage probabilities.",
            "Fixed thresholds are sensitivity diagnostics only.",
            "No best threshold is selected from 2024.",
            "2024 remains a previously used diagnostic period.",
            "No transaction costs or trading profitability are evaluated.",
        ],
    }

    with open(
            OUTPUT_DIR / "probability_audit_summary.json",
            "w",
            encoding="utf-8",
    ) as f:
        json.dump(summary, f, indent=2, default=str)

    # ========================================================
    # CONSOLE OUTPUT
    # ========================================================

    print("\n" + "=" * 75)
    print("STAGE 1 PROBABILITY METRICS")
    print("=" * 75)
    print(json.dumps(stage1_metrics, indent=2))

    print("\n" + "=" * 75)
    print("STAGE 2 CONDITIONAL PROBABILITY METRICS - CORRECTED")
    print("=" * 75)
    print(json.dumps(stage2_metrics, indent=2))

    print("\n" + "=" * 75)
    print("FIXED POLICY COMPARISON")
    print("=" * 75)
    print(policy_comparison.to_string(index=False))

    print("\n" + "=" * 75)
    print("OUTPUT")
    print("=" * 75)
    print(OUTPUT_DIR)

    print("\nGenerated files:")
    for path in sorted(OUTPUT_DIR.iterdir()):
        print(" ", path.name)

    print("\nAudit completed successfully.")


if __name__ == "__main__":
    main()
