
from pathlib import Path
import duckdb
import csv
import re

ROOT = Path(__file__).resolve().parents[1]

INPUT_DIR = ROOT / "data" / "training" / "supervised"
OUTPUT_DIR = ROOT / "data" / "training" / "model_splits"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

DATASETS = [
    ("nifty", "5m"),
    ("nifty", "15m"),
    ("nifty", "30m"),
    ("banknifty", "5m"),
    ("banknifty", "15m"),
    ("banknifty", "30m"),
]

# Chronological, non-random split.
def assign_split(year):
    if 2021 <= year <= 2023:
        return "train"
    if year == 2024:
        return "validation"
    if year == 2025:
        return "test"
    if year >= 2026:
        return "recent_holdout"
    return "exclude"


# Columns that must never be used as model inputs.
EXACT_EXCLUSIONS = {
    "timestamp",
    "trading_day",
    "symbol",
    "future_return_5m",
    "future_return_15m",
    "future_return_30m",
    "label_valid_5m",
    "label_valid_15m",
    "label_valid_30m",
}

# Also exclude any target/label-derived columns.
TARGET_PATTERN = re.compile(
    r"(^target_|^label_|future_return|future_|"
    r"target_class|target_z|target_sigma|target_return)",
    re.IGNORECASE
)

con = duckdb.connect()

summary_rows = []
feature_rows = []

for index_name, horizon in DATASETS:
    name = f"{index_name}_{horizon}"
    path = INPUT_DIR / f"{name}_supervised.parquet"

    print("\n" + "=" * 75)
    print(f"INSPECTING {name.upper()}")
    print("=" * 75)

    if not path.exists():
        raise FileNotFoundError(path)

    schema = con.execute(
        "DESCRIBE SELECT * FROM read_parquet(?)",
        [str(path)]
    ).fetchall()

    columns = [row[0] for row in schema]

    # Discover the target class column from the actual schema.
    class_candidates = [
        c for c in columns
        if c.lower() in {
            "target_class",
            "target_class_05",
            "target_class_050",
            "class_label",
        }
    ]

    if not class_candidates:
        class_candidates = [
            c for c in columns
            if "class" in c.lower()
               and not TARGET_PATTERN.search(c)
        ]

    if not class_candidates:
        raise RuntimeError(
            f"{name}: Could not identify the target class column. "
            f"Columns: {columns}"
        )

    class_column = class_candidates[0]

    # Safe feature list: numeric fields only, excluding identifiers
    # and every target/label-derived field.
    numeric_types = {
        "DOUBLE", "FLOAT", "REAL",
        "INTEGER", "BIGINT", "SMALLINT",
        "TINYINT", "DECIMAL",
        "HUGEINT", "UBIGINT", "UINTEGER",
    }

    safe_features = []

    for column, dtype, *_ in schema:
        normalized_type = dtype.upper().split("(")[0]

        if column in EXACT_EXCLUSIONS:
            continue

        if TARGET_PATTERN.search(column):
            continue

        if normalized_type not in numeric_types:
            continue

        safe_features.append(column)

    if not safe_features:
        raise RuntimeError(f"{name}: No safe numeric features found.")

    # Ensure class column is not accidentally used as a feature.
    safe_features = [
        c for c in safe_features if c != class_column
    ]

    # Inspect date range and class distribution.
    date_stats = con.execute(
        """
        SELECT
            MIN(trading_day),
            MAX(trading_day),
            COUNT(*),
            COUNT(DISTINCT trading_day)
        FROM read_parquet(?)
        """,
        [str(path)]
    ).fetchone()

    print("Date range:", date_stats[0], "to", date_stats[1])
    print("Rows:", f"{date_stats[2]:,}")
    print("Trading days:", f"{date_stats[3]:,}")
    print("Target class:", class_column)
    print("Safe numeric features:", len(safe_features))

    # Build daily split manifest.
    daily = con.execute(
        """
        SELECT
            trading_day,
            YEAR(trading_day) AS year,
            COUNT(*) AS observations
        FROM read_parquet(?)
        GROUP BY trading_day
        ORDER BY trading_day
        """,
        [str(path)]
    ).fetchall()

    manifest_path = OUTPUT_DIR / f"{name}_split_manifest.csv"

    with open(manifest_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow([
            "trading_day", "year", "split", "observations"
        ])

        for trading_day, year, observations in daily:
            writer.writerow([
                trading_day,
                year,
                assign_split(year),
                observations
            ])

    # Store feature manifest.
    for feature in safe_features:
        dtype = next(row[1] for row in schema if row[0] == feature)
        feature_rows.append([
            name, feature, dtype, "MODEL_INPUT"
        ])

    # Split row counts.
    split_counts = con.execute(
        """
        SELECT
            YEAR(trading_day) AS year,
            COUNT(*) AS rows
        FROM read_parquet(?)
        GROUP BY year
        ORDER BY year
        """,
        [str(path)]
    ).fetchall()

    counts = {
        "train": 0,
        "validation": 0,
        "test": 0,
        "recent_holdout": 0,
        "exclude": 0,
    }

    for year, rows in split_counts:
        counts[assign_split(year)] += rows

    summary_rows.append([
        name,
        date_stats[2],
        date_stats[3],
        len(safe_features),
        class_column,
        counts["train"],
        counts["validation"],
        counts["test"],
        counts["recent_holdout"],
        counts["exclude"],
    ])

    print("Split rows:", counts)
    print("Manifest:", manifest_path)

# Write combined reports.
with open(
        OUTPUT_DIR / "split_summary.csv",
        "w",
        newline="",
        encoding="utf-8"
) as f:
    writer = csv.writer(f)
    writer.writerow([
        "dataset", "total_rows", "trading_days",
        "feature_count", "class_column",
        "train_rows", "validation_rows",
        "test_rows", "recent_holdout_rows",
        "excluded_rows"
    ])
    writer.writerows(summary_rows)

with open(
        OUTPUT_DIR / "feature_manifest.csv",
        "w",
        newline="",
        encoding="utf-8"
) as f:
    writer = csv.writer(f)
    writer.writerow([
        "dataset", "feature", "data_type", "role"
    ])
    writer.writerows(feature_rows)

con.close()

print("\n" + "=" * 75)
print("MODEL SPLIT PREPARATION COMPLETED")
print("Output:", OUTPUT_DIR)
print("=" * 75)
