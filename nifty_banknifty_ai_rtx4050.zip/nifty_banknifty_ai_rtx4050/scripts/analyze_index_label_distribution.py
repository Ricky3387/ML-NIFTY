
from pathlib import Path
import duckdb
import pandas as pd

# ------------------------------------------------------------
# Configuration
# ------------------------------------------------------------

ROOT = Path(__file__).resolve().parents[1]

INPUT_DIR = ROOT / "data" / "training" / "index_features"
OUTPUT_DIR = ROOT / "data" / "training" / "label_analysis"

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

DATABASE = ROOT / "data" / "database" / "nifty_options.duckdb"

INDEX_FILES = {
    "NIFTY": INPUT_DIR / "nifty_index_features.parquet",
    "BANKNIFTY": INPUT_DIR / "banknifty_index_features.parquet",
}

HORIZONS = [5, 15, 30]

# Decimal returns:
# 0.0002 = 0.02%
# 0.0010 = 0.10%
SIDEWAYS_BANDS = [
    0.0002,
    0.0005,
    0.0010,
    0.0015,
    0.0020,
    0.0030,
]

PERCENTILES = [
    0.01, 0.05, 0.10, 0.25, 0.50,
    0.75, 0.90, 0.95, 0.99
]

# ------------------------------------------------------------
# DuckDB setup
# ------------------------------------------------------------

con = duckdb.connect(str(DATABASE))

con.execute("SET TimeZone = 'Asia/Calcutta'")
con.execute("SET memory_limit = '4GB'")
con.execute("SET threads = 4")

# ------------------------------------------------------------
# Helpers
# ------------------------------------------------------------

def sql_path(path: Path) -> str:
    return str(path.resolve()).replace("\\", "/").replace("'", "''")


def percentile_sql(column: str) -> str:
    expressions = []

    for p in PERCENTILES:
        label = f"p{int(p * 100):02d}"
        expressions.append(
            f"quantile_cont({column}, {p}) AS {label}"
        )

    return ",\n".join(expressions)


def analyze_index(index_name: str, parquet_path: Path):
    print("\n" + "=" * 85)
    print(f"ANALYSING {index_name}")
    print("=" * 85)

    if not parquet_path.exists():
        raise FileNotFoundError(
            f"Feature dataset not found: {parquet_path}"
        )

    view_name = f"{index_name.lower()}_features_analysis"

    con.execute(f"""
        CREATE OR REPLACE VIEW {view_name} AS
        SELECT *
        FROM read_parquet('{sql_path(parquet_path)}')
    """)

    available_columns = {
        row[0]
        for row in con.execute(
            f"DESCRIBE SELECT * FROM {view_name}"
        ).fetchall()
    }

    # Check required fields.
    for horizon in HORIZONS:
        col = f"future_return_{horizon}m"

        if col not in available_columns:
            raise ValueError(
                f"Required column '{col}' missing in {index_name}"
            )

    if "trading_day" not in available_columns:
        raise ValueError("trading_day column missing")

    # --------------------------------------------------------
    # 1. Overall signed and absolute return percentiles
    # --------------------------------------------------------

    percentile_rows = []

    for horizon in HORIZONS:
        col = f"future_return_{horizon}m"

        query = f"""
            SELECT
                '{index_name}' AS index_name,
                {horizon} AS horizon_minutes,
                COUNT({col}) AS valid_rows,
                AVG({col}) AS average_return,
                STDDEV_SAMP({col}) AS std_return,
                MIN({col}) AS minimum_return,
                MAX({col}) AS maximum_return,
                {percentile_sql(col)}
            FROM {view_name}
            WHERE {col} IS NOT NULL
        """

        signed = con.execute(query).fetchdf()

        absolute_query = f"""
            SELECT
                {percentile_sql(f'ABS({col})')}
            FROM {view_name}
            WHERE {col} IS NOT NULL
        """

        absolute = con.execute(absolute_query).fetchdf()

        for p in PERCENTILES:
            label = f"p{int(p * 100):02d}"
            signed[f"abs_{label}"] = absolute.iloc[0][label]

        percentile_rows.append(signed)

    percentile_df = pd.concat(
        percentile_rows,
        ignore_index=True
    )

    # Convert returns to percentage units for easier interpretation.
    return_columns = [
        c for c in percentile_df.columns
        if c in (
            "average_return",
            "std_return",
            "minimum_return",
            "maximum_return",
        )
           or c.startswith("p")
           or c.startswith("abs_p")
    ]

    percentile_df[return_columns] *= 100

    percentile_file = (
            OUTPUT_DIR / f"{index_name.lower()}_return_percentiles.csv"
    )

    percentile_df.to_csv(percentile_file, index=False)

    # --------------------------------------------------------
    # 2. Sideways-band distribution
    # --------------------------------------------------------

    band_rows = []

    for horizon in HORIZONS:
        col = f"future_return_{horizon}m"

        for band in SIDEWAYS_BANDS:
            result = con.execute(f"""
                SELECT
                    COUNT(*) AS valid_rows,

                    COUNT(*) FILTER (
                        WHERE ABS({col}) <= {band}
                    ) AS sideways_rows,

                    COUNT(*) FILTER (
                        WHERE {col} > {band}
                    ) AS up_rows,

                    COUNT(*) FILTER (
                        WHERE {col} < -{band}
                    ) AS down_rows,

                    COUNT(*) FILTER (
                        WHERE {col} IS NOT NULL
                    ) AS total_rows

                FROM {view_name}
                WHERE {col} IS NOT NULL
            """).fetchdf().iloc[0]

            total = int(result["total_rows"])
            sideways = int(result["sideways_rows"])
            up = int(result["up_rows"])
            down = int(result["down_rows"])

            band_rows.append({
                "index_name": index_name,
                "horizon_minutes": horizon,
                "sideways_band_pct": band * 100,
                "total_rows": total,
                "sideways_rows": sideways,
                "up_rows": up,
                "down_rows": down,
                "sideways_pct": sideways / total * 100,
                "up_pct": up / total * 100,
                "down_pct": down / total * 100,
            })

    band_df = pd.DataFrame(band_rows)

    band_file = (
            OUTPUT_DIR / f"{index_name.lower()}_sideways_bands.csv"
    )

    band_df.to_csv(band_file, index=False)

    # --------------------------------------------------------
    # 3. Year-wise return distribution
    # --------------------------------------------------------

    yearly_rows = []

    for horizon in HORIZONS:
        col = f"future_return_{horizon}m"

        query = f"""
            SELECT
                '{index_name}' AS index_name,
                {horizon} AS horizon_minutes,
                YEAR(CAST(trading_day AS DATE)) AS year,
                COUNT({col}) AS valid_rows,
                AVG({col}) AS average_return,
                STDDEV_SAMP({col}) AS std_return,
                quantile_cont({col}, 0.05) AS p05,
                quantile_cont({col}, 0.25) AS p25,
                quantile_cont({col}, 0.50) AS p50,
                quantile_cont({col}, 0.75) AS p75,
                quantile_cont({col}, 0.95) AS p95,
                quantile_cont(ABS({col}), 0.50) AS abs_median,
                quantile_cont(ABS({col}), 0.90) AS abs_p90
            FROM {view_name}
            WHERE {col} IS NOT NULL
            GROUP BY YEAR(CAST(trading_day AS DATE))
            ORDER BY year
        """

        yearly_rows.append(con.execute(query).fetchdf())

    yearly_df = pd.concat(
        yearly_rows,
        ignore_index=True
    )

    yearly_return_columns = [
        "average_return", "std_return",
        "p05", "p25", "p50", "p75", "p95",
        "abs_median", "abs_p90"
    ]

    yearly_df[yearly_return_columns] *= 100

    yearly_file = (
            OUTPUT_DIR / f"{index_name.lower()}_yearly_distribution.csv"
    )

    yearly_df.to_csv(yearly_file, index=False)

    # --------------------------------------------------------
    # 4. Basic data-quality checks
    # --------------------------------------------------------

    quality_rows = []

    for horizon in HORIZONS:
        col = f"future_return_{horizon}m"

        quality = con.execute(f"""
            SELECT
                '{index_name}' AS index_name,
                {horizon} AS horizon_minutes,
                COUNT(*) AS total_rows,
                COUNT({col}) AS valid_labels,
                COUNT(*) - COUNT({col}) AS missing_labels,
                COUNT(*) FILTER (
                    WHERE {col} IS NOT NULL
                      AND NOT ISFINITE({col})
                ) AS non_finite_labels
            FROM {view_name}
        """).fetchdf()

        quality_rows.append(quality)

    quality_df = pd.concat(
        quality_rows,
        ignore_index=True
    )

    quality_file = (
            OUTPUT_DIR / f"{index_name.lower()}_label_quality.csv"
    )

    quality_df.to_csv(quality_file, index=False)

    # --------------------------------------------------------
    # Console summary
    # --------------------------------------------------------

    print("\nRETURN PERCENTILES (%)")
    print(
        percentile_df[
            [
                "horizon_minutes",
                "valid_rows",
                "average_return",
                "std_return",
                "p01",
                "p05",
                "p25",
                "p50",
                "p75",
                "p95",
                "p99",
                "abs_p50",
                "abs_p90",
                "abs_p99",
            ]
        ].to_string(index=False)
    )

    print("\nSIDEWAYS BAND DISTRIBUTION (%)")
    print(
        band_df[
            [
                "horizon_minutes",
                "sideways_band_pct",
                "sideways_pct",
                "up_pct",
                "down_pct",
            ]
        ].to_string(index=False)
    )

    print("\nYEARLY DISTRIBUTION (%)")
    print(yearly_df.to_string(index=False))

    print("\nLABEL QUALITY")
    print(quality_df.to_string(index=False))

    print("\nGenerated reports:")
    print(percentile_file)
    print(band_file)
    print(yearly_file)
    print(quality_file)


# ------------------------------------------------------------
# Main
# ------------------------------------------------------------

try:
    for index_name, parquet_path in INDEX_FILES.items():
        analyze_index(index_name, parquet_path)

    print("\n" + "=" * 85)
    print("INDEX LABEL DISTRIBUTION ANALYSIS COMPLETED")
    print("=" * 85)

finally:
    con.close()
