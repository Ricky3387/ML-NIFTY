
from pathlib import Path
import duckdb

BASE = Path(__file__).resolve().parent.parent

DB = BASE / "data" / "database" / "nifty_options.duckdb"

con = duckdb.connect(str(DB), read_only=True)

try:
    print("\nAvailable views:")

    print(
        con.execute("SHOW TABLES").fetchdf()
    )

    print("\nBANKNIFTY options sample:")

    print(
        con.execute("""
                    SELECT
                        timestamp,
                        symbol,
                        expiry,
                        strike,
                        option_type,
                        close,
                        volume,
                        open_interest
                    FROM banknifty_options
                        LIMIT 10
                    """).fetchdf()
    )

    print("\nNIFTY options sample:")

    print(
        con.execute("""
                    SELECT *
                    FROM nifty_options
                             LIMIT 5
                    """).fetchdf()
    )

finally:
    con.close()
