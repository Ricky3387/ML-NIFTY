#!/usr/bin/env python3
"""
NIFTY target-label audit v2.

Save under <project_root>/scripts/
Run from project root:
    python scripts/audit_nifty_target_labels_v2.py

Reads:
  data/processed/nifty_features_v1/nifty_features_labels_long.parquet
  data/processed/nifty_index_cleaned/nifty_index_cleaned_final.parquet

Writes:
  reports/nifty_label_audit_v2/
    forward_return_distribution.csv
    zscore_distribution.csv
    class_distribution_by_year.csv
    class_distribution_by_volatility.csv
    threshold_sensitivity.csv
    atr_normalized_threshold_sensitivity.csv
    directional_persistence.csv
    cross_horizon_label_agreement.csv
    label_transition_rates.csv
    audit_summary.json

Research-only: does not select a winning target, retrain models, or modify input data.
"""
from pathlib import Path
import json
import time
import logging
import numpy as np
import pandas as pd

START = time.time()
HORIZONS = (5, 15, 30)
Z_THRESHOLDS = (0.50, 0.75, 1.00, 1.25)
ATR_THRESHOLDS = (0.25, 0.50, 0.75)
CLASSES = ["DOWN", "SIDEWAYS", "UP"]

def classify(values, threshold):
    return np.select(
        [values <= -threshold, values >= threshold],
        ["DOWN", "UP"],
        default="SIDEWAYS"
    )

def pct(series):
    return series.value_counts(normalize=True, dropna=False).mul(100)

def main():
    script_dir = Path(__file__).resolve().parent
    root = script_dir.parent if script_dir.name.lower() == "scripts" else script_dir
    feature_path = root / "data" / "processed" / "nifty_features_v1" / "nifty_features_labels_long.parquet"
    clean_path = root / "data" / "processed" / "nifty_index_cleaned" / "nifty_index_cleaned_final.parquet"
    out = root / "reports" / "nifty_label_audit_v2"
    out.mkdir(parents=True, exist_ok=True)

    logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(message)s")
    log = logging.getLogger("nifty_label_audit")
    for p in (feature_path, clean_path):
        if not p.exists():
            raise FileNotFoundError(f"Required input missing: {p}")

    log.info("Loading feature/label dataset")
    features = pd.read_parquet(feature_path)
    needed = {
        "timestamp_ist", "trading_day", "horizon_minutes", "close",
        "future_close", "forward_return", "target_vol_scale", "target_z",
        "label", "sample_eligible", "realized_vol_60m"
    }
    missing = needed - set(features.columns)
    if missing:
        raise RuntimeError(f"Feature Parquet missing required fields: {sorted(missing)}")

    features["timestamp_ist"] = pd.to_datetime(features["timestamp_ist"])
    features["trading_day"] = pd.to_datetime(features["trading_day"]).dt.strftime("%Y-%m-%d")
    features["horizon_minutes"] = features["horizon_minutes"].astype(int)
    features = features[features["horizon_minutes"].isin(HORIZONS)].copy()
    features["year"] = pd.to_datetime(features["trading_day"]).dt.year

    # Preserve all eligible rows as the primary population; separately report
    # overall generated rows where helpful. No class balancing or resampling.
    eligible = features[features["sample_eligible"].astype(bool)].copy()
    if eligible.empty:
        raise RuntimeError("No eligible feature/label rows found.")

    log.info("Calculating ATR(14) from cleaned one-minute OHLC")
    bars = pd.read_parquet(clean_path, columns=[
        "timestamp_ist", "trading_day", "high", "low", "close", "is_synthetic"
    ])
    bars["timestamp_ist"] = pd.to_datetime(bars["timestamp_ist"])
    bars["trading_day"] = pd.to_datetime(bars["trading_day"]).dt.strftime("%Y-%m-%d")
    bars = bars.sort_values(["trading_day", "timestamp_ist"]).reset_index(drop=True)
    bars["prev_close"] = bars.groupby("trading_day", sort=False)["close"].shift(1)
    tr_components = pd.concat([
        (bars["high"] - bars["low"]).rename("hl"),
        (bars["high"] - bars["prev_close"]).abs().rename("hc"),
        (bars["low"] - bars["prev_close"]).abs().rename("lc")
    ], axis=1)
    bars["true_range"] = tr_components.max(axis=1)
    bars["atr14"] = bars.groupby("trading_day", sort=False)["true_range"].transform(
        lambda s: s.rolling(14, min_periods=14).mean()
    )
    bars["atr14_pct"] = bars["atr14"] / bars["close"]
    atr = bars[["timestamp_ist", "atr14", "atr14_pct", "is_synthetic"]].rename(
        columns={"is_synthetic": "source_bar_synthetic"}
    )
    eligible = eligible.merge(atr, on="timestamp_ist", how="left", validate="many_to_one")
    eligible["atr_normalized_move"] = (
        eligible["future_close"] - eligible["close"]
    ) / eligible["atr14"]

    if eligible["atr14"].isna().any():
        n = int(eligible["atr14"].isna().sum())
        raise RuntimeError(f"{n} eligible rows have no ATR14 value; inspect input alignment.")

    log.info("Building return and z-score distribution reports")
    dist_rows = []
    for h, g in eligible.groupby("horizon_minutes"):
        for metric in ("forward_return", "target_z", "atr_normalized_move"):
            s = g[metric].replace([np.inf, -np.inf], np.nan).dropna()
            q = s.quantile([0.001, 0.01, 0.05, 0.10, 0.25, 0.50, 0.75, 0.90, 0.95, 0.99, 0.999])
            row = {"horizon_minutes": int(h), "metric": metric,
                   "count": int(s.size), "mean": float(s.mean()), "std": float(s.std()),
                   "min": float(s.min()), "max": float(s.max())}
            for quantile, value in q.items():
                row[f"p{quantile * 100:g}"] = float(value)
            dist_rows.append(row)
    pd.DataFrame(dist_rows).to_csv(out / "forward_return_distribution.csv", index=False)

    # Z distribution gets its own compact table, including absolute-z percentiles.
    zrows = []
    for h, g in eligible.groupby("horizon_minutes"):
        z = g["target_z"].abs()
        zrows.append({
            "horizon_minutes": int(h),
            "abs_z_p50": float(z.quantile(.50)),
            "abs_z_p75": float(z.quantile(.75)),
            "abs_z_p90": float(z.quantile(.90)),
            "abs_z_p95": float(z.quantile(.95)),
            "abs_z_p99": float(z.quantile(.99)),
            "positive_z_pct": float((g["target_z"] > 0).mean() * 100),
            "negative_z_pct": float((g["target_z"] < 0).mean() * 100)
        })
    pd.DataFrame(zrows).to_csv(out / "zscore_distribution.csv", index=False)

    log.info("Testing z-score threshold sensitivity")
    sens = []
    for h, g in eligible.groupby("horizon_minutes"):
        for threshold in Z_THRESHOLDS:
            labels = classify(g["target_z"].to_numpy(), threshold)
            counts = pd.Series(labels).value_counts()
            total = len(labels)
            sens.append({
                "horizon_minutes": int(h), "threshold_abs_z": threshold,
                **{f"{c.lower()}_count": int(counts.get(c, 0)) for c in CLASSES},
                **{f"{c.lower()}_pct": float(counts.get(c, 0) / total * 100) for c in CLASSES}
            })
    pd.DataFrame(sens).to_csv(out / "threshold_sensitivity.csv", index=False)

    log.info("Testing ATR-normalized target thresholds")
    atr_sens = []
    for h, g in eligible.groupby("horizon_minutes"):
        for threshold in ATR_THRESHOLDS:
            labels = classify(g["atr_normalized_move"].to_numpy(), threshold)
            counts = pd.Series(labels).value_counts()
            total = len(labels)
            atr_sens.append({
                "horizon_minutes": int(h), "threshold_atr": threshold,
                **{f"{c.lower()}_count": int(counts.get(c, 0)) for c in CLASSES},
                **{f"{c.lower()}_pct": float(counts.get(c, 0) / total * 100) for c in CLASSES}
            })
    pd.DataFrame(atr_sens).to_csv(out / "atr_normalized_threshold_sensitivity.csv", index=False)

    log.info("Measuring year and volatility regime label stability")
    year_rows, vol_rows = [], []
    for h, g in eligible.groupby("horizon_minutes"):
        for (year, label), n in g.groupby(["year", "label"]).size().items():
            total = int((g["year"] == year).sum())
            year_rows.append({
                "horizon_minutes": int(h), "year": int(year), "class": label,
                "samples": int(n), "percentage": float(n / total * 100)
            })
        # Use train-period volatility terciles only to define stable regimes.
        train_vol = g.loc[g["year"] <= 2023, "realized_vol_60m"].dropna()
        q1, q2 = train_vol.quantile([1/3, 2/3]).tolist()
        regime = pd.cut(
            g["realized_vol_60m"],
            bins=[-np.inf, q1, q2, np.inf],
            labels=["LOW", "MEDIUM", "HIGH"],
            include_lowest=True
        )
        temp = g.assign(volatility_regime=regime)
        for (bucket, label), n in temp.groupby(["volatility_regime", "label"], observed=False).size().items():
            total = int((temp["volatility_regime"] == bucket).sum())
            vol_rows.append({
                "horizon_minutes": int(h), "volatility_regime": str(bucket),
                "class": label, "samples": int(n),
                "percentage": float(n / total * 100) if total else 0,
                "train_tercile_q1": float(q1), "train_tercile_q2": float(q2)
            })
    pd.DataFrame(year_rows).to_csv(out / "class_distribution_by_year.csv", index=False)
    pd.DataFrame(vol_rows).to_csv(out / "class_distribution_by_volatility.csv", index=False)

    log.info("Measuring directional persistence and label transitions")
    persistence_rows, transition_rows = [], []
    for h, g in eligible.groupby("horizon_minutes"):
        g = g.sort_values(["trading_day", "timestamp_ist"]).copy()
        g["next_minute_label"] = g.groupby("trading_day", sort=False)["label"].shift(-1)
        g["next_horizon_label"] = g.groupby("trading_day", sort=False)["label"].shift(-h)
        for offset_name, col in (("next_minute", "next_minute_label"), ("next_horizon", "next_horizon_label")):
            valid = g[g[col].notna()]
            persistence_rows.append({
                "horizon_minutes": int(h), "comparison": offset_name,
                "compared_samples": int(len(valid)),
                "same_label_pct": float((valid["label"] == valid[col]).mean() * 100) if len(valid) else None,
                "directional_to_directional_pct": float(
                    valid.loc[valid["label"].isin(["DOWN", "UP"]), col].isin(["DOWN", "UP"]).mean() * 100
                ) if valid["label"].isin(["DOWN", "UP"]).any() else None
            })
        trans = g[g["next_minute_label"].notna()].groupby(
            ["label", "next_minute_label"]
        ).size()
        for (a, b), n in trans.items():
            transition_rows.append({
                "horizon_minutes": int(h), "from_label": a,
                "to_next_minute_label": b, "transitions": int(n)
            })
    pd.DataFrame(persistence_rows).to_csv(out / "directional_persistence.csv", index=False)
    pd.DataFrame(transition_rows).to_csv(out / "label_transition_rates.csv", index=False)

    log.info("Measuring cross-horizon label agreement")
    wide = eligible.pivot_table(
        index=["timestamp_ist", "trading_day"], columns="horizon_minutes",
        values="label", aggfunc="first"
    ).dropna()
    agreement = {
        "common_timestamp_count": int(len(wide)),
        "agreement_5m_15m_pct": float((wide[5] == wide[15]).mean() * 100) if len(wide) else None,
        "agreement_5m_30m_pct": float((wide[5] == wide[30]).mean() * 100) if len(wide) else None,
        "agreement_15m_30m_pct": float((wide[15] == wide[30]).mean() * 100) if len(wide) else None,
        "all_three_agree_pct": float(((wide[5] == wide[15]) & (wide[15] == wide[30])).mean() * 100) if len(wide) else None
    }
    pd.DataFrame([agreement]).to_csv(out / "cross_horizon_label_agreement.csv", index=False)

    # Summary only: no automatic threshold selection.
    summary = {
        "status": "LABEL_AUDIT_COMPLETED_REVIEW_REQUIRED",
        "feature_rows": int(len(features)),
        "eligible_rows": int(len(eligible)),
        "eligible_rows_by_horizon": {
            str(int(h)): int(len(g)) for h, g in eligible.groupby("horizon_minutes")
        },
        "z_thresholds_tested": list(Z_THRESHOLDS),
        "atr_thresholds_tested": list(ATR_THRESHOLDS),
        "atr_definition": "14-bar simple moving average of true range, calculated within each trading day",
        "atr_target": "(future_close - current_close) / ATR14",
        "cross_horizon_agreement": agreement,
        "important_caveats": [
            "Threshold tables are descriptive experiments, not a threshold selection result.",
            "ATR values are calculated from cleaned one-minute OHLC; no volume feature is used.",
            "Adjacent horizon labels overlap heavily in time; persistence is descriptive and not independent evidence.",
            "Current eligible population follows the existing v1 sample_eligible guard.",
            "2024 must not be used repeatedly to optimize and claim unbiased final performance."
        ],
        "elapsed_seconds": round(time.time() - START, 2)
    }
    (out / "audit_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))
    print(f"REPORTS: {out}")

if __name__ == "__main__":
    main()
