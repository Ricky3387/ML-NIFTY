
from pathlib import Path
from datetime import datetime
import json
import time
import warnings

import joblib
import lightgbm as lgb
import numpy as np
import pandas as pd

from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    classification_report,
    f1_score,
    precision_score,
    recall_score,
    confusion_matrix,
    roc_auc_score,
    brier_score_loss,
    log_loss,
)

warnings.filterwarnings("ignore", category=UserWarning)

# ============================================================
# CONFIGURATION
# ============================================================

ROOT = Path(__file__).resolve().parents[1]

DATA_DIR = ROOT / "data" / "processed" / "nifty_walkforward_v1"
TRAIN_FILE = DATA_DIR / "train_5m.parquet"
VALIDATION_FILE = DATA_DIR / "validation_5m.parquet"

MODEL_ROOT = ROOT / "models" / "nifty_calibrated_threshold_transfer_v2"
REPORT_ROOT = ROOT / "reports" / "nifty_calibrated_threshold_transfer_v2"

STAGE1_ITERATIONS = 57
STAGE2_ITERATIONS = 47

SEED = 42
EPS = 1e-6

# Existing raw policy thresholds.
OLD_DIRECTIONAL_THRESHOLD = 0.600
OLD_CONDITIONAL_UP_THRESHOLD = 0.525

# Candidate thresholds selected only on Jul-Dec 2023.
DIRECTIONAL_THRESHOLDS = np.round(
    np.arange(0.35, 0.701, 0.025), 3
)

CONDITIONAL_UP_THRESHOLDS = np.round(
    np.arange(0.40, 0.601, 0.025), 3
)

LABELS = ["DOWN", "SIDEWAYS", "UP"]

FEATURES = [
    "ret_1m",
    "logret_1m",
    "range_pct",
    "body_pct",
    "upper_wick_pct",
    "lower_wick_pct",
    "return_5m",
    "return_15m",
    "return_30m",
    "return_60m",
    "realized_vol_5m",
    "realized_vol_15m",
    "realized_vol_30m",
    "realized_vol_60m",
    "high_low_range_5m",
    "high_low_range_15m",
    "high_low_range_30m",
    "high_low_range_60m",
    "close_vs_ema9_pct",
    "close_vs_ema21_pct",
    "close_vs_ema50_pct",
    "rsi_14",
    "positive_return_count_5m",
    "negative_return_count_5m",
    "target_vol_scale",
]


# ============================================================
# DIRECTORIES AND DATA
# ============================================================

def create_directories():
    run_id = datetime.now().strftime("%Y%m%d_%H%M%S")

    model_dir = MODEL_ROOT / run_id
    report_dir = REPORT_ROOT / run_id

    model_dir.mkdir(parents=True, exist_ok=False)
    report_dir.mkdir(parents=True, exist_ok=False)

    return run_id, model_dir, report_dir


def load_data(path, name):
    if not path.exists():
        raise FileNotFoundError(
            f"Missing {name} file: {path}"
        )

    df = pd.read_parquet(path)

    required = FEATURES + [
        "timestamp_ist",
        "trading_day",
        "label",
        "sample_eligible",
    ]

    missing = sorted(set(required) - set(df.columns))

    if missing:
        raise ValueError(
            f"{name} missing columns: {missing}"
        )

    df["trading_day"] = pd.to_datetime(
        df["trading_day"]
    ).dt.date

    df["label"] = (
        df["label"].astype(str).str.upper()
    )

    df = df.loc[
        df["sample_eligible"].astype(bool)
        & df["label"].isin(LABELS)
        ].copy()

    for col in FEATURES:
        df[col] = pd.to_numeric(
            df[col], errors="coerce"
        )

    finite = np.isfinite(
        df[FEATURES].to_numpy(dtype=np.float64)
    ).all(axis=1)

    if not finite.all():
        raise ValueError(
            f"{name} contains {int((~finite).sum())} "
            "rows with non-finite features."
        )

    if df["timestamp_ist"].duplicated().any():
        raise ValueError(
            f"{name} contains duplicate timestamps."
        )

    return df.sort_values(
        "timestamp_ist"
    ).reset_index(drop=True)


# ============================================================
# TWO-STAGE MODEL
# ============================================================

def make_model(iterations):
    return lgb.LGBMClassifier(
        objective="binary",
        n_estimators=int(iterations),
        learning_rate=0.025,
        num_leaves=31,
        max_depth=-1,
        min_child_samples=100,
        subsample=0.8,
        subsample_freq=1,
        colsample_bytree=0.8,
        reg_lambda=2.0,
        random_state=SEED,
        n_jobs=-1,
        verbosity=-1,
    )


def fit_two_stage(train_df, description):
    x = train_df[FEATURES]

    # Stage 1: directional vs sideways.
    y1 = (
            train_df["label"] != "SIDEWAYS"
    ).astype(int)

    if y1.nunique() != 2:
        raise ValueError(
            f"{description}: Stage 1 requires both classes."
        )

    stage1 = make_model(STAGE1_ITERATIONS)
    stage1.fit(x, y1)

    # Stage 2: UP vs DOWN, directional observations only.
    directional = train_df[
        train_df["label"].isin(["DOWN", "UP"])
    ]

    y2 = (
            directional["label"] == "UP"
    ).astype(int)

    if y2.nunique() != 2:
        raise ValueError(
            f"{description}: Stage 2 requires both classes."
        )

    stage2 = make_model(STAGE2_ITERATIONS)
    stage2.fit(
        directional[FEATURES],
        y2,
    )

    print(
        f"{description}: "
        f"Stage 1 rows={len(train_df):,}; "
        f"Stage 2 rows={len(directional):,}"
    )

    return stage1, stage2


def predict_probabilities(stage1, stage2, df):
    x = df[FEATURES]

    p_directional = stage1.predict_proba(x)[:, 1]
    p_up_conditional = stage2.predict_proba(x)[:, 1]

    return pd.DataFrame({
        "timestamp_ist": df["timestamp_ist"].to_numpy(),
        "trading_day": df["trading_day"].to_numpy(),
        "actual_label": df["label"].to_numpy(),
        "p_directional_raw": p_directional,
        "p_up_conditional_raw": p_up_conditional,
    })


# ============================================================
# PLATT CALIBRATION
# ============================================================

def to_logit(probability):
    p = np.clip(
        np.asarray(probability, dtype=float),
        EPS,
        1.0 - EPS,
        )

    return np.log(
        p / (1.0 - p)
    ).reshape(-1, 1)


def fit_platt(probability, actual, name):
    actual = np.asarray(actual, dtype=int)

    if len(np.unique(actual)) != 2:
        raise ValueError(
            f"{name}: calibration sample needs both classes."
        )

    calibrator = LogisticRegression(
        C=1.0,
        solver="lbfgs",
        max_iter=2000,
        random_state=SEED,
    )

    calibrator.fit(
        to_logit(probability),
        actual,
    )

    return calibrator


def apply_platt(calibrator, probability):
    return calibrator.predict_proba(
        to_logit(probability)
    )[:, 1]


# ============================================================
# POLICY AND METRICS
# ============================================================

def apply_policy(
        df,
        directional_threshold,
        conditional_up_threshold,
        calibrated,
):
    if calibrated:
        p_directional = (
            df["p_directional_calibrated"].to_numpy()
        )

        p_up = (
            df["p_up_conditional_calibrated"].to_numpy()
        )
    else:
        p_directional = (
            df["p_directional_raw"].to_numpy()
        )

        p_up = (
            df["p_up_conditional_raw"].to_numpy()
        )

    predicted = np.full(
        len(df),
        "SIDEWAYS",
        dtype=object,
    )

    directional_mask = (
            p_directional >= directional_threshold
    )

    up_mask = (
            p_up >= conditional_up_threshold
    )

    predicted[
        directional_mask & up_mask
        ] = "UP"

    predicted[
        directional_mask & ~up_mask
        ] = "DOWN"

    return predicted


def calculate_metrics(actual, predicted):
    actual = np.asarray(actual)
    predicted = np.asarray(predicted)

    actual_directional = actual != "SIDEWAYS"
    predicted_directional = predicted != "SIDEWAYS"

    return {
        "rows": int(len(actual)),
        "accuracy": float(
            accuracy_score(actual, predicted)
        ),
        "balanced_accuracy": float(
            balanced_accuracy_score(actual, predicted)
        ),
        "macro_f1": float(
            f1_score(
                actual,
                predicted,
                labels=LABELS,
                average="macro",
                zero_division=0,
            )
        ),
        "weighted_f1": float(
            f1_score(
                actual,
                predicted,
                labels=LABELS,
                average="weighted",
                zero_division=0,
            )
        ),
        "directional_precision": float(
            precision_score(
                actual_directional,
                predicted_directional,
                zero_division=0,
            )
        ),
        "directional_recall": float(
            recall_score(
                actual_directional,
                predicted_directional,
                zero_division=0,
            )
        ),
        "actual_directional_pct": float(
            actual_directional.mean() * 100
        ),
        "predicted_directional_pct": float(
            predicted_directional.mean() * 100
        ),
        "down_precision": float(
            precision_score(
                actual == "DOWN",
                predicted == "DOWN",
                zero_division=0,
                )
        ),
        "down_recall": float(
            recall_score(
                actual == "DOWN",
                predicted == "DOWN",
                zero_division=0,
                )
        ),
        "up_precision": float(
            precision_score(
                actual == "UP",
                predicted == "UP",
                zero_division=0,
                )
        ),
        "up_recall": float(
            recall_score(
                actual == "UP",
                predicted == "UP",
                zero_division=0,
                )
        ),
        "predicted_down_pct": float(
            (predicted == "DOWN").mean() * 100
        ),
        "predicted_sideways_pct": float(
            (predicted == "SIDEWAYS").mean() * 100
        ),
        "predicted_up_pct": float(
            (predicted == "UP").mean() * 100
        ),
    }


def make_threshold_grid(df):
    actual = df["actual_label"].to_numpy()
    rows = []

    for directional_threshold in DIRECTIONAL_THRESHOLDS:
        for up_threshold in CONDITIONAL_UP_THRESHOLDS:
            predicted = apply_policy(
                df,
                directional_threshold,
                up_threshold,
                calibrated=True,
            )

            metrics = calculate_metrics(
                actual,
                predicted,
            )

            rows.append({
                "directional_threshold": float(
                    directional_threshold
                ),
                "conditional_up_threshold": float(
                    up_threshold
                ),
                **metrics,
            })

    grid = pd.DataFrame(rows)

    # Primary objective: macro-F1.
    # Tie-breaks: balanced accuracy, directional precision.
    grid = grid.sort_values(
        [
            "macro_f1",
            "balanced_accuracy",
            "directional_precision",
        ],
        ascending=[False, False, False],
    ).reset_index(drop=True)

    grid.insert(
        0,
        "calibration_rank",
        np.arange(1, len(grid) + 1),
    )

    return grid


# ============================================================
# REPORTS
# ============================================================

def save_policy_outputs(
        df,
        predicted,
        report_dir,
        prefix,
        directional_threshold,
        up_threshold,
):
    output = df.copy()
    output["predicted_label"] = predicted

    output.to_parquet(
        report_dir / f"{prefix}_predictions.parquet",
        index=False,
        )

    metrics = calculate_metrics(
        output["actual_label"],
        output["predicted_label"],
    )

    metrics["directional_threshold"] = float(
        directional_threshold
    )

    metrics["conditional_up_threshold"] = float(
        up_threshold
    )

    with open(
            report_dir / f"{prefix}_metrics.json",
            "w",
            encoding="utf-8",
    ) as f:
        json.dump(metrics, f, indent=2)

    cm = confusion_matrix(
        output["actual_label"],
        output["predicted_label"],
        labels=LABELS,
    )

    pd.DataFrame(
        cm,
        index=[f"actual_{x}" for x in LABELS],
        columns=[f"predicted_{x}" for x in LABELS],
    ).to_csv(
        report_dir / f"{prefix}_confusion_matrix.csv"
    )

    report = classification_report(
        output["actual_label"],
        output["predicted_label"],
        labels=LABELS,
        output_dict=True,
        zero_division=0,
    )

    pd.DataFrame(report).transpose().to_csv(
        report_dir / f"{prefix}_classification_report.csv"
    )

    return metrics


def monthly_policy_report(df, policy_predictions):
    work = df.copy()

    work["predicted_label"] = policy_predictions

    work["month"] = pd.to_datetime(
        work["trading_day"].astype(str)
    ).dt.strftime("%Y-%m")

    rows = []

    for month, group in work.groupby("month"):
        metrics = calculate_metrics(
            group["actual_label"],
            group["predicted_label"],
        )

        rows.append({
            "month": month,
            **metrics,
        })

    return pd.DataFrame(rows)


def probability_metrics(df):
    actual_directional = (
            df["actual_label"] != "SIDEWAYS"
    ).astype(int).to_numpy()

    actual_directional_rate = float(
        actual_directional.mean()
    )

    rows = []

    for method, column in [
        ("RAW", "p_directional_raw"),
        ("CALIBRATED", "p_directional_calibrated"),
    ]:
        probability = np.clip(
            df[column].to_numpy(),
            EPS,
            1.0 - EPS,
            )

        rows.append({
            "method": method,
            "actual_directional_pct": (
                    actual_directional_rate * 100
            ),
            "mean_probability_pct": (
                    probability.mean() * 100
            ),
            "brier_score": float(
                brier_score_loss(
                    actual_directional,
                    probability,
                )
            ),
            "log_loss": float(
                log_loss(
                    actual_directional,
                    probability,
                    labels=[0, 1],
                )
            ),
            "roc_auc": float(
                roc_auc_score(
                    actual_directional,
                    probability,
                )
            ),
        })

    return pd.DataFrame(rows)


# ============================================================
# MAIN
# ============================================================

def main():
    start = time.time()

    run_id, model_dir, report_dir = create_directories()

    print("=" * 75)
    print("NIFTY CALIBRATED THRESHOLD TRANSFER V2")
    print("=" * 75)
    print(f"Run ID: {run_id}")

    train = load_data(TRAIN_FILE, "training")
    validation = load_data(VALIDATION_FILE, "validation")

    d2023_start = pd.to_datetime("2023-01-01").date()
    d2023_june_end = pd.to_datetime("2023-06-30").date()
    d2023_end = pd.to_datetime("2023-12-31").date()
    d2024_start = pd.to_datetime("2024-01-01").date()
    d2024_end = pd.to_datetime("2024-12-31").date()

    train_2021_2022 = train[
        train["trading_day"] < d2023_start
        ].copy()

    calibration_fit_2023 = train[
        (train["trading_day"] >= d2023_start)
        & (train["trading_day"] <= d2023_june_end)
        ].copy()

    threshold_selection_2023 = train[
        (train["trading_day"] > d2023_june_end)
        & (train["trading_day"] <= d2023_end)
        ].copy()

    final_train = train[
        train["trading_day"] <= d2023_end
        ].copy()

    evaluation_2024 = validation[
        (validation["trading_day"] >= d2024_start)
        & (validation["trading_day"] <= d2024_end)
        ].copy()

    partitions = [
        ("2021-2022", train_2021_2022),
        ("2023 Jan-Jun calibration", calibration_fit_2023),
        ("2023 Jul-Dec threshold selection", threshold_selection_2023),
        ("2021-2023 final fit", final_train),
        ("2024 diagnostic", evaluation_2024),
    ]

    for name, df in partitions:
        if df.empty:
            raise ValueError(f"Empty partition: {name}")
        print(f"{name}: {len(df):,} rows")

    # --------------------------------------------------------
    # A. Fit base classifiers on 2021-2022.
    # --------------------------------------------------------

    print("\nFITTING 2021-2022 CALIBRATION BASE MODELS")

    calibration_stage1, calibration_stage2 = fit_two_stage(
        train_2021_2022,
        "Calibration base model",
    )

    calibration_fit_predictions = predict_probabilities(
        calibration_stage1,
        calibration_stage2,
        calibration_fit_2023,
    )

    threshold_selection_predictions = predict_probabilities(
        calibration_stage1,
        calibration_stage2,
        threshold_selection_2023,
    )

    # --------------------------------------------------------
    # B. Fit calibrators on Jan-Jun 2023 only.
    # --------------------------------------------------------

    print("\nFITTING PLATT CALIBRATORS ON 2023 JAN-JUN")

    y1_calibration = (
            calibration_fit_predictions["actual_label"] != "SIDEWAYS"
    ).astype(int)

    directional_calibration_mask = (
            calibration_fit_predictions["actual_label"] != "SIDEWAYS"
    )

    y2_calibration = (
            calibration_fit_predictions.loc[
                directional_calibration_mask,
                "actual_label",
            ] == "UP"
    ).astype(int)

    stage1_calibrator = fit_platt(
        calibration_fit_predictions["p_directional_raw"],
        y1_calibration,
        "Stage 1",
    )

    stage2_calibrator = fit_platt(
        calibration_fit_predictions.loc[
            directional_calibration_mask,
            "p_up_conditional_raw",
        ],
        y2_calibration,
        "Stage 2",
    )

    joblib.dump(
        stage1_calibrator,
        model_dir / "stage1_platt_calibrator.joblib",
        )

    joblib.dump(
        stage2_calibrator,
        model_dir / "stage2_platt_calibrator.joblib",
        )

    # Apply the calibrators to the Jul-Dec threshold-selection set.
    threshold_selection_predictions[
        "p_directional_calibrated"
    ] = apply_platt(
        stage1_calibrator,
        threshold_selection_predictions["p_directional_raw"],
    )

    threshold_selection_predictions[
        "p_up_conditional_calibrated"
    ] = apply_platt(
        stage2_calibrator,
        threshold_selection_predictions["p_up_conditional_raw"],
    )

    threshold_selection_predictions.to_parquet(
        report_dir / "2023_jul_dec_calibrated_probabilities.parquet",
        index=False,
        )

    calibration_fit_predictions.to_parquet(
        report_dir / "2023_jan_jun_calibration_probabilities.parquet",
        index=False,
        )

    # --------------------------------------------------------
    # C. Select calibrated thresholds on Jul-Dec 2023.
    # --------------------------------------------------------

    print("\nSELECTING THRESHOLDS ON 2023 JUL-DEC")

    grid = make_threshold_grid(
        threshold_selection_predictions
    )

    grid.to_csv(
        report_dir / "2023_calibrated_threshold_grid.csv",
        index=False,
        )

    grid.head(25).to_csv(
        report_dir / "top_25_2023_calibrated_thresholds.csv",
        index=False,
        )

    selected = grid.iloc[0]

    selected_directional_threshold = float(
        selected["directional_threshold"]
    )

    selected_up_threshold = float(
        selected["conditional_up_threshold"]
    )

    print("\nSELECTED CALIBRATED THRESHOLDS")
    print(
        f"Directional: {selected_directional_threshold:.3f}"
    )
    print(
        f"Conditional UP: {selected_up_threshold:.3f}"
    )
    print(
        f"2023 Jul-Dec macro-F1: {selected['macro_f1']:.6f}"
    )
    print(
        f"2023 Jul-Dec directional coverage: "
        f"{selected['predicted_directional_pct']:.3f}%"
    )

    # Save the calibration-period threshold metrics.
    calibration_selected_predictions = apply_policy(
        threshold_selection_predictions,
        selected_directional_threshold,
        selected_up_threshold,
        calibrated=True,
    )

    calibration_metrics = save_policy_outputs(
        threshold_selection_predictions,
        calibration_selected_predictions,
        report_dir,
        "2023_jul_dec_selected_calibrated_policy",
        selected_directional_threshold,
        selected_up_threshold,
    )

    # --------------------------------------------------------
    # D. Fit final models on 2021-2023.
    # --------------------------------------------------------

    print("\nFITTING FINAL CLASSIFIERS THROUGH 2023")

    final_stage1, final_stage2 = fit_two_stage(
        final_train,
        "Final model",
    )

    joblib.dump(
        final_stage1,
        model_dir / "stage1_directional_classifier.joblib",
        )

    joblib.dump(
        final_stage2,
        model_dir / "stage2_up_down_classifier.joblib",
        )

    # --------------------------------------------------------
    # E. Generate 2024 raw and calibrated probabilities.
    # --------------------------------------------------------

    print("\nGENERATING 2024 PROBABILITIES")

    evaluation = predict_probabilities(
        final_stage1,
        final_stage2,
        evaluation_2024,
    )

    evaluation["p_directional_calibrated"] = apply_platt(
        stage1_calibrator,
        evaluation["p_directional_raw"],
    )

    evaluation["p_up_conditional_calibrated"] = apply_platt(
        stage2_calibrator,
        evaluation["p_up_conditional_raw"],
    )

    evaluation.to_parquet(
        report_dir / "2024_raw_and_calibrated_probabilities.parquet",
        index=False,
        )

    # --------------------------------------------------------
    # F. Compare three decision policies on 2024.
    # --------------------------------------------------------

    print("\nEVALUATING THREE POLICIES ON 2024")

    policies = [
        {
            "name": "RAW_OLD_THRESHOLDS",
            "calibrated": False,
            "directional_threshold": OLD_DIRECTIONAL_THRESHOLD,
            "up_threshold": OLD_CONDITIONAL_UP_THRESHOLD,
        },
        {
            "name": "CALIBRATED_OLD_THRESHOLDS",
            "calibrated": True,
            "directional_threshold": OLD_DIRECTIONAL_THRESHOLD,
            "up_threshold": OLD_CONDITIONAL_UP_THRESHOLD,
        },
        {
            "name": "CALIBRATED_NEW_THRESHOLDS",
            "calibrated": True,
            "directional_threshold": selected_directional_threshold,
            "up_threshold": selected_up_threshold,
        },
    ]

    comparison_rows = []
    monthly_reports = []

    for policy in policies:
        predicted = apply_policy(
            evaluation,
            policy["directional_threshold"],
            policy["up_threshold"],
            policy["calibrated"],
        )

        metrics = save_policy_outputs(
            evaluation,
            predicted,
            report_dir,
            f"2024_{policy['name'].lower()}",
            policy["directional_threshold"],
            policy["up_threshold"],
        )

        metrics["policy"] = policy["name"]
        comparison_rows.append(metrics)

        monthly = monthly_policy_report(
            evaluation,
            predicted,
        )

        monthly.insert(0, "policy", policy["name"])
        monthly_reports.append(monthly)

    comparison = pd.DataFrame(comparison_rows)

    comparison.to_csv(
        report_dir / "2024_policy_comparison.csv",
        index=False,
        )

    pd.concat(
        monthly_reports,
        ignore_index=True,
    ).to_csv(
        report_dir / "2024_monthly_policy_stability.csv",
        index=False,
        )

    # --------------------------------------------------------
    # G. Probability ranking/calibration metrics on 2024.
    # --------------------------------------------------------

    probability_comparison = probability_metrics(
        evaluation
    )

    probability_comparison.to_csv(
        report_dir / "2024_directional_probability_comparison.csv",
        index=False,
        )

    # --------------------------------------------------------
    # H. Save calibrator parameters and manifest.
    # --------------------------------------------------------

    parameters = {
        "stage1": {
            "coefficient": float(
                stage1_calibrator.coef_[0][0]
            ),
            "intercept": float(
                stage1_calibrator.intercept_[0]
            ),
        },
        "stage2": {
            "coefficient": float(
                stage2_calibrator.coef_[0][0]
            ),
            "intercept": float(
                stage2_calibrator.intercept_[0]
            ),
        },
        "selected_thresholds": {
            "directional": selected_directional_threshold,
            "conditional_up": selected_up_threshold,
        },
        "old_thresholds": {
            "directional": OLD_DIRECTIONAL_THRESHOLD,
            "conditional_up": OLD_CONDITIONAL_UP_THRESHOLD,
        },
    }

    with open(
            report_dir / "calibration_and_threshold_parameters.json",
            "w",
            encoding="utf-8",
    ) as f:
        json.dump(parameters, f, indent=2)

    manifest = {
        "run_id": run_id,
        "experiment": "calibrated_threshold_transfer_v2",
        "base_model_fit_period": "2021-2022",
        "calibrator_fit_period": "2023-01 through 2023-06",
        "threshold_selection_period": "2023-07 through 2023-12",
        "final_classifier_fit_period": "2021-2023",
        "evaluation_period": "2024 diagnostic only",
        "excluded_periods": ["2025", "2026"],
        "calibration_method": "Platt sigmoid on probability logits",
        "stage1_iterations": STAGE1_ITERATIONS,
        "stage2_iterations": STAGE2_ITERATIONS,
        "threshold_selection_metric": "macro_f1",
        "threshold_tie_breakers": [
            "balanced_accuracy",
            "directional_precision",
        ],
        "feature_count": len(FEATURES),
        "features": FEATURES,
        "timezone": "Asia/Kolkata",
        "warning": (
            "The calibrator is fitted on Jan-Jun 2023 scores from "
            "models trained through 2022. Thresholds are selected "
            "on Jul-Dec 2023 scores from the same base models. "
            "The final model is refitted through 2023, so calibration "
            "transfer to 2024 may be imperfect. 2024 is diagnostic, "
            "not an untouched test."
        ),
    }

    with open(
            report_dir / "run_manifest.json",
            "w",
            encoding="utf-8",
    ) as f:
        json.dump(manifest, f, indent=2)

    # --------------------------------------------------------
    # CONSOLE SUMMARY
    # --------------------------------------------------------

    display_columns = [
        "policy",
        "accuracy",
        "balanced_accuracy",
        "macro_f1",
        "directional_precision",
        "directional_recall",
        "predicted_directional_pct",
        "down_precision",
        "down_recall",
        "up_precision",
        "up_recall",
    ]

    print("\n" + "=" * 75)
    print("2024 POLICY COMPARISON")
    print("=" * 75)

    print(
        comparison[display_columns].to_string(
            index=False,
            float_format=lambda x: f"{x:.5f}",
        )
    )

    print("\n2024 DIRECTIONAL PROBABILITY COMPARISON")
    print(
        probability_comparison.to_string(
            index=False,
            float_format=lambda x: f"{x:.6f}",
        )
    )

    print("\nTOP 10 CALIBRATED THRESHOLD CANDIDATES")
    print(
        grid.head(10)[
            [
                "calibration_rank",
                "directional_threshold",
                "conditional_up_threshold",
                "macro_f1",
                "balanced_accuracy",
                "directional_precision",
                "directional_recall",
                "predicted_directional_pct",
            ]
        ].to_string(index=False)
    )

    print("\nOUTPUTS")
    print(f"Models: {model_dir}")
    print(f"Reports: {report_dir}")
    print(f"Elapsed seconds: {time.time() - start:.2f}")

    print("\nCompleted successfully.")


if __name__ == "__main__":
    main()
