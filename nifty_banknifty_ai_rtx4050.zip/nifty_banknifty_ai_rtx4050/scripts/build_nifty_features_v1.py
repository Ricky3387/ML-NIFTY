#!/usr/bin/env python3
"""
NIFTY feature engineering v1: gap-aware, synthetic-aware, session-aware.

Save this file under the project's scripts/ folder.

Run from the project root:
    python scripts/build_nifty_features_v1.py

Input:
  data/processed/nifty_index_cleaned/nifty_index_cleaned_final.parquet

Outputs:
  data/processed/nifty_features_v1/nifty_features_labels_long.parquet
  data/processed/nifty_features_v1/nifty_features_labels_long_sample.csv
  data/processed/nifty_features_v1/nifty_feature_engineering_summary.json
  data/processed/nifty_features_v1/nifty_feature_engineering_daily_audit.csv

Design:
- NIFTY index only.
- One-minute observations; feature rows are generated at every observed minute.
- Features use only current/past information within the same trading day.
- Labels use future close at t+5, t+15, t+30 minutes, within the same session/day.
- Any synthetic bar in the 60-minute feature lookback or future label window
  invalidates that sample.
- 2022-03-07 is excluded for the whole day.
- 2023-03-28 is guarded automatically because its synthetic minute invalidates
  windows touching it.
- Labels use z = forward_return / (past_60m_return_std * sqrt(horizon)).
  Initial configurable class boundaries: z <= -0.5 DOWN,
  -0.5 < z < 0.5 SIDEWAYS, z >= 0.5 UP.
  These are research defaults, not optimized thresholds or trading signals.
"""
from pathlib import Path
import json
import time
import numpy as np
import pandas as pd

START = time.time()
# This script lives in <project_root>/scripts/. Resolve all data paths
# from the project root, independent of the caller's current directory.
SCRIPT_DIR = Path(__file__).resolve().parent
ROOT = SCRIPT_DIR.parent if SCRIPT_DIR.name.lower() == "scripts" else SCRIPT_DIR
INPUT = ROOT / "data" / "processed" / "nifty_index_cleaned" / "nifty_index_cleaned_final.parquet"
OUT = ROOT / "data" / "processed" / "nifty_features_v1"
FULL_DAY_EXCLUSIONS = {"2022-03-07"}
HORIZONS = (5, 15, 30)
LOOKBACK = 60
Z_THRESHOLD = 0.5

def main():
    if not INPUT.exists():
        raise FileNotFoundError(
            f"Final cleaned Parquet not found: {INPUT}\n"
            "Expected location: <project_root>/data/processed/nifty_index_cleaned/"
            "nifty_index_cleaned_final.parquet"
        )
    OUT.mkdir(parents=True, exist_ok=True)
    print(f"[1/7] Reading {INPUT}", flush=True)
    df = pd.read_parquet(INPUT)

    required = {
        "timestamp_ist", "trading_day", "open", "high", "low", "close",
        "is_synthetic", "training_day_eligible"
    }
    missing = required - set(df.columns)
    if missing:
        raise RuntimeError(f"Missing required columns: {sorted(missing)}")

    print("[2/7] Normalizing timestamps and validating input", flush=True)
    df["timestamp_ist"] = pd.to_datetime(df["timestamp_ist"])
    df["trading_day"] = pd.to_datetime(df["trading_day"]).dt.strftime("%Y-%m-%d")
    for c in ("open", "high", "low", "close"):
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df["is_synthetic"] = df["is_synthetic"].astype(bool)
    df["training_day_eligible"] = df["training_day_eligible"].astype(bool)
    df = df.sort_values(["trading_day", "timestamp_ist"]).reset_index(drop=True)

    if df["timestamp_ist"].duplicated().any():
        raise RuntimeError("Duplicate timestamp_ist values found; stop before feature generation.")
    if df[["open", "high", "low", "close"]].isna().any().any():
        raise RuntimeError("Null OHLC values found; stop before feature generation.")

    # Only use days that are allowed by the closure audit.
    df["day_allowed"] = (
        df["training_day_eligible"]
        & ~df["trading_day"].isin(FULL_DAY_EXCLUSIONS)
    )

    print("[3/7] Building same-day, one-minute features", flush=True)
    pieces = []
    for day, g in df.groupby("trading_day", sort=True):
        g = g.copy().sort_values("timestamp_ist").reset_index(drop=True)
        # The calendar cleaner should create one row per minute. Assert this;
        # don't silently calculate rolling features across any unexpected gap.
        delta = g["timestamp_ist"].diff().dt.total_seconds().div(60)
        contiguous = delta.eq(1)
        contiguous.iloc[0] = True
        g["bar_contiguous_from_prev"] = contiguous

        close = g["close"].astype(float)
        logret = np.log(close).diff()
        g["ret_1m"] = close.pct_change(fill_method=None)
        g["logret_1m"] = logret
        # Volatility scale is calculated within each trading day; never let
        # a previous session's final return leak into the next session.
        g["trailing_sigma_60m"] = logret.rolling(LOOKBACK, min_periods=LOOKBACK).std()
        g["range_pct"] = (g["high"] - g["low"]) / close
        g["body_pct"] = (g["close"] - g["open"]) / g["open"]
        g["upper_wick_pct"] = (g["high"] - g[["open", "close"]].max(axis=1)) / close
        g["lower_wick_pct"] = (g[["open", "close"]].min(axis=1) - g["low"]) / close

        for w in (5, 15, 30, 60):
            g[f"return_{w}m"] = close.pct_change(w, fill_method=None)
            g[f"realized_vol_{w}m"] = logret.rolling(w, min_periods=w).std() * np.sqrt(w)
            g[f"high_low_range_{w}m"] = (
                g["high"].rolling(w, min_periods=w).max()
                - g["low"].rolling(w, min_periods=w).min()
            ) / close

        g["ema_9"] = close.ewm(span=9, adjust=False, min_periods=9).mean()
        g["ema_21"] = close.ewm(span=21, adjust=False, min_periods=21).mean()
        g["ema_50"] = close.ewm(span=50, adjust=False, min_periods=50).mean()
        g["close_vs_ema9_pct"] = close / g["ema_9"] - 1
        g["close_vs_ema21_pct"] = close / g["ema_21"] - 1
        g["close_vs_ema50_pct"] = close / g["ema_50"] - 1
        delta_close = close.diff()
        gain = delta_close.clip(lower=0).rolling(14, min_periods=14).mean()
        loss = (-delta_close.clip(upper=0)).rolling(14, min_periods=14).mean()
        rs = gain / loss.replace(0, np.nan)
        g["rsi_14"] = 100 - (100 / (1 + rs))
        # Streak/run features can be useful for short-horizon direction.
        g["positive_return_count_5m"] = (g["ret_1m"] > 0).rolling(5, min_periods=5).sum()
        g["negative_return_count_5m"] = (g["ret_1m"] < 0).rolling(5, min_periods=5).sum()

        # A sample's full 60-bar feature lookback must be real and contiguous.
        g["feature_window_valid"] = (
            (~g["is_synthetic"]).rolling(LOOKBACK, min_periods=LOOKBACK).sum().eq(LOOKBACK)
            & g["bar_contiguous_from_prev"].rolling(LOOKBACK, min_periods=LOOKBACK).sum().eq(LOOKBACK)
            & g["day_allowed"]
        )
        # Current row is the prediction timestamp. Future target windows are
        # checked below using shifts within this trading day.
        for h in HORIZONS:
            g[f"future_close_{h}m"] = close.shift(-h)
            future_synth_count = (
                g["is_synthetic"].astype("int8").shift(-1)
                .iloc[::-1].rolling(h, min_periods=h).sum().iloc[::-1]
            )
            # The expression above aligns a forward window t+1 ... t+h at t.
            g[f"future_synthetic_count_{h}m"] = future_synth_count.to_numpy()
            future_delta = g["timestamp_ist"].shift(-h) - g["timestamp_ist"]
            expected_delta = pd.to_timedelta(h, unit="m")
            g[f"future_time_valid_{h}m"] = future_delta.eq(expected_delta)
        pieces.append(g)

    data = pd.concat(pieces, ignore_index=True)
    print("[4/7] Creating forward targets and volatility-normalized labels", flush=True)
    output_parts = []
    feature_cols = [
        "ret_1m", "logret_1m", "range_pct", "body_pct",
        "upper_wick_pct", "lower_wick_pct",
        "return_5m", "return_15m", "return_30m", "return_60m",
        "realized_vol_5m", "realized_vol_15m", "realized_vol_30m", "realized_vol_60m",
        "high_low_range_5m", "high_low_range_15m", "high_low_range_30m", "high_low_range_60m",
        "close_vs_ema9_pct", "close_vs_ema21_pct", "close_vs_ema50_pct",
        "rsi_14", "positive_return_count_5m", "negative_return_count_5m"
    ]
    base_cols = ["timestamp_ist", "trading_day", "open", "high", "low", "close",
                 "is_synthetic", "training_day_eligible", "session_type"]
    base_cols = [c for c in base_cols if c in data.columns]

    for h in HORIZONS:
        x = data[base_cols + feature_cols].copy()
        x["horizon_minutes"] = h
        x["future_close"] = data[f"future_close_{h}m"]
        x["forward_return"] = x["future_close"] / x["close"] - 1
        # Scale by trailing one-minute return volatility over 60 prior/current
        # bars. This is a normalization, not a calibrated probability.
        x["target_vol_scale"] = data["trailing_sigma_60m"].to_numpy() * np.sqrt(h)
        x["target_z"] = np.log(x["future_close"] / x["close"]) / x["target_vol_scale"]
        x["label"] = np.select(
            [x["target_z"] <= -Z_THRESHOLD, x["target_z"] >= Z_THRESHOLD],
            ["DOWN", "UP"], default="SIDEWAYS"
        )
        valid = (
            data["feature_window_valid"].to_numpy()
            & data[f"future_time_valid_{h}m"].to_numpy()
            & data[f"future_synthetic_count_{h}m"].fillna(1).eq(0).to_numpy()
            & data[f"future_close_{h}m"].notna().to_numpy()
            & x["target_vol_scale"].gt(0).to_numpy()
            & x[feature_cols].notna().all(axis=1).to_numpy()
            & data["day_allowed"].to_numpy()
        )
        x["sample_eligible"] = valid
        x["sample_exclusion_reason"] = np.where(
            ~data["day_allowed"].to_numpy(), "FULL_DAY_INELIGIBLE",
            np.where(~data["feature_window_valid"].to_numpy(), "FEATURE_WINDOW_INVALID_OR_SYNTHETIC",
            np.where(~data[f"future_time_valid_{h}m"].to_numpy(), "FUTURE_WINDOW_GAP_OR_SESSION_END",
            np.where(data[f"future_synthetic_count_{h}m"].fillna(1).to_numpy() > 0, "FUTURE_WINDOW_SYNTHETIC",
            np.where(x["target_vol_scale"].le(0).to_numpy(), "INVALID_VOL_SCALE",
            np.where(~x[feature_cols].notna().all(axis=1).to_numpy(), "FEATURES_NOT_READY", "ELIGIBLE")))))
        )
        output_parts.append(x)

    result = pd.concat(output_parts, ignore_index=True)
    result["split"] = np.select(
        [
            pd.to_datetime(result["trading_day"]).dt.year.le(2023),
            result["trading_day"].str.startswith("2024"),
            result["trading_day"].str.startswith("2025"),
            result["trading_day"].str.startswith("2026")
        ],
        ["TRAIN", "VALIDATION", "TEST", "RECENT_HOLDOUT"],
        default="OUT_OF_SCOPE"
    )
    # Current source period ends 2024-12-31. Future split labels are reserved
    # for when 2025/2026 calendar-validated data is added; do not synthesize it.
    result.loc[result["split"].isin(["TEST", "RECENT_HOLDOUT"]), "split"] = "NOT_IN_CURRENT_CLEANED_PERIOD"

    print("[5/7] Writing feature dataset and audits", flush=True)
    parquet_path = OUT / "nifty_features_labels_long.parquet"
    csv_path = OUT / "nifty_features_labels_long_sample.csv"
    daily_path = OUT / "nifty_feature_engineering_daily_audit.csv"
    summary_path = OUT / "nifty_feature_engineering_summary.json"

    result.to_parquet(parquet_path, index=False, compression="zstd")
    result.head(5000).to_csv(csv_path, index=False)

    daily = result.groupby(["trading_day", "horizon_minutes"], as_index=False).agg(
        rows=("sample_eligible", "size"),
        eligible_samples=("sample_eligible", "sum"),
        synthetic_source_rows=("is_synthetic", "sum"),
        excluded_full_day=("training_day_eligible", lambda s: (~s).all())
    )
    daily.to_csv(daily_path, index=False)

    eligible = result[result["sample_eligible"]]
    summary = {
        "status": "FEATURES_AND_LABELS_GENERATED_REVIEW_REQUIRED",
        "input_parquet": str(INPUT),
        "rows_written": int(len(result)),
        "eligible_samples": int(result["sample_eligible"].sum()),
        "excluded_samples": int((~result["sample_eligible"]).sum()),
        "horizons_minutes": list(HORIZONS),
        "lookback_minutes": LOOKBACK,
        "feature_count": len(feature_cols),
        "label_method": "forward log return divided by trailing 60-bar log-return std times sqrt(horizon)",
        "class_threshold_abs_z": Z_THRESHOLD,
        "class_distribution": {
            str(h): {
                str(k): int(v) for k, v in
                eligible[eligible["horizon_minutes"].eq(h)]["label"].value_counts().items()
            } for h in HORIZONS
        },
        "split_policy": "2021-2023 TRAIN; 2024 VALIDATION; 2025 TEST and 2026 RECENT_HOLDOUT reserved but unavailable in current cleaned input",
        "guard_policy": "60-bar feature window and future horizon must be contiguous, same-day, and free of synthetic bars; 2022-03-07 excluded fully",
        "elapsed_seconds": round(time.time() - START, 2)
    }
    summary_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2), flush=True)
    print(f"\nPARQUET: {parquet_path}")
    print(f"SAMPLE CSV: {csv_path}")
    print(f"DAILY AUDIT: {daily_path}")
    print(f"SUMMARY: {summary_path}")

if __name__ == "__main__":
    main()
