nvidia-smi
python -c "import torch; print('torch',torch.__version__); print('cuda',torch.cuda.is_available()); print(torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'CUDA unavailable; install PyTorch CUDA build')"
