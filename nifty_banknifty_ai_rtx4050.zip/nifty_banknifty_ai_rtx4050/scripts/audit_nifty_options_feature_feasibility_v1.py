
from pathlib import Path
from datetime import datetime
import json
import duckdb
import pandas as pd

# ============================================================
# NIFTY OPTIONS FEATURE FEASIBILITY AUDIT v1
#
# Read-only source audit.
# No training, no source modifications.
#
# Scope:
#   2021-05-24 through 2024-12-31
#   Normal NSE session: 09:15-15:29 IST
#   NIFTY only
#
# Outputs:
#   reports/nifty_options_feature_feasibility_v1/
# ============================================================

ROOT = Path(__file__).resolve().parent.parent
DB_PATH = ROOT / "data" / "database" / "nifty_options.duckdb"
OUTPUT_DIR = ROOT / "reports" / "nifty_options_feature_feasibility_v1"

START_DATE = "2021-05-24"
END_DATE = "2024-12-31"

TIMEZONE = "Asia/Kolkata"
SESSION_START = "09:15:00"
SESSION_END = "15:29:00"

SPECIAL_DATES = [
    "2021-11-04",
    "2022-10-24",
    "2023-11-12",
    "2024-11-01",
    "2024-01-20",
    "2024-03-02",
    "2024-05-18",
]

# Candidate ATM bands are descriptive audit bands only.
ATM_BANDS_PCT = [0.5, 1.0, 2.0]

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


def qid(value):
    return '"' + str(value).replace('"', '""') + '"'


def write_csv(df, filename):
    path = OUTPUT_DIR / filename
    df.to_csv(path, index=False)
    print(f"Generated: {path} ({len(df):,} rows)")


def scalar(con, sql):
    return con.execute(sql).fetchone()[0]


def main():
    if not DB_PATH.exists():
        raise FileNotFoundError(f"DuckDB not found: {DB_PATH}")

    con = duckdb.connect(str(DB_PATH), read_only=True)

    try:
        con.execute("SET threads = 4")
        con.execute("SET memory_limit = '8GB'")
        con.execute(
            f"SET temp_directory = '{str(OUTPUT_DIR / 'duckdb_temp').replace(chr(92), '/')}'"
        )

        print("=" * 85)
        print("NIFTY OPTIONS FEATURE FEASIBILITY AUDIT v1")
        print("=" * 85)

        # ----------------------------------------------------
        # 1. Inspect actual schema
        # ----------------------------------------------------
        schema = con.execute("""
            DESCRIBE SELECT * FROM nifty_options
        """).df()

        write_csv(schema, "source_schema.csv")

        available = set(schema["column_name"].astype(str))

        required = {
            "timestamp",
            "open",
            "high",
            "low",
            "close",
            "volume",
            "open_interest",
            "trading_day",
            "symbol",
            "strike",
            "option_type",
            "expiry",
            "underlying",
        }

        missing = sorted(required - available)

        if missing:
            raise RuntimeError(
                "Required source columns missing: " + ", ".join(missing)
            )

        timestamp_type = schema.loc[
            schema["column_name"] == "timestamp", "column_type"
        ].iloc[0]

        print("Timestamp type:", timestamp_type)

        # ----------------------------------------------------
        # 2. Build read-only filtered view
        #
        # Convert timezone-aware timestamp to IST wall clock.
        # Never add 5:30 manually to a TIMESTAMPTZ value.
        # ----------------------------------------------------
        special_sql = ", ".join(
            f"DATE '{d}'" for d in SPECIAL_DATES
        )

        con.execute(f"""
            CREATE OR REPLACE TEMP VIEW nifty_options_scope AS
            SELECT
                timestamp,
                timezone('{TIMEZONE}', timestamp) AS timestamp_ist,
                CAST(timezone('{TIMEZONE}', timestamp) AS DATE)
                    AS trading_date_ist,
                CAST(trading_day AS VARCHAR) AS source_trading_day,
                CAST(expiry AS DATE) AS expiry_date,
                CAST(strike AS DOUBLE) AS strike,
                UPPER(TRIM(CAST(option_type AS VARCHAR))) AS option_type,
                UPPER(TRIM(CAST(underlying AS VARCHAR))) AS underlying,
                UPPER(TRIM(CAST(symbol AS VARCHAR))) AS symbol,
                CAST(open AS DOUBLE) AS open,
                CAST(high AS DOUBLE) AS high,
                CAST(low AS DOUBLE) AS low,
                CAST(close AS DOUBLE) AS close,
                CAST(volume AS DOUBLE) AS volume,
                CAST(open_interest AS DOUBLE) AS open_interest,
                CAST(dataset_type AS VARCHAR) AS dataset_type
            FROM nifty_options
            WHERE UPPER(TRIM(CAST(underlying AS VARCHAR))) = 'NIFTY'
              AND CAST(timezone('{TIMEZONE}', timestamp) AS DATE)
                    BETWEEN DATE '{START_DATE}' AND DATE '{END_DATE}'
              AND CAST(timezone('{TIMEZONE}', timestamp) AS TIME)
                    BETWEEN TIME '{SESSION_START}' AND TIME '{SESSION_END}'
              AND CAST(timezone('{TIMEZONE}', timestamp) AS DATE)
                    NOT IN ({special_sql})
        """)

        total_rows = scalar(
            con, "SELECT COUNT(*) FROM nifty_options_scope"
        )

        print("\nScoped NIFTY option rows:", f"{total_rows:,}")

        if total_rows == 0:
            raise RuntimeError("No rows found in the requested scope.")

        # ----------------------------------------------------
        # 3. Basic data quality summary
        # ----------------------------------------------------
        basic = con.execute("""
                            SELECT
                                COUNT(*) AS rows,
                COUNT(DISTINCT trading_date_ist) AS trading_days,
                COUNT(DISTINCT timestamp_ist) AS unique_timestamps,
                COUNT(DISTINCT expiry_date) AS unique_expiries,
                COUNT(DISTINCT strike) AS unique_strikes,
                COUNT(DISTINCT symbol) AS unique_symbols,
                MIN(timestamp_ist) AS first_timestamp_ist,
                MAX(timestamp_ist) AS last_timestamp_ist,

                COUNT(*) FILTER (WHERE timestamp IS NULL)
                    AS null_timestamp_rows,
                COUNT(*) FILTER (WHERE expiry_date IS NULL)
                    AS null_expiry_rows,
                COUNT(*) FILTER (WHERE strike IS NULL OR strike <= 0)
                    AS invalid_strike_rows,
                COUNT(*) FILTER (WHERE close IS NULL OR close <= 0)
                    AS invalid_close_rows,
                COUNT(*) FILTER (WHERE volume IS NULL OR volume < 0)
                    AS invalid_volume_rows,
                COUNT(*) FILTER (
                    WHERE open_interest IS NULL OR open_interest < 0
                ) AS invalid_oi_rows,

                COUNT(*) FILTER (
                    WHERE option_type NOT IN ('CE', 'PE')
                       OR option_type IS NULL
                ) AS unknown_option_type_rows,

                COUNT(*) FILTER (
                    WHERE high < low
                       OR high < open
                       OR high < close
                       OR low > open
                       OR low > close
                ) AS invalid_ohlc_rows,

                COUNT(*) FILTER (
                    WHERE volume = 0
                ) AS zero_volume_rows,

                COUNT(*) FILTER (
                    WHERE open_interest = 0
                ) AS zero_oi_rows

                            FROM nifty_options_scope
                            """).df()

        write_csv(basic, "basic_data_quality.csv")

        # ----------------------------------------------------
        # 4. Option type and dataset type distributions
        # ----------------------------------------------------
        option_types = con.execute("""
                                   SELECT
                                       option_type,
                                       COUNT(*) AS rows,
                COUNT(DISTINCT timestamp_ist) AS timestamps,
                COUNT(DISTINCT expiry_date) AS expiries,
                COUNT(DISTINCT strike) AS strikes,
                COUNT(DISTINCT trading_date_ist) AS trading_days
                                   FROM nifty_options_scope
                                   GROUP BY option_type
                                   ORDER BY option_type
                                   """).df()

        write_csv(option_types, "option_type_distribution.csv")

        dataset_types = con.execute("""
                                    SELECT
                                        dataset_type,
                                        COUNT(*) AS rows,
                COUNT(DISTINCT trading_date_ist) AS trading_days
                                    FROM nifty_options_scope
                                    GROUP BY dataset_type
                                    ORDER BY rows DESC
                                    """).df()

        write_csv(dataset_types, "dataset_type_distribution.csv")

        # ----------------------------------------------------
        # 5. Daily timestamp and CE/PE coverage
        # ----------------------------------------------------
        daily = con.execute("""
                            WITH minute_type AS (
                                SELECT
                                    trading_date_ist,
                                    timestamp_ist,
                                    COUNT(*) AS option_rows,
                                    COUNT(DISTINCT strike) AS active_strikes,
                                    COUNT(DISTINCT expiry_date) AS active_expiries,
                                    COUNT(*) FILTER (WHERE option_type = 'CE') AS ce_rows,
                                    COUNT(*) FILTER (WHERE option_type = 'PE') AS pe_rows
                                FROM nifty_options_scope
                                GROUP BY trading_date_ist, timestamp_ist
                            )
                            SELECT
                                trading_date_ist,
                                COUNT(*) AS observed_option_minutes,
                                SUM(option_rows) AS option_rows,
                                AVG(active_strikes) AS avg_active_strikes_per_minute,
                                MAX(active_strikes) AS max_active_strikes_per_minute,
                                AVG(active_expiries) AS avg_active_expiries_per_minute,
                                COUNT(*) FILTER (WHERE ce_rows > 0) AS minutes_with_ce,
                                COUNT(*) FILTER (WHERE pe_rows > 0) AS minutes_with_pe,
                                COUNT(*) FILTER (
                    WHERE ce_rows > 0 AND pe_rows > 0
                ) AS minutes_with_both_ce_pe
                            FROM minute_type
                            GROUP BY trading_date_ist
                            ORDER BY trading_date_ist
                            """).df()

        write_csv(daily, "daily_options_coverage.csv")

        # ----------------------------------------------------
        # 6. Exact CE/PE contract pairing
        #
        # A paired slot means same:
        # timestamp + expiry + strike
        # with both CE and PE present.
        # ----------------------------------------------------
        paired = con.execute("""
                             WITH contract_slots AS (
                                 SELECT
                                     timestamp_ist,
                                     trading_date_ist,
                                     expiry_date,
                                     strike,
                                     COUNT(*) FILTER (WHERE option_type = 'CE') AS ce_rows,
                                     COUNT(*) FILTER (WHERE option_type = 'PE') AS pe_rows,
                                     COUNT(*) AS total_rows
                                 FROM nifty_options_scope
                                 WHERE option_type IN ('CE', 'PE')
                                 GROUP BY
                                     timestamp_ist,
                                     trading_date_ist,
                                     expiry_date,
                                     strike
                             )
                             SELECT
                                 COUNT(*) AS contract_minute_slots,
                                 COUNT(*) FILTER (
                    WHERE ce_rows > 0 AND pe_rows > 0
                ) AS paired_contract_slots,
                                 COUNT(*) FILTER (
                    WHERE ce_rows > 0 AND pe_rows = 0
                ) AS ce_only_slots,
                                 COUNT(*) FILTER (
                    WHERE pe_rows > 0 AND ce_rows = 0
                ) AS pe_only_slots,
                                 ROUND(
                                         100.0 * COUNT(*) FILTER (
                        WHERE ce_rows > 0 AND pe_rows > 0
                    ) / NULLIF(COUNT(*), 0),
                                         4
                                 ) AS paired_slot_percentage
                             FROM contract_slots
                             """).df()

        write_csv(paired, "ce_pe_contract_pairing_summary.csv")

        # Daily paired contract slots.
        paired_daily = con.execute("""
                                   WITH contract_slots AS (
                                       SELECT
                                           trading_date_ist,
                                           timestamp_ist,
                                           expiry_date,
                                           strike,
                                           COUNT(*) FILTER (WHERE option_type = 'CE') AS ce_rows,
                                           COUNT(*) FILTER (WHERE option_type = 'PE') AS pe_rows
                                       FROM nifty_options_scope
                                       WHERE option_type IN ('CE', 'PE')
                                       GROUP BY
                                           trading_date_ist,
                                           timestamp_ist,
                                           expiry_date,
                                           strike
                                   )
                                   SELECT
                                       trading_date_ist,
                                       COUNT(*) AS contract_slots,
                                       COUNT(*) FILTER (
                    WHERE ce_rows > 0 AND pe_rows > 0
                ) AS paired_slots,
                                       ROUND(
                                               100.0 * COUNT(*) FILTER (
                        WHERE ce_rows > 0 AND pe_rows > 0
                    ) / NULLIF(COUNT(*), 0),
                                               4
                                       ) AS paired_pct
                                   FROM contract_slots
                                   GROUP BY trading_date_ist
                                   ORDER BY trading_date_ist
                                   """).df()

        write_csv(paired_daily, "daily_ce_pe_pairing.csv")

        # ----------------------------------------------------
        # 7. OI and volume feasibility
        # ----------------------------------------------------
        oi_volume = con.execute("""
                                SELECT
                                    option_type,
                                    COUNT(*) AS rows,

                COUNT(*) FILTER (
                    WHERE open_interest IS NOT NULL
                ) AS non_null_oi_rows,

                COUNT(*) FILTER (
                    WHERE open_interest > 0
                ) AS positive_oi_rows,

                COUNT(*) FILTER (
                    WHERE volume IS NOT NULL
                ) AS non_null_volume_rows,

                COUNT(*) FILTER (
                    WHERE volume > 0
                ) AS positive_volume_rows,

                ROUND(
                    100.0 * COUNT(*) FILTER (
                        WHERE open_interest > 0
                    ) / NULLIF(COUNT(*), 0),
                    4
                ) AS positive_oi_pct,

                ROUND(
                    100.0 * COUNT(*) FILTER (
                        WHERE volume > 0
                    ) / NULLIF(COUNT(*), 0),
                    4
                ) AS positive_volume_pct,

                APPROX_QUANTILE(open_interest, 0.50)
                    AS median_oi,

                APPROX_QUANTILE(volume, 0.50)
                    AS median_volume,

                MIN(open_interest) AS min_oi,
                MAX(open_interest) AS max_oi,
                MIN(volume) AS min_volume,
                MAX(volume) AS max_volume

                                FROM nifty_options_scope
                                GROUP BY option_type
                                ORDER BY option_type
                                """).df()

        write_csv(oi_volume, "oi_volume_feasibility.csv")

        # ----------------------------------------------------
        # 8. Expiry and DTE coverage
        # ----------------------------------------------------
        dte = con.execute("""
                          WITH x AS (
                              SELECT
                                  *,
                                  DATE_DIFF(
                                          'day',
                                          trading_date_ist,
                                          expiry_date
                                  ) AS dte
                              FROM nifty_options_scope
                              WHERE expiry_date IS NOT NULL
                          )
                          SELECT
                              dte,
                              option_type,
                              COUNT(*) AS rows,
                COUNT(DISTINCT trading_date_ist) AS trading_days,
                COUNT(DISTINCT expiry_date) AS expiries,
                COUNT(DISTINCT strike) AS strikes
                          FROM x
                          GROUP BY dte, option_type
                          ORDER BY dte, option_type
                          """).df()

        write_csv(dte, "expiry_dte_coverage.csv")

        # ----------------------------------------------------
        # 9. Strike interval diagnostics
        #
        # This is descriptive only. We do not assume a fixed
        # NIFTY strike interval across the entire history.
        # ----------------------------------------------------
        strike_steps = con.execute("""
                                   WITH strikes AS (
                                       SELECT DISTINCT
                                           trading_date_ist,
                                           expiry_date,
                                           strike
                                       FROM nifty_options_scope
                                       WHERE strike > 0
                                   ),
                                        steps AS (
                                            SELECT
                                                trading_date_ist,
                                                expiry_date,
                                                strike,
                                                LEAD(strike) OVER (
                        PARTITION BY trading_date_ist, expiry_date
                        ORDER BY strike
                    ) - strike AS strike_step
                                            FROM strikes
                                        )
                                   SELECT
                                       strike_step,
                                       COUNT(*) AS observations,
                                       COUNT(DISTINCT trading_date_ist) AS trading_days
                                   FROM steps
                                   WHERE strike_step > 0
                                   GROUP BY strike_step
                                   ORDER BY observations DESC
                                       LIMIT 50
                                   """).df()

        write_csv(strike_steps, "strike_interval_distribution.csv")

        # ----------------------------------------------------
        # 10. ATM coverage using exact index timestamp match
        #
        # Uses raw nifty_index view for timestamp/spot matching.
        # Index timestamps are timezone-aware and match the
        # options timestamp convention.
        #
        # Synthetic index bars are excluded if the source view
        # contains is_synthetic.
        # ----------------------------------------------------
        index_schema = con.execute("""
            DESCRIBE SELECT * FROM nifty_index
        """).df()

        index_columns = set(index_schema["column_name"].astype(str))

        if not {"timestamp", "close"}.issubset(index_columns):
            raise RuntimeError(
                "nifty_index must contain timestamp and close columns."
            )

        synthetic_filter = ""
        if "is_synthetic" in index_columns:
            synthetic_filter = "AND COALESCE(is_synthetic, FALSE) = FALSE"

        con.execute(f"""
            CREATE OR REPLACE TEMP VIEW nifty_spot_scope AS
            SELECT
                timestamp,
                timezone('{TIMEZONE}', timestamp) AS timestamp_ist,
                CAST(timezone('{TIMEZONE}', timestamp) AS DATE)
                    AS trading_date_ist,
                CAST(close AS DOUBLE) AS spot_close
            FROM nifty_index
            WHERE CAST(timezone('{TIMEZONE}', timestamp) AS DATE)
                    BETWEEN DATE '{START_DATE}' AND DATE '{END_DATE}'
              AND CAST(timezone('{TIMEZONE}', timestamp) AS TIME)
                    BETWEEN TIME '{SESSION_START}' AND TIME '{SESSION_END}'
              AND CAST(timezone('{TIMEZONE}', timestamp) AS DATE)
                    NOT IN ({special_sql})
              AND close > 0
              {synthetic_filter}
        """)

        atm = con.execute("""
                          WITH option_slots AS (
                              SELECT
                              timestamp,
                              timestamp_ist,
                              trading_date_ist,
                              expiry_date,
                              strike,
                              COUNT(*) FILTER (WHERE option_type = 'CE') AS ce_rows,
                              COUNT(*) FILTER (WHERE option_type = 'PE') AS pe_rows
                          FROM nifty_options_scope
                          WHERE option_type IN ('CE', 'PE')
                          GROUP BY
                              timestamp,
                              timestamp_ist,
                              trading_date_ist,
                              expiry_date,
                              strike
                              ),
                              matched AS (
                          SELECT
                              o.*,
                              s.spot_close,
                              DATE_DIFF(
                              'day',
                              o.trading_date_ist,
                              o.expiry_date
                              ) AS dte,
                              ABS(o.strike - s.spot_close)
                              / NULLIF(s.spot_close, 0) * 100.0
                              AS distance_pct,
                              CASE
                              WHEN o.ce_rows > 0 AND o.pe_rows > 0
                              THEN 1 ELSE 0
                              END AS is_paired
                          FROM option_slots o
                              INNER JOIN nifty_spot_scope s
                          ON o.timestamp = s.timestamp
                          WHERE o.expiry_date IS NOT NULL
                              ),
                              expiry_min_distance AS (
                          SELECT
                              timestamp_ist,
                              trading_date_ist,
                              expiry_date,
                              dte,
                              MIN(distance_pct) AS nearest_strike_distance_pct
                          FROM matched
                          WHERE dte BETWEEN 0 AND 7
                          GROUP BY
                              timestamp_ist,
                              trading_date_ist,
                              expiry_date,
                              dte
                              ),
                              expiry_band AS (
                          SELECT
                              m.*,
                              e.nearest_strike_distance_pct
                          FROM matched m
                              INNER JOIN expiry_min_distance e
                          ON m.timestamp_ist = e.timestamp_ist
                              AND m.expiry_date = e.expiry_date
                          WHERE m.dte BETWEEN 0 AND 7
                              )
                          SELECT
                              COUNT(*) AS dte_0_7_contract_slots,

                              COUNT(*) FILTER (
                    WHERE distance_pct <= 0.5
                ) AS slots_within_0_5_pct,

                              COUNT(*) FILTER (
                    WHERE distance_pct <= 1.0
                ) AS slots_within_1_pct,

                              COUNT(*) FILTER (
                    WHERE distance_pct <= 2.0
                ) AS slots_within_2_pct,

                              COUNT(*) FILTER (
                    WHERE distance_pct <= 0.5 AND is_paired = 1
                ) AS paired_slots_within_0_5_pct,

                              COUNT(*) FILTER (
                    WHERE distance_pct <= 1.0 AND is_paired = 1
                ) AS paired_slots_within_1_pct,

                              COUNT(*) FILTER (
                    WHERE distance_pct <= 2.0 AND is_paired = 1
                ) AS paired_slots_within_2_pct,

                              COUNT(DISTINCT timestamp_ist)
                                  AS matched_option_minutes,

                              COUNT(DISTINCT trading_date_ist)
                                       AS matched_trading_days,

                              APPROX_QUANTILE(distance_pct, 0.50)
                                       AS median_strike_distance_pct

                          FROM expiry_band
                          """).df()

        write_csv(atm, "atm_dte_0_7_coverage.csv")

        # More useful daily ATM coverage.
        atm_daily = con.execute("""
                                WITH option_slots AS (
                                    SELECT
                                    timestamp,
                                    timestamp_ist,
                                    trading_date_ist,
                                    expiry_date,
                                    strike,
                                    COUNT(*) FILTER (WHERE option_type = 'CE') AS ce_rows,
                                    COUNT(*) FILTER (WHERE option_type = 'PE') AS pe_rows
                                FROM nifty_options_scope
                                WHERE option_type IN ('CE', 'PE')
                                GROUP BY
                                    timestamp,
                                    timestamp_ist,
                                    trading_date_ist,
                                    expiry_date,
                                    strike
                                    ),
                                    matched AS (
                                SELECT
                                    o.*,
                                    s.spot_close,
                                    DATE_DIFF(
                                    'day',
                                    o.trading_date_ist,
                                    o.expiry_date
                                    ) AS dte,
                                    ABS(o.strike - s.spot_close)
                                    / NULLIF(s.spot_close, 0) * 100.0
                                    AS distance_pct
                                FROM option_slots o
                                    INNER JOIN nifty_spot_scope s
                                ON o.timestamp = s.timestamp
                                    )
                                SELECT
                                    trading_date_ist,
                                    COUNT(*) FILTER (
                    WHERE dte BETWEEN 0 AND 7
                ) AS dte_0_7_slots,
                                    COUNT(*) FILTER (
                    WHERE dte BETWEEN 0 AND 7
                      AND distance_pct <= 1.0
                ) AS within_1_pct_slots,
                                    COUNT(*) FILTER (
                    WHERE dte BETWEEN 0 AND 7
                      AND distance_pct <= 1.0
                      AND ce_rows > 0 AND pe_rows > 0
                ) AS paired_within_1_pct_slots
                                FROM matched
                                GROUP BY trading_date_ist
                                ORDER BY trading_date_ist
                                """).df()

        write_csv(atm_daily, "daily_atm_coverage.csv")

        # ----------------------------------------------------
        # 11. Feature feasibility matrix
        # ----------------------------------------------------
        feasibility = pd.DataFrame([
            {
                "feature_group": "ATM CE/PE premium returns",
                "required_fields": "timestamp, expiry, strike, option_type, close",
                "source_fields_present": "YES",
                "calculation_feasibility": "HIGH",
                "limitations": "Requires exact paired CE/PE contract observations and valid prices."
            },
            {
                "feature_group": "ATM CE/PE relative strength",
                "required_fields": "timestamp, expiry, strike, option_type, close",
                "source_fields_present": "YES",
                "calculation_feasibility": "HIGH",
                "limitations": "Must align same expiry, strike and timestamp."
            },
            {
                "feature_group": "Open-interest change",
                "required_fields": "timestamp, expiry, strike, option_type, open_interest",
                "source_fields_present": "YES",
                "calculation_feasibility": "CONDITIONAL",
                "limitations": "Requires consecutive valid observations; distinguish missing records from unchanged OI."
            },
            {
                "feature_group": "Volume imbalance",
                "required_fields": "timestamp, expiry, strike, option_type, volume",
                "source_fields_present": "YES",
                "calculation_feasibility": "CONDITIONAL",
                "limitations": "Validate whether volume is per-bar or cumulative before calculating changes."
            },
            {
                "feature_group": "PCR by OI",
                "required_fields": "timestamp, expiry, strike, option_type, open_interest",
                "source_fields_present": "YES",
                "calculation_feasibility": "CONDITIONAL",
                "limitations": "Must define expiry and strike universe consistently; missing CE/PE contracts can bias PCR."
            },
            {
                "feature_group": "PCR by volume",
                "required_fields": "timestamp, expiry, strike, option_type, volume",
                "source_fields_present": "YES",
                "calculation_feasibility": "CONDITIONAL",
                "limitations": "Validate volume semantics and paired coverage first."
            },
            {
                "feature_group": "ATM straddle premium",
                "required_fields": "timestamp, expiry, strike, option_type, close",
                "source_fields_present": "YES",
                "calculation_feasibility": "HIGH",
                "limitations": "Requires same-strike CE and PE with valid simultaneous prices."
            },
            {
                "feature_group": "Implied volatility",
                "required_fields": "option price, spot, strike, expiry, risk-free rate, option type",
                "source_fields_present": "PARTIAL",
                "calculation_feasibility": "CONDITIONAL",
                "limitations": "Requires defensible rate, time-to-expiry convention, price quality and pricing assumptions."
            },
            {
                "feature_group": "Greeks",
                "required_fields": "implied volatility, spot, strike, expiry, rate, option type",
                "source_fields_present": "PARTIAL",
                "calculation_feasibility": "NOT YET",
                "limitations": "Do not calculate until IV methodology and expiry/time conventions are validated."
            },
            {
                "feature_group": "Bid/ask spread and order-book imbalance",
                "required_fields": "bid, ask, bid_size, ask_size",
                "source_fields_present": "NO",
                "calculation_feasibility": "UNAVAILABLE",
                "limitations": "Historical bid/ask fields are not present in the known source schema."
            },
        ])

        write_csv(feasibility, "feature_feasibility_matrix.csv")

        # ----------------------------------------------------
        # 12. Final summary
        # ----------------------------------------------------
        basic_record = basic.iloc[0].to_dict()
        paired_record = paired.iloc[0].to_dict()
        atm_record = atm.iloc[0].to_dict()

        summary = {
            "generated_at": datetime.now().isoformat(),
            "database": str(DB_PATH),
            "source_view": "nifty_options",
            "underlying": "NIFTY",
            "date_scope": {
                "start": START_DATE,
                "end": END_DATE
            },
            "session": {
                "timezone": TIMEZONE,
                "start": SESSION_START,
                "end": SESSION_END,
                "preopen_excluded": True,
                "post_session_excluded": True,
                "special_dates_excluded": SPECIAL_DATES
            },
            "source_timestamp_type": str(timestamp_type),
            "rows_in_scope": int(total_rows),
            "basic_quality": basic_record,
            "ce_pe_pairing": paired_record,
            "atm_dte_0_7": atm_record,
            "source_modified": False,
            "model_training_performed": False,
            "limitations": [
                "No historical bid/ask data is assumed.",
                "No implied volatility or Greeks are calculated in this audit.",
                "Volume semantics must be validated before using volume changes.",
                "OI changes require consecutive valid contract observations.",
                "ATM coverage is measured using exact timestamp matches to NIFTY spot."
            ]
        }

        with open(
                OUTPUT_DIR / "options_feature_feasibility_summary.json",
                "w",
                encoding="utf-8"
        ) as f:
            json.dump(summary, f, indent=2, default=str)

        print("\n" + "=" * 85)
        print("AUDIT COMPLETED")
        print("=" * 85)
        print("Rows in scope:", f"{total_rows:,}")
        print("Output directory:", OUTPUT_DIR)
        print("Database opened read-only.")
        print("No model training performed.")
        print("No source files modified.")

    finally:
        con.close()


if __name__ == "__main__":
    main()
