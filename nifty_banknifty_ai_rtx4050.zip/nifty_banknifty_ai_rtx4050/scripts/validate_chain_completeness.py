
from pathlib import Path
import duckdb
import pandas as pd

BASE = Path(__file__).resolve().parent.parent
DB = BASE / "data" / "database" / "nifty_options.duckdb"
OUT = BASE / "data" / "reports"
OUT.mkdir(parents=True, exist_ok=True)

DATASETS = {
    "NIFTY": ("nifty_options", "nifty_index"),
    "BANKNIFTY": ("banknifty_options", "banknifty_index"),
}

con = duckdb.connect(str(DB), read_only=True)
con.execute("SET threads = 4")

try:
    for underlying, (options_table, index_table) in DATASETS.items():

        print("\n" + "=" * 85)
        print(f"{underlying} OPTION CHAIN COMPLETENESS")
        print("=" * 85)

        # --------------------------------------------------
        # 1. Daily option-chain completeness
        # --------------------------------------------------

        daily_sql = f"""
        WITH raw_daily AS (
            SELECT
                trading_day,
                COUNT(*) AS option_rows,
                COUNT(DISTINCT timestamp) AS option_minutes,
                COUNT(DISTINCT expiry) AS expiries,
                COUNT(DISTINCT strike) AS strikes,
                COUNT(DISTINCT CASE
                    WHEN option_type = 'CE' THEN strike
                END) AS ce_strikes,
                COUNT(DISTINCT CASE
                    WHEN option_type = 'PE' THEN strike
                END) AS pe_strikes
            FROM {options_table}
            GROUP BY trading_day
        ),

        contract_daily AS (
            SELECT
                trading_day,
                COUNT(DISTINCT
                    concat(
                        CAST(expiry AS VARCHAR), '|',
                        CAST(strike AS VARCHAR), '|',
                        option_type
                    )
                ) AS unique_contracts
            FROM {options_table}
            GROUP BY trading_day
        ),

        chain_slots AS (
            SELECT
                trading_day,
                timestamp,
                expiry,
                strike,
                COUNT(DISTINCT option_type) AS side_count
            FROM {options_table}
            GROUP BY trading_day, timestamp, expiry, strike
        ),

        chain_daily AS (
            SELECT
                trading_day,
                COUNT(*) AS contract_minute_slots,
                COUNT(*) FILTER (
                    WHERE side_count = 2
                ) AS paired_contract_slots,
                COUNT(DISTINCT timestamp) AS observed_minutes,
                COUNT(DISTINCT timestamp) FILTER (
                    WHERE side_count = 2
                ) AS minutes_with_ce_pe_pairs
            FROM chain_slots
            GROUP BY trading_day
        ),

        minute_width AS (
            SELECT
                trading_day,
                timestamp,
                COUNT(DISTINCT concat(
                    CAST(expiry AS VARCHAR), '|',
                    CAST(strike AS VARCHAR)
                )) AS active_strikes
            FROM {options_table}
            GROUP BY trading_day, timestamp
        ),

        width_daily AS (
            SELECT
                trading_day,
                ROUND(AVG(active_strikes), 1)
                    AS avg_active_strikes_per_minute,
                MAX(active_strikes)
                    AS max_active_strikes_per_minute
            FROM minute_width
            GROUP BY trading_day
        ),

        index_daily AS (
            SELECT
                trading_day,
                COUNT(*) AS index_rows,
                COUNT(DISTINCT timestamp) AS index_minutes
            FROM {index_table}
            GROUP BY trading_day
        ),

        alignment_daily AS (
            SELECT
                o.trading_day,
                COUNT(*) AS option_rows,
                COUNT(*) FILTER (
                    WHERE i.timestamp IS NOT NULL
                ) AS rows_with_exact_index_match
            FROM {options_table} o
            LEFT JOIN (
                SELECT DISTINCT trading_day, timestamp
                FROM {index_table}
            ) i
              ON o.trading_day = i.trading_day
             AND o.timestamp = i.timestamp
            GROUP BY o.trading_day
        )

        SELECT
            r.trading_day,
            r.option_rows,
            r.option_minutes,
            r.expiries,
            r.strikes,
            r.ce_strikes,
            r.pe_strikes,
            c.unique_contracts,
            ch.contract_minute_slots,
            ch.paired_contract_slots,
            ROUND(
                100.0 * ch.paired_contract_slots
                / NULLIF(ch.contract_minute_slots, 0), 2
            ) AS paired_slot_percentage,
            ch.minutes_with_ce_pe_pairs,
            w.avg_active_strikes_per_minute,
            w.max_active_strikes_per_minute,
            COALESCE(i.index_minutes, 0) AS index_minutes,
            COALESCE(a.rows_with_exact_index_match, 0)
                AS rows_with_exact_index_match,
            ROUND(
                100.0 * a.rows_with_exact_index_match
                / NULLIF(a.option_rows, 0), 2
            ) AS index_alignment_percentage

        FROM raw_daily r
        LEFT JOIN contract_daily c USING (trading_day)
        LEFT JOIN chain_daily ch USING (trading_day)
        LEFT JOIN width_daily w USING (trading_day)
        LEFT JOIN index_daily i USING (trading_day)
        LEFT JOIN alignment_daily a USING (trading_day)
        ORDER BY r.trading_day
        """

        daily = con.execute(daily_sql).fetchdf()

        daily_file = OUT / (
            f"{underlying.lower()}_chain_completeness_daily.csv"
        )
        daily.to_csv(daily_file, index=False)

        print("\nDaily completeness summary:")
        print(daily.describe().round(2).to_string())

        print("\nLowest paired-contract coverage days:")
        print(
            daily.sort_values("paired_slot_percentage")
            [[
                "trading_day",
                "option_rows",
                "unique_contracts",
                "paired_contract_slots",
                "paired_slot_percentage",
                "index_alignment_percentage"
            ]]
            .head(15)
            .to_string(index=False)
        )

        # --------------------------------------------------
        # 2. Overall CE / PE simultaneous coverage
        # --------------------------------------------------

        pair_sql = f"""
        WITH slots AS (
            SELECT
                trading_day,
                timestamp,
                expiry,
                strike,
                COUNT(DISTINCT option_type) AS sides
            FROM {options_table}
            GROUP BY trading_day, timestamp, expiry, strike
        )
        SELECT
            COUNT(*) AS total_contract_minute_slots,
            COUNT(*) FILTER (
                WHERE sides = 2
            ) AS paired_contract_minute_slots,
            COUNT(*) FILTER (
                WHERE sides = 1
            ) AS single_side_contract_minute_slots,
            ROUND(
                100.0 * COUNT(*) FILTER (WHERE sides = 2)
                / NULLIF(COUNT(*), 0), 2
            ) AS paired_percentage
        FROM slots
        """

        pair = con.execute(pair_sql).fetchdf()

        print("\nOverall simultaneous CE/PE coverage:")
        print(pair.to_string(index=False))

        pair.to_csv(
            OUT / f"{underlying.lower()}_paired_coverage.csv",
            index=False
        )

        print(f"\nSaved daily report: {daily_file}")

finally:
    con.close()

print("\nOPTION CHAIN COMPLETENESS VALIDATION FINISHED")
print("Reports:", OUT)
