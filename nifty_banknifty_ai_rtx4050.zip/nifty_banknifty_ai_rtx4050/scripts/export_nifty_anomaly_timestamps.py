"""
Export and audit raw NIFTY index timestamps for six anomaly dates.

IMPORTANT TIMEZONE ASSUMPTION:
The DuckDB `timestamp` values are naive UTC timestamps. This script converts
them to Asia/Kolkata before comparing them with NSE session times.

Run from the project root:
    python export_nifty_anomaly_timestamps.py

The database is opened read-only. No source data is modified.
"""

from pathlib import Path
import sys

import duckdb
import pandas as pd


DB_PATH = Path("data/database/nifty_options.duckdb")
VIEW_NAME = "nifty_index"
OUTPUT_DIR = Path("data/reports/nifty_index_calendar_validation")
TIMEZONE = "Asia/Kolkata"

ANOMALY_DATES = [
    "2021-06-28",
    "2022-03-07",
    "2023-03-28",
    "2024-01-20",
    "2024-03-02",
    "2024-05-18",
]

# Minute-start labels: 09:15 through 15:29 = 375 expected bars.
NORMAL_WINDOWS = [("09:15", 375)]

SPECIAL_WINDOWS = {
    # January 20, 2024: final schedule was full-day trading.
    "2024-01-20": [("09:15", 375)],

    # March 2 and May 18, 2024: split-session DR exercises.
    "2024-03-02": [("09:15", 45), ("11:30", 60)],
    "2024-05-18": [("09:15", 45), ("11:30", 60)],
}


def convert_naive_utc_to_ist(values: pd.Series) -> pd.Series:
    """Interpret naive DuckDB timestamps as UTC and convert them to IST."""
    parsed = pd.to_datetime(values, errors="coerce")

    # If DuckDB unexpectedly returns timezone-aware values, normalize them
    # to UTC first. Otherwise, explicitly localize the naive values as UTC.
    if parsed.dt.tz is None:
        parsed = parsed.dt.tz_localize("UTC")
    else:
        parsed = parsed.dt.tz_convert("UTC")

    return parsed.dt.tz_convert(TIMEZONE).dt.tz_localize(None)


def build_expected_timestamps(trading_date: str, windows: list) -> pd.DatetimeIndex:
    parts = []
    for start_time, minutes in windows:
        start = pd.Timestamp(f"{trading_date} {start_time}")
        parts.append(pd.date_range(start=start, periods=int(minutes), freq="min"))

    if not parts:
        return pd.DatetimeIndex([])

    result = parts[0]
    for part in parts[1:]:
        result = result.append(part)
    return result


def classify_observed_timestamp(ts: pd.Timestamp, expected_set: set,
                                windows: list) -> str:
    if ts in expected_set:
        return "EXPECTED_SESSION_MINUTE"

    minute_of_day = ts.hour * 60 + ts.minute

    for start_time, minutes in windows:
        start = pd.Timestamp(f"{ts.date()} {start_time}")
        start_minute = start.hour * 60 + start.minute
        end_exclusive = start_minute + int(minutes)

        if start_minute <= minute_of_day < end_exclusive:
            return "INSIDE_WINDOW_NON_EXPECTED_LABEL"

    if minute_of_day < 9 * 60 + 15:
        return "BEFORE_REGULAR_SESSION"

    if minute_of_day > 15 * 60 + 29:
        return "AFTER_REGULAR_SESSION"

    return "BETWEEN_OR_OUTSIDE_CONFIGURED_WINDOWS"


def main() -> int:
    if not DB_PATH.exists():
        print(f"ERROR: Database not found: {DB_PATH.resolve()}")
        print("Run this script from the project root or update DB_PATH.")
        return 1

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    date_sql = ", ".join(f"DATE '{d}'" for d in ANOMALY_DATES)

    print("Opening DuckDB read-only...")
    con = duckdb.connect(str(DB_PATH), read_only=True)

    try:
        raw = con.execute(
            f"""
            SELECT *
            FROM {VIEW_NAME}
            WHERE CAST(timestamp AS DATE) IN ({date_sql})
            ORDER BY timestamp
            """
        ).df()
    except Exception as exc:
        print(f"ERROR reading {VIEW_NAME}: {exc}")
        return 1
    finally:
        con.close()

    if raw.empty:
        print("ERROR: No observations found for the requested dates.")
        return 1

    if "timestamp" not in raw.columns:
        print("ERROR: Query did not return a timestamp column.")
        print("Columns:", list(raw.columns))
        return 1

    # Preserve original timestamp exactly as returned by DuckDB.
    raw["timestamp_ist"] = convert_naive_utc_to_ist(raw["timestamp"])
    raw = raw.dropna(subset=["timestamp_ist"]).copy()
    raw["trading_date_ist"] = raw["timestamp_ist"].dt.strftime("%Y-%m-%d")
    raw = raw.sort_values("timestamp_ist").reset_index(drop=True)

    raw_file = OUTPUT_DIR / "nifty_anomaly_date_raw_observations.csv"
    raw.to_csv(raw_file, index=False)

    audit_rows = []
    missing_rows = []
    summary_rows = []

    for trading_date in ANOMALY_DATES:
        day = raw[raw["trading_date_ist"] == trading_date].copy()
        windows = SPECIAL_WINDOWS.get(trading_date, NORMAL_WINDOWS)

        expected = build_expected_timestamps(trading_date, windows)
        expected_set = set(expected)
        observed_set = set(day["timestamp_ist"])

        missing = sorted(expected_set - observed_set)
        extras = sorted(observed_set - expected_set)
        matched = expected_set & observed_set

        for _, row in day.iterrows():
            ts = row["timestamp_ist"]
            audit_rows.append({
                "trading_date": trading_date,
                "record_type": "OBSERVED",
                "timestamp_ist": ts,
                "classification": classify_observed_timestamp(
                    ts, expected_set, windows
                ),
                "expected_session_minute": ts in expected_set,
            })

        for ts in missing:
            item = {
                "trading_date": trading_date,
                "record_type": "MISSING_EXPECTED_MINUTE",
                "timestamp_ist": ts,
                "classification": "MISSING_FROM_SOURCE",
                "expected_session_minute": True,
            }
            audit_rows.append(item)
            missing_rows.append(item)

        first_ts = day["timestamp_ist"].min() if not day.empty else pd.NaT
        last_ts = day["timestamp_ist"].max() if not day.empty else pd.NaT

        session_type = (
            "SPECIAL_FULL_DAY" if trading_date == "2024-01-20"
            else "SPECIAL_SPLIT_SESSION" if trading_date in SPECIAL_WINDOWS
            else "NORMAL_SESSION"
        )

        summary_rows.append({
            "trading_date": trading_date,
            "session_type": session_type,
            "observed_rows": len(day),
            "unique_observed_timestamps": len(observed_set),
            "expected_minutes": len(expected_set),
            "matched_expected_minutes": len(matched),
            "missing_expected_minutes": len(missing),
            "extra_unique_timestamps": len(extras),
            "first_timestamp_ist": first_ts,
            "last_timestamp_ist": last_ts,
            "extra_timestamps_ist": ";".join(
                ts.strftime("%Y-%m-%d %H:%M:%S") for ts in extras
            ),
            "missing_timestamps_ist": ";".join(
                ts.strftime("%Y-%m-%d %H:%M:%S") for ts in missing
            ),
        })

        print(
            f"{trading_date}: rows={len(day)}, expected={len(expected_set)}, "
            f"matched={len(matched)}, missing={len(missing)}, extras={len(extras)}"
        )

    audit_df = pd.DataFrame(audit_rows)
    if not audit_df.empty:
        audit_df = audit_df.sort_values(
            ["trading_date", "timestamp_ist", "record_type"]
        )

    missing_df = pd.DataFrame(
        missing_rows,
        columns=[
            "trading_date", "record_type", "timestamp_ist",
            "classification", "expected_session_minute"
        ],
    )
    summary_df = pd.DataFrame(summary_rows)

    audit_file = OUTPUT_DIR / "nifty_anomaly_timestamp_audit.csv"
    missing_file = OUTPUT_DIR / "nifty_exact_missing_minutes.csv"
    summary_file = OUTPUT_DIR / "nifty_anomaly_date_summary.csv"

    audit_df.to_csv(audit_file, index=False)
    missing_df.to_csv(missing_file, index=False)
    summary_df.to_csv(summary_file, index=False)

    print("\nExport complete. Database was not modified.")
    print("Timezone conversion: naive UTC -> Asia/Kolkata")
    print("Raw observations :", raw_file.resolve())
    print("Timestamp audit  :", audit_file.resolve())
    print("Missing minutes  :", missing_file.resolve())
    print("Daily summary    :", summary_file.resolve())
    print("\nUpload all four CSV files for review.")

    return 0


if __name__ == "__main__":
    sys.exit(main())
