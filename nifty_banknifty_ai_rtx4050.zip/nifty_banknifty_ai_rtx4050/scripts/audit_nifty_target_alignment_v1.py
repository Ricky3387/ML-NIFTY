
from pathlib import Path
from datetime import datetime, timezone
import json

import duckdb
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]

FEATURE_FILE = (
        ROOT / "data/processed/nifty_features_v1/"
               "nifty_features_labels_long.parquet"
)

CLEAN_INDEX_FILE = (
        ROOT / "data/processed/nifty_index_cleaned/"
               "nifty_index_cleaned_final.parquet"
)

REPORT_DIR = ROOT / "reports/nifty_target_alignment_v1"
REPORT_DIR.mkdir(parents=True, exist_ok=True)

SUMMARY_FILE = REPORT_DIR / "target_alignment_summary.json"
HORIZON_FILE = REPORT_DIR / "target_alignment_by_horizon.csv"
MISMATCH_FILE = REPORT_DIR / "target_alignment_mismatches.csv"

TOLERANCE = 1e-8


def qi(name):
    return '"' + name.replace('"', '""') + '"'


def sql_path(path):
    return "'" + str(path).replace("\\", "/").replace("'", "''") + "'"


def find_column(columns, candidates, description):
    for candidate in candidates:
        if candidate in columns:
            return candidate
    raise RuntimeError(
        f"Cannot find {description}. Available columns: {columns}"
    )


def main():
    if not FEATURE_FILE.exists():
        raise FileNotFoundError(FEATURE_FILE)

    if not CLEAN_INDEX_FILE.exists():
        raise FileNotFoundError(CLEAN_INDEX_FILE)

    con = duckdb.connect(":memory:")
    con.execute("SET TimeZone='Asia/Kolkata'")
    con.execute("SET threads=4")

    con.execute(f"""
        CREATE VIEW features AS
        SELECT *
        FROM read_parquet({sql_path(FEATURE_FILE)})
    """)

    con.execute(f"""
        CREATE VIEW clean_index AS
        SELECT *
        FROM read_parquet({sql_path(CLEAN_INDEX_FILE)})
    """)

    feature_cols = [
        r[0] for r in con.execute(
            "DESCRIBE SELECT * FROM features"
        ).fetchall()
    ]

    index_cols = [
        r[0] for r in con.execute(
            "DESCRIBE SELECT * FROM clean_index"
        ).fetchall()
    ]

    required_feature_cols = [
        "timestamp_ist",
        "horizon_minutes",
        "trading_day",
        "close",
        "future_close",
        "sample_eligible"
    ]

    missing = [
        c for c in required_feature_cols
        if c not in feature_cols
    ]

    if missing:
        raise RuntimeError(
            f"Missing feature dataset columns: {missing}"
        )

    index_timestamp_col = find_column(
        index_cols,
        ["timestamp_ist", "timestamp"],
        "clean index timestamp"
    )

    index_close_col = find_column(
        index_cols,
        ["close", "spot_close", "index_close"],
        "clean index close"
    )

    if "is_synthetic" not in index_cols:
        raise RuntimeError(
            "Cleaned index dataset has no is_synthetic column. "
            "Cannot verify that future target bars are real."
        )

    # Normalize the cleaned source columns.
    con.execute(f"""
        CREATE VIEW source_bars AS
        SELECT
            {qi(index_timestamp_col)} AS source_timestamp,
            {qi(index_close_col)} AS source_close,
            CAST({qi(index_timestamp_col)} AS DATE)
                AS source_trading_day,
            COALESCE(is_synthetic, FALSE) AS source_is_synthetic
        FROM clean_index
    """)

    # Join each eligible feature row to:
    # 1. Its current source bar.
    # 2. Its expected future source bar.
    con.execute("""
                CREATE VIEW alignment AS
                SELECT
                    f.timestamp_ist,
                    CAST(f.trading_day AS DATE) AS trading_day,
                    f.horizon_minutes,
                    f.close AS feature_close,
                    f.future_close,
                    f.forward_return,

                    current_bar.source_close AS source_current_close,
                    current_bar.source_trading_day AS current_source_day,
                    current_bar.source_is_synthetic AS current_is_synthetic,

                    future_bar.source_timestamp AS matched_future_timestamp,
                    future_bar.source_close AS source_future_close,
                    future_bar.source_trading_day AS future_source_day,
                    future_bar.source_is_synthetic AS future_is_synthetic,

                    f.timestamp_ist
                        + f.horizon_minutes * INTERVAL '1 minute'
                        AS expected_future_timestamp,

                        f.sample_eligible

                        FROM features f

                        LEFT JOIN source_bars current_bar
                        ON current_bar.source_timestamp = f.timestamp_ist

                        LEFT JOIN source_bars future_bar
                        ON future_bar.source_timestamp =
                        f.timestamp_ist
                        + f.horizon_minutes * INTERVAL '1 minute'

                        WHERE f.sample_eligible = TRUE
                """)

    # Alignment audit at row level.
    con.execute(f"""
        CREATE VIEW audited AS
        SELECT
            *,

            CASE
                WHEN source_current_close IS NOT NULL
                 AND ABS(feature_close - source_current_close)
                     <= {TOLERANCE}
                THEN TRUE ELSE FALSE
            END AS current_close_matches,

            CASE
                WHEN source_future_close IS NOT NULL
                 AND future_close IS NOT NULL
                 AND ABS(future_close - source_future_close)
                     <= {TOLERANCE}
                THEN TRUE ELSE FALSE
            END AS future_close_matches,

            CASE
                WHEN matched_future_timestamp =
                     expected_future_timestamp
                THEN TRUE ELSE FALSE
            END AS future_timestamp_matches,

            CASE
                WHEN future_source_day = trading_day
                THEN TRUE ELSE FALSE
            END AS same_trading_day,

            CASE
                WHEN future_is_synthetic = FALSE
                THEN TRUE ELSE FALSE
            END AS future_bar_is_real,

            CASE
                WHEN feature_close IS NOT NULL
                 AND future_close IS NOT NULL
                 AND feature_close > 0
                 AND future_close > 0
                 AND forward_return IS NOT NULL
                 AND ABS(
                     forward_return -
                     LN(future_close / feature_close)
                 ) <= 0.0000001
                THEN TRUE ELSE FALSE
            END AS log_return_matches,

            CASE
                WHEN feature_close IS NOT NULL
                 AND future_close IS NOT NULL
                 AND feature_close > 0
                 AND forward_return IS NOT NULL
                 AND ABS(
                     forward_return -
                     (future_close / feature_close - 1.0)
                 ) <= 0.0000001
                THEN TRUE ELSE FALSE
            END AS simple_return_matches

        FROM alignment
    """)

    # Overall metrics.
    overall = con.execute("""
                          SELECT
                              COUNT(*) AS eligible_rows,

                              COUNT(*) FILTER (
                WHERE current_close_matches
            ) AS current_close_matches,

                              COUNT(*) FILTER (
                WHERE future_close_matches
            ) AS future_close_matches,

                              COUNT(*) FILTER (
                WHERE future_timestamp_matches
            ) AS future_timestamp_matches,

                              COUNT(*) FILTER (
                WHERE same_trading_day
            ) AS same_trading_day_rows,

                              COUNT(*) FILTER (
                WHERE future_bar_is_real
            ) AS real_future_bar_rows,

                              COUNT(*) FILTER (
                WHERE log_return_matches
            ) AS log_return_matches,

                              COUNT(*) FILTER (
                WHERE simple_return_matches
            ) AS simple_return_matches,

                              COUNT(*) FILTER (
                WHERE source_current_close IS NULL
            ) AS missing_current_source_bars,

                              COUNT(*) FILTER (
                WHERE source_future_close IS NULL
            ) AS missing_future_source_bars,

                              COUNT(*) FILTER (
                WHERE future_close IS NULL
            ) AS missing_future_close_labels,

                              COUNT(*) FILTER (
                WHERE future_is_synthetic
            ) AS synthetic_future_bars,

                              COUNT(*) FILTER (
                WHERE current_is_synthetic
            ) AS synthetic_current_bars

                          FROM audited
                          """).fetchdf().iloc[0].to_dict()

    # Per-horizon results.
    by_horizon = con.execute("""
                             SELECT
                                 horizon_minutes,
                                 COUNT(*) AS eligible_rows,

                                 COUNT(*) FILTER (
                WHERE current_close_matches
            ) AS current_close_matches,

                                 COUNT(*) FILTER (
                WHERE future_close_matches
            ) AS future_close_matches,

                                 COUNT(*) FILTER (
                WHERE future_timestamp_matches
            ) AS future_timestamp_matches,

                                 COUNT(*) FILTER (
                WHERE same_trading_day
            ) AS same_trading_day_rows,

                                 COUNT(*) FILTER (
                WHERE future_bar_is_real
            ) AS real_future_bar_rows,

                                 COUNT(*) FILTER (
                WHERE log_return_matches
            ) AS log_return_matches,

                                 COUNT(*) FILTER (
                WHERE simple_return_matches
            ) AS simple_return_matches,

                                 COUNT(*) FILTER (
                WHERE source_future_close IS NULL
            ) AS missing_future_source_bars,

                                 COUNT(*) FILTER (
                WHERE future_is_synthetic
            ) AS synthetic_future_bars

                             FROM audited
                             GROUP BY horizon_minutes
                             ORDER BY horizon_minutes
                             """).fetchdf()

    by_horizon.to_csv(HORIZON_FILE, index=False)

    # Capture mismatches for investigation.
    mismatches = con.execute("""
                             SELECT *
                             FROM audited
                             WHERE NOT current_close_matches
                                OR NOT future_close_matches
                                OR NOT future_timestamp_matches
                                OR NOT same_trading_day
                                OR NOT future_bar_is_real
                             ORDER BY timestamp_ist, horizon_minutes
                                 LIMIT 5000
                             """).fetchdf()

    mismatches.to_csv(MISMATCH_FILE, index=False)

    # Formula diagnosis. We report both possibilities rather
    # than assuming the existing forward_return convention.
    log_match = (
            overall["log_return_matches"] == overall["eligible_rows"]
    )
    simple_match = (
            overall["simple_return_matches"] == overall["eligible_rows"]
    )

    if log_match:
        return_formula = "LOG_RETURN"
    elif simple_match:
        return_formula = "SIMPLE_RETURN"
    else:
        return_formula = "MIXED_OR_MISMATCH"

    checks = {
        "all_current_closes_match_source": (
                overall["current_close_matches"]
                == overall["eligible_rows"]
        ),
        "all_future_closes_match_expected_source": (
                overall["future_close_matches"]
                == overall["eligible_rows"]
        ),
        "all_future_timestamps_match_horizon": (
                overall["future_timestamp_matches"]
                == overall["eligible_rows"]
        ),
        "all_future_bars_same_trading_day": (
                overall["same_trading_day_rows"]
                == overall["eligible_rows"]
        ),
        "all_future_bars_are_real": (
                overall["real_future_bar_rows"]
                == overall["eligible_rows"]
        ),
        "no_missing_future_source_bars": (
                overall["missing_future_source_bars"] == 0
        ),
        "no_missing_future_close_labels": (
                overall["missing_future_close_labels"] == 0
        ),
        "forward_return_formula_consistent": (
                return_formula in ["LOG_RETURN", "SIMPLE_RETURN"]
        )
    }

    summary = {
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "feature_file": str(FEATURE_FILE),
        "clean_index_file": str(CLEAN_INDEX_FILE),
        "timestamp_policy": {
            "source_timestamp_convention": "MINUTE_START",
            "decision_time": "timestamp_ist + 1 minute",
            "expected_future_bar_timestamp":
                "timestamp_ist + horizon_minutes",
            "prediction_assumption":
                "Current completed bar values available at decision time",
            "provider_publication_latency_verified": False
        },
        "tolerance": TOLERANCE,
        "overall": overall,
        "detected_forward_return_formula": return_formula,
        "checks": checks,
        "passed_checks": sum(checks.values()),
        "total_checks": len(checks),
        "overall_status": (
            "PASS" if all(checks.values())
            else "REVIEW_REQUIRED"
        ),
        "reports": {
            "by_horizon": str(HORIZON_FILE),
            "mismatches": str(MISMATCH_FILE)
        }
    }

    SUMMARY_FILE.write_text(
        json.dumps(summary, indent=2, default=str),
        encoding="utf-8"
    )

    print("\n" + "=" * 75)
    print("NIFTY TARGET ALIGNMENT AUDIT")
    print("=" * 75)

    print(json.dumps(summary, indent=2, default=str))

    print("\nRESULTS BY HORIZON")
    print(by_horizon.to_string(index=False))

    print("\nMismatch sample rows:", len(mismatches))
    print("Generated reports:")
    print(SUMMARY_FILE)
    print(HORIZON_FILE)
    print(MISMATCH_FILE)

    con.close()


if __name__ == "__main__":
    main()
