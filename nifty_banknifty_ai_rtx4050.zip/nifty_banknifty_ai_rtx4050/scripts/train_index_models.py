
# scripts/train_index_models.py
#
# Weighted LightGBM classifier experiment.
#
# Training:   2021-2023
# Validation: 2024
# Test:       NOT USED
# Holdout:    2025 and 2026 NOT USED
#
# Class mapping:
#   0 = DOWN
#   1 = SIDEWAYS
#   2 = UP
#
# Outputs:
#   models/index_models_weighted_15/
#   data/training/model_results_weighted_15/
#
# This script does not overwrite the original baseline models.

from pathlib import Path
import json
import warnings

import numpy as np
import pandas as pd
import lightgbm as lgb

from lightgbm import LGBMClassifier
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    f1_score,
    log_loss,
    confusion_matrix,
    precision_recall_fscore_support,
)

warnings.filterwarnings("ignore", category=UserWarning)

# ============================================================
# PATHS
# ============================================================

ROOT = Path(__file__).resolve().parents[1]

INPUT_DIR = ROOT / "data" / "training" / "supervised"

MODEL_DIR = ROOT / "models" / "index_models_weighted_15"

RESULT_DIR = (
        ROOT
        / "data"
        / "training"
        / "model_results_weighted_15"
)

MODEL_DIR.mkdir(parents=True, exist_ok=True)
RESULT_DIR.mkdir(parents=True, exist_ok=True)

# ============================================================
# EXPERIMENT CONFIGURATION
# ============================================================

DATASETS = [
    ("nifty", "5m"),
    ("nifty", "15m"),
    ("nifty", "30m"),
    ("banknifty", "5m"),
    ("banknifty", "15m"),
    ("banknifty", "30m"),
]

TRAIN_START_YEAR = 2021
TRAIN_END_YEAR = 2023
VALIDATION_YEAR = 2024

# Do not change the weights during this experiment.
CLASS_WEIGHTS = {
    0: 1.5,  # DOWN
    1: 1.0,  # SIDEWAYS
    2: 1.5,  # UP
}

CLASS_NAMES = {
    0: "DOWN",
    1: "SIDEWAYS",
    2: "UP",
}

CLASS_LABELS = [0, 1, 2]

RANDOM_STATE = 42
N_JOBS = 4

# ============================================================
# FEATURES
# ============================================================

FEATURES = [
    "minute_of_day",
    "day_of_week",
    "month_of_year",

    "return_1m",
    "return_5m",
    "return_15m",
    "return_30m",

    "volatility_5m",
    "volatility_15m",
    "volatility_30m",
    "volatility_60m",

    "candle_range_pct",
    "candle_body_pct",
    "upper_wick_pct",
    "lower_wick_pct",
    "close_location",

    "vwap_deviation_pct",

    "volume_ratio_30",
    "volume_zscore_30",

    "range_position_15",
    "range_position_30",
]

REQUIRED_COLUMNS = (
        FEATURES
        + [
            "trading_day",
            "target_class",
        ]
)

# ============================================================
# MODEL
# ============================================================

def create_classifier():

    return LGBMClassifier(
        objective="multiclass",
        num_class=3,

        n_estimators=3000,
        learning_rate=0.03,

        num_leaves=31,
        max_depth=-1,

        min_child_samples=100,

        subsample=0.8,
        subsample_freq=1,

        colsample_bytree=0.8,

        reg_alpha=0.1,
        reg_lambda=1.0,

        class_weight=CLASS_WEIGHTS,

        random_state=RANDOM_STATE,
        n_jobs=N_JOBS,

        verbosity=-1,
        deterministic=True,
        force_col_wise=True,
    )


# ============================================================
# DATA LOADING
# ============================================================

def load_dataset(index_name, horizon):

    dataset_name = f"{index_name}_{horizon}"

    path = INPUT_DIR / f"{dataset_name}_supervised.parquet"

    if not path.exists():
        raise FileNotFoundError(
            f"Dataset not found: {path}"
        )

    print(f"\nLoading {dataset_name}: {path}")

    df = pd.read_parquet(path)

    missing = [
        column
        for column in REQUIRED_COLUMNS
        if column not in df.columns
    ]

    if missing:
        raise ValueError(
            f"{dataset_name}: missing columns: {missing}"
        )

    df["trading_day"] = pd.to_datetime(
        df["trading_day"],
        errors="coerce"
    )

    df["target_class"] = pd.to_numeric(
        df["target_class"],
        errors="coerce"
    )

    df = df.dropna(
        subset=["trading_day", "target_class"]
    ).copy()

    df["target_class"] = df["target_class"].astype(int)

    invalid_classes = sorted(
        set(df["target_class"].unique()) - {0, 1, 2}
    )

    if invalid_classes:
        raise ValueError(
            f"{dataset_name}: unexpected target classes "
            f"{invalid_classes}"
        )

    df["year"] = df["trading_day"].dt.year

    train_df = df[
        (df["year"] >= TRAIN_START_YEAR)
        & (df["year"] <= TRAIN_END_YEAR)
        ].copy()

    validation_df = df[
        df["year"] == VALIDATION_YEAR
        ].copy()

    if train_df.empty or validation_df.empty:
        raise ValueError(
            f"{dataset_name}: empty training or validation data"
        )

    train_df = train_df.sort_values(
        ["trading_day"]
    ).reset_index(drop=True)

    validation_df = validation_df.sort_values(
        ["trading_day"]
    ).reset_index(drop=True)

    # Convert features to numeric.
    # LightGBM handles missing numeric values natively.
    for column in FEATURES:

        train_df[column] = pd.to_numeric(
            train_df[column],
            errors="coerce"
        )

        validation_df[column] = pd.to_numeric(
            validation_df[column],
            errors="coerce"
        )

    # Replace infinite values with NaN.
    X_train = (
        train_df[FEATURES]
        .replace([np.inf, -np.inf], np.nan)
    )

    X_val = (
        validation_df[FEATURES]
        .replace([np.inf, -np.inf], np.nan)
    )

    y_train = train_df["target_class"]
    y_val = validation_df["target_class"]

    # Remove features that are entirely missing in training.
    usable_features = [
        column
        for column in FEATURES
        if X_train[column].notna().any()
    ]

    X_train = X_train[usable_features]
    X_val = X_val[usable_features]

    print("Training observations:", len(X_train))
    print("Validation observations:", len(X_val))
    print("Training features:", len(usable_features))

    print("\nTraining class distribution:")
    print(
        y_train.value_counts(normalize=True)
        .sort_index()
        .mul(100)
        .round(2)
    )

    print("\nValidation class distribution:")
    print(
        y_val.value_counts(normalize=True)
        .sort_index()
        .mul(100)
        .round(2)
    )

    return (
        train_df,
        validation_df,
        X_train,
        X_val,
        y_train,
        y_val,
        usable_features,
    )


# ============================================================
# METRICS
# ============================================================

def evaluate_model(
        dataset_name,
        y_true,
        probabilities,
        validation_df,
        best_iteration,
):

    predicted = np.argmax(
        probabilities,
        axis=1
    )

    accuracy = accuracy_score(
        y_true,
        predicted
    )

    balanced_accuracy = balanced_accuracy_score(
        y_true,
        predicted
    )

    macro_f1 = f1_score(
        y_true,
        predicted,
        labels=CLASS_LABELS,
        average="macro",
        zero_division=0,
    )

    loss = log_loss(
        y_true,
        probabilities,
        labels=CLASS_LABELS,
    )

    precision, recall, f1, support = (
        precision_recall_fscore_support(
            y_true,
            predicted,
            labels=CLASS_LABELS,
            zero_division=0,
        )
    )

    matrix = confusion_matrix(
        y_true,
        predicted,
        labels=CLASS_LABELS,
    )

    total = len(predicted)

    predicted_distribution = {
        class_id: (
            float(np.mean(predicted == class_id) * 100)
        )
        for class_id in CLASS_LABELS
    }

    actual_distribution = {
        class_id: (
            float(np.mean(np.asarray(y_true) == class_id) * 100)
        )
        for class_id in CLASS_LABELS
    }

    metrics = {
        "dataset": dataset_name,
        "observations": total,
        "best_iteration": int(best_iteration or 0),

        "accuracy": float(accuracy),
        "balanced_accuracy": float(balanced_accuracy),
        "macro_f1": float(macro_f1),
        "log_loss": float(loss),

        "actual_down_pct": actual_distribution[0],
        "actual_sideways_pct": actual_distribution[1],
        "actual_up_pct": actual_distribution[2],

        "pred_down_pct": predicted_distribution[0],
        "pred_sideways_pct": predicted_distribution[1],
        "pred_up_pct": predicted_distribution[2],

        "down_precision": float(precision[0]),
        "down_recall": float(recall[0]),
        "down_f1": float(f1[0]),

        "sideways_precision": float(precision[1]),
        "sideways_recall": float(recall[1]),
        "sideways_f1": float(f1[1]),

        "up_precision": float(precision[2]),
        "up_recall": float(recall[2]),
        "up_f1": float(f1[2]),
    }

    # Confusion matrix output.
    confusion_rows = []

    for actual_id in CLASS_LABELS:
        for predicted_id in CLASS_LABELS:

            confusion_rows.append({
                "dataset": dataset_name,
                "actual_class": CLASS_NAMES[actual_id],
                "predicted_class": CLASS_NAMES[predicted_id],
                "count": int(
                    matrix[actual_id, predicted_id]
                ),
            })

    # Prediction output.
    predictions = pd.DataFrame({
        "trading_day": validation_df["trading_day"].values,
        "actual_class": np.asarray(y_true),
        "predicted_class": predicted,
        "prob_down": probabilities[:, 0],
        "prob_sideways": probabilities[:, 1],
        "prob_up": probabilities[:, 2],
        "max_probability": probabilities.max(axis=1),
    })

    return metrics, confusion_rows, predictions


# ============================================================
# MAIN TRAINING LOOP
# ============================================================

def main():

    summary_rows = []
    confusion_rows_all = []
    class_rows = []
    validation_prediction_paths = []

    for index_name, horizon in DATASETS:

        dataset_name = f"{index_name}_{horizon}"

        print("\n" + "=" * 75)
        print("WEIGHTED CLASSIFIER:", dataset_name.upper())
        print("=" * 75)

        (
            train_df,
            validation_df,
            X_train,
            X_val,
            y_train,
            y_val,
            usable_features,
        ) = load_dataset(index_name, horizon)

        # ----------------------------------------------------
        # Train
        # ----------------------------------------------------

        model = create_classifier()

        model.fit(
            X_train,
            y_train,

            eval_set=[
                (X_val, y_val)
            ],

            eval_metric="multi_logloss",

            callbacks=[
                lgb.early_stopping(
                    stopping_rounds=100,
                    first_metric_only=True,
                    verbose=True,
                ),
                lgb.log_evaluation(
                    period=100
                ),
            ],
        )

        best_iteration = (
            model.best_iteration_
            if model.best_iteration_
            else model.n_estimators
        )

        print("\nBest iteration:", best_iteration)

        # ----------------------------------------------------
        # Validation predictions
        # ----------------------------------------------------

        probabilities = model.predict_proba(
            X_val,
            num_iteration=best_iteration,
        )

        (
            metrics,
            confusion_rows,
            predictions,
        ) = evaluate_model(
            dataset_name,
            y_val,
            probabilities,
            validation_df,
            best_iteration,
        )

        summary_rows.append(metrics)
        confusion_rows_all.extend(confusion_rows)

        print("\nValidation metrics:")

        for key, value in metrics.items():
            if key != "dataset":
                print(f"{key}: {value}")

        # ----------------------------------------------------
        # Save model
        # ----------------------------------------------------

        dataset_model_dir = MODEL_DIR / dataset_name

        dataset_model_dir.mkdir(
            parents=True,
            exist_ok=True
        )

        model_path = (
                dataset_model_dir / "classifier.txt"
        )

        model.booster_.save_model(
            str(model_path),
            num_iteration=best_iteration,
        )

        # ----------------------------------------------------
        # Save metadata
        # ----------------------------------------------------

        metadata = {
            "dataset": dataset_name,
            "model_type": "LightGBM weighted multiclass classifier",
            "training_years": [
                TRAIN_START_YEAR,
                TRAIN_END_YEAR,
            ],
            "validation_year": VALIDATION_YEAR,
            "test_years_used": [],
            "holdout_years_used": [],
            "class_mapping": CLASS_NAMES,
            "class_weights": CLASS_WEIGHTS,
            "features": usable_features,
            "best_iteration": int(best_iteration),
            "parameters": model.get_params(),
            "validation_metrics": metrics,
        }

        metadata_path = (
                dataset_model_dir / "classifier_metadata.json"
        )

        with open(
                metadata_path,
                "w",
                encoding="utf-8"
        ) as file:

            json.dump(
                metadata,
                file,
                indent=2,
                default=str,
            )

        # ----------------------------------------------------
        # Save validation predictions
        # ----------------------------------------------------

        prediction_path = (
                RESULT_DIR
                / f"{dataset_name}_validation_predictions.parquet"
        )

        predictions.to_parquet(
            prediction_path,
            index=False,
        )

        validation_prediction_paths.append(
            str(prediction_path)
        )

        # ----------------------------------------------------
        # Save feature importance
        # ----------------------------------------------------

        importance = pd.DataFrame({
            "feature": usable_features,
            "importance": model.feature_importances_,
        })

        importance = importance.sort_values(
            "importance",
            ascending=False
        )

        importance.to_csv(
            RESULT_DIR / f"{dataset_name}_feature_importance.csv",
            index=False,
            )

        # ----------------------------------------------------
        # Class metrics
        # ----------------------------------------------------

        for class_id in CLASS_LABELS:

            class_rows.append({
                "dataset": dataset_name,
                "class": CLASS_NAMES[class_id],
                "precision": metrics[
                    f"{CLASS_NAMES[class_id].lower()}_precision"
                ],
                "recall": metrics[
                    f"{CLASS_NAMES[class_id].lower()}_recall"
                ],
                "f1": metrics[
                    f"{CLASS_NAMES[class_id].lower()}_f1"
                ],
            })

        print("\nSaved model:", model_path)

    # ========================================================
    # SAVE COMBINED REPORTS
    # ========================================================

    summary = pd.DataFrame(summary_rows)

    summary.to_csv(
        RESULT_DIR / "weighted_validation_summary.csv",
        index=False,
        )

    pd.DataFrame(confusion_rows_all).to_csv(
        RESULT_DIR / "weighted_confusion_matrices.csv",
        index=False,
        )

    pd.DataFrame(class_rows).to_csv(
        RESULT_DIR / "weighted_class_metrics.csv",
        index=False,
        )

    print("\n" + "=" * 75)
    print("WEIGHTED EXPERIMENT COMPLETED")
    print("=" * 75)

    print("\nValidation summary:")
    print(
        summary[
            [
                "dataset",
                "accuracy",
                "balanced_accuracy",
                "macro_f1",
                "log_loss",
                "down_recall",
                "up_recall",
                "pred_sideways_pct",
                "best_iteration",
            ]
        ].round(4).to_string(index=False)
    )

    print("\nReports:", RESULT_DIR)
    print("Models:", MODEL_DIR)


if __name__ == "__main__":
    main()
