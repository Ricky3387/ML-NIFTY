
from pathlib import Path
import duckdb
import pandas as pd

# ============================================================
# CONFIGURATION
# ============================================================

ROOT = Path(__file__).resolve().parents[1]

DB_PATH = (
        ROOT / "data" / "database" / "nifty_options.duckdb"
)

OUT_DIR = (
        ROOT / "reports" / "raw_timestamp_audit_v2"
)

OUT_DIR.mkdir(parents=True, exist_ok=True)

con = duckdb.connect(str(DB_PATH), read_only=True)

print("=" * 90)
print("RAW TIMESTAMP CONVENTION AUDIT V2")
print("=" * 90)

print("Database:", DB_PATH)
print("Output:", OUT_DIR)
print("Detected timestamp type will be inspected.")
print("UTC and IST will be extracted using timezone().")

if not DB_PATH.exists():
    raise FileNotFoundError(DB_PATH)

# ============================================================
# 1. INSPECT ORIGINAL SCHEMA
# ============================================================

print("\n" + "=" * 90)
print("1. ORIGINAL TIMESTAMP SCHEMA")
print("=" * 90)

for view in ["nifty_index", "nifty_options"]:
    schema = con.execute(
        f'DESCRIBE SELECT * FROM "{view}"'
    ).fetchdf()

    print(f"\n{view}")
    print(schema.to_string(index=False))

# ============================================================
# 2. INDEX TIMESTAMP SUMMARY
# ============================================================

print("\n" + "=" * 90)
print("2. INDEX TIMESTAMP SUMMARY")
print("=" * 90)

index_summary_query = """
                      WITH base AS (
                          SELECT
                          timestamp,
                          trading_day,

                          timezone('UTC', timestamp) AS utc_timestamp,

                          timezone(
                          'Asia/Kolkata', timestamp
                          ) AS ist_timestamp

                      FROM nifty_index
                          ),
                          classified AS (
                      SELECT
                          *,

                          CAST(utc_timestamp AS DATE) AS utc_date,
                          CAST(utc_timestamp AS TIME) AS utc_time,

                          CAST(ist_timestamp AS DATE) AS ist_date,
                          CAST(ist_timestamp AS TIME) AS ist_time,

                          CASE
                          WHEN CAST(utc_timestamp AS TIME)
                          BETWEEN TIME '09:00:00' AND TIME '09:14:00'
                          THEN 1 ELSE 0
                          END AS utc_preopen,

                          CASE
                          WHEN CAST(ist_timestamp AS TIME)
                          BETWEEN TIME '09:00:00' AND TIME '09:14:00'
                          THEN 1 ELSE 0
                          END AS ist_preopen,

                          CASE
                          WHEN CAST(utc_timestamp AS TIME)
                          BETWEEN TIME '09:15:00' AND TIME '15:29:00'
                          THEN 1 ELSE 0
                          END AS utc_regular,

                          CASE
                          WHEN CAST(ist_timestamp AS TIME)
                          BETWEEN TIME '09:15:00' AND TIME '15:29:00'
                          THEN 1 ELSE 0
                          END AS ist_regular

                      FROM base
                          )
                      SELECT
                          COUNT(*) AS total_rows,

                          COUNT(DISTINCT trading_day) AS trading_days,

                          MIN(utc_timestamp) AS minimum_utc_timestamp,
                          MAX(utc_timestamp) AS maximum_utc_timestamp,

                          MIN(ist_timestamp) AS minimum_ist_timestamp,
                          MAX(ist_timestamp) AS maximum_ist_timestamp,

                          SUM(utc_preopen) AS utc_preopen_rows,
                          SUM(ist_preopen) AS ist_preopen_rows,

                          SUM(utc_regular) AS utc_regular_rows,
                          SUM(ist_regular) AS ist_regular_rows,

                          ROUND(
                                  100.0 * SUM(utc_regular) / COUNT(*), 3
                          ) AS utc_regular_session_pct,

                          ROUND(
                                  100.0 * SUM(ist_regular) / COUNT(*), 3
                          ) AS ist_regular_session_pct,

                          SUM(
                                  CASE
                                      WHEN utc_date = CAST(trading_day AS DATE)
                                          THEN 1 ELSE 0
                                      END
                          ) AS utc_date_matches_trading_day,

                          SUM(
                                  CASE
                                      WHEN ist_date = CAST(trading_day AS DATE)
                                          THEN 1 ELSE 0
                                      END
                          ) AS ist_date_matches_trading_day

                      FROM classified \
                      """

index_summary = con.execute(
    index_summary_query
).fetchdf()

print(index_summary.to_string(index=False))

index_summary.to_csv(
    OUT_DIR / "index_timestamp_summary.csv",
    index=False
)

# ============================================================
# 3. DAILY TIMESTAMP PROFILE
# ============================================================

print("\n" + "=" * 90)
print("3. DAILY TIMESTAMP PROFILE")
print("=" * 90)

daily_query = """
              WITH base AS (
                  SELECT
                      CAST(trading_day AS DATE) AS trading_day,

                      timezone('UTC', timestamp) AS utc_timestamp,

                      timezone(
                              'Asia/Kolkata', timestamp
                      ) AS ist_timestamp

                  FROM nifty_index
              )
              SELECT
                  trading_day,

                  COUNT(*) AS observed_rows,

                  MIN(utc_timestamp) AS first_utc_timestamp,
                  MAX(utc_timestamp) AS last_utc_timestamp,

                  MIN(ist_timestamp) AS first_ist_timestamp,
                  MAX(ist_timestamp) AS last_ist_timestamp,

                  MIN(CAST(ist_timestamp AS TIME)) AS first_ist_clock,
                  MAX(CAST(ist_timestamp AS TIME)) AS last_ist_clock,

                  SUM(
                          CASE
                              WHEN CAST(ist_timestamp AS TIME)
                                  BETWEEN TIME '09:00:00' AND TIME '09:14:00'
                                  THEN 1 ELSE 0
                              END
                  ) AS preopen_rows,

                  SUM(
                          CASE
                              WHEN CAST(ist_timestamp AS TIME)
                                  BETWEEN TIME '09:15:00' AND TIME '15:29:00'
                                  THEN 1 ELSE 0
                              END
                  ) AS regular_rows

              FROM base
              GROUP BY trading_day
              ORDER BY trading_day \
              """

daily_profile = con.execute(
    daily_query
).fetchdf()

print("\nFirst 20 trading days:")
print(daily_profile.head(20).to_string(index=False))

print("\nLast 10 trading days:")
print(daily_profile.tail(10).to_string(index=False))

daily_profile.to_csv(
    OUT_DIR / "index_daily_timestamp_profile.csv",
    index=False
)

# ============================================================
# 4. INDEX OPENING SAMPLES
# ============================================================

print("\n" + "=" * 90)
print("4. INDEX OPENING SAMPLES")
print("=" * 90)

opening_query = """
                SELECT
                    timezone('UTC', timestamp) AS utc_timestamp,

                    timezone(
                            'Asia/Kolkata', timestamp
                    ) AS ist_timestamp,

                    trading_day,

                    open,
                    high,
                    low,
                    close,
                    volume

                FROM nifty_index

                WHERE CAST(trading_day AS DATE) BETWEEN
                    DATE '2021-05-24'
                  AND DATE '2021-05-28'

                ORDER BY timestamp

                    LIMIT 150 \
                """

opening_samples = con.execute(
    opening_query
).fetchdf()

print(opening_samples.head(50).to_string(index=False))

opening_samples.to_csv(
    OUT_DIR / "index_opening_samples.csv",
    index=False
)

# ============================================================
# 5. OPTIONS TIMESTAMP SUMMARY
# ============================================================

print("\n" + "=" * 90)
print("5. OPTIONS TIMESTAMP SUMMARY")
print("=" * 90)

options_query = """
                WITH base AS (
                    SELECT
                    timestamp,
                    trading_day,
                    expiry,
                    strike,

                    timezone('UTC', timestamp) AS utc_timestamp,

                    timezone(
                    'Asia/Kolkata', timestamp
                    ) AS ist_timestamp

                FROM nifty_options
                    )
                SELECT
                    COUNT(*) AS total_rows,

                    COUNT(DISTINCT trading_day) AS trading_days,

                    COUNT(DISTINCT expiry) AS distinct_expiries,

                    COUNT(DISTINCT strike) AS distinct_strikes,

                    MIN(utc_timestamp) AS minimum_utc_timestamp,
                    MAX(utc_timestamp) AS maximum_utc_timestamp,

                    MIN(ist_timestamp) AS minimum_ist_timestamp,
                    MAX(ist_timestamp) AS maximum_ist_timestamp,

                    MIN(CAST(ist_timestamp AS TIME)) AS earliest_ist_clock,
                    MAX(CAST(ist_timestamp AS TIME)) AS latest_ist_clock,

                    SUM(
                            CASE
                                WHEN CAST(ist_timestamp AS TIME)
                                    BETWEEN TIME '09:00:00' AND TIME '09:14:00'
                                    THEN 1 ELSE 0
                                END
                    ) AS preopen_rows,

                    SUM(
                            CASE
                                WHEN CAST(ist_timestamp AS TIME)
                                    BETWEEN TIME '09:15:00' AND TIME '15:29:00'
                                    THEN 1 ELSE 0
                                END
                    ) AS regular_session_rows

                FROM base \
                """

options_summary = con.execute(
    options_query
).fetchdf()

print(options_summary.to_string(index=False))

options_summary.to_csv(
    OUT_DIR / "options_timestamp_summary.csv",
    index=False
)

# ============================================================
# 6. OPTIONS SAMPLE
# ============================================================

print("\n" + "=" * 90)
print("6. OPTIONS SAMPLE")
print("=" * 90)

options_sample_query = """
                       SELECT
                           timezone('UTC', timestamp) AS utc_timestamp,

                           timezone(
                                   'Asia/Kolkata', timestamp
                           ) AS ist_timestamp,

                           trading_day,
                           symbol,
                           strike,
                           option_type,
                           expiry,

                           open,
                           high,
                           low,
                           close,
                           volume,
                           open_interest

                       FROM nifty_options

                       ORDER BY timestamp

                           LIMIT 30 \
                       """

options_samples = con.execute(
    options_sample_query
).fetchdf()

print(options_samples.to_string(index=False))

options_samples.to_csv(
    OUT_DIR / "options_samples.csv",
    index=False
)

# ============================================================
# 7. VERIFY THE KNOWN EPOCH EXAMPLE
# ============================================================

print("\n" + "=" * 90)
print("7. EPOCH EXAMPLE VALIDATION")
print("=" * 90)

epoch_query = """
SELECT
    timezone(
        'UTC',
        make_timestamptz(2023, 9, 25, 4, 0, 0)
    ) AS utc_time,

    timezone(
        'Asia/Kolkata',
        make_timestamptz(2023, 9, 25, 4, 0, 0)
    ) AS ist_time
"""

epoch_result = con.execute(
    epoch_query
).fetchdf()

print(epoch_result.to_string(index=False))

# ============================================================
# 8. FINISH
# ============================================================

con.close()

print("\n" + "=" * 90)
print("AUDIT V2 COMPLETED")
print("=" * 90)

print("Output directory:", OUT_DIR)

for file in sorted(OUT_DIR.glob("*.csv")):
    print("Generated:", file.name)

print("\nOriginal DuckDB database was not modified.")
print("Existing cleaned datasets were not modified.")

print("\nPlease share:")
print("1. index_timestamp_summary.csv output")
print("2. First 20 daily timestamp profile rows")
print("3. options_timestamp_summary.csv output")
print("4. Epoch example validation")
