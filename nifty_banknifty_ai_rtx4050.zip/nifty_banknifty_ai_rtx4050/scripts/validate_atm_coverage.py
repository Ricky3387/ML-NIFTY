
from pathlib import Path
import duckdb
import pandas as pd

BASE = Path(__file__).resolve().parent.parent
DB = BASE / "data" / "database" / "nifty_options.duckdb"
OUT = BASE / "data" / "reports"
TEMP = BASE / "data" / "duckdb_temp"

OUT.mkdir(parents=True, exist_ok=True)
TEMP.mkdir(parents=True, exist_ok=True)

DATASETS = {
    "NIFTY": ("nifty_options", "nifty_index"),
    "BANKNIFTY": ("banknifty_options", "banknifty_index"),
}

BANDS = (0.5, 1.0, 2.0)

con = duckdb.connect(str(DB), read_only=False)
con.execute("SET threads = 4")
con.execute("SET memory_limit = '6GB'")
con.execute(f"SET temp_directory = '{TEMP.as_posix()}'")
con.execute("SET TimeZone = 'Asia/Kolkata'")

def validate_index(index_name, options_view, index_view):
    print("\n" + "=" * 85)
    print(f"{index_name} ATM COVERAGE VALIDATION")
    print("=" * 85)

    # Build one row per expiry/strike/minute where at least one option
    # side has an observation. CE and PE are paired only when both exist
    # for the same expiry, strike and timestamp.
    con.execute("DROP TABLE IF EXISTS atm_contract_slots")

    build_sql = f"""
        CREATE TEMP TABLE atm_contract_slots AS
        WITH matched AS (
            SELECT
                o.trading_day,
                o.timestamp,
                CAST(o.expiry AS DATE) AS expiry,
                CAST(o.strike AS DOUBLE) AS strike,
                CAST(i.close AS DOUBLE) AS spot_close,
                o.option_type
            FROM {options_view} o
            INNER JOIN {index_view} i
                ON o.timestamp = i.timestamp
               AND o.trading_day = i.trading_day
            WHERE
                i.close IS NOT NULL
                AND CAST(i.close AS DOUBLE) > 0
                AND o.strike IS NOT NULL
                AND o.expiry IS NOT NULL
                AND o.option_type IN ('CE', 'PE')
        ),
        grouped AS (
            SELECT
                trading_day,
                timestamp,
                expiry,
                strike,
                MAX(spot_close) AS spot_close,
                MAX(CASE WHEN option_type = 'CE' THEN 1 ELSE 0 END) AS has_ce,
                MAX(CASE WHEN option_type = 'PE' THEN 1 ELSE 0 END) AS has_pe
            FROM matched
            GROUP BY
                trading_day,
                timestamp,
                expiry,
                strike
        )
        SELECT
            trading_day,
            timestamp,
            expiry,
            strike,
            spot_close,
            ABS(strike - spot_close) / spot_close * 100.0 AS atm_distance_pct,
            has_ce,
            has_pe,
            CASE
                WHEN has_ce = 1 AND has_pe = 1 THEN 1
                ELSE 0
            END AS is_paired,
            DATE_DIFF(
    'day',
    CAST(trading_day AS DATE),
    CAST(expiry AS DATE)
) AS days_to_expiry
        FROM grouped
    """

    print("Building matched ATM contract-minute observations...")
    con.execute(build_sql)

    slot_count = con.execute(
        "SELECT COUNT(*) FROM atm_contract_slots"
    ).fetchone()[0]
    print(f"Contract-minute slots built: {slot_count:,}")

    bands_sql = """
        (VALUES (0.5), (1.0), (2.0)) AS b(band_pct)
    """

    # Daily metrics by ATM band.
    daily_sql = f"""
        WITH index_daily AS (
            SELECT
                trading_day,
                COUNT(DISTINCT timestamp) AS index_minutes
            FROM {index_view}
            GROUP BY trading_day
        ),
        band_metrics AS (
            SELECT
                s.trading_day,
                b.band_pct,

                COUNT(*) AS eligible_contract_minute_slots,

                SUM(s.has_ce) AS ce_contract_minute_slots,
                SUM(s.has_pe) AS pe_contract_minute_slots,
                SUM(s.is_paired) AS paired_contract_minute_slots,

                COUNT(DISTINCT s.timestamp)
                    FILTER (WHERE s.has_ce = 1) AS minutes_with_ce,

                COUNT(DISTINCT s.timestamp)
                    FILTER (WHERE s.has_pe = 1) AS minutes_with_pe,

                COUNT(DISTINCT s.timestamp)
                    FILTER (WHERE s.is_paired = 1) AS minutes_with_same_strike_ce_pe,

                COUNT(DISTINCT s.expiry) AS expiries_in_band,
                COUNT(DISTINCT s.strike) AS strikes_in_band,

                COUNT(DISTINCT s.timestamp) AS option_minutes_in_band,

                AVG(s.atm_distance_pct) AS avg_distance_pct,
                MIN(s.atm_distance_pct) AS closest_distance_pct,

                SUM(CASE WHEN s.days_to_expiry = 0 THEN 1 ELSE 0 END)
                    AS expiry_day_slots

            FROM atm_contract_slots s
            CROSS JOIN {bands_sql}
            WHERE s.atm_distance_pct <= b.band_pct
            GROUP BY s.trading_day, b.band_pct
        )
        SELECT
            m.trading_day,
            m.band_pct,
            m.eligible_contract_minute_slots,
            m.ce_contract_minute_slots,
            m.pe_contract_minute_slots,
            m.paired_contract_minute_slots,

            ROUND(
                100.0 * m.paired_contract_minute_slots
                / NULLIF(m.eligible_contract_minute_slots, 0),
                2
            ) AS paired_slot_percentage,

            m.minutes_with_ce,
            m.minutes_with_pe,
            m.minutes_with_same_strike_ce_pe,
            COALESCE(i.index_minutes, 0) AS index_minutes,

            ROUND(
                100.0 * m.minutes_with_ce
                / NULLIF(i.index_minutes, 0),
                2
            ) AS ce_minute_coverage_pct,

            ROUND(
                100.0 * m.minutes_with_pe
                / NULLIF(i.index_minutes, 0),
                2
            ) AS pe_minute_coverage_pct,

            ROUND(
                100.0 * m.minutes_with_same_strike_ce_pe
                / NULLIF(i.index_minutes, 0),
                2
            ) AS paired_minute_coverage_pct,

            m.expiries_in_band,
            m.strikes_in_band,
            m.option_minutes_in_band,
            ROUND(m.avg_distance_pct, 4) AS avg_distance_pct,
            ROUND(m.closest_distance_pct, 4) AS closest_distance_pct,
            m.expiry_day_slots

        FROM band_metrics m
        LEFT JOIN index_daily i USING (trading_day)
        ORDER BY m.trading_day, m.band_pct
    """

    print("Calculating daily ATM-band coverage...")
    daily = con.execute(daily_sql).df()

    daily_file = OUT / f"{index_name.lower()}_atm_coverage_daily.csv"
    daily.to_csv(daily_file, index=False)

    # Expiry-level metrics help identify whether coverage is concentrated
    # in the nearest expiry or spread across multiple expiries.
    expiry_sql = f"""
        SELECT
            s.trading_day,
            s.expiry,
            s.days_to_expiry,
            b.band_pct,

            COUNT(*) AS eligible_contract_minute_slots,
            SUM(s.has_ce) AS ce_contract_minute_slots,
            SUM(s.has_pe) AS pe_contract_minute_slots,
            SUM(s.is_paired) AS paired_contract_minute_slots,

            ROUND(
                100.0 * SUM(s.is_paired) / NULLIF(COUNT(*), 0),
                2
            ) AS paired_slot_percentage,

            COUNT(DISTINCT s.strike) AS strikes_in_band,
            COUNT(DISTINCT s.timestamp) AS option_minutes_in_band,

            COUNT(DISTINCT s.timestamp)
                FILTER (WHERE s.has_ce = 1) AS minutes_with_ce,

            COUNT(DISTINCT s.timestamp)
                FILTER (WHERE s.has_pe = 1) AS minutes_with_pe,

            COUNT(DISTINCT s.timestamp)
                FILTER (WHERE s.is_paired = 1) AS minutes_with_same_strike_ce_pe

        FROM atm_contract_slots s
        CROSS JOIN {bands_sql}
        WHERE s.atm_distance_pct <= b.band_pct
        GROUP BY
            s.trading_day,
            s.expiry,
            s.days_to_expiry,
            b.band_pct
        ORDER BY
            s.trading_day,
            s.days_to_expiry,
            b.band_pct
    """

    print("Calculating expiry-level ATM coverage...")
    expiry = con.execute(expiry_sql).df()

    expiry_file = OUT / f"{index_name.lower()}_atm_coverage_by_expiry.csv"
    expiry.to_csv(expiry_file, index=False)

    # Weighted overall metrics. These are based on contract-minute slots,
    # not averages of daily percentages.
    summary = (
        daily.groupby("band_pct", as_index=False)
        .agg(
            trading_days=("trading_day", "nunique"),
            total_slots=("eligible_contract_minute_slots", "sum"),
            ce_slots=("ce_contract_minute_slots", "sum"),
            pe_slots=("pe_contract_minute_slots", "sum"),
            paired_slots=("paired_contract_minute_slots", "sum"),
            total_index_minutes=("index_minutes", "sum"),
            paired_minutes=("minutes_with_same_strike_ce_pe", "sum"),
            ce_minutes=("minutes_with_ce", "sum"),
            pe_minutes=("minutes_with_pe", "sum"),
        )
    )

    summary["paired_slot_percentage"] = (
            100 * summary["paired_slots"] / summary["total_slots"].replace(0, pd.NA)
    ).round(2)

    summary["paired_minute_coverage_pct"] = (
            100 * summary["paired_minutes"]
            / summary["total_index_minutes"].replace(0, pd.NA)
    ).round(2)

    summary["ce_minute_coverage_pct"] = (
            100 * summary["ce_minutes"]
            / summary["total_index_minutes"].replace(0, pd.NA)
    ).round(2)

    summary["pe_minute_coverage_pct"] = (
            100 * summary["pe_minutes"]
            / summary["total_index_minutes"].replace(0, pd.NA)
    ).round(2)

    summary_file = OUT / f"{index_name.lower()}_atm_coverage_summary.csv"
    summary.to_csv(summary_file, index=False)

    print("\nOVERALL ATM COVERAGE BY BAND")
    print(summary.to_string(index=False))

    print("\nDAILY COVERAGE STATISTICS")
    cols = [
        "band_pct",
        "eligible_contract_minute_slots",
        "paired_slot_percentage",
        "ce_minute_coverage_pct",
        "pe_minute_coverage_pct",
        "paired_minute_coverage_pct",
    ]
    print(daily[cols].groupby("band_pct").describe().round(2).to_string())

    print("\nLOWEST PAIRED-MINUTE COVERAGE DAYS (±1% BAND)")
    low = daily[daily["band_pct"] == 1.0].nsmallest(
        15, "paired_minute_coverage_pct"
    )
    print(
        low[
            [
                "trading_day",
                "eligible_contract_minute_slots",
                "paired_slot_percentage",
                "ce_minute_coverage_pct",
                "pe_minute_coverage_pct",
                "paired_minute_coverage_pct",
            ]
        ].to_string(index=False)
    )

    print("\nSAVED:")
    print(daily_file)
    print(expiry_file)
    print(summary_file)

    con.execute("DROP TABLE IF EXISTS atm_contract_slots")


try:
    for index_name, (options_view, index_view) in DATASETS.items():
        validate_index(index_name, options_view, index_view)

    print("\nATM COVERAGE VALIDATION FINISHED SUCCESSFULLY.")

finally:
    con.close()
