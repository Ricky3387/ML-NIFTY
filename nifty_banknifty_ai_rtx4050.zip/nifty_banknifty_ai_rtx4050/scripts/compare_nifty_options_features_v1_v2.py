
from __future__ import annotations

import json
import sys
import traceback
from datetime import datetime
from pathlib import Path

import duckdb
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]

V1_FILE = (
        ROOT / "data/processed/nifty_options_features_v1/"
               "nifty_options_features_v1.parquet"
)

V2_FILE = (
        ROOT / "data/processed/nifty_options_features_v2/"
               "nifty_options_features_v2.parquet"
)

REPORT_DIR = ROOT / "reports/nifty_options_v1_v2_preservation_audit"

KEY_COLUMNS = ["timestamp_ist"]

ROLLING_COLUMNS = {
    "atm_ce_volume_sum_5m",
    "atm_pe_volume_sum_5m",
    "atm_volume_imbalance_5m",
    "atm_ce_volume_sum_15m",
    "atm_pe_volume_sum_15m",
    "atm_volume_imbalance_15m",
    "atm_ce_volume_sum_30m",
    "atm_pe_volume_sum_30m",
    "atm_volume_imbalance_30m",
}


def qpath(path: Path) -> str:
    return "'" + str(path).replace("\\", "/").replace("'", "''") + "'"


def main():
    if not V1_FILE.exists():
        raise FileNotFoundError(V1_FILE)

    if not V2_FILE.exists():
        raise FileNotFoundError(V2_FILE)

    REPORT_DIR.mkdir(parents=True, exist_ok=True)

    con = duckdb.connect(":memory:")
    con.execute("SET threads TO 4")

    try:
        v1_path = qpath(V1_FILE)
        v2_path = qpath(V2_FILE)

        con.execute(f"""
            CREATE VIEW v1 AS
            SELECT * FROM read_parquet({v1_path})
        """)

        con.execute(f"""
            CREATE VIEW v2 AS
            SELECT * FROM read_parquet({v2_path})
        """)

        log = lambda msg: print(
            f"[{datetime.now():%H:%M:%S}] {msg}"
        )

        log("Inspecting v1 and v2 schemas")

        schema1 = con.execute(
            f"DESCRIBE SELECT * FROM read_parquet({v1_path})"
        ).df()

        schema2 = con.execute(
            f"DESCRIBE SELECT * FROM read_parquet({v2_path})"
        ).df()

        columns1 = schema1["column_name"].tolist()
        columns2 = schema2["column_name"].tolist()

        schema1.to_csv(
            REPORT_DIR / "v1_schema.csv", index=False
        )
        schema2.to_csv(
            REPORT_DIR / "v2_schema.csv", index=False
        )

        missing_v2 = sorted(set(columns1) - set(columns2))
        added_v2 = sorted(set(columns2) - set(columns1))

        type_changes = []

        types1 = dict(zip(schema1["column_name"], schema1["column_type"]))
        types2 = dict(zip(schema2["column_name"], schema2["column_type"]))

        for col in sorted(set(columns1) & set(columns2)):
            if types1[col] != types2[col]:
                type_changes.append({
                    "column": col,
                    "v1_type": types1[col],
                    "v2_type": types2[col],
                })

        pd.DataFrame(type_changes).to_csv(
            REPORT_DIR / "column_type_changes.csv",
            index=False,
            )

        if missing_v2 or added_v2:
            raise ValueError(
                f"Schema column differences. "
                f"Missing in v2={missing_v2}; added in v2={added_v2}"
            )

        missing_keys = [
            c for c in KEY_COLUMNS
            if c not in columns1 or c not in columns2
        ]

        if missing_keys:
            raise ValueError(f"Missing key columns: {missing_keys}")

        nonrolling_columns = [
            c for c in columns1
            if c not in ROLLING_COLUMNS
        ]

        missing_rolling = sorted(
            ROLLING_COLUMNS.intersection(columns1)
            - ROLLING_COLUMNS.intersection(columns2)
        )

        if missing_rolling:
            raise ValueError(
                f"Rolling columns missing from v2: {missing_rolling}"
            )

        log("Checking row counts and timestamp uniqueness")

        counts = {}

        counts["v1_rows"] = con.execute(
            "SELECT COUNT(*) FROM v1"
        ).fetchone()[0]

        counts["v2_rows"] = con.execute(
            "SELECT COUNT(*) FROM v2"
        ).fetchone()[0]

        counts["v1_unique_timestamps"] = con.execute(
            "SELECT COUNT(DISTINCT timestamp_ist) FROM v1"
        ).fetchone()[0]

        counts["v2_unique_timestamps"] = con.execute(
            "SELECT COUNT(DISTINCT timestamp_ist) FROM v2"
        ).fetchone()[0]

        counts["v1_duplicate_groups"] = con.execute("""
                                                    SELECT COUNT(*) FROM (
                                                                             SELECT timestamp_ist
                                                                             FROM v1
                                                                             GROUP BY timestamp_ist
                                                                             HAVING COUNT(*) > 1
                                                                         )
                                                    """).fetchone()[0]

        counts["v2_duplicate_groups"] = con.execute("""
                                                    SELECT COUNT(*) FROM (
                                                                             SELECT timestamp_ist
                                                                             FROM v2
                                                                             GROUP BY timestamp_ist
                                                                             HAVING COUNT(*) > 1
                                                                         )
                                                    """).fetchone()[0]

        # ----------------------------------------------------
        # Exact comparison of all non-rolling columns.
        # EXCEPT ALL preserves duplicate multiplicity.
        # ----------------------------------------------------

        log("Comparing all non-rolling columns exactly")

        selected = ", ".join(
            f'"{c}"' for c in nonrolling_columns
        )

        differences = con.execute(f"""
            WITH v1_only AS (
                SELECT {selected} FROM v1
                EXCEPT ALL
                SELECT {selected} FROM v2
            ),
            v2_only AS (
                SELECT {selected} FROM v2
                EXCEPT ALL
                SELECT {selected} FROM v1
            )
            SELECT
                (SELECT COUNT(*) FROM v1_only) AS rows_only_in_v1,
                (SELECT COUNT(*) FROM v2_only) AS rows_only_in_v2
        """).df()

        differences.to_csv(
            REPORT_DIR / "nonrolling_exact_comparison.csv",
            index=False,
            )

        diff = differences.iloc[0].to_dict()

        # ----------------------------------------------------
        # Compare rolling columns separately.
        # These are expected to differ.
        # ----------------------------------------------------

        log("Auditing rolling feature changes")

        rolling_results = []

        for col in sorted(ROLLING_COLUMNS):
            result = con.execute(f"""
                SELECT
                    COUNT(*) AS total_rows,

                    COUNT(*) FILTER (
                        WHERE a."{col}" IS DISTINCT FROM b."{col}"
                    ) AS changed_rows,

                    COUNT(*) FILTER (
                        WHERE a."{col}" IS NULL
                          AND b."{col}" IS NOT NULL
                    ) AS became_null,

                    COUNT(*) FILTER (
                        WHERE a."{col}" IS NOT NULL
                          AND b."{col}" IS NULL
                    ) AS became_nonnull,

                    COUNT(*) FILTER (
                        WHERE a."{col}" IS NOT NULL
                          AND b."{col}" IS NOT NULL
                          AND a."{col}" <> b."{col}"
                    ) AS changed_nonnull_values

                FROM v1 a
                INNER JOIN v2 b
                    ON a.timestamp_ist = b.timestamp_ist
            """).df()

            item = result.iloc[0].to_dict()
            item["column"] = col
            rolling_results.append(item)

        rolling_df = pd.DataFrame(rolling_results)

        rolling_df.to_csv(
            REPORT_DIR / "rolling_feature_change_audit.csv",
            index=False,
            )

        # ----------------------------------------------------
        # Timestamp key coverage
        # ----------------------------------------------------

        key_coverage = con.execute("""
                                   SELECT
                                       COUNT(*) FILTER (
                    WHERE b.timestamp_ist IS NULL
                ) AS timestamps_missing_from_v2,

                                       COUNT(*) FILTER (
                    WHERE a.timestamp_ist IS NULL
                ) AS timestamps_missing_from_v1

                                   FROM v1 a
                                            FULL OUTER JOIN v2 b
                                                            ON a.timestamp_ist = b.timestamp_ist
                                   """).df()

        key_coverage.to_csv(
            REPORT_DIR / "timestamp_key_coverage.csv",
            index=False,
            )

        key_result = key_coverage.iloc[0].to_dict()

        # ----------------------------------------------------
        # Final checks
        # ----------------------------------------------------

        checks = {
            "same_row_count": counts["v1_rows"] == counts["v2_rows"],
            "v1_timestamps_unique": counts["v1_duplicate_groups"] == 0,
            "v2_timestamps_unique": counts["v2_duplicate_groups"] == 0,
            "same_unique_timestamp_count": (
                    counts["v1_unique_timestamps"]
                    == counts["v2_unique_timestamps"]
            ),
            "same_timestamp_key_coverage": (
                    int(key_result["timestamps_missing_from_v2"]) == 0
                    and int(key_result["timestamps_missing_from_v1"]) == 0
            ),
            "same_nonrolling_values_exactly": (
                    int(diff["rows_only_in_v1"]) == 0
                    and int(diff["rows_only_in_v2"]) == 0
            ),
            "same_column_types": len(type_changes) == 0,
        }

        summary = {
            "generated_at": datetime.now().isoformat(),
            "v1_file": str(V1_FILE),
            "v2_file": str(V2_FILE),
            "v1_columns": len(columns1),
            "v2_columns": len(columns2),
            "nonrolling_columns_compared": len(nonrolling_columns),
            "rolling_columns_compared": len(ROLLING_COLUMNS),
            "counts": counts,
            "timestamp_key_coverage": key_result,
            "nonrolling_exact_comparison": diff,
            "rolling_feature_changes": rolling_results,
            "column_type_changes": type_changes,
            "checks": checks,
            "passed_checks": sum(bool(v) for v in checks.values()),
            "total_checks": len(checks),
            "overall_status": (
                "PASS" if all(checks.values()) else "REVIEW_REQUIRED"
            ),
            "source_files_modified": False,
        }

        summary_path = (
                REPORT_DIR / "v1_v2_preservation_summary.json"
        )

        with open(summary_path, "w", encoding="utf-8") as f:
            json.dump(summary, f, indent=2, default=str)

        print("\n" + "=" * 76)
        print("NIFTY OPTIONS V1/V2 PRESERVATION AUDIT")
        print("=" * 76)

        print(f"V1 rows: {counts['v1_rows']:,}")
        print(f"V2 rows: {counts['v2_rows']:,}")
        print(f"Non-rolling columns compared: {len(nonrolling_columns)}")
        print(f"Rolling columns compared: {len(ROLLING_COLUMNS)}")

        print("\nNon-rolling differences:")
        print(differences.to_string(index=False))

        print("\nRolling feature changes:")
        print(rolling_df.to_string(index=False))

        print("\nChecks:")
        for name, passed in checks.items():
            print(f"{'PASS' if passed else 'FAIL'} : {name}")

        print("-" * 76)
        print(f"Overall status: {summary['overall_status']}")
        print(f"Reports: {REPORT_DIR}")
        print("=" * 76)

    finally:
        con.close()


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print("\nPRESERVATION AUDIT FAILED")
        print(str(exc))
        traceback.print_exc()
        sys.exit(1)
