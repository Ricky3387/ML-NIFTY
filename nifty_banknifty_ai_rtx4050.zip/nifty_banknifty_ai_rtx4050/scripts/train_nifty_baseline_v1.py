#!/usr/bin/env python3
"""
NIFTY baseline LightGBM training v1.

Save under <project_root>/scripts/
Run from project root:
    python scripts/train_nifty_baseline_v1.py

Inputs:
  data/processed/nifty_walkforward_v1/train_5m.parquet
  data/processed/nifty_walkforward_v1/validation_5m.parquet
  ... corresponding 15m and 30m files

Outputs:
  models/nifty_baseline_v1/model_5m.txt (and 15m/30m)
  reports/nifty_baseline_v1/metrics_by_horizon.json
  reports/nifty_baseline_v1/classification_report.csv
  reports/nifty_baseline_v1/confusion_matrix.csv
  reports/nifty_baseline_v1/feature_importance.csv
  reports/nifty_baseline_v1/training_log.txt

No test set is used. No class weights are applied. No live trading.
"""
from pathlib import Path
import json
import time
import logging
import warnings
import numpy as np
import pandas as pd
import lightgbm as lgb
from sklearn.metrics import (
    accuracy_score, balanced_accuracy_score, f1_score,
    classification_report, confusion_matrix, log_loss
)

START = time.time()
SEED = 42
LABELS = ["DOWN", "SIDEWAYS", "UP"]
LABEL_TO_ID = {name: i for i, name in enumerate(LABELS)}
HORIZONS = (5, 15, 30)

FEATURES = [
    "ret_1m", "logret_1m", "range_pct", "body_pct",
    "upper_wick_pct", "lower_wick_pct",
    "return_5m", "return_15m", "return_30m", "return_60m",
    "realized_vol_5m", "realized_vol_15m", "realized_vol_30m", "realized_vol_60m",
    "high_low_range_5m", "high_low_range_15m", "high_low_range_30m", "high_low_range_60m",
    "close_vs_ema9_pct", "close_vs_ema21_pct", "close_vs_ema50_pct",
    "rsi_14", "positive_return_count_5m", "negative_return_count_5m"
]

def main():
    script_dir = Path(__file__).resolve().parent
    root = script_dir.parent if script_dir.name.lower() == "scripts" else script_dir
    data_dir = root / "data" / "processed" / "nifty_walkforward_v1"
    model_dir = root / "models" / "nifty_baseline_v1"
    report_dir = root / "reports" / "nifty_baseline_v1"
    model_dir.mkdir(parents=True, exist_ok=True)
    report_dir.mkdir(parents=True, exist_ok=True)

    log_path = report_dir / "training_log.txt"
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s",
        handlers=[logging.FileHandler(log_path, encoding="utf-8"), logging.StreamHandler()]
    )
    log = logging.getLogger("nifty_baseline")
    log.info("LightGBM version: %s", lgb.__version__)
    log.info("NumPy: %s | pandas: %s", np.__version__, pd.__version__)

    all_metrics = {
        "status": "BASELINE_TRAINING_COMPLETED_REVIEW_REQUIRED",
        "model": "LightGBM multiclass CPU",
        "labels_order": LABELS,
        "features": FEATURES,
        "class_weights": None,
        "seed": SEED,
        "horizons": {},
        "limitations": [
            "2024 is used for early stopping and validation, not an untouched test set.",
            "No 2025+ test dataset is included.",
            "Metrics are historical classification metrics, not trading profitability.",
            "No probability calibration or threshold optimization is performed."
        ]
    }
    reports, matrices, importances = [], [], []

    for h in HORIZONS:
        log.info("============================================================")
        log.info("Training horizon: %s minutes", h)
        train_path = data_dir / f"train_{h}m.parquet"
        valid_path = data_dir / f"validation_{h}m.parquet"
        if not train_path.exists() or not valid_path.exists():
            raise FileNotFoundError(f"Missing train/validation parquet for {h}m in {data_dir}")

        log.info("Loading training data: %s", train_path)
        train = pd.read_parquet(train_path, columns=FEATURES + ["label", "timestamp_ist", "trading_day"])
        log.info("Loading validation data: %s", valid_path)
        valid = pd.read_parquet(valid_path, columns=FEATURES + ["label", "timestamp_ist", "trading_day"])

        if train.empty or valid.empty:
            raise RuntimeError(f"Empty train or validation data for horizon {h}m")
        if set(train["label"].unique()) != set(LABELS):
            raise RuntimeError(f"Training labels differ from expected classes for {h}m: {train['label'].unique()}")
        if not set(valid["label"].unique()).issubset(set(LABELS)):
            raise RuntimeError(f"Unexpected validation labels for {h}m")

        X_train = train[FEATURES].replace([np.inf, -np.inf], np.nan)
        X_valid = valid[FEATURES].replace([np.inf, -np.inf], np.nan)
        if X_train.isna().any().any() or X_valid.isna().any().any():
            bad_train = X_train.columns[X_train.isna().any()].tolist()
            bad_valid = X_valid.columns[X_valid.isna().any()].tolist()
            raise RuntimeError(
                f"Missing/infinite feature values for {h}m. "
                f"Train columns={bad_train}; validation columns={bad_valid}"
            )

        y_train = train["label"].map(LABEL_TO_ID).astype("int32")
        y_valid = valid["label"].map(LABEL_TO_ID).astype("int32")

        # Reference baseline: always predict the most frequent TRAIN class.
        majority_id = int(y_train.value_counts().idxmax())
        majority_pred = np.full(len(y_valid), majority_id, dtype=np.int32)
        majority_metrics = {
            "majority_class": LABELS[majority_id],
            "accuracy": float(accuracy_score(y_valid, majority_pred)),
            "balanced_accuracy": float(balanced_accuracy_score(y_valid, majority_pred)),
            "macro_f1": float(f1_score(y_valid, majority_pred, labels=[0,1,2], average="macro", zero_division=0))
        }

        model = lgb.LGBMClassifier(
            objective="multiclass",
            num_class=3,
            class_weight=None,
            boosting_type="gbdt",
            n_estimators=1800,
            learning_rate=0.025,
            num_leaves=31,
            max_depth=-1,
            min_child_samples=100,
            subsample=0.8,
            subsample_freq=1,
            colsample_bytree=0.8,
            reg_lambda=2.0,
            random_state=SEED,
            n_jobs=-1,
            verbosity=-1,
            deterministic=True,
            force_col_wise=True
        )

        log.info("Train rows=%s | validation rows=%s | features=%s",
                 len(train), len(valid), len(FEATURES))
        callbacks = [
            lgb.early_stopping(stopping_rounds=100, first_metric_only=True, verbose=True),
            lgb.log_evaluation(period=100)
        ]
        model.fit(
            X_train, y_train,
            eval_set=[(X_valid, y_valid)],
            eval_metric="multi_logloss",
            callbacks=callbacks
        )

        pred = model.predict(X_valid).astype(int)
        proba = model.predict_proba(X_valid)
        metrics = {
            "horizon_minutes": h,
            "train_rows": int(len(train)),
            "validation_rows": int(len(valid)),
            "train_start": str(pd.to_datetime(train["trading_day"]).min().date()),
            "train_end": str(pd.to_datetime(train["trading_day"]).max().date()),
            "validation_start": str(pd.to_datetime(valid["trading_day"]).min().date()),
            "validation_end": str(pd.to_datetime(valid["trading_day"]).max().date()),
            "best_iteration": int(model.best_iteration_ or model.n_estimators),
            "majority_baseline": majority_metrics,
            "model": {
                "accuracy": float(accuracy_score(y_valid, pred)),
                "balanced_accuracy": float(balanced_accuracy_score(y_valid, pred)),
                "macro_f1": float(f1_score(y_valid, pred, labels=[0,1,2], average="macro", zero_division=0)),
                "weighted_f1": float(f1_score(y_valid, pred, average="weighted", zero_division=0)),
                "multi_logloss": float(log_loss(y_valid, proba, labels=[0,1,2]))
            }
        }
        all_metrics["horizons"][str(h)] = metrics
        log.info("Horizon %sm metrics: %s", h, json.dumps(metrics, default=str))

        model_path = model_dir / f"model_{h}m.txt"
        model.booster_.save_model(str(model_path))

        report = classification_report(
            y_valid, pred, labels=[0,1,2], target_names=LABELS,
            output_dict=True, zero_division=0
        )
        for label, vals in report.items():
            if isinstance(vals, dict):
                reports.append({
                    "horizon_minutes": h, "class": label,
                    "precision": vals.get("precision"),
                    "recall": vals.get("recall"),
                    "f1_score": vals.get("f1-score"),
                    "support": vals.get("support")
                })
        cm = confusion_matrix(y_valid, pred, labels=[0,1,2])
        for i, actual in enumerate(LABELS):
            for j, predicted in enumerate(LABELS):
                matrices.append({
                    "horizon_minutes": h,
                    "actual": actual,
                    "predicted": predicted,
                    "count": int(cm[i, j])
                })
        for name, gain, split in zip(
            FEATURES,
            model.booster_.feature_importance(importance_type="gain"),
            model.booster_.feature_importance(importance_type="split")
        ):
            importances.append({
                "horizon_minutes": h, "feature": name,
                "gain_importance": float(gain), "split_importance": int(split)
            })

        del train, valid, X_train, X_valid, y_train, y_valid, model, proba, pred

    (report_dir / "metrics_by_horizon.json").write_text(
        json.dumps(all_metrics, indent=2), encoding="utf-8"
    )
    pd.DataFrame(reports).to_csv(report_dir / "classification_report.csv", index=False)
    pd.DataFrame(matrices).to_csv(report_dir / "confusion_matrix.csv", index=False)
    pd.DataFrame(importances).to_csv(report_dir / "feature_importance.csv", index=False)

    all_metrics["elapsed_seconds"] = round(time.time() - START, 2)
    (report_dir / "metrics_by_horizon.json").write_text(
        json.dumps(all_metrics, indent=2), encoding="utf-8"
    )
    log.info("Training complete in %.2f seconds", all_metrics["elapsed_seconds"])
    log.info("Models: %s", model_dir)
    log.info("Reports: %s", report_dir)

if __name__ == "__main__":
    main()
