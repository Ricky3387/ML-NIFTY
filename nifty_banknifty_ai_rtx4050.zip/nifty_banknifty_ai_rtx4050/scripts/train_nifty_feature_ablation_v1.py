
"""
NIFTY FEATURE ABLATION TRAINING V1

Experiments:
 A = baseline features
 B = baseline + experimental shortlist
 C = experimental shortlist only

Horizons: 5, 15, 30 minutes

Chronology:
 2021-2022: fit for early-stopping selection
 2023: early-stopping selection
 2021-2023: final model fit with selected iteration count
 2024: out-of-period diagnostic evaluation

2024 is NOT an untouched test set because previous research
and feature selection have already used it.

No input files are modified.
"""

from pathlib import Path
from datetime import datetime, timezone
import json
import os
import sys
import time

import duckdb
import joblib
import lightgbm as lgb
import numpy as np
import pandas as pd

from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    log_loss,
)

ROOT = Path(__file__).resolve().parents[1]

WALK_DIR = ROOT / "data" / "processed" / "nifty_walkforward_v1"

EXPERIMENTAL_FILE = (
        ROOT
        / "data"
        / "processed"
        / "nifty_features_experimental_v1"
        / "nifty_features_labels_experimental_v1.parquet"
)

MODEL_ROOT = ROOT / "models" / "nifty_feature_ablation_v1"
REPORT_ROOT = ROOT / "reports" / "nifty_feature_ablation_v1"

RUN_ID = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S_%f")
MODEL_DIR = MODEL_ROOT / RUN_ID
REPORT_DIR = REPORT_ROOT / RUN_ID

HORIZONS = [5, 15, 30]
CLASSES = ["DOWN", "SIDEWAYS", "UP"]

SEED = 42
NUM_THREADS = min(6, os.cpu_count() or 4)
MAX_ESTIMATORS = 1800
EARLY_STOPPING_ROUNDS = 100

BASELINE_FEATURES = [
    "ret_1m",
    "logret_1m",
    "range_pct",
    "body_pct",
    "upper_wick_pct",
    "lower_wick_pct",
    "return_5m",
    "return_15m",
    "return_30m",
    "return_60m",
    "realized_vol_5m",
    "realized_vol_15m",
    "realized_vol_30m",
    "realized_vol_60m",
    "high_low_range_5m",
    "high_low_range_15m",
    "high_low_range_30m",
    "high_low_range_60m",
    "close_vs_ema9_pct",
    "close_vs_ema21_pct",
    "close_vs_ema50_pct",
    "rsi_14",
    "positive_return_count_5m",
    "negative_return_count_5m",
    "target_vol_scale",
]

EXPERIMENTAL_COMMON = [
    "exp_close_location_20m",
    "exp_close_location_60m",
    "exp_ema9_21_spread_atr",
    "exp_vol_ratio_15m_60m",
    "exp_ema9_slope_atr",
    "exp_trend_alignment",
]

EXPERIMENTAL_BY_HORIZON = {
    5: EXPERIMENTAL_COMMON + ["exp_efficiency_ratio_20m"],
    15: EXPERIMENTAL_COMMON + ["exp_efficiency_ratio_20m"],
    30: EXPERIMENTAL_COMMON + ["exp_ema21_50_spread_atr"],
}

JOIN_KEYS = ["timestamp_ist", "horizon_minutes"]

META_COLUMNS = [
    "timestamp_ist",
    "trading_day",
    "horizon_minutes",
    "label",
    "sample_eligible",
    "is_synthetic",
    "training_day_eligible",
    "session_type",
]

METRIC_ROWS = []
PREDICTION_DISTRIBUTIONS = []
CLASS_METRICS = []
IMPORTANCE_ROWS = []
RUN_AUDIT = []


def log(message):
    print(message, flush=True)


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def save_json(path, obj):
    path.write_text(
        json.dumps(obj, indent=2, default=str),
        encoding="utf-8",
    )


def get_feature_sets(horizon):
    experimental = EXPERIMENTAL_BY_HORIZON[horizon]

    return {
        "A_baseline": BASELINE_FEATURES,
        "B_combined": BASELINE_FEATURES + experimental,
        "C_experimental": experimental,
    }


def load_parquet(path, columns=None, horizon=None):
    require(path.exists(), f"Missing input file: {path}")

    con = duckdb.connect(":memory:")

    try:
        if columns is None:
            sql = "SELECT * FROM read_parquet(?)"
            df = con.execute(sql, [str(path)]).df()
        else:
            available = set(
                con.execute(
                    "DESCRIBE SELECT * FROM read_parquet(?)",
                    [str(path)],
                ).df()["column_name"].tolist()
            )

            missing = set(columns) - available
            require(
                not missing,
                f"Missing columns in {path.name}: {sorted(missing)}",
            )

            quoted = ", ".join(
                '"' + col.replace('"', '""') + '"'
                for col in columns
            )

            sql = f"SELECT {quoted} FROM read_parquet(?)"
            params = [str(path)]

            if horizon is not None:
                sql += " WHERE horizon_minutes = ?"
                params.append(horizon)

            df = con.execute(sql, params).df()

        return df

    finally:
        con.close()


def normalize_timestamp(df):
    df["timestamp_ist"] = pd.to_datetime(
        df["timestamp_ist"],
        utc=True,
        errors="raise",
    ).dt.tz_convert("Asia/Kolkata")

    return df


def check_keys(df, name):
    require(
        not df[JOIN_KEYS].isna().any().any(),
        f"{name}: null join keys",
    )

    duplicates = df.duplicated(JOIN_KEYS).sum()

    require(
        duplicates == 0,
        f"{name}: {duplicates} duplicate timestamp+horizon keys",
        )


def load_horizon_data(horizon):
    log(f"\nLoading horizon {horizon}m...")

    train_path = WALK_DIR / f"train_{horizon}m.parquet"
    val_path = WALK_DIR / f"validation_{horizon}m.parquet"

    train = normalize_timestamp(load_parquet(train_path))
    validation = normalize_timestamp(load_parquet(val_path))

    train["__partition"] = "train"
    validation["__partition"] = "validation"

    require(
        set(train.columns) == set(validation.columns),
        "Train/validation schemas differ",
        )

    base = pd.concat(
        [train, validation],
        ignore_index=True,
    )

    del train, validation

    check_keys(base, "walkforward")

    require(
        (base["horizon_minutes"] == horizon).all(),
        "Incorrect horizon in walkforward",
    )

    require(
        base["sample_eligible"].eq(True).all(),
        "Ineligible walkforward samples found",
    )

    require(
        base["is_synthetic"].eq(False).all(),
        "Synthetic samples found",
    )

    require(
        base["training_day_eligible"].eq(True).all(),
        "Training-day eligibility violation",
    )

    require(
        base["label"].isin(CLASSES).all(),
        "Unexpected labels found",
    )

    base["trading_day"] = pd.to_datetime(
        base["trading_day"],
        errors="raise",
    )

    years = base["trading_day"].dt.year

    require(
        (years[base["__partition"] == "train"] <= 2023).all(),
        "Training partition includes dates after 2023",
    )

    require(
        (years[base["__partition"] == "validation"] == 2024).all(),
        "Validation partition is not entirely 2024",
    )

    exp_features = EXPERIMENTAL_BY_HORIZON[horizon]

    exp_columns = (
            JOIN_KEYS
            + ["trading_day", "label", "sample_eligible"]
            + exp_features
    )

    experimental = load_parquet(
        EXPERIMENTAL_FILE,
        columns=exp_columns,
        horizon=horizon,
    )

    experimental = normalize_timestamp(experimental)

    check_keys(experimental, "experimental")

    experimental["trading_day"] = pd.to_datetime(
        experimental["trading_day"],
        errors="raise",
    )

    experimental = experimental.rename(
        columns={
            "trading_day": "__exp_trading_day",
            "label": "__exp_label",
            "sample_eligible": "__exp_eligible",
        }
    )

    before = len(base)

    merged = base.merge(
        experimental,
        on=JOIN_KEYS,
        how="left",
        validate="one_to_one",
        indicator=True,
        sort=False,
    )

    require(
        len(merged) == before,
        "Join changed row count",
        )

    require(
        merged["_merge"].eq("both").all(),
        "Missing experimental matches",
    )

    require(
        merged["label"].eq(merged["__exp_label"]).all(),
        "Baseline/experimental labels differ",
    )

    require(
        merged["trading_day"].eq(
            merged["__exp_trading_day"]
        ).all(),
        "Trading-day mismatch",
    )

    require(
        merged["__exp_eligible"].eq(True).all(),
        "Experimental eligibility mismatch",
    )

    merged = merged.drop(
        columns=[
            "_merge",
            "__exp_label",
            "__exp_trading_day",
            "__exp_eligible",
        ]
    )

    all_features = list(
        dict.fromkeys(BASELINE_FEATURES + exp_features)
    )

    numeric = merged[all_features].apply(
        pd.to_numeric,
        errors="raise",
    )

    values = numeric.to_numpy(dtype=np.float64)

    require(
        np.isfinite(values).all(),
        "NaN or infinite feature values found",
    )

    merged[all_features] = numeric.astype(np.float32)

    year = merged["trading_day"].dt.year

    fit_mask = (
            (merged["__partition"] == "train")
            & year.isin([2021, 2022])
    )

    stop_mask = (
            (merged["__partition"] == "train")
            & (year == 2023)
    )

    final_train_mask = (
            merged["__partition"] == "train"
    )

    evaluation_mask = (
            (merged["__partition"] == "validation")
            & (year == 2024)
    )

    masks = {
        "fit": fit_mask.to_numpy(),
        "stop": stop_mask.to_numpy(),
        "final_train": final_train_mask.to_numpy(),
        "evaluation": evaluation_mask.to_numpy(),
    }

    require(
        all(mask.sum() > 0 for mask in masks.values()),
        "One or more chronological partitions are empty",
    )

    require(
        masks["fit"].sum() + masks["stop"].sum()
        == masks["final_train"].sum(),
        "Internal training partitions do not reconcile",
        )

    require(
        masks["final_train"].sum()
        + masks["evaluation"].sum()
        == len(merged),
        "Train/evaluation partitions do not reconcile",
        )

    RUN_AUDIT.append({
        "horizon_minutes": horizon,
        "total_rows": len(merged),
        "fit_2021_2022": int(fit_mask.sum()),
        "early_stop_2023": int(stop_mask.sum()),
        "final_train_2021_2023": int(
            final_train_mask.sum()
        ),
        "diagnostic_2024": int(evaluation_mask.sum()),
        "matched_experimental_rows": len(merged),
        "duplicate_keys": 0,
        "missing_features": 0,
        "label_mismatches": 0,
    })

    log(
        f"Rows: {len(merged):,} | "
        f"fit: {fit_mask.sum():,} | "
        f"stop: {stop_mask.sum():,} | "
        f"final train: {final_train_mask.sum():,} | "
        f"2024: {evaluation_mask.sum():,}"
    )

    return merged, masks


def encode_labels(labels):
    mapping = {
        "DOWN": 0,
        "SIDEWAYS": 1,
        "UP": 2,
    }

    result = labels.map(mapping)

    require(
        result.notna().all(),
        "Unknown target label",
    )

    return result.to_numpy(dtype=np.int32)


def make_model(n_estimators):
    return lgb.LGBMClassifier(
        objective="multiclass",
        num_class=3,
        n_estimators=int(n_estimators),
        learning_rate=0.025,
        num_leaves=31,
        min_child_samples=100,
        subsample=0.8,
        subsample_freq=1,
        colsample_bytree=0.8,
        reg_lambda=2.0,
        random_state=SEED,
        n_jobs=NUM_THREADS,
        verbosity=-1,
        deterministic=True,
        force_col_wise=True,
    )


def get_metrics(y_true, y_pred, probabilities):
    return {
        "accuracy": float(
            accuracy_score(y_true, y_pred)
        ),
        "balanced_accuracy": float(
            balanced_accuracy_score(y_true, y_pred)
        ),
        "macro_f1": float(
            f1_score(
                y_true,
                y_pred,
                average="macro",
                zero_division=0,
            )
        ),
        "weighted_f1": float(
            f1_score(
                y_true,
                y_pred,
                average="weighted",
                zero_division=0,
            )
        ),
        "logloss": float(
            log_loss(
                y_true,
                probabilities,
                labels=[0, 1, 2],
            )
        ),
    }


def train_experiment(
        horizon,
        experiment,
        features,
        data,
        masks,
):
    started = time.time()

    name = f"{experiment}_{horizon}m"

    log("\n" + "=" * 80)
    log(f"TRAINING: {name}")
    log("=" * 80)

    X = data[features].to_numpy(dtype=np.float32)
    y = encode_labels(data["label"])

    X_fit = X[masks["fit"]]
    y_fit = y[masks["fit"]]

    X_stop = X[masks["stop"]]
    y_stop = y[masks["stop"]]

    X_train = X[masks["final_train"]]
    y_train = y[masks["final_train"]]

    X_eval = X[masks["evaluation"]]
    y_eval = y[masks["evaluation"]]

    selector = make_model(MAX_ESTIMATORS)

    selector.fit(
        X_fit,
        y_fit,
        eval_set=[(X_stop, y_stop)],
        eval_metric="multi_logloss",
        callbacks=[
            lgb.early_stopping(
                stopping_rounds=EARLY_STOPPING_ROUNDS,
                verbose=False,
            ),
        ],
        feature_name=features,
    )

    best_iteration = int(
        selector.best_iteration_ or MAX_ESTIMATORS
    )

    log(f"Selected iterations: {best_iteration}")

    # Refit on all available pre-2024 training data.
    final_model = make_model(best_iteration)

    final_model.fit(
        X_train,
        y_train,
        feature_name=features,
    )

    probabilities = final_model.predict_proba(X_eval)

    # Explicit class-order alignment.
    model_classes = final_model.classes_.tolist()

    require(
        model_classes == [0, 1, 2],
        f"Unexpected model class order: {model_classes}",
        )

    predictions = np.argmax(
        probabilities,
        axis=1,
    )

    metrics = get_metrics(
        y_eval,
        predictions,
        probabilities,
    )

    model_path = MODEL_DIR / f"{name}.txt"

    final_model.booster_.save_model(
        str(model_path)
    )

    metadata = {
        "experiment": experiment,
        "horizon_minutes": horizon,
        "features": features,
        "class_order": CLASSES,
        "best_iteration": best_iteration,
        "selection_fit_years": [2021, 2022],
        "selection_validation_year": 2023,
        "final_train_years": [2021, 2022, 2023],
        "diagnostic_year": 2024,
        "prediction_timing": (
            "After current one-minute bar completes"
        ),
        "evaluation_is_untouched_test": False,
        "seed": SEED,
        "model_parameters": final_model.get_params(),
        "metrics": metrics,
    }

    save_json(
        MODEL_DIR / f"{name}_metadata.json",
        metadata,
        )

    # Predictions
    eval_rows = data.loc[
        masks["evaluation"],
        ["timestamp_ist", "trading_day", "label"],
    ].copy()

    eval_rows["predicted_label"] = [
        CLASSES[i] for i in predictions
    ]

    for index, class_name in enumerate(CLASSES):
        eval_rows[f"prob_{class_name.lower()}"] = (
            probabilities[:, index]
        )

    eval_rows.to_parquet(
        REPORT_DIR / f"{name}_predictions.parquet",
        index=False,
        )

    # Confusion matrix
    cm = confusion_matrix(
        y_eval,
        predictions,
        labels=[0, 1, 2],
    )

    pd.DataFrame(
        cm,
        index=CLASSES,
        columns=CLASSES,
    ).to_csv(
        REPORT_DIR / f"{name}_confusion_matrix.csv"
    )

    # Per-class report
    report = classification_report(
        y_eval,
        predictions,
        labels=[0, 1, 2],
        target_names=CLASSES,
        output_dict=True,
        zero_division=0,
    )

    for class_name in CLASSES:
        row = report[class_name]

        CLASS_METRICS.append({
            "horizon_minutes": horizon,
            "experiment": experiment,
            "class": class_name,
            "precision": row["precision"],
            "recall": row["recall"],
            "f1": row["f1-score"],
            "support": row["support"],
        })

    # Predicted versus actual distribution
    for index, class_name in enumerate(CLASSES):
        PREDICTION_DISTRIBUTIONS.append({
            "horizon_minutes": horizon,
            "experiment": experiment,
            "class": class_name,
            "actual_pct": float(
                100 * np.mean(y_eval == index)
            ),
            "predicted_pct": float(
                100 * np.mean(predictions == index)
            ),
            "mean_predicted_probability_pct": float(
                100 * np.mean(probabilities[:, index])
            ),
        })

    # Feature importance
    booster = final_model.booster_

    gains = booster.feature_importance(
        importance_type="gain"
    )

    splits = booster.feature_importance(
        importance_type="split"
    )

    for feature, gain, split_count in zip(
            features, gains, splits
    ):
        IMPORTANCE_ROWS.append({
            "horizon_minutes": horizon,
            "experiment": experiment,
            "feature": feature,
            "gain": float(gain),
            "split_count": int(split_count),
        })

    elapsed = time.time() - started

    result = {
        "horizon_minutes": horizon,
        "experiment": experiment,
        "feature_count": len(features),
        "best_iteration": best_iteration,
        "fit_rows": len(X_fit),
        "early_stop_rows": len(X_stop),
        "final_train_rows": len(X_train),
        "evaluation_rows": len(X_eval),
        "training_seconds": round(elapsed, 2),
        **metrics,
    }

    METRIC_ROWS.append(result)

    log(
        f"Accuracy: {metrics['accuracy']:.4f} | "
        f"Balanced: {metrics['balanced_accuracy']:.4f} | "
        f"Macro-F1: {metrics['macro_f1']:.4f} | "
        f"Logloss: {metrics['logloss']:.4f}"
    )

    log(
        "Predicted distribution: "
        + ", ".join(
            f"{CLASSES[i]}="
            f"{100 * np.mean(predictions == i):.2f}%"
            for i in range(3)
        )
    )

    log(f"Elapsed: {elapsed:.1f}s")

    del selector, final_model, X
    del X_fit, X_stop, X_train, X_eval

    return result


def write_comparisons():
    metrics = pd.DataFrame(METRIC_ROWS)

    metrics.to_csv(
        REPORT_DIR / "model_comparison.csv",
        index=False,
        )

    pd.DataFrame(
        PREDICTION_DISTRIBUTIONS
    ).to_csv(
        REPORT_DIR / "predicted_class_distribution.csv",
        index=False,
        )

    pd.DataFrame(
        CLASS_METRICS
    ).to_csv(
        REPORT_DIR / "per_class_metrics.csv",
        index=False,
        )

    pd.DataFrame(
        IMPORTANCE_ROWS
    ).to_csv(
        REPORT_DIR / "feature_importance.csv",
        index=False,
        )

    pd.DataFrame(
        RUN_AUDIT
    ).to_csv(
        REPORT_DIR / "training_data_audit.csv",
        index=False,
        )

    comparisons = []

    for horizon in HORIZONS:
        subset = metrics[
            metrics["horizon_minutes"] == horizon
            ].set_index("experiment")

        baseline = subset.loc["A_baseline"]

        for experiment in [
            "B_combined",
            "C_experimental",
        ]:
            candidate = subset.loc[experiment]

            comparisons.append({
                "horizon_minutes": horizon,
                "candidate": experiment,
                "delta_accuracy": (
                        candidate["accuracy"]
                        - baseline["accuracy"]
                ),
                "delta_balanced_accuracy": (
                        candidate["balanced_accuracy"]
                        - baseline["balanced_accuracy"]
                ),
                "delta_macro_f1": (
                        candidate["macro_f1"]
                        - baseline["macro_f1"]
                ),
                "delta_logloss": (
                        candidate["logloss"]
                        - baseline["logloss"]
                ),
            })

    pd.DataFrame(comparisons).to_csv(
        REPORT_DIR / "ablation_deltas_vs_baseline.csv",
        index=False,
        )

    save_json(
        REPORT_DIR / "run_summary.json",
        {
            "run_id": RUN_ID,
            "horizons": HORIZONS,
            "experiments": [
                "A_baseline",
                "B_combined",
                "C_experimental",
            ],
            "models_trained": len(METRIC_ROWS),
            "metrics": METRIC_ROWS,
            "data_audit": RUN_AUDIT,
            "notes": [
                "2024 is a diagnostic period, not an untouched test.",
                "Experimental features selected after prior analysis.",
                "No historical transaction-cost or PnL claims.",
                "All model inputs are current/past completed-bar features.",
                "No original datasets or prior models overwritten.",
            ],
        },
        )

    return metrics


def main():
    log("=" * 80)
    log("NIFTY CONTROLLED FEATURE ABLATION V1")
    log("=" * 80)

    require(
        EXPERIMENTAL_FILE.exists(),
        f"Missing experimental dataset: {EXPERIMENTAL_FILE}",
    )

    MODEL_DIR.mkdir(
        parents=True,
        exist_ok=False,
    )

    REPORT_DIR.mkdir(
        parents=True,
        exist_ok=False,
    )

    save_json(
        REPORT_DIR / "experiment_config.json",
        {
            "run_id": RUN_ID,
            "baseline_features": BASELINE_FEATURES,
            "experimental_features_by_horizon": (
                EXPERIMENTAL_BY_HORIZON
            ),
            "seed": SEED,
            "threads": NUM_THREADS,
            "max_estimators": MAX_ESTIMATORS,
            "early_stopping_rounds": EARLY_STOPPING_ROUNDS,
            "model_root": str(MODEL_DIR),
            "report_root": str(REPORT_DIR),
            "python_version": sys.version,
            "lightgbm_version": lgb.__version__,
            "duckdb_version": duckdb.__version__,
            "pandas_version": pd.__version__,
        },
        )

    for horizon in HORIZONS:
        data, masks = load_horizon_data(horizon)

        feature_sets = get_feature_sets(horizon)

        for experiment, features in feature_sets.items():
            train_experiment(
                horizon,
                experiment,
                features,
                data,
                masks,
            )

        del data, masks

    metrics = write_comparisons()

    log("\n" + "=" * 80)
    log("FINAL MODEL COMPARISON")
    log("=" * 80)

    display_columns = [
        "horizon_minutes",
        "experiment",
        "best_iteration",
        "accuracy",
        "balanced_accuracy",
        "macro_f1",
        "logloss",
    ]

    log(
        metrics[display_columns].to_string(
            index=False,
            float_format=lambda x: f"{x:.5f}",
        )
    )

    log("\nTraining complete.")
    log(f"Models: {MODEL_DIR}")
    log(f"Reports: {REPORT_DIR}")


if __name__ == "__main__":
    main()
