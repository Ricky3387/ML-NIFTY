#!/usr/bin/env python3
"""
NIFTY Feature Quality Audit v1
==============================

Save as:
  <project_root>/scripts/audit_nifty_feature_quality_v1.py

Run from project root:
  python scripts/audit_nifty_feature_quality_v1.py

Reads:
  data/processed/nifty_features_v1/nifty_features_labels_long.parquet

Writes:
  reports/nifty_feature_quality_v1/

This is a diagnostic-only audit. It does not train models, alter features,
change labels, or overwrite existing v1/v2/v3 artifacts.
"""
from pathlib import Path
import json
import time
import logging
import warnings

import numpy as np
import pandas as pd

START = time.time()
HORIZONS = (5, 15, 30)
CLASSES = ("DOWN", "SIDEWAYS", "UP")
TARGET_COLUMNS = {
    "label", "target_z", "future_close", "future_return",
    "forward_return", "atr_normalized_move", "sample_eligible"
}
META_COLUMNS = {
    "timestamp_ist", "trading_day", "horizon_minutes", "year",
    "split", "dataset_split", "sample_id", "symbol", "close",
    "open", "high", "low", "volume", "is_synthetic",
    "feature_window_valid", "label_window_valid", "exclusion_reason"
}


def numeric_feature_columns(df):
    excluded = TARGET_COLUMNS | META_COLUMNS
    cols = []
    for c in df.columns:
        if c in excluded or c.startswith("atr_label_"):
            continue
        if pd.api.types.is_numeric_dtype(df[c]):
            cols.append(c)
    return cols


def standardized_mean_difference(a, b):
    a = pd.Series(a).dropna().astype(float)
    b = pd.Series(b).dropna().astype(float)
    if len(a) < 2 or len(b) < 2:
        return np.nan
    va, vb = a.var(ddof=1), b.var(ddof=1)
    denom = np.sqrt(((len(a) - 1) * va + (len(b) - 1) * vb) /
                    max(len(a) + len(b) - 2, 1))
    if not np.isfinite(denom) or denom == 0:
        return 0.0
    return float((a.mean() - b.mean()) / denom)


def safe_corr(x, y, method="spearman"):
    pair = pd.DataFrame({"x": x, "y": y}).replace([np.inf, -np.inf], np.nan).dropna()
    if len(pair) < 3 or pair["x"].nunique() < 2 or pair["y"].nunique() < 2:
        return np.nan
    return float(pair["x"].corr(pair["y"], method=method))


def main():
    script_dir = Path(__file__).resolve().parent
    root = script_dir.parent if script_dir.name.lower() == "scripts" else script_dir
    input_path = root / "data/processed/nifty_features_v1/nifty_features_labels_long.parquet"
    out = root / "reports/nifty_feature_quality_v1"
    out.mkdir(parents=True, exist_ok=True)

    logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(message)s")
    log = logging.getLogger("nifty_feature_quality_v1")
    if not input_path.exists():
        raise FileNotFoundError(f"Required input missing: {input_path}")

    log.info("Loading feature/label parquet")
    df = pd.read_parquet(input_path)
    required = {"timestamp_ist", "trading_day", "horizon_minutes",
                "sample_eligible", "label", "target_z"}
    missing = required - set(df.columns)
    if missing:
        raise RuntimeError(f"Input missing required columns: {sorted(missing)}")

    df["timestamp_ist"] = pd.to_datetime(df["timestamp_ist"])
    df["trading_day"] = pd.to_datetime(df["trading_day"]).dt.strftime("%Y-%m-%d")
    df["year"] = pd.to_datetime(df["trading_day"]).dt.year
    df["horizon_minutes"] = df["horizon_minutes"].astype(int)
    df = df[df["horizon_minutes"].isin(HORIZONS)].copy()
    eligible = df[df["sample_eligible"].astype(bool)].copy()
    if eligible.empty:
        raise RuntimeError("No eligible rows found.")

    features = numeric_feature_columns(df)
    if not features:
        raise RuntimeError("No numeric feature columns detected.")
    # Normalize detected numeric columns to float64 once. This safely handles
    # boolean indicator features in quantiles, correlations, and effect sizes.
    for col in features:
        df[col] = pd.to_numeric(df[col], errors="coerce").astype("float64")
    eligible = df[df["sample_eligible"].astype(bool)].copy()
    # Exclude columns that are effectively metadata or constant.
    feature_profile = []
    usable = []
    for col in features:
        # Pandas treats bool as numeric for dtype checks, but NumPy quantile
        # interpolation cannot subtract boolean values. Convert every numeric
        # feature (including bool flags) to float before profiling/correlation.
        s = pd.to_numeric(eligible[col], errors="coerce")
        s = s.replace([np.inf, -np.inf], np.nan).astype("float64")
        non_null = int(s.notna().sum())
        nunique = int(s.nunique(dropna=True))
        feature_profile.append({
            "feature": col,
            "eligible_non_null": non_null,
            "missing_pct": float(s.isna().mean() * 100),
            "unique_values": nunique,
            "mean": float(s.mean()) if non_null else None,
            "std": float(s.std()) if non_null else None,
            "min": float(s.min()) if non_null else None,
            "p01": float(s.quantile(.01)) if non_null else None,
            "median": float(s.median()) if non_null else None,
            "p99": float(s.quantile(.99)) if non_null else None,
            "max": float(s.max()) if non_null else None,
            "usable": bool(nunique > 1 and non_null > 0)
        })
        if nunique > 1 and non_null > 0:
            usable.append(col)
    pd.DataFrame(feature_profile).to_csv(out / "feature_profile.csv", index=False)
    if not usable:
        raise RuntimeError("All detected numeric features are constant or empty.")

    log.info("Feature-target separation by horizon and class")
    separation_rows = []
    for h, g in eligible.groupby("horizon_minutes"):
        for feature in usable:
            overall = g[feature].replace([np.inf, -np.inf], np.nan)
            for cls in CLASSES:
                positive = g.loc[g["label"] == cls, feature]
                negative = g.loc[g["label"] != cls, feature]
                separation_rows.append({
                    "horizon_minutes": int(h), "feature": feature,
                    "class": cls, "class_samples": int(positive.notna().sum()),
                    "other_samples": int(negative.notna().sum()),
                    "class_mean": float(positive.mean()) if positive.notna().any() else None,
                    "other_mean": float(negative.mean()) if negative.notna().any() else None,
                    "standardized_mean_difference": standardized_mean_difference(
                        positive, negative
                    ),
                    "spearman_feature_vs_target_z": safe_corr(
                        overall, g["target_z"], "spearman"
                    )
                })
    separation = pd.DataFrame(separation_rows)
    separation.to_csv(out / "feature_class_separation.csv", index=False)

    log.info("Feature redundancy/correlation by horizon")
    corr_rows = []
    for h, g in eligible.groupby("horizon_minutes"):
        corr = g[usable].replace([np.inf, -np.inf], np.nan).corr(method="spearman")
        for i, a in enumerate(usable):
            for b in usable[i + 1:]:
                value = corr.loc[a, b] if a in corr.index and b in corr.columns else np.nan
                if pd.notna(value):
                    corr_rows.append({
                        "horizon_minutes": int(h), "feature_a": a,
                        "feature_b": b, "spearman_correlation": float(value),
                        "abs_correlation": abs(float(value))
                    })
    corr_df = pd.DataFrame(corr_rows)
    if not corr_df.empty:
        corr_df = corr_df.sort_values(
            ["horizon_minutes", "abs_correlation"], ascending=[True, False]
        )
    corr_df.to_csv(out / "feature_correlation_pairs.csv", index=False)

    log.info("Feature-target separation by year")
    year_rows = []
    for h, g in eligible.groupby("horizon_minutes"):
        for year, gy in g.groupby("year"):
            for feature in usable:
                for cls in CLASSES:
                    a = gy.loc[gy["label"] == cls, feature]
                    b = gy.loc[gy["label"] != cls, feature]
                    year_rows.append({
                        "horizon_minutes": int(h), "year": int(year),
                        "feature": feature, "class": cls,
                        "standardized_mean_difference": standardized_mean_difference(a, b),
                        "class_samples": int(a.notna().sum()),
                        "other_samples": int(b.notna().sum())
                    })
    pd.DataFrame(year_rows).to_csv(out / "feature_separation_by_year.csv", index=False)

    log.info("Feature-target separation by volatility regime")
    regime_rows = []
    for h, g in eligible.groupby("horizon_minutes"):
        train_vol = g.loc[g["year"] <= 2023, "realized_vol_60m"] if "realized_vol_60m" in g else None
        if train_vol is None:
            log.warning("realized_vol_60m not present; skipping volatility-regime separation.")
            break
        train_vol = train_vol.replace([np.inf, -np.inf], np.nan).dropna()
        q1, q2 = train_vol.quantile([1/3, 2/3]).tolist()
        regimes = pd.cut(
            g["realized_vol_60m"], [-np.inf, q1, q2, np.inf],
            labels=["LOW", "MEDIUM", "HIGH"], include_lowest=True
        )
        g2 = g.assign(volatility_regime=regimes)
        for regime, gr in g2.groupby("volatility_regime", observed=False):
            for feature in usable:
                for cls in CLASSES:
                    a = gr.loc[gr["label"] == cls, feature]
                    b = gr.loc[gr["label"] != cls, feature]
                    regime_rows.append({
                        "horizon_minutes": int(h), "volatility_regime": str(regime),
                        "feature": feature, "class": cls,
                        "standardized_mean_difference": standardized_mean_difference(a, b),
                        "class_samples": int(a.notna().sum()),
                        "other_samples": int(b.notna().sum()),
                        "train_vol_q1": float(q1), "train_vol_q2": float(q2)
                    })
    pd.DataFrame(regime_rows).to_csv(
        out / "feature_separation_by_volatility.csv", index=False
    )

    log.info("Feature stability by year (distribution drift)")
    stability_rows = []
    for h, g in eligible.groupby("horizon_minutes"):
        for feature in usable:
            reference = g.loc[g["year"] <= 2023, feature].replace(
                [np.inf, -np.inf], np.nan
            ).dropna()
            if reference.empty:
                continue
            ref_median = float(reference.median())
            ref_iqr = float(reference.quantile(.75) - reference.quantile(.25))
            scale = ref_iqr if ref_iqr > 0 else float(reference.std())
            if not np.isfinite(scale) or scale == 0:
                scale = 1.0
            for year, gy in g.groupby("year"):
                current = gy[feature].replace([np.inf, -np.inf], np.nan).dropna()
                if current.empty:
                    continue
                stability_rows.append({
                    "horizon_minutes": int(h), "feature": feature,
                    "year": int(year), "samples": int(len(current)),
                    "year_median": float(current.median()),
                    "train_2021_2023_median": ref_median,
                    "median_shift_in_train_iqr": float(
                        (current.median() - ref_median) / scale
                    ),
                    "year_iqr": float(current.quantile(.75) - current.quantile(.25)),
                    "train_2021_2023_iqr": ref_iqr
                })
    pd.DataFrame(stability_rows).to_csv(out / "feature_distribution_stability.csv", index=False)

    log.info("Feature pair redundancy summary")
    if not corr_df.empty:
        high_corr = corr_df[corr_df["abs_correlation"] >= .90]
        high_corr_summary = (
            high_corr.groupby("horizon_minutes").size().astype(int).to_dict()
        )
    else:
        high_corr_summary = {}

    # Per-horizon sample and feature counts.
    horizon_counts = {
        str(int(h)): int(len(g)) for h, g in eligible.groupby("horizon_minutes")
    }
    summary = {
        "status": "FEATURE_QUALITY_AUDIT_V1_COMPLETED_REVIEW_REQUIRED",
        "input_rows": int(len(df)),
        "eligible_rows": int(len(eligible)),
        "eligible_rows_by_horizon": horizon_counts,
        "detected_numeric_feature_count": int(len(features)),
        "usable_feature_count": int(len(usable)),
        "usable_features": usable,
        "high_correlation_pair_count_by_horizon_abs_spearman_ge_0_90": high_corr_summary,
        "outputs": [
            "feature_profile.csv",
            "feature_class_separation.csv",
            "feature_correlation_pairs.csv",
            "feature_separation_by_year.csv",
            "feature_separation_by_volatility.csv",
            "feature_distribution_stability.csv"
        ],
        "caveats": [
            "Diagnostic associations are not evidence of causal or out-of-sample predictive power.",
            "Standardized mean differences are univariate and do not measure joint model performance.",
            "Feature-target associations use the existing v1 labels and eligible population.",
            "Yearly stability compares each year's feature median with the 2021-2023 pooled training median.",
            "Volatility cutoffs are estimated from 2021-2023 data and applied to all years.",
            "No feature is automatically removed and no model is trained.",
            "Prediction timing assumes the current completed one-minute bar is available at its close."
        ],
        "elapsed_seconds": round(time.time() - START, 2)
    }
    (out / "feature_quality_summary.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )
    print(json.dumps(summary, indent=2))
    print(f"REPORTS: {out}")


if __name__ == "__main__":
    main()
