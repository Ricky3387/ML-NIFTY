
from pathlib import Path
import duckdb

ROOT = Path(__file__).resolve().parents[1]
FEATURE_DIR = ROOT / "data" / "training" / "index_features"

con = duckdb.connect()
con.execute("SET TimeZone = 'Asia/Calcutta'")

for name in ["nifty", "banknifty"]:
    path = FEATURE_DIR / f"{name}_index_features.parquet"
    path_sql = str(path).replace("\\", "/").replace("'", "''")

    print("\n" + "=" * 75)
    print(name.upper(), "FEATURE SCHEMA")
    print("=" * 75)

    schema = con.execute(
        f"DESCRIBE SELECT * FROM read_parquet('{path_sql}')"
    ).fetchdf()

    print(schema.to_string(index=False))

    columns = schema["column_name"].tolist()

    print("\nVOLATILITY / RETURN / LABEL COLUMNS")
    for col in columns:
        if any(term in col.lower() for term in [
            "volatility", "return", "future", "log_return"
        ]):
            print(col)

    for horizon in [5, 15, 30]:
        col = f"future_return_{horizon}m"
        if col in columns:
            count = con.execute(f"""
                SELECT
                    COUNT(*) AS total_rows,
                    COUNT("{col}") AS valid_rows,
                    COUNT(*) - COUNT("{col}") AS missing_rows
                FROM read_parquet('{path_sql}')
            """).fetchone()

            print(
                f"{col}: total={count[0]}, "
                f"valid={count[1]}, missing={count[2]}"
            )

con.close()
