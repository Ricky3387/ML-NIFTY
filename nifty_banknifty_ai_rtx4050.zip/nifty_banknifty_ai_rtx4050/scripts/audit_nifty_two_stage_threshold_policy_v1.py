
from pathlib import Path
from datetime import datetime
import json
import time
import warnings

import joblib
import lightgbm as lgb
import numpy as np
import pandas as pd

from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    log_loss,
    precision_score,
    recall_score,
    roc_auc_score,
)

warnings.filterwarnings("ignore", category=UserWarning)

# ============================================================
# CONFIGURATION
# ============================================================

ROOT = Path(__file__).resolve().parents[1]

DATA_DIR = ROOT / "data" / "processed" / "nifty_walkforward_v1"
TRAIN_FILE = DATA_DIR / "train_5m.parquet"
VALIDATION_FILE = DATA_DIR / "validation_5m.parquet"

MODEL_ROOT = ROOT / "models" / "nifty_two_stage_threshold_v1"
REPORT_ROOT = ROOT / "reports" / "nifty_two_stage_threshold_v1"

# Reuse the iteration counts from the completed two-stage run.
# These were selected using 2023 early stopping.
STAGE1_ITERATIONS = 57
STAGE2_ITERATIONS = 47

SEED = 42

LABELS = ["DOWN", "SIDEWAYS", "UP"]

FEATURES = [
    "ret_1m",
    "logret_1m",
    "range_pct",
    "body_pct",
    "upper_wick_pct",
    "lower_wick_pct",
    "return_5m",
    "return_15m",
    "return_30m",
    "return_60m",
    "realized_vol_5m",
    "realized_vol_15m",
    "realized_vol_30m",
    "realized_vol_60m",
    "high_low_range_5m",
    "high_low_range_15m",
    "high_low_range_30m",
    "high_low_range_60m",
    "close_vs_ema9_pct",
    "close_vs_ema21_pct",
    "close_vs_ema50_pct",
    "rsi_14",
    "positive_return_count_5m",
    "negative_return_count_5m",
    "target_vol_scale",
]

# Thresholds selected on 2023 only.
DIRECTIONAL_THRESHOLDS = np.round(
    np.arange(0.35, 0.701, 0.025), 3
)

CONDITIONAL_UP_THRESHOLDS = np.round(
    np.arange(0.40, 0.601, 0.025), 3
)


# ============================================================
# DATA AND MODEL HELPERS
# ============================================================

def create_directories():
    run_id = datetime.now().strftime("%Y%m%d_%H%M%S")

    model_dir = MODEL_ROOT / run_id
    report_dir = REPORT_ROOT / run_id

    model_dir.mkdir(parents=True, exist_ok=False)
    report_dir.mkdir(parents=True, exist_ok=False)

    return run_id, model_dir, report_dir


def load_and_filter(path, name):
    if not path.exists():
        raise FileNotFoundError(f"Missing {name} file: {path}")

    df = pd.read_parquet(path)

    required = FEATURES + [
        "timestamp_ist",
        "trading_day",
        "label",
        "sample_eligible",
    ]

    missing = sorted(set(required) - set(df.columns))

    if missing:
        raise ValueError(
            f"{name} is missing required columns: {missing}"
        )

    df["trading_day"] = pd.to_datetime(
        df["trading_day"]
    ).dt.date

    df["label"] = (
        df["label"].astype(str).str.upper()
    )

    df = df.loc[
        df["sample_eligible"].astype(bool)
        & df["label"].isin(LABELS)
        ].copy()

    if df.empty:
        raise ValueError(f"{name} has no eligible rows.")

    if df["timestamp_ist"].duplicated().any():
        raise ValueError(
            f"{name} contains duplicate timestamps."
        )

    # Check model features are numeric and finite.
    for col in FEATURES:
        df[col] = pd.to_numeric(
            df[col], errors="coerce"
        )

    invalid = ~np.isfinite(
        df[FEATURES].to_numpy(dtype=np.float64)
    ).all(axis=1)

    if invalid.any():
        raise ValueError(
            f"{name} contains {int(invalid.sum())} rows "
            "with missing or non-finite model features."
        )

    return df.sort_values(
        "timestamp_ist"
    ).reset_index(drop=True)


def make_model(iterations):
    return lgb.LGBMClassifier(
        objective="binary",
        n_estimators=int(iterations),
        learning_rate=0.025,
        num_leaves=31,
        max_depth=-1,
        min_child_samples=100,
        subsample=0.8,
        subsample_freq=1,
        colsample_bytree=0.8,
        reg_lambda=2.0,
        random_state=SEED,
        n_jobs=-1,
        verbosity=-1,
    )


def fit_two_stage(train_df, description):
    x = train_df[FEATURES]

    # Stage 1: directional versus sideways.
    y_directional = (
            train_df["label"] != "SIDEWAYS"
    ).astype(int)

    if y_directional.nunique() != 2:
        raise ValueError(
            f"{description}: Stage 1 requires both classes."
        )

    stage1 = make_model(STAGE1_ITERATIONS)
    stage1.fit(x, y_directional)

    # Stage 2: UP versus DOWN, using directional rows only.
    directional_df = train_df[
        train_df["label"].isin(["DOWN", "UP"])
    ]

    y_up = (
            directional_df["label"] == "UP"
    ).astype(int)

    if y_up.nunique() != 2:
        raise ValueError(
            f"{description}: Stage 2 requires DOWN and UP."
        )

    stage2 = make_model(STAGE2_ITERATIONS)
    stage2.fit(
        directional_df[FEATURES],
        y_up,
    )

    print(
        f"{description}: Stage 1 rows={len(train_df):,}; "
        f"Stage 2 rows={len(directional_df):,}"
    )

    return stage1, stage2


def predict_probabilities(stage1, stage2, df):
    x = df[FEATURES]

    p_directional = stage1.predict_proba(x)[:, 1]
    p_up_given_directional = stage2.predict_proba(x)[:, 1]

    p_down_given_directional = (
            1.0 - p_up_given_directional
    )

    p_down = (
            p_directional * p_down_given_directional
    )

    p_up = (
            p_directional * p_up_given_directional
    )

    p_sideways = 1.0 - p_directional

    return pd.DataFrame({
        "timestamp_ist": df["timestamp_ist"].to_numpy(),
        "trading_day": df["trading_day"].to_numpy(),
        "actual_label": df["label"].to_numpy(),
        "directional_probability": p_directional,
        "conditional_up_probability": p_up_given_directional,
        "conditional_down_probability": p_down_given_directional,
        "prob_down": p_down,
        "prob_sideways": p_sideways,
        "prob_up": p_up,
    })


# ============================================================
# THRESHOLD POLICY
# ============================================================

def apply_policy(
        predictions,
        directional_threshold,
        conditional_up_threshold,
):
    p_directional = (
        predictions["directional_probability"].to_numpy()
    )

    p_up = (
        predictions["conditional_up_probability"].to_numpy()
    )

    predicted = np.full(
        len(predictions),
        "SIDEWAYS",
        dtype=object,
    )

    directional_mask = (
            p_directional >= directional_threshold
    )

    up_mask = (
            p_up >= conditional_up_threshold
    )

    predicted[
        directional_mask & up_mask
        ] = "UP"

    predicted[
        directional_mask & ~up_mask
        ] = "DOWN"

    return predicted


def calculate_metrics(actual, predicted):
    actual = np.asarray(actual)
    predicted = np.asarray(predicted)

    actual_directional = actual != "SIDEWAYS"
    predicted_directional = predicted != "SIDEWAYS"

    directional_precision = precision_score(
        actual_directional,
        predicted_directional,
        zero_division=0,
    )

    directional_recall = recall_score(
        actual_directional,
        predicted_directional,
        zero_division=0,
    )

    result = {
        "rows": int(len(actual)),
        "accuracy": float(
            accuracy_score(actual, predicted)
        ),
        "balanced_accuracy": float(
            balanced_accuracy_score(
                actual,
                predicted,
            )
        ),
        "macro_f1": float(
            f1_score(
                actual,
                predicted,
                labels=LABELS,
                average="macro",
                zero_division=0,
            )
        ),
        "weighted_f1": float(
            f1_score(
                actual,
                predicted,
                labels=LABELS,
                average="weighted",
                zero_division=0,
            )
        ),
        "directional_precision": float(
            directional_precision
        ),
        "directional_recall": float(
            directional_recall
        ),
        "actual_directional_pct": float(
            actual_directional.mean() * 100
        ),
        "predicted_directional_pct": float(
            predicted_directional.mean() * 100
        ),
        "down_precision": float(
            precision_score(
                actual == "DOWN",
                predicted == "DOWN",
                zero_division=0,
                )
        ),
        "down_recall": float(
            recall_score(
                actual == "DOWN",
                predicted == "DOWN",
                zero_division=0,
                )
        ),
        "up_precision": float(
            precision_score(
                actual == "UP",
                predicted == "UP",
                zero_division=0,
                )
        ),
        "up_recall": float(
            recall_score(
                actual == "UP",
                predicted == "UP",
                zero_division=0,
                )
        ),
        "predicted_class_distribution_pct": {
            label: float(
                (predicted == label).mean() * 100
            )
            for label in LABELS
        },
    }

    return result


def make_threshold_grid(calibration_predictions):
    rows = []

    actual = (
        calibration_predictions["actual_label"].to_numpy()
    )

    for directional_threshold in DIRECTIONAL_THRESHOLDS:
        for up_threshold in CONDITIONAL_UP_THRESHOLDS:

            predicted = apply_policy(
                calibration_predictions,
                directional_threshold,
                up_threshold,
            )

            metrics = calculate_metrics(
                actual,
                predicted,
            )

            rows.append({
                "directional_threshold": float(
                    directional_threshold
                ),
                "conditional_up_threshold": float(
                    up_threshold
                ),
                **metrics,
            })

    grid = pd.DataFrame(rows)

    # Macro-F1 is the primary selection metric.
    # Tie-break using balanced accuracy, then directional precision.
    grid = grid.sort_values(
        [
            "macro_f1",
            "balanced_accuracy",
            "directional_precision",
        ],
        ascending=[False, False, False],
    ).reset_index(drop=True)

    grid.insert(
        0,
        "calibration_rank",
        np.arange(1, len(grid) + 1),
    )

    return grid


# ============================================================
# REPORT HELPERS
# ============================================================

def save_policy_report(predictions, predicted, report_dir, prefix):
    output = predictions.copy()
    output["predicted_label"] = predicted

    output.to_parquet(
        report_dir / f"{prefix}_predictions.parquet",
        index=False,
        )

    metrics = calculate_metrics(
        output["actual_label"],
        output["predicted_label"],
    )

    # Probability ranking diagnostics.
    actual_directional = (
            output["actual_label"] != "SIDEWAYS"
    ).astype(int)

    metrics["directional_auc"] = float(
        roc_auc_score(
            actual_directional,
            output["directional_probability"],
        )
    )

    actual_up = (
            output["actual_label"] == "UP"
    ).astype(int)

    actual_down = (
            output["actual_label"] == "DOWN"
    ).astype(int)

    metrics["up_vs_rest_auc"] = float(
        roc_auc_score(
            actual_up,
            output["prob_up"],
        )
    )

    metrics["down_vs_rest_auc"] = float(
        roc_auc_score(
            actual_down,
            output["prob_down"],
        )
    )

    matrix = confusion_matrix(
        output["actual_label"],
        output["predicted_label"],
        labels=LABELS,
    )

    pd.DataFrame(
        matrix,
        index=[f"actual_{x}" for x in LABELS],
        columns=[f"predicted_{x}" for x in LABELS],
    ).to_csv(
        report_dir / f"{prefix}_confusion_matrix.csv"
    )

    report = classification_report(
        output["actual_label"],
        output["predicted_label"],
        labels=LABELS,
        output_dict=True,
        zero_division=0,
    )

    pd.DataFrame(report).transpose().to_csv(
        report_dir / f"{prefix}_classification_report.csv"
    )

    with open(
            report_dir / f"{prefix}_metrics.json",
            "w",
            encoding="utf-8",
    ) as f:
        json.dump(metrics, f, indent=2)

    return metrics


def save_argmax_comparison(predictions, report_dir, prefix):
    probability_matrix = predictions[
        ["prob_down", "prob_sideways", "prob_up"]
    ].to_numpy()

    predicted = np.array(LABELS)[
        np.argmax(probability_matrix, axis=1)
    ]

    metrics = calculate_metrics(
        predictions["actual_label"],
        predicted,
    )

    metrics["policy"] = "combined_probability_argmax"

    with open(
            report_dir / f"{prefix}_argmax_metrics.json",
            "w",
            encoding="utf-8",
    ) as f:
        json.dump(metrics, f, indent=2)

    return metrics


# ============================================================
# MAIN
# ============================================================

def main():
    start = time.time()

    run_id, model_dir, report_dir = create_directories()

    print("=" * 75)
    print("NIFTY TWO-STAGE THRESHOLD POLICY AUDIT V1")
    print("=" * 75)
    print(f"Run ID: {run_id}")

    train = load_and_filter(
        TRAIN_FILE,
        "training",
    )

    validation = load_and_filter(
        VALIDATION_FILE,
        "validation",
    )

    date_2023_start = pd.to_datetime(
        "2023-01-01"
    ).date()

    date_2023_end = pd.to_datetime(
        "2023-12-31"
    ).date()

    date_2024_start = pd.to_datetime(
        "2024-01-01"
    ).date()

    date_2024_end = pd.to_datetime(
        "2024-12-31"
    ).date()

    train_2021_2022 = train[
        train["trading_day"] < date_2023_start
        ].copy()

    calibration_2023 = train[
        (train["trading_day"] >= date_2023_start)
        & (train["trading_day"] <= date_2023_end)
        ].copy()

    final_train_2021_2023 = train[
        train["trading_day"] <= date_2023_end
        ].copy()

    evaluation_2024 = validation[
        (validation["trading_day"] >= date_2024_start)
        & (validation["trading_day"] <= date_2024_end)
        ].copy()

    if any(
            x.empty
            for x in [
                train_2021_2022,
                calibration_2023,
                final_train_2021_2023,
                evaluation_2024,
            ]
    ):
        raise ValueError(
            "One or more chronological partitions are empty."
        )

    print("\nDATA PARTITIONS")
    print(f"2021-2022 fit: {len(train_2021_2022):,}")
    print(f"2023 threshold calibration: {len(calibration_2023):,}")
    print(f"2021-2023 final fit: {len(final_train_2021_2023):,}")
    print(f"2024 diagnostic evaluation: {len(evaluation_2024):,}")

    # --------------------------------------------------------
    # Model A: train only through 2022, predict 2023.
    # --------------------------------------------------------

    print("\nFITTING CALIBRATION MODELS")

    calibration_stage1, calibration_stage2 = fit_two_stage(
        train_2021_2022,
        "Calibration model",
    )

    calibration_predictions = predict_probabilities(
        calibration_stage1,
        calibration_stage2,
        calibration_2023,
    )

    calibration_predictions.to_parquet(
        report_dir / "2023_calibration_probabilities.parquet",
        index=False,
        )

    # --------------------------------------------------------
    # Select thresholds using 2023 only.
    # --------------------------------------------------------

    print("\nSEARCHING THRESHOLD GRID")

    grid = make_threshold_grid(
        calibration_predictions
    )

    grid.to_csv(
        report_dir / "2023_threshold_grid.csv",
        index=False,
        )

    selected = grid.iloc[0]

    selected_directional_threshold = float(
        selected["directional_threshold"]
    )

    selected_up_threshold = float(
        selected["conditional_up_threshold"]
    )

    print("\nSELECTED POLICY FROM 2023")
    print(
        f"Directional threshold: "
        f"{selected_directional_threshold:.3f}"
    )
    print(
        f"Conditional UP threshold: "
        f"{selected_up_threshold:.3f}"
    )
    print(
        f"2023 calibration macro-F1: "
        f"{selected['macro_f1']:.6f}"
    )

    # Also save the calibration metrics for the selected policy.
    calibration_prediction = apply_policy(
        calibration_predictions,
        selected_directional_threshold,
        selected_up_threshold,
    )

    calibration_metrics = save_policy_report(
        calibration_predictions,
        calibration_prediction,
        report_dir,
        "2023_selected_policy",
    )

    # --------------------------------------------------------
    # Model B: refit through 2023, predict 2024.
    # --------------------------------------------------------

    print("\nFITTING FINAL MODEL THROUGH 2023")

    final_stage1, final_stage2 = fit_two_stage(
        final_train_2021_2023,
        "Final model",
    )

    joblib.dump(
        final_stage1,
        model_dir / "stage1_directional_vs_sideways.joblib",
        )

    joblib.dump(
        final_stage2,
        model_dir / "stage2_down_vs_up.joblib",
        )

    evaluation_predictions = predict_probabilities(
        final_stage1,
        final_stage2,
        evaluation_2024,
    )

    evaluation_predictions.to_parquet(
        report_dir / "2024_evaluation_probabilities.parquet",
        index=False,
        )

    # --------------------------------------------------------
    # Apply frozen 2023 thresholds to 2024.
    # --------------------------------------------------------

    evaluation_prediction = apply_policy(
        evaluation_predictions,
        selected_directional_threshold,
        selected_up_threshold,
    )

    evaluation_metrics = save_policy_report(
        evaluation_predictions,
        evaluation_prediction,
        report_dir,
        "2024_selected_policy",
    )

    # Compare with default argmax on exactly the same probabilities.
    argmax_metrics = save_argmax_comparison(
        evaluation_predictions,
        report_dir,
        "2024",
    )

    # Compare threshold policy with argmax.
    comparison = pd.DataFrame([
        {
            "policy": "2023_selected_threshold_policy",
            **evaluation_metrics,
        },
        {
            "policy": "combined_probability_argmax",
            **argmax_metrics,
        },
    ])

    comparison.to_csv(
        report_dir / "2024_policy_comparison.csv",
        index=False,
        )

    # --------------------------------------------------------
    # Save top calibration candidates.
    # --------------------------------------------------------

    grid.head(25).to_csv(
        report_dir / "top_25_2023_threshold_policies.csv",
        index=False,
        )

    # --------------------------------------------------------
    # Save manifest.
    # --------------------------------------------------------

    manifest = {
        "run_id": run_id,
        "experiment": "two_stage_threshold_policy_v1",
        "training_fit_period": "2021-2022",
        "threshold_calibration_period": "2023",
        "final_model_fit_period": "2021-2023",
        "diagnostic_evaluation_period": "2024",
        "excluded_periods": ["2025", "2026"],
        "stage1_iterations": STAGE1_ITERATIONS,
        "stage2_iterations": STAGE2_ITERATIONS,
        "threshold_selection_metric": "macro_f1",
        "threshold_tie_breakers": [
            "balanced_accuracy",
            "directional_precision",
        ],
        "selected_directional_threshold": (
            selected_directional_threshold
        ),
        "selected_conditional_up_threshold": (
            selected_up_threshold
        ),
        "feature_count": len(FEATURES),
        "features": FEATURES,
        "timezone": "Asia/Kolkata",
        "warning": (
            "Iteration counts were previously selected using 2023. "
            "Therefore 2023 is a calibration set, not an independent "
            "validation set. 2024 has been used in prior research and "
            "is diagnostic, not an untouched test."
        ),
    }

    with open(
            report_dir / "run_manifest.json",
            "w",
            encoding="utf-8",
    ) as f:
        json.dump(manifest, f, indent=2)

    # --------------------------------------------------------
    # Console summary.
    # --------------------------------------------------------

    print("\n" + "=" * 75)
    print("2024 POLICY COMPARISON")
    print("=" * 75)

    display_columns = [
        "policy",
        "accuracy",
        "balanced_accuracy",
        "macro_f1",
        "directional_precision",
        "directional_recall",
        "predicted_directional_pct",
        "down_precision",
        "down_recall",
        "up_precision",
        "up_recall",
    ]

    print(
        comparison[display_columns].to_string(
            index=False,
            float_format=lambda x: f"{x:.5f}",
        )
    )

    print("\nTOP 10 THRESHOLD POLICIES FROM 2023")
    print(
        grid.head(10)[
            [
                "calibration_rank",
                "directional_threshold",
                "conditional_up_threshold",
                "macro_f1",
                "balanced_accuracy",
                "directional_precision",
                "directional_recall",
                "predicted_directional_pct",
            ]
        ].to_string(index=False)
    )

    print("\nOUTPUT DIRECTORIES")
    print(f"Models: {model_dir}")
    print(f"Reports: {report_dir}")
    print(f"Elapsed seconds: {time.time() - start:.2f}")

    print("\nCompleted successfully.")


if __name__ == "__main__":
    main()
