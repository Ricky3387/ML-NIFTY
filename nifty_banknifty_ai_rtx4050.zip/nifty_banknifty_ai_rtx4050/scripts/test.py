import duckdb

db = r"data/database/nifty_options.duckdb"

con = duckdb.connect(db, read_only=True)

for view in ["nifty_index", "nifty_options"]:
    print("\n", view)

    print(
        con.execute(
            f'SELECT * FROM "{view}" LIMIT 5'
        ).fetchdf().to_string(index=False)
    )

con.close()