
from pathlib import Path
from datetime import datetime
import json
import duckdb
import pandas as pd

# ============================================================
# NIFTY OPTIONS CONTINUITY AND DATA-SEMANTICS AUDIT v2
#
# Read-only audit.
# No model training.
# No source database modifications.
#
# Checks:
# 1. Duplicate contract-minute keys
# 2. Volume semantics: cumulative vs per-bar evidence
# 3. OI continuity and observation gaps
# 4. Exact-minute ATM CE/PE availability
# 5. Reconciliation of options days vs index days
# ============================================================

ROOT = Path(__file__).resolve().parent.parent
DB_PATH = ROOT / "data" / "database" / "nifty_options.duckdb"

OUTPUT_DIR = ROOT / "reports" / "nifty_options_continuity_v2"

START_DATE = "2021-05-24"
END_DATE = "2024-12-31"

TIMEZONE = "Asia/Kolkata"
SESSION_START = "09:15:00"
SESSION_END = "15:29:00"

SPECIAL_DATES = [
    "2021-11-04",
    "2022-10-24",
    "2023-11-12",
    "2024-11-01",
    "2024-01-20",
    "2024-03-02",
    "2024-05-18",
]

# ATM expiry selection is limited to this DTE range.
MAX_DTE = 7

# A gap larger than this is not considered continuous.
CONTINUITY_MAX_GAP_MINUTES = 1

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


def qid(value):
    return '"' + str(value).replace('"', '""') + '"'


def write_csv(df, filename):
    path = OUTPUT_DIR / filename
    df.to_csv(path, index=False)
    print(f"Generated: {path} ({len(df):,} rows)")


def save_json(data, filename):
    path = OUTPUT_DIR / filename
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, default=str)
    print(f"Generated: {path}")


def main():
    if not DB_PATH.exists():
        raise FileNotFoundError(f"DuckDB database not found: {DB_PATH}")

    con = duckdb.connect(str(DB_PATH), read_only=True)

    try:
        con.execute("SET threads = 4")
        con.execute("SET memory_limit = '8GB'")
        temp_dir = str(OUTPUT_DIR / "duckdb_temp").replace("\\", "/")
        con.execute(f"SET temp_directory = '{temp_dir}'")

        print("=" * 85)
        print("NIFTY OPTIONS CONTINUITY AUDIT v2")
        print("=" * 85)

        special_sql = ", ".join(
            f"DATE '{d}'" for d in SPECIAL_DATES
        )

        # ----------------------------------------------------
        # 1. Validate required columns
        # ----------------------------------------------------
        schema = con.execute(
            "DESCRIBE SELECT * FROM nifty_options"
        ).df()

        columns = set(schema["column_name"].astype(str))

        required = {
            "timestamp", "trading_day", "expiry", "strike",
            "option_type", "underlying", "close", "volume",
            "open_interest"
        }

        missing = sorted(required - columns)

        if missing:
            raise RuntimeError(
                "Missing required columns: " + ", ".join(missing)
            )

        write_csv(schema, "source_schema.csv")

        # ----------------------------------------------------
        # 2. Create normal-session NIFTY options scope
        # ----------------------------------------------------
        con.execute(f"""
            CREATE OR REPLACE TEMP VIEW opt_scope AS
            SELECT
                timestamp,
                timezone('{TIMEZONE}', timestamp) AS timestamp_ist,
                CAST(timezone('{TIMEZONE}', timestamp) AS DATE)
                    AS trading_date,
                CAST(expiry AS DATE) AS expiry_date,
                CAST(strike AS DOUBLE) AS strike,
                UPPER(TRIM(CAST(option_type AS VARCHAR)))
                    AS option_type,
                UPPER(TRIM(CAST(underlying AS VARCHAR)))
                    AS underlying,
                CAST(close AS DOUBLE) AS close,
                CAST(volume AS DOUBLE) AS volume,
                CAST(open_interest AS DOUBLE) AS open_interest
            FROM nifty_options
            WHERE UPPER(TRIM(CAST(underlying AS VARCHAR))) = 'NIFTY'
              AND CAST(timezone('{TIMEZONE}', timestamp) AS DATE)
                    BETWEEN DATE '{START_DATE}' AND DATE '{END_DATE}'
              AND CAST(timezone('{TIMEZONE}', timestamp) AS TIME)
                    BETWEEN TIME '{SESSION_START}' AND TIME '{SESSION_END}'
              AND CAST(timezone('{TIMEZONE}', timestamp) AS DATE)
                    NOT IN ({special_sql})
              AND UPPER(TRIM(CAST(option_type AS VARCHAR)))
                    IN ('CE', 'PE')
        """)

        total_rows = con.execute(
            "SELECT COUNT(*) FROM opt_scope"
        ).fetchone()[0]

        print("\nScoped option rows:", f"{total_rows:,}")

        # ----------------------------------------------------
        # 3. Duplicate contract-minute key audit
        #
        # Key:
        # timestamp + expiry + strike + option_type
        # ----------------------------------------------------
        con.execute("""
                    CREATE OR REPLACE TEMP VIEW opt_key_groups AS
                    SELECT
                        timestamp,
                        timestamp_ist,
                        trading_date,
                        expiry_date,
                        strike,
                        option_type,
                        COUNT(*) AS duplicate_count,
                        COUNT(DISTINCT close) AS distinct_close_values,
                        COUNT(DISTINCT volume) AS distinct_volume_values,
                        COUNT(DISTINCT open_interest) AS distinct_oi_values,
                        MIN(close) AS min_close,
                        MAX(close) AS max_close,
                        MIN(volume) AS min_volume,
                        MAX(volume) AS max_volume,
                        MIN(open_interest) AS min_oi,
                        MAX(open_interest) AS max_oi
                    FROM opt_scope
                    GROUP BY
                        timestamp,
                        timestamp_ist,
                        trading_date,
                        expiry_date,
                        strike,
                        option_type
                    """)

        duplicate_summary = con.execute("""
                                        SELECT
                                            COUNT(*) AS unique_contract_minute_keys,
                                            SUM(duplicate_count) AS source_rows,
                                            COUNT(*) FILTER (
                    WHERE duplicate_count > 1
                ) AS duplicate_key_groups,
                                            SUM(duplicate_count - 1) FILTER (
                    WHERE duplicate_count > 1
                ) AS duplicate_excess_rows,
                                            COUNT(*) FILTER (
                    WHERE duplicate_count > 1
                      AND (
                          distinct_close_values > 1
                          OR distinct_volume_values > 1
                          OR distinct_oi_values > 1
                      )
                ) AS conflicting_duplicate_groups
                                        FROM opt_key_groups
                                        """).df()

        write_csv(
            duplicate_summary,
            "duplicate_key_summary.csv"
        )

        duplicate_samples = con.execute("""
                                        SELECT *
                                        FROM opt_key_groups
                                        WHERE duplicate_count > 1
                                        ORDER BY duplicate_count DESC, timestamp_ist
                                            LIMIT 500
                                        """).df()

        write_csv(
            duplicate_samples,
            "duplicate_key_samples.csv"
        )

        # Only unique source keys are used for continuity analysis.
        con.execute("""
                    CREATE OR REPLACE TEMP VIEW opt_unique AS
                    SELECT o.*
                    FROM opt_scope o
                             INNER JOIN opt_key_groups g
                                        ON o.timestamp = g.timestamp
                                            AND o.expiry_date = g.expiry_date
                                            AND o.strike = g.strike
                                            AND o.option_type = g.option_type
                    WHERE g.duplicate_count = 1
                    """)

        unique_rows = con.execute(
            "SELECT COUNT(*) FROM opt_unique"
        ).fetchone()[0]

        print("Unique-key rows:", f"{unique_rows:,}")

        # ----------------------------------------------------
        # 4. Volume semantics audit
        #
        # Analyze same contract within same trading day.
        # A monotonically increasing series is evidence of
        # cumulative volume, but does not prove it.
        # ----------------------------------------------------
        con.execute("""
                    CREATE OR REPLACE TEMP VIEW volume_sequence AS
                    SELECT
                        *,
                        LAG(volume) OVER (
                    PARTITION BY
                        trading_date,
                        expiry_date,
                        strike,
                        option_type
                    ORDER BY timestamp
                ) AS previous_volume,
                        LAG(timestamp_ist) OVER (
                    PARTITION BY
                        trading_date,
                        expiry_date,
                        strike,
                        option_type
                    ORDER BY timestamp
                ) AS previous_timestamp
                    FROM opt_unique
                    """)

        volume_summary = con.execute("""
                                     WITH x AS (
                                         SELECT
                                             *,
                                             DATE_DIFF(
                                                     'minute',
                                                     previous_timestamp,
                                                     timestamp_ist
                                             ) AS gap_minutes,
                                             volume - previous_volume AS volume_delta
                                         FROM volume_sequence
                                         WHERE previous_volume IS NOT NULL
                                     )
                                     SELECT
                                         option_type,
                                         COUNT(*) AS consecutive_observation_pairs,
                                         COUNT(*) FILTER (
                    WHERE gap_minutes = 1
                ) AS one_minute_pairs,
                                         COUNT(*) FILTER (
                    WHERE gap_minutes > 1
                ) AS larger_gap_pairs,
                                         COUNT(*) FILTER (
                    WHERE gap_minutes = 1
                      AND volume_delta >= 0
                ) AS nondecreasing_one_minute_pairs,
                                         COUNT(*) FILTER (
                    WHERE gap_minutes = 1
                      AND volume_delta > 0
                ) AS increasing_one_minute_pairs,
                                         COUNT(*) FILTER (
                    WHERE gap_minutes = 1
                      AND volume_delta = 0
                ) AS unchanged_one_minute_pairs,
                                         COUNT(*) FILTER (
                    WHERE gap_minutes = 1
                      AND volume_delta < 0
                ) AS decreasing_one_minute_pairs,
                                         ROUND(
                                                 100.0 * COUNT(*) FILTER (
                        WHERE gap_minutes = 1
                          AND volume_delta >= 0
                    ) / NULLIF(
                        COUNT(*) FILTER (WHERE gap_minutes = 1),
                        0
                    ),
                                                 4
                                         ) AS nondecreasing_pct,
                                         APPROX_QUANTILE(volume, 0.50)
                                                  AS median_observed_volume,
                                         APPROX_QUANTILE(volume_delta, 0.50)
                                                     FILTER (WHERE gap_minutes = 1)
                    AS median_one_minute_delta
                                     FROM x
                                     GROUP BY option_type
                                     ORDER BY option_type
                                     """).df()

        write_csv(
            volume_summary,
            "volume_semantics_summary.csv"
        )

        volume_examples = con.execute("""
                                      SELECT
                                          trading_date,
                                          timestamp_ist,
                                          expiry_date,
                                          strike,
                                          option_type,
                                          previous_volume,
                                          volume,
                                          volume_delta,
                                          gap_minutes
                                      FROM (
                                               SELECT
                                                   *,
                                                   volume - previous_volume AS volume_delta,
                                                   DATE_DIFF(
                                                           'minute',
                                                           previous_timestamp,
                                                           timestamp_ist
                                                   ) AS gap_minutes
                                               FROM volume_sequence
                                               WHERE previous_volume IS NOT NULL
                                           )
                                      WHERE gap_minutes = 1
                                      ORDER BY
                                          CASE WHEN volume_delta < 0 THEN 0 ELSE 1 END,
                                          ABS(volume_delta) DESC
                                          LIMIT 500
                                      """).df()

        write_csv(
            volume_examples,
            "volume_consecutive_samples.csv"
        )

        # ----------------------------------------------------
        # 5. OI continuity and gap audit
        # ----------------------------------------------------
        con.execute("""
                    CREATE OR REPLACE TEMP VIEW oi_sequence AS
                    SELECT
                        *,
                        LAG(open_interest) OVER (
                    PARTITION BY
                        trading_date,
                        expiry_date,
                        strike,
                        option_type
                    ORDER BY timestamp
                ) AS previous_oi,
                        LAG(timestamp_ist) OVER (
                    PARTITION BY
                        trading_date,
                        expiry_date,
                        strike,
                        option_type
                    ORDER BY timestamp
                ) AS previous_timestamp
                    FROM opt_unique
                    WHERE open_interest IS NOT NULL
                      AND open_interest > 0
                    """)

        oi_summary = con.execute("""
                                 WITH x AS (
                                     SELECT
                                         *,
                                         DATE_DIFF(
                                                 'minute',
                                                 previous_timestamp,
                                                 timestamp_ist
                                         ) AS gap_minutes,
                                         open_interest - previous_oi AS oi_delta
                                     FROM oi_sequence
                                     WHERE previous_oi IS NOT NULL
                                 )
                                 SELECT
                                     option_type,
                                     COUNT(*) AS consecutive_oi_pairs,

                                     COUNT(*) FILTER (
                    WHERE gap_minutes = 1
                ) AS one_minute_pairs,

                                     COUNT(*) FILTER (
                    WHERE gap_minutes BETWEEN 2 AND 5
                ) AS gap_2_to_5_pairs,

                                     COUNT(*) FILTER (
                    WHERE gap_minutes BETWEEN 6 AND 15
                ) AS gap_6_to_15_pairs,

                                     COUNT(*) FILTER (
                    WHERE gap_minutes > 15
                ) AS gap_over_15_pairs,

                                     COUNT(*) FILTER (
                    WHERE gap_minutes = 1 AND oi_delta > 0
                ) AS oi_increase_pairs,

                                     COUNT(*) FILTER (
                    WHERE gap_minutes = 1 AND oi_delta < 0
                ) AS oi_decrease_pairs,

                                     COUNT(*) FILTER (
                    WHERE gap_minutes = 1 AND oi_delta = 0
                ) AS oi_unchanged_pairs,

                                     APPROX_QUANTILE(ABS(oi_delta), 0.50)
                                         FILTER (WHERE gap_minutes = 1)
                    AS median_absolute_oi_change

                                 FROM x
                                 GROUP BY option_type
                                 ORDER BY option_type
                                 """).df()

        write_csv(oi_summary, "oi_continuity_summary.csv")

        oi_gap_distribution = con.execute("""
                                          WITH x AS (
                                              SELECT
                                                  *,
                                                  DATE_DIFF(
                                                          'minute',
                                                          previous_timestamp,
                                                          timestamp_ist
                                                  ) AS gap_minutes
                                              FROM oi_sequence
                                              WHERE previous_oi IS NOT NULL
                                          )
                                          SELECT
                                              option_type,
                                              CASE
                                                  WHEN gap_minutes = 1 THEN '1 minute'
                                                  WHEN gap_minutes BETWEEN 2 AND 5 THEN '2-5 minutes'
                                                  WHEN gap_minutes BETWEEN 6 AND 15 THEN '6-15 minutes'
                                                  WHEN gap_minutes BETWEEN 16 AND 30 THEN '16-30 minutes'
                                                  WHEN gap_minutes > 30 THEN 'over 30 minutes'
                                                  ELSE 'invalid'
                                                  END AS gap_bucket,
                                              COUNT(*) AS observations
                                          FROM x
                                          GROUP BY option_type, gap_bucket
                                          ORDER BY option_type, gap_bucket
                                          """).df()

        write_csv(
            oi_gap_distribution,
            "oi_gap_distribution.csv"
        )

        # ----------------------------------------------------
        # 6. Build normal-session index minute universe
        # ----------------------------------------------------
        index_schema = con.execute(
            "DESCRIBE SELECT * FROM nifty_index"
        ).df()

        index_columns = set(index_schema["column_name"].astype(str))

        if not {"timestamp", "close"}.issubset(index_columns):
            raise RuntimeError(
                "nifty_index must contain timestamp and close."
            )

        synthetic_filter = ""
        if "is_synthetic" in index_columns:
            synthetic_filter = """
                AND COALESCE(is_synthetic, FALSE) = FALSE
            """

        con.execute(f"""
            CREATE OR REPLACE TEMP VIEW index_scope AS
            SELECT
                timestamp,
                timezone('{TIMEZONE}', timestamp) AS timestamp_ist,
                CAST(timezone('{TIMEZONE}', timestamp) AS DATE)
                    AS trading_date,
                CAST(close AS DOUBLE) AS spot_close
            FROM nifty_index
            WHERE CAST(timezone('{TIMEZONE}', timestamp) AS DATE)
                    BETWEEN DATE '{START_DATE}' AND DATE '{END_DATE}'
              AND CAST(timezone('{TIMEZONE}', timestamp) AS TIME)
                    BETWEEN TIME '{SESSION_START}' AND TIME '{SESSION_END}'
              AND CAST(timezone('{TIMEZONE}', timestamp) AS DATE)
                    NOT IN ({special_sql})
              AND close > 0
              {synthetic_filter}
        """)

        index_summary = con.execute("""
                                    SELECT
                                        COUNT(*) AS index_minutes,
                                        COUNT(DISTINCT trading_date) AS index_trading_days,
                                        MIN(timestamp_ist) AS first_timestamp_ist,
                                        MAX(timestamp_ist) AS last_timestamp_ist
                                    FROM index_scope
                                    """).df()

        write_csv(index_summary, "index_scope_summary.csv")

        # ----------------------------------------------------
        # 7. Options vs index timestamp reconciliation
        # ----------------------------------------------------
        reconciliation = con.execute("""
                                     WITH option_minutes AS (
                                         SELECT DISTINCT timestamp
                                     FROM opt_unique
                                         )
                                     SELECT
                                         COUNT(*) AS index_minutes,
                                         COUNT(*) FILTER (
                    WHERE o.timestamp IS NOT NULL
                ) AS index_minutes_with_options,
                                         COUNT(*) FILTER (
                    WHERE o.timestamp IS NULL
                ) AS index_minutes_without_options,
                                         ROUND(
                                                 100.0 * COUNT(*) FILTER (
                        WHERE o.timestamp IS NOT NULL
                    ) / NULLIF(COUNT(*), 0),
                                                 4
                                         ) AS index_minute_option_coverage_pct
                                     FROM index_scope i
                                              LEFT JOIN option_minutes o
                                                        ON i.timestamp = o.timestamp
                                     """).df()

        write_csv(
            reconciliation,
            "index_options_timestamp_reconciliation.csv"
        )

        missing_minutes = con.execute("""
                                      WITH option_minutes AS (
                                          SELECT DISTINCT timestamp
                                      FROM opt_unique
                                          )
                                      SELECT
                                          i.trading_date,
                                          i.timestamp_ist,
                                          i.spot_close
                                      FROM index_scope i
                                               LEFT JOIN option_minutes o
                                                         ON i.timestamp = o.timestamp
                                      WHERE o.timestamp IS NULL
                                      ORDER BY i.timestamp_ist
                                      """).df()

        write_csv(
            missing_minutes,
            "index_minutes_without_options.csv"
        )

        daily_reconciliation = con.execute("""
                                           WITH option_minutes AS (
                                               SELECT DISTINCT timestamp
                                           FROM opt_unique
                                               )
                                           SELECT
                                               i.trading_date,
                                               COUNT(*) AS index_minutes,
                                               COUNT(*) FILTER (
                    WHERE o.timestamp IS NOT NULL
                ) AS matched_option_minutes,
                                               COUNT(*) FILTER (
                    WHERE o.timestamp IS NULL
                ) AS missing_option_minutes,
                                               ROUND(
                                                       100.0 * COUNT(*) FILTER (
                        WHERE o.timestamp IS NOT NULL
                    ) / NULLIF(COUNT(*), 0),
                                                       4
                                               ) AS coverage_pct
                                           FROM index_scope i
                                                    LEFT JOIN option_minutes o
                                                              ON i.timestamp = o.timestamp
                                           GROUP BY i.trading_date
                                           ORDER BY i.trading_date
                                           """).df()

        write_csv(
            daily_reconciliation,
            "daily_index_options_reconciliation.csv"
        )

        # ----------------------------------------------------
        # 8. ATM CE/PE availability
        #
        # Selection:
        #   - exact spot timestamp
        #   - expiry DTE 0..7
        #   - nearest expiry first
        #   - nearest strike to spot within that expiry
        #
        # The selected nearest strike is NOT replaced by a
        # farther strike merely because it has a paired option.
        # We explicitly measure whether CE and PE are present.
        # ----------------------------------------------------
        con.execute("""
                    CREATE OR REPLACE TEMP VIEW option_contract_slots AS
                    SELECT
                        timestamp,
                        trading_date,
                        expiry_date,
                        strike,
                        COUNT(*) FILTER (
                        WHERE option_type = 'CE'
                        ) AS ce_count,
                        COUNT(*) FILTER (
                        WHERE option_type = 'PE'
                        ) AS pe_count,
                        MAX(close) FILTER (
                        WHERE option_type = 'CE'
                        ) AS ce_close,
                        MAX(close) FILTER (
                        WHERE option_type = 'PE'
                        ) AS pe_close,
                        MAX(open_interest) FILTER (
                        WHERE option_type = 'CE'
                        ) AS ce_oi,
                        MAX(open_interest) FILTER (
                        WHERE option_type = 'PE'
                        ) AS pe_oi,
                        MAX(volume) FILTER (
                        WHERE option_type = 'CE'
                        ) AS ce_volume,
                        MAX(volume) FILTER (
                        WHERE option_type = 'PE'
                        ) AS pe_volume
                    FROM opt_unique
                    GROUP BY
                        timestamp,
                        trading_date,
                        expiry_date,
                        strike
                    """)

        con.execute("""
                    CREATE OR REPLACE TEMP VIEW atm_candidates AS
                    SELECT
                        i.timestamp,
                        i.timestamp_ist,
                        i.trading_date,
                        i.spot_close,
                        o.expiry_date,
                        o.strike,
                        DATE_DIFF(
                                'day',
                                i.trading_date,
                                o.expiry_date
                        ) AS dte,
                        ABS(o.strike - i.spot_close)
                            / NULLIF(i.spot_close, 0) * 100.0
                          AS strike_distance_pct,
                        o.ce_count,
                        o.pe_count,
                        o.ce_close,
                        o.pe_close,
                        o.ce_oi,
                        o.pe_oi,
                        o.ce_volume,
                        o.pe_volume
                    FROM index_scope i
                             INNER JOIN option_contract_slots o
                                        ON i.timestamp = o.timestamp
                    WHERE DATE_DIFF(
                                  'day',
                                  i.trading_date,
                                  o.expiry_date
                          ) BETWEEN 0 AND 7
                    """)

        con.execute("""
                    CREATE OR REPLACE TEMP VIEW selected_atm AS
                    SELECT *
                    FROM atm_candidates
                             QUALIFY ROW_NUMBER() OVER (
                PARTITION BY timestamp
                ORDER BY
                    dte ASC,
                    strike_distance_pct ASC,
                    strike ASC
            ) = 1
                    """)

        atm_summary = con.execute("""
                                  WITH x AS (
                                      SELECT
                                          *,
                                          CASE
                                              WHEN ce_count > 0 THEN 1 ELSE 0
                                              END AS has_ce,
                                          CASE
                                              WHEN pe_count > 0 THEN 1 ELSE 0
                                              END AS has_pe,
                                          CASE
                                              WHEN ce_count > 0 AND pe_count > 0
                                                  THEN 1 ELSE 0
                                              END AS has_pair
                                      FROM selected_atm
                                  )
                                  SELECT
                                          (SELECT COUNT(*) FROM index_scope)
                                                   AS total_index_minutes,

                                          COUNT(*) AS index_minutes_with_dte_0_7_candidate,

                                          COUNT(*) FILTER (WHERE has_ce = 1)
                    AS selected_atm_with_ce,

                                      COUNT(*) FILTER (WHERE has_pe = 1)
                    AS selected_atm_with_pe,

                                      COUNT(*) FILTER (WHERE has_pair = 1)
                    AS selected_atm_with_ce_pe_pair,

                                      COUNT(*) FILTER (WHERE has_pair = 0)
                    AS selected_atm_without_pair,

                                      ROUND(
                                              100.0 * COUNT(*) FILTER (WHERE has_pair = 1)
                    / NULLIF(
                        (SELECT COUNT(*) FROM index_scope), 0
                    ),
                                              4
                                      ) AS paired_atm_coverage_all_index_minutes_pct,

                                          ROUND(
                                                  100.0 * COUNT(*) FILTER (WHERE has_pair = 1)
                    / NULLIF(COUNT(*), 0),
                                                  4
                                          ) AS paired_atm_coverage_candidate_minutes_pct,

                                          APPROX_QUANTILE(strike_distance_pct, 0.50)
                                                   AS median_selected_strike_distance_pct,

                                          APPROX_QUANTILE(dte, 0.50)
                                                   AS median_selected_dte

                                  FROM x
                                  """).df()

        write_csv(
            atm_summary,
            "atm_exact_minute_coverage_summary.csv"
        )

        atm_daily = con.execute("""
                                SELECT
                                    i.trading_date,
                                    COUNT(*) AS index_minutes,
                                    COUNT(a.timestamp) AS minutes_with_dte_0_7_candidate,
                                    COUNT(*) FILTER (
                    WHERE a.ce_count > 0 AND a.pe_count > 0
                ) AS minutes_with_paired_nearest_atm,
                                    COUNT(*) FILTER (
                    WHERE a.timestamp IS NULL
                ) AS minutes_without_expiry_candidate,
                                    ROUND(
                                            100.0 * COUNT(*) FILTER (
                        WHERE a.ce_count > 0 AND a.pe_count > 0
                    ) / NULLIF(COUNT(*), 0),
                                            4
                                    ) AS paired_atm_coverage_pct
                                FROM index_scope i
                                         LEFT JOIN selected_atm a
                                                   ON i.timestamp = a.timestamp
                                GROUP BY i.trading_date
                                ORDER BY i.trading_date
                                """).df()

        write_csv(
            atm_daily,
            "daily_atm_exact_minute_coverage.csv"
        )

        atm_missing = con.execute("""
                                  SELECT
                                      i.trading_date,
                                      i.timestamp_ist,
                                      i.spot_close,
                                      a.expiry_date,
                                      a.strike,
                                      a.dte,
                                      a.strike_distance_pct,
                                      a.ce_count,
                                      a.pe_count
                                  FROM index_scope i
                                           LEFT JOIN selected_atm a
                                                     ON i.timestamp = a.timestamp
                                  WHERE a.timestamp IS NULL
                                     OR a.ce_count = 0
                                     OR a.pe_count = 0
                                  ORDER BY i.timestamp_ist
                                      LIMIT 5000
                                  """).df()

        write_csv(
            atm_missing,
            "atm_missing_pair_samples.csv"
        )

        # ----------------------------------------------------
        # 9. Selected ATM OI and volume availability
        # ----------------------------------------------------
        atm_field_quality = con.execute("""
                                        SELECT
                                            COUNT(*) AS paired_atm_rows,

                                            COUNT(*) FILTER (
                    WHERE ce_oi IS NOT NULL AND ce_oi > 0
                      AND pe_oi IS NOT NULL AND pe_oi > 0
                ) AS paired_positive_oi_rows,

                                            COUNT(*) FILTER (
                    WHERE ce_volume IS NOT NULL
                      AND pe_volume IS NOT NULL
                ) AS paired_non_null_volume_rows,

                                            COUNT(*) FILTER (
                    WHERE ce_close > 0 AND pe_close > 0
                ) AS paired_valid_price_rows,

                                            COUNT(*) FILTER (
                    WHERE ce_oi = 0 OR pe_oi = 0
                ) AS paired_rows_with_zero_oi,

                                            COUNT(*) FILTER (
                    WHERE ce_volume = 0 OR pe_volume = 0
                ) AS paired_rows_with_zero_volume

                                        FROM selected_atm
                                        WHERE ce_count > 0 AND pe_count > 0
                                        """).df()

        write_csv(
            atm_field_quality,
            "atm_paired_field_quality.csv"
        )

        # ----------------------------------------------------
        # 10. Final summary
        # ----------------------------------------------------
        def first_record(df):
            if df.empty:
                return {}
            return df.iloc[0].to_dict()

        summary = {
            "generated_at": datetime.now().isoformat(),
            "source": str(DB_PATH),
            "date_scope": {
                "start": START_DATE,
                "end": END_DATE
            },
            "session": {
                "timezone": TIMEZONE,
                "start": SESSION_START,
                "end": SESSION_END,
                "special_dates_excluded": SPECIAL_DATES
            },
            "rows_in_scope": int(total_rows),
            "unique_key_rows": int(unique_rows),
            "duplicate_key_summary": first_record(
                duplicate_summary
            ),
            "volume_semantics": (
                volume_summary.to_dict(orient="records")
            ),
            "oi_continuity": (
                oi_summary.to_dict(orient="records")
            ),
            "index_options_reconciliation": first_record(
                reconciliation
            ),
            "atm_exact_minute_coverage": first_record(
                atm_summary
            ),
            "atm_field_quality": first_record(
                atm_field_quality
            ),
            "source_modified": False,
            "model_training_performed": False,
            "important_limitations": [
                "Volume monotonicity is evidence, not definitive proof, of cumulative volume.",
                "Duplicate keys are excluded from continuity calculations.",
                "ATM selection uses nearest expiry first and nearest strike second.",
                "ATM pairing is checked at exact index timestamps.",
                "No bid/ask, implied volatility or Greeks are fabricated.",
                "This audit does not generate model features."
            ]
        }

        save_json(
            summary,
            "continuity_audit_summary.json"
        )

        print("\n" + "=" * 85)
        print("CONTINUITY AUDIT COMPLETED")
        print("=" * 85)
        print("Options rows:", f"{total_rows:,}")
        print("Unique-key rows:", f"{unique_rows:,}")
        print("Output:", OUTPUT_DIR)
        print("Source database: READ ONLY")
        print("Training: NOT PERFORMED")

    finally:
        con.close()


if __name__ == "__main__":
    main()
