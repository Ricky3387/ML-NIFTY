
from pathlib import Path
import duckdb
import pandas as pd
import json

# -------------------------------------------------
# Configuration
# -------------------------------------------------

BASE_DIR = Path(__file__).resolve().parent.parent

PROCESSED_DIR = BASE_DIR / "data" / "processed"
DATABASE_DIR = BASE_DIR / "data" / "database"
REPORT_DIR = BASE_DIR / "data" / "reports"
TEMP_DIR = BASE_DIR / "data" / "duckdb_temp"

DB_FILE = DATABASE_DIR / "nifty_options.duckdb"

DATABASE_DIR.mkdir(parents=True, exist_ok=True)
REPORT_DIR.mkdir(parents=True, exist_ok=True)
TEMP_DIR.mkdir(parents=True, exist_ok=True)

# Conservative settings for 16 GB RAM.
MEMORY_LIMIT = "6GB"
THREADS = 4

DATASETS = {
    "nifty_index": ("NIFTY", "index"),
    "nifty_options": ("NIFTY", "options"),
    "banknifty_index": ("BANKNIFTY", "index"),
    "banknifty_options": ("BANKNIFTY", "options"),
}


def sql_string(value):
    """Safely quote a SQL string literal."""
    return "'" + str(value).replace("'", "''") + "'"


def get_parquet_files(index_name, data_type):
    folder = PROCESSED_DIR / index_name / data_type

    if not folder.exists():
        raise FileNotFoundError(
            f"Dataset folder not found: {folder}"
        )

    files = sorted(folder.rglob("*.parquet"))

    if not files:
        raise FileNotFoundError(
            f"No Parquet files found in: {folder}"
        )

    return files


def create_view(con, view_name, index_name, data_type):
    files = get_parquet_files(index_name, data_type)

    file_list = ", ".join(
        sql_string(file.resolve().as_posix())
        for file in files
    )

    sql = f"""
        CREATE OR REPLACE VIEW {view_name} AS
        SELECT
            *,
            {sql_string(index_name)} AS underlying,
            {sql_string(data_type)} AS dataset_type
        FROM read_parquet(
            [{file_list}],
            union_by_name = true
        )
    """

    con.execute(sql)

    print(
        f"Created view: {view_name} "
        f"({len(files)} Parquet files)"
    )

    return len(files)


def profile_view(con, view_name, data_type):
    query = f"""
        SELECT
            COUNT(*) AS rows,
            COUNT(DISTINCT symbol) AS symbols,
            MIN(timestamp) AS first_timestamp,
            MAX(timestamp) AS last_timestamp,
            COUNT(*) FILTER (
                WHERE timestamp IS NULL
            ) AS null_timestamps,
            COUNT(*) FILTER (
                WHERE open IS NULL
                   OR high IS NULL
                   OR low IS NULL
                   OR close IS NULL
            ) AS null_ohlc,
            COUNT(*) FILTER (
                WHERE volume < 0
            ) AS negative_volume
        FROM {view_name}
    """

    result = con.execute(query).fetchone()

    profile = {
        "dataset": view_name,
        "rows": result[0],
        "symbols": result[1],
        "first_timestamp": str(result[2]),
        "last_timestamp": str(result[3]),
        "null_timestamps": result[4],
        "null_ohlc": result[5],
        "negative_volume": result[6],
    }

    if data_type == "options":
        extra = con.execute(f"""
            SELECT
                COUNT(DISTINCT expiry),
                COUNT(DISTINCT strike),
                COUNT(*) FILTER (
                    WHERE expiry IS NULL
                ),
                COUNT(*) FILTER (
                    WHERE strike IS NULL
                ),
                COUNT(*) FILTER (
                    WHERE option_type IS NULL
                ),
                COUNT(*) FILTER (
                    WHERE open_interest < 0
                )
            FROM {view_name}
        """).fetchone()

        profile.update({
            "unique_expiries": extra[0],
            "unique_strikes": extra[1],
            "null_expiries": extra[2],
            "null_strikes": extra[3],
            "null_option_types": extra[4],
            "negative_oi": extra[5],
        })

        option_types = con.execute(f"""
            SELECT
                option_type,
                COUNT(*) AS rows
            FROM {view_name}
            GROUP BY option_type
            ORDER BY option_type
        """).fetchdf()

        option_types["dataset"] = view_name

        return profile, option_types

    return profile, None


def main():

    print("Starting DuckDB setup...")

    con = duckdb.connect(str(DB_FILE))

    try:
        con.execute(
            f"SET memory_limit = '{MEMORY_LIMIT}'"
        )

        con.execute(
            f"SET threads = {THREADS}"
        )

        con.execute(
            f"SET temp_directory = {sql_string(str(TEMP_DIR))}"
        )

        con.execute("SET preserve_insertion_order = false")

        print("\nCreating analytical views...\n")

        total_files = 0

        for view_name, (index_name, data_type) in DATASETS.items():
            total_files += create_view(
                con,
                view_name,
                index_name,
                data_type
            )

        print("\nProfiling datasets...\n")

        profiles = []
        option_type_reports = []

        for view_name, (_, data_type) in DATASETS.items():

            profile, option_types = profile_view(
                con,
                view_name,
                data_type
            )

            profiles.append(profile)

            if option_types is not None:
                option_type_reports.append(option_types)

            print(
                f"{view_name}: "
                f"{profile['rows']:,} rows"
            )

        profile_df = pd.DataFrame(profiles)

        profile_file = (
                REPORT_DIR / "duckdb_dataset_profile.csv"
        )

        profile_df.to_csv(profile_file, index=False)

        if option_type_reports:
            option_df = pd.concat(
                option_type_reports,
                ignore_index=True
            )

            option_file = (
                    REPORT_DIR / "duckdb_option_type_distribution.csv"
            )

            option_df.to_csv(option_file, index=False)

        # Save database metadata.
        metadata = {
            "database": str(DB_FILE),
            "total_parquet_files": total_files,
            "memory_limit": MEMORY_LIMIT,
            "threads": THREADS,
            "datasets": DATASETS
        }

        metadata_file = (
                REPORT_DIR / "duckdb_ingestion_metadata.json"
        )

        metadata_file.write_text(
            json.dumps(metadata, indent=2),
            encoding="utf-8"
        )

        print("\n========== DUCKDB SUMMARY ==========")

        print("Database:", DB_FILE)
        print("Parquet files:", total_files)

        for _, row in profile_df.iterrows():
            print(
                f"{row['dataset']}: "
                f"{int(row['rows']):,} rows"
            )

        print("\nProfile report:", profile_file)
        print("Metadata:", metadata_file)

        print("\nDuckDB setup completed successfully.")

    finally:
        con.close()


if __name__ == "__main__":
    main()
