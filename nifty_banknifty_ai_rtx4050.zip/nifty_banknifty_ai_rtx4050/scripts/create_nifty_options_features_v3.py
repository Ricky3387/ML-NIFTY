
from __future__ import annotations

import json
import sys
import traceback
from datetime import datetime
from pathlib import Path

import duckdb


ROOT = Path(__file__).resolve().parents[1]

INPUT_FILE = (
        ROOT / "data/processed/nifty_options_features_v2/"
               "nifty_options_features_v2.parquet"
)

OUTPUT_DIR = ROOT / "data/processed/nifty_options_features_v3"
OUTPUT_FILE = OUTPUT_DIR / "nifty_options_features_v3.parquet"

REPORT_DIR = ROOT / "reports/nifty_options_features_v3"

TEMP_COLUMNS = [
    "prior_timestamp_5m",
    "prior_timestamp_15m",
    "prior_timestamp_30m",
    "ce_count_5m",
    "ce_count_15m",
    "ce_count_30m",
    "pe_count_5m",
    "pe_count_15m",
    "pe_count_30m",
    "ce_sum_candidate_5m",
    "ce_sum_candidate_15m",
    "ce_sum_candidate_30m",
    "pe_sum_candidate_5m",
    "pe_sum_candidate_15m",
    "pe_sum_candidate_30m",
]


def sql_string(value: str) -> str:
    """Safely quote a SQL string literal."""
    return "'" + value.replace("'", "''") + "'"


def main():
    if not INPUT_FILE.exists():
        raise FileNotFoundError(INPUT_FILE)

    if OUTPUT_FILE.exists():
        raise FileExistsError(
            f"Refusing to overwrite existing file: {OUTPUT_FILE}"
        )

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    REPORT_DIR.mkdir(parents=True, exist_ok=True)

    con = duckdb.connect(":memory:")
    con.execute("SET threads TO 4")

    try:
        input_path = INPUT_FILE.resolve().as_posix()
        output_path = OUTPUT_FILE.resolve().as_posix()

        input_sql = sql_string(input_path)
        output_sql = sql_string(output_path)

        print("Inspecting v2 schema...")

        schema = con.execute(
            f"DESCRIBE SELECT * FROM read_parquet({input_sql})"
        ).fetchall()

        input_columns = [row[0] for row in schema]

        missing_temp = [
            col for col in TEMP_COLUMNS
            if col not in input_columns
        ]

        if missing_temp:
            raise ValueError(
                "Expected intermediate columns are missing from v2: "
                f"{missing_temp}. Inspect the schema before proceeding."
            )

        original_rows = con.execute(
            f"SELECT COUNT(*) FROM read_parquet({input_sql})"
        ).fetchone()[0]

        print(f"Input rows: {original_rows:,}")
        print(f"Removing {len(TEMP_COLUMNS)} intermediate columns...")

        excluded = ", ".join(f'"{col}"' for col in TEMP_COLUMNS)

        con.execute(f"""
            COPY (
                SELECT * EXCLUDE ({excluded})
                FROM read_parquet({input_sql})
            )
            TO {output_sql}
            (FORMAT PARQUET, COMPRESSION ZSTD)
        """)

        output_rows = con.execute(
            f"SELECT COUNT(*) FROM read_parquet({output_sql})"
        ).fetchone()[0]

        output_schema = con.execute(
            f"DESCRIBE SELECT * FROM read_parquet({output_sql})"
        ).fetchall()

        output_columns = [row[0] for row in output_schema]

        remaining_temp = [
            col for col in TEMP_COLUMNS
            if col in output_columns
        ]

        checks = {
            "row_count_preserved": original_rows == output_rows,
            "all_intermediate_columns_removed": len(remaining_temp) == 0,
            "column_count_reduced_by_15": (
                    len(input_columns) - len(output_columns)
                    == len(TEMP_COLUMNS)
            ),
        }

        summary = {
            "generated_at": datetime.now().isoformat(),
            "input_file": str(INPUT_FILE),
            "output_file": str(OUTPUT_FILE),
            "input_rows": original_rows,
            "output_rows": output_rows,
            "input_column_count": len(input_columns),
            "output_column_count": len(output_columns),
            "removed_intermediate_columns": TEMP_COLUMNS,
            "remaining_intermediate_columns": remaining_temp,
            "checks": checks,
            "overall_status": (
                "PASS" if all(checks.values()) else "REVIEW_REQUIRED"
            ),
            "input_modified": False,
        }

        summary_path = REPORT_DIR / "options_feature_v3_summary.json"

        with open(summary_path, "w", encoding="utf-8") as f:
            json.dump(summary, f, indent=2, default=str)

        print("\n" + "=" * 72)
        print("NIFTY OPTIONS FEATURE V3")
        print("=" * 72)
        print(f"Input rows : {original_rows:,}")
        print(f"Output rows: {output_rows:,}")
        print(f"Input columns : {len(input_columns)}")
        print(f"Output columns: {len(output_columns)}")

        for name, passed in checks.items():
            print(f"{'PASS' if passed else 'FAIL'} : {name}")

        print(f"\nOverall status: {summary['overall_status']}")
        print(f"Output: {OUTPUT_FILE}")
        print(f"Summary: {summary_path}")
        print("=" * 72)

    finally:
        con.close()


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print("\nV3 CREATION FAILED")
        print(str(exc))
        traceback.print_exc()
        sys.exit(1)
