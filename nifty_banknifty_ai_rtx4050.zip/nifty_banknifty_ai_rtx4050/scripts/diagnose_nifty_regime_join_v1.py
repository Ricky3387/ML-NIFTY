
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
RUN_ID = "20261111_200710"

validation_file = (
        ROOT / "data" / "processed" / "nifty_walkforward_v1"
        / "validation_5m.parquet"
)

probability_file = (
        ROOT / "reports" / "nifty_calibrated_threshold_transfer_v2"
        / RUN_ID / "2024_raw_and_calibrated_probabilities.parquet"
)

v = pd.read_parquet(validation_file)
p = pd.read_parquet(probability_file)

print("\nVALIDATION SCHEMA")
print(v.dtypes.to_string())

print("\nPROBABILITY SCHEMA")
print(p.dtypes.to_string())

for name, df in [("VALIDATION", v), ("PROBABILITY", p)]:
    print(f"\n{name} SAMPLE")
    print(df[["timestamp_ist", "trading_day"]].head(5).to_string(index=False))

    print(f"\n{name} TIMESTAMP DETAILS")
    ts = pd.to_datetime(df["timestamp_ist"], errors="coerce")
    print("dtype:", ts.dtype)
    print("min:", ts.min())
    print("max:", ts.max())
    print("null timestamps:", ts.isna().sum())

    print(f"\n{name} TRADING DAY DETAILS")
    print("dtype:", df["trading_day"].dtype)
    print("sample:", df["trading_day"].head(5).tolist())

# Compare timestamp matches independently of trading_day.
v_ts = pd.to_datetime(v["timestamp_ist"], utc=True, errors="coerce")
p_ts = pd.to_datetime(p["timestamp_ist"], utc=True, errors="coerce")

v_set = set(v_ts.dropna())
p_set = set(p_ts.dropna())

print("\n" + "=" * 65)
print("JOIN DIAGNOSTICS")
print("=" * 65)

print("Validation rows:", len(v))
print("Probability rows:", len(p))
print("Timestamp matches:", len(v_set.intersection(p_set)))
print("Probability timestamps missing in validation:", len(p_set - v_set))
print("Validation timestamps missing in probability:", len(v_set - p_set))

# Check whether trading_day is the only mismatch.
v2 = pd.DataFrame({
    "timestamp_utc": v_ts,
    "validation_day": v["trading_day"].astype(str).str.strip().values,
})

p2 = pd.DataFrame({
    "timestamp_utc": p_ts,
    "probability_day": p["trading_day"].astype(str).str.strip().values,
})

comparison = p2.merge(
    v2,
    on="timestamp_utc",
    how="left",
    indicator=True,
)

print("\nTimestamp-only matches:", (comparison["_merge"] == "both").sum())

matched = comparison[comparison["_merge"] == "both"].copy()

if len(matched):
    matched["day_matches"] = (
            matched["probability_day"] == matched["validation_day"]
    )

    print("Trading-day matches:", matched["day_matches"].sum())
    print("Trading-day mismatches:", (~matched["day_matches"]).sum())

    print("\nMISMATCH EXAMPLES")
    print(
        matched.loc[
            ~matched["day_matches"],
            ["timestamp_utc", "probability_day", "validation_day"]
        ].head(10).to_string(index=False)
    )

print("\nDIAGNOSTIC COMPLETED")
