"""
Targeted NIFTY price verification audit.

Run from project root:
    python audit_nifty_targeted_price_verification.py

Reads DuckDB view `nifty_index` in read-only mode.
Assumes database timestamps are naive UTC and converts to Asia/Kolkata,
consistent with the previous project audit. Verify this against source docs.

No source data is changed. No bars are deleted, filled, or repaired.
"""

from pathlib import Path
import sys
import json

import duckdb
import numpy as np
import pandas as pd


DB_PATH = Path("data/database/nifty_options.duckdb")
VIEW_NAME = "nifty_index"
OUTPUT_DIR = Path("data/reports/nifty_targeted_price_verification")
TIMEZONE = "Asia/Kolkata"

# Previously identified observations, expressed in IST.
TARGET_TIMESTAMPS_IST = [
    "2022-03-07 10:07:00",
    "2022-03-07 10:25:00",
    "2024-05-18 11:15:00",
]

# Full date to inspect, plus repeated-value run on 2021-06-28.
VOLATILITY_DATE = "2024-06-04"
REPEATED_RUN_DATE = "2021-06-28"
REPEATED_RUN_START = "2021-06-28 15:40:00"
REPEATED_RUN_END = "2021-06-28 16:00:00"

# Boundary review window around May 18 split session.
MAY18_START = "2024-05-18 11:00:00"
MAY18_END = "2024-05-18 12:40:00"

# Context bars on either side of targeted observations.
CONTEXT_MINUTES_BEFORE = 5
CONTEXT_MINUTES_AFTER = 5

FIXED_RETURN_THRESHOLD_PCT = 0.50
FIXED_RANGE_THRESHOLD_PCT = 0.75


def to_ist(series: pd.Series) -> pd.Series:
    parsed = pd.to_datetime(series, errors="coerce")
    if parsed.dt.tz is None:
        parsed = parsed.dt.tz_localize("UTC")
    else:
        parsed = parsed.dt.tz_convert("UTC")
    return parsed.dt.tz_convert(TIMEZONE).dt.tz_localize(None)


def main() -> int:
    if not DB_PATH.exists():
        print(f"ERROR: Database not found: {DB_PATH.resolve()}")
        print("Run from project root or update DB_PATH.")
        return 1

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    print("Reading NIFTY index data (read-only)...")
    con = duckdb.connect(str(DB_PATH), read_only=True)
    try:
        # Pull the full requested period because previous-close and adjacent
        # observed-bar context must be calculated from actual source rows.
        df = con.execute(
            f"""
            SELECT *
            FROM {VIEW_NAME}
            WHERE CAST(timestamp AS DATE)
                  BETWEEN DATE '2021-05-24' AND DATE '2024-12-31'
            ORDER BY timestamp
            """
        ).df()
    except Exception as exc:
        print(f"ERROR reading {VIEW_NAME}: {exc}")
        return 1
    finally:
        con.close()

    required = {"timestamp", "open", "high", "low", "close"}
    missing = required - set(df.columns)
    if missing:
        print("ERROR: Missing required columns:", sorted(missing))
        print("Available columns:", list(df.columns))
        return 1

    df["timestamp_ist"] = to_ist(df["timestamp"])
    df = df.dropna(subset=["timestamp_ist"]).copy()
    df = df.sort_values("timestamp_ist").reset_index(drop=True)

    for col in ["open", "high", "low", "close"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    if "volume" in df.columns:
        df["volume"] = pd.to_numeric(df["volume"], errors="coerce")

    df["trading_date_ist"] = df["timestamp_ist"].dt.strftime("%Y-%m-%d")
    df["prev_timestamp_ist"] = df["timestamp_ist"].shift(1)
    df["prev_close"] = df["close"].shift(1)
    df["next_timestamp_ist"] = df["timestamp_ist"].shift(-1)
    df["next_open"] = df["open"].shift(-1)
    df["next_close"] = df["close"].shift(-1)

    same_day_prev = df["trading_date_ist"].eq(
        df["trading_date_ist"].shift(1)
    )
    same_day_next = df["trading_date_ist"].eq(
        df["trading_date_ist"].shift(-1)
    )
    prev_gap = (
        df["timestamp_ist"] - df["prev_timestamp_ist"]
    ).dt.total_seconds() / 60.0
    next_gap = (
        df["next_timestamp_ist"] - df["timestamp_ist"]
    ).dt.total_seconds() / 60.0

    df["prev_observed_gap_minutes"] = prev_gap
    df["next_observed_gap_minutes"] = next_gap

    # Only label a close-to-close return as a one-minute return when the
    # previous observed bar is exactly one minute earlier on the same day.
    valid_adjacent_prev = same_day_prev & prev_gap.eq(1.0) & df["prev_close"].ne(0)
    df["close_return_from_prev_observed_pct"] = np.where(
        valid_adjacent_prev,
        (df["close"] / df["prev_close"] - 1.0) * 100.0,
        np.nan,
    )

    df["bar_range_pct_prev_close"] = np.where(
        df["prev_close"].notna() & df["prev_close"].ne(0),
        ((df["high"] - df["low"]) / df["prev_close"].abs()) * 100.0,
        np.nan,
    )

    df["open_gap_from_prev_close_pct"] = np.where(
        df["prev_close"].notna() & df["prev_close"].ne(0),
        ((df["open"] / df["prev_close"]) - 1.0) * 100.0,
        np.nan,
    )

    df["fixed_return_flag"] = (
        df["close_return_from_prev_observed_pct"].abs()
        >= FIXED_RETURN_THRESHOLD_PCT
    )
    df["fixed_range_flag"] = (
        df["bar_range_pct_prev_close"].abs()
        >= FIXED_RANGE_THRESHOLD_PCT
    )
    df["fixed_any_flag"] = df["fixed_return_flag"] | df["fixed_range_flag"]

    # Every row that crossed either fixed threshold in the entire period.
    fixed_flags = df[df["fixed_any_flag"]].copy()
    fixed_flags["flag_reason"] = fixed_flags.apply(
        lambda r: ";".join(
            reason for reason, condition in [
                ("ABS_1M_CLOSE_RETURN_GE_0_50_PCT", r["fixed_return_flag"]),
                ("INTRABAR_RANGE_GE_0_75_PCT", r["fixed_range_flag"]),
            ] if condition
        ),
        axis=1,
    )

    # Context around specifically named timestamp targets. The nearest
    # available bars are included, even when there are gaps.
    target_context_parts = []
    target_records = []

    for target_text in TARGET_TIMESTAMPS_IST:
        target = pd.Timestamp(target_text)
        same_day = df[df["trading_date_ist"] == target.strftime("%Y-%m-%d")].copy()
        same_day["distance_minutes"] = (
            (same_day["timestamp_ist"] - target).abs().dt.total_seconds() / 60.0
        )
        nearest = same_day.nsmallest(
            CONTEXT_MINUTES_BEFORE + CONTEXT_MINUTES_AFTER + 1,
            "distance_minutes",
        ).sort_values("timestamp_ist")

        if nearest.empty:
            target_records.append({
                "target_timestamp_ist": target,
                "target_found_exactly": False,
                "nearest_observed_timestamp_ist": pd.NaT,
                "nearest_distance_minutes": np.nan,
            })
            continue

        exact = same_day[same_day["timestamp_ist"] == target]
        target_records.append({
            "target_timestamp_ist": target,
            "target_found_exactly": not exact.empty,
            "nearest_observed_timestamp_ist": nearest.iloc[
                (nearest["distance_minutes"]).argmin()
            ]["timestamp_ist"],
            "nearest_distance_minutes": float(nearest["distance_minutes"].min()),
        })

        nearest = nearest.copy()
        nearest["context_target_timestamp_ist"] = target
        nearest["context_reason"] = "TARGETED_PRICE_OBSERVATION"
        target_context_parts.append(nearest)

    target_context = (
        pd.concat(target_context_parts, ignore_index=True)
        if target_context_parts else pd.DataFrame()
    )

    # June 4, 2024: complete session day's bars, plus derived returns/ranges.
    volatility_day = df[
        df["trading_date_ist"] == VOLATILITY_DATE
    ].copy()

    # June 28 repeated identical OHLC window.
    repeated_window = df[
        (df["timestamp_ist"] >= pd.Timestamp(REPEATED_RUN_START)) &
        (df["timestamp_ist"] <= pd.Timestamp(REPEATED_RUN_END))
    ].copy()
    if not repeated_window.empty:
        repeated_window["same_ohlc_as_previous"] = (
            repeated_window[["open", "high", "low", "close"]]
            .eq(repeated_window[["open", "high", "low", "close"]].shift())
            .all(axis=1)
        )
        repeated_window["one_minute_after_previous"] = (
            repeated_window["timestamp_ist"].diff()
            .eq(pd.Timedelta(minutes=1))
        )

    # May 18 session transition: include full requested boundary interval.
    may18_boundary = df[
        (df["timestamp_ist"] >= pd.Timestamp(MAY18_START)) &
        (df["timestamp_ist"] <= pd.Timestamp(MAY18_END))
    ].copy()

    # Daily summary of June 4, including fixed-threshold counts by time band.
    june4_summary = {}
    if not volatility_day.empty:
        june4_summary = {
            "date": VOLATILITY_DATE,
            "observed_rows": int(len(volatility_day)),
            "first_timestamp_ist": str(volatility_day["timestamp_ist"].min()),
            "last_timestamp_ist": str(volatility_day["timestamp_ist"].max()),
            "fixed_return_flag_rows": int(volatility_day["fixed_return_flag"].sum()),
            "fixed_range_flag_rows": int(volatility_day["fixed_range_flag"].sum()),
            "fixed_any_flag_rows": int(volatility_day["fixed_any_flag"].sum()),
            "max_abs_adjacent_1m_return_pct": (
                float(volatility_day["close_return_from_prev_observed_pct"].abs().max())
                if volatility_day["close_return_from_prev_observed_pct"].notna().any()
                else None
            ),
            "max_intrabar_range_pct_prev_close": (
                float(volatility_day["bar_range_pct_prev_close"].max())
                if volatility_day["bar_range_pct_prev_close"].notna().any()
                else None
            ),
        }

    target_summary = pd.DataFrame(target_records)

    # Include every fixed-threshold row with nearby observed bars on same date.
    # This helps identify whether a flagged bar is isolated or part of a move.
    all_fixed_context_parts = []
    for _, flagged_row in fixed_flags.iterrows():
        date = flagged_row["trading_date_ist"]
        ts = flagged_row["timestamp_ist"]
        day = df[df["trading_date_ist"] == date].copy()
        day["distance_minutes"] = (
            (day["timestamp_ist"] - ts).abs().dt.total_seconds() / 60.0
        )
        context = day.nsmallest(5, "distance_minutes").sort_values("timestamp_ist")
        context["flagged_timestamp_ist"] = ts
        all_fixed_context_parts.append(context)

    fixed_context = (
        pd.concat(all_fixed_context_parts, ignore_index=True)
        if all_fixed_context_parts else pd.DataFrame()
    )

    # Export CSVs.
    outputs = {
        "nifty_all_fixed_threshold_anomalies.csv": fixed_flags,
        "nifty_targeted_observation_context.csv": target_context,
        "nifty_targeted_observation_lookup.csv": target_summary,
        "nifty_2024_06_04_full_day.csv": volatility_day,
        "nifty_2021_06_28_repeated_value_window.csv": repeated_window,
        "nifty_2024_05_18_session_boundary.csv": may18_boundary,
        "nifty_fixed_anomaly_neighbour_context.csv": fixed_context,
    }

    for filename, frame in outputs.items():
        frame.to_csv(OUTPUT_DIR / filename, index=False)

    summary = {
        "dataset": "NIFTY index",
        "timezone_assumption": (
            "Naive database timestamps interpreted as UTC and converted to Asia/Kolkata."
        ),
        "fixed_thresholds": {
            "absolute_adjacent_one_minute_close_return_pct": FIXED_RETURN_THRESHOLD_PCT,
            "intrabar_high_low_range_pct_of_previous_close": FIXED_RANGE_THRESHOLD_PCT,
        },
        "fixed_threshold_anomaly_rows": int(len(fixed_flags)),
        "fixed_return_flag_rows": int(df["fixed_return_flag"].sum()),
        "fixed_range_flag_rows": int(df["fixed_range_flag"].sum()),
        "targeted_timestamp_lookup": target_records,
        "june_4_2024_summary": june4_summary,
        "june_28_2021_repeated_window_rows": int(len(repeated_window)),
        "june_28_2021_unique_ohlc_combinations": (
            int(repeated_window[["open", "high", "low", "close"]].drop_duplicates().shape[0])
            if not repeated_window.empty else 0
        ),
        "may_18_2024_boundary_rows": int(len(may18_boundary)),
        "caveat": (
            "Flags are diagnostic candidates, not proof of corrupt prices. "
            "This script does not verify against an independent exchange/provider source "
            "and does not prove minute-start versus minute-end semantics."
        ),
    }

    with open(OUTPUT_DIR / "nifty_targeted_price_verification_summary.json",
              "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, default=str)

    print("\nTARGETED AUDIT COMPLETE — no source data modified.")
    print("Fixed-threshold anomaly rows:", len(fixed_flags))
    print("2024-06-04 rows:", len(volatility_day))
    print("2021-06-28 repeated-window rows:", len(repeated_window))
    print("2024-05-18 boundary rows:", len(may18_boundary))
    print("\nOutput folder:", OUTPUT_DIR.resolve())
    for filename in list(outputs) + ["nifty_targeted_price_verification_summary.json"]:
        print(" -", filename)
    print("\nUpload all generated files for review.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
