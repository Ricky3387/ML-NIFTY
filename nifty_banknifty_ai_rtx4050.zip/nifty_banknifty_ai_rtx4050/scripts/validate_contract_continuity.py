
from pathlib import Path
import duckdb
import time

# ------------------------------------------------------------
# Configuration
# ------------------------------------------------------------

ROOT = Path(__file__).resolve().parents[1]
DB_PATH = ROOT / "data" / "database" / "nifty_options.duckdb"
REPORT_DIR = ROOT / "data" / "reports"
TEMP_DIR = ROOT / "data" / "duckdb_temp"

REPORT_DIR.mkdir(parents=True, exist_ok=True)
TEMP_DIR.mkdir(parents=True, exist_ok=True)

INDICES = {
    "NIFTY": "nifty_options",
    "BANKNIFTY": "banknifty_options",
}

# ------------------------------------------------------------
# DuckDB connection
# ------------------------------------------------------------

if not DB_PATH.exists():
    raise FileNotFoundError(f"DuckDB database not found: {DB_PATH}")

con = duckdb.connect(str(DB_PATH))

con.execute("SET memory_limit = '6GB'")
con.execute("SET threads = 4")
con.execute(f"SET temp_directory = '{TEMP_DIR.as_posix()}'")
con.execute("SET preserve_insertion_order = false")
con.execute("SET TimeZone = 'Asia/Calcutta'")

print("=" * 90)
print("CONTRACT CONTINUITY VALIDATION")
print("=" * 90)
print("Database:", DB_PATH)
print("DuckDB:", con.execute("SELECT version()").fetchone()[0])
print("Timezone:", con.execute(
    "SELECT current_setting('TimeZone')"
).fetchone()[0])


def export_query(query, output_path):
    """Export a DuckDB query directly to CSV."""
    path = output_path.as_posix().replace("'", "''")

    con.execute(
        f"""
        COPY ({query})
        TO '{path}'
        (HEADER, DELIMITER ',')
        """
    )

    print("Generated:", output_path.name)


def validate_index(index_name, view_name):
    start = time.time()

    print("\n" + "=" * 90)
    print(f"{index_name} CONTRACT CONTINUITY")
    print("=" * 90)

    # Verify required columns.
    columns = {
        row[0].lower()
        for row in con.execute(
            f"DESCRIBE SELECT * FROM {view_name}"
        ).fetchall()
    }

    required = {
        "timestamp",
        "trading_day",
        "expiry",
        "strike",
        "option_type",
    }

    missing = required - columns

    if missing:
        raise RuntimeError(
            f"{view_name} is missing required columns: {sorted(missing)}"
        )

    # --------------------------------------------------------
    # 1. Individual contract continuity
    #
    # A contract is identified by:
    # trading_day + expiry + strike + option_type
    #
    # Gap minutes are measured only within the same trading
    # day, so overnight/weekend gaps are not counted.
    # --------------------------------------------------------

    print("Calculating individual contract intervals...")

    con.execute(f"""
        CREATE OR REPLACE TEMP TABLE {index_name.lower()}_contract_daily AS

        WITH ordered AS (
            SELECT
                CAST(trading_day AS DATE) AS trading_day,
                CAST(expiry AS DATE) AS expiry,
                strike,
                UPPER(option_type) AS option_type,
                timestamp AS ts,

                LAG(timestamp) OVER (
                    PARTITION BY
                        CAST(trading_day AS DATE),
                        CAST(expiry AS DATE),
                        strike,
                        UPPER(option_type)
                    ORDER BY timestamp
                ) AS previous_ts

            FROM {view_name}

            WHERE expiry IS NOT NULL
              AND strike IS NOT NULL
              AND UPPER(option_type) IN ('CE', 'PE')
        ),

        intervals AS (
            SELECT
                trading_day,
                expiry,
                strike,
                option_type,
                ts,
                previous_ts,

                CASE
                    WHEN previous_ts IS NULL THEN NULL
                    ELSE DATE_DIFF(
                        'minute',
                        STRPTIME(
                            STRFTIME(previous_ts, '%Y-%m-%d %H:%M:%S'),
                            '%Y-%m-%d %H:%M:%S'
                        ),
                        STRPTIME(
                            STRFTIME(ts, '%Y-%m-%d %H:%M:%S'),
                            '%Y-%m-%d %H:%M:%S'
                        )
                    )
                END AS elapsed_minutes

            FROM ordered
        )

        SELECT
            trading_day,
            expiry,
            strike,
            option_type,

            COUNT(*) AS observed_rows,
            COUNT(DISTINCT ts) AS observed_minutes,

            MIN(STRFTIME(ts, '%H:%M:%S')) AS first_observation,
            MAX(STRFTIME(ts, '%H:%M:%S')) AS last_observation,

            COUNT(elapsed_minutes) AS observed_intervals,

            SUM(
                CASE WHEN elapsed_minutes = 1
                     THEN 1 ELSE 0 END
            ) AS consecutive_1m_intervals,

            SUM(
                CASE WHEN elapsed_minutes BETWEEN 2 AND 5
                     THEN 1 ELSE 0 END
            ) AS intervals_2_to_5m,

            SUM(
                CASE WHEN elapsed_minutes BETWEEN 6 AND 15
                     THEN 1 ELSE 0 END
            ) AS intervals_6_to_15m,

            SUM(
                CASE WHEN elapsed_minutes > 15
                     THEN 1 ELSE 0 END
            ) AS intervals_over_15m,

            MAX(elapsed_minutes) AS maximum_elapsed_minutes

        FROM intervals

        GROUP BY
            trading_day,
            expiry,
            strike,
            option_type
    """)

    contract_table = f"{index_name.lower()}_contract_daily"

    # Export detailed contract-day report.
    export_query(
        f"SELECT * FROM {contract_table}",
        REPORT_DIR / f"{index_name.lower()}_contract_daily_continuity.csv"
    )

    # --------------------------------------------------------
    # 2. Contract continuity summary
    # --------------------------------------------------------

    summary_query = f"""
        SELECT
            '{index_name}' AS index_name,

            COUNT(*) AS contract_days,
            COUNT(DISTINCT trading_day) AS trading_days,

            COUNT(DISTINCT expiry) AS unique_expiries,
            COUNT(DISTINCT strike) AS unique_strikes,

            ROUND(AVG(observed_minutes), 2)
                AS avg_observed_minutes,

            ROUND(MEDIAN(observed_minutes), 2)
                AS median_observed_minutes,

            ROUND(AVG(observed_rows), 2)
                AS avg_observed_rows,

            ROUND(AVG(maximum_elapsed_minutes), 2)
                AS avg_maximum_elapsed_minutes,

            MAX(maximum_elapsed_minutes)
                AS overall_maximum_elapsed_minutes,

            SUM(consecutive_1m_intervals)
                AS consecutive_1m_intervals,

            SUM(intervals_2_to_5m)
                AS intervals_2_to_5m,

            SUM(intervals_6_to_15m)
                AS intervals_6_to_15m,

            SUM(intervals_over_15m)
                AS intervals_over_15m,

            SUM(
                CASE WHEN observed_minutes >= 300
                     THEN 1 ELSE 0 END
            ) AS contract_days_300plus_minutes,

            SUM(
                CASE WHEN observed_minutes >= 350
                     THEN 1 ELSE 0 END
            ) AS contract_days_350plus_minutes,

            SUM(
                CASE WHEN maximum_elapsed_minutes > 5
                     THEN 1 ELSE 0 END
            ) AS contract_days_with_gap_over_5m,

            SUM(
                CASE WHEN maximum_elapsed_minutes > 15
                     THEN 1 ELSE 0 END
            ) AS contract_days_with_gap_over_15m

        FROM {contract_table}
    """

    export_query(
        summary_query,
        REPORT_DIR / f"{index_name.lower()}_contract_continuity_summary.csv"
    )

    # --------------------------------------------------------
    # 3. Same-strike CE/PE timestamp pairing
    #
    # We compare exact timestamp observations for the same
    # expiry, strike and trading day.
    # --------------------------------------------------------

    print("Calculating same-strike CE/PE continuity...")

    con.execute(f"""
        CREATE OR REPLACE TEMP TABLE {index_name.lower()}_paired_daily AS

        WITH per_timestamp AS (
            SELECT
                CAST(trading_day AS DATE) AS trading_day,
                CAST(expiry AS DATE) AS expiry,
                strike,
                timestamp AS ts,

                MAX(
                    CASE WHEN UPPER(option_type) = 'CE'
                         THEN 1 ELSE 0 END
                ) AS has_ce,

                MAX(
                    CASE WHEN UPPER(option_type) = 'PE'
                         THEN 1 ELSE 0 END
                ) AS has_pe

            FROM {view_name}

            WHERE expiry IS NOT NULL
              AND strike IS NOT NULL
              AND UPPER(option_type) IN ('CE', 'PE')

            GROUP BY
                CAST(trading_day AS DATE),
                CAST(expiry AS DATE),
                strike,
                timestamp
        )

        SELECT
            trading_day,
            expiry,
            strike,

            COUNT(*) AS timestamps_with_either_side,

            SUM(has_ce) AS ce_minutes,
            SUM(has_pe) AS pe_minutes,

            SUM(
                CASE WHEN has_ce = 1 AND has_pe = 1
                     THEN 1 ELSE 0 END
            ) AS paired_minutes,

            ROUND(
                100.0 * SUM(
                    CASE WHEN has_ce = 1 AND has_pe = 1
                         THEN 1 ELSE 0 END
                ) / NULLIF(COUNT(*), 0),
                2
            ) AS paired_percentage_of_union,

            ROUND(
                100.0 * SUM(
                    CASE WHEN has_ce = 1 AND has_pe = 1
                         THEN 1 ELSE 0 END
                ) / NULLIF(LEAST(SUM(has_ce), SUM(has_pe)), 0),
                2
            ) AS paired_percentage_of_smaller_side

        FROM per_timestamp

        GROUP BY
            trading_day,
            expiry,
            strike
    """)

    paired_table = f"{index_name.lower()}_paired_daily"

    export_query(
        f"SELECT * FROM {paired_table}",
        REPORT_DIR / f"{index_name.lower()}_paired_contract_daily.csv"
    )

    # --------------------------------------------------------
    # 4. Daily pairing summary
    # --------------------------------------------------------

    daily_pair_summary = f"""
        SELECT
            '{index_name}' AS index_name,
            trading_day,

            COUNT(*) AS expiry_strike_pairs,

            SUM(ce_minutes) AS total_ce_minutes,
            SUM(pe_minutes) AS total_pe_minutes,
            SUM(paired_minutes) AS total_paired_minutes,

            ROUND(AVG(paired_percentage_of_union), 2)
                AS avg_pairing_percentage,

            ROUND(MEDIAN(paired_percentage_of_union), 2)
                AS median_pairing_percentage,

            SUM(
                CASE WHEN paired_minutes >= 300
                     THEN 1 ELSE 0 END
            ) AS pairs_with_300plus_paired_minutes,

            SUM(
                CASE WHEN paired_minutes >= 350
                     THEN 1 ELSE 0 END
            ) AS pairs_with_350plus_paired_minutes

        FROM {paired_table}

        GROUP BY trading_day
        ORDER BY trading_day
    """

    export_query(
        daily_pair_summary,
        REPORT_DIR / f"{index_name.lower()}_paired_daily_summary.csv"
    )

    # --------------------------------------------------------
    # 5. Poor-continuity contract days
    # --------------------------------------------------------

    poor_contracts_query = f"""
        SELECT *
        FROM {contract_table}

        WHERE observed_minutes < 300
           OR maximum_elapsed_minutes > 15

        ORDER BY
            observed_minutes ASC,
            maximum_elapsed_minutes DESC

        LIMIT 10000
    """

    export_query(
        poor_contracts_query,
        REPORT_DIR / f"{index_name.lower()}_poor_continuity_contracts.csv"
    )

    # --------------------------------------------------------
    # 6. Console summary
    # --------------------------------------------------------

    result = con.execute(summary_query).fetchdf()

    print("\nSUMMARY")
    print(result.to_string(index=False))

    pair_result = con.execute(f"""
        SELECT
            COUNT(*) AS expiry_strike_days,
            ROUND(AVG(paired_percentage_of_union), 2)
                AS avg_pairing_percentage,
            ROUND(MEDIAN(paired_percentage_of_union), 2)
                AS median_pairing_percentage,
            SUM(
                CASE WHEN paired_minutes >= 350
                     THEN 1 ELSE 0 END
            ) AS pairs_with_350plus_minutes
        FROM {paired_table}
    """).fetchdf()

    print("\nSAME-STRIKE CE/PE PAIRING")
    print(pair_result.to_string(index=False))

    print(
        f"\n{index_name} completed in "
        f"{(time.time() - start) / 60:.2f} minutes"
    )


# ------------------------------------------------------------
# Run both indices
# ------------------------------------------------------------

try:
    for index_name, view_name in INDICES.items():
        validate_index(index_name, view_name)

    print("\n" + "=" * 90)
    print("CONTRACT CONTINUITY VALIDATION FINISHED")
    print("=" * 90)
    print("Reports folder:", REPORT_DIR)

finally:
    con.close()
