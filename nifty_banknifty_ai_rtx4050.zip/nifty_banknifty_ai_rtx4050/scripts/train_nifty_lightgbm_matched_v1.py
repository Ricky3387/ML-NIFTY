
from pathlib import Path
import json
import sys
import traceback
import gc
from datetime import datetime, timezone

import numpy as np
import pandas as pd
import duckdb
import lightgbm as lgb

from sklearn.utils.class_weight import compute_sample_weight
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    f1_score,
    precision_score,
    recall_score,
    log_loss,
    confusion_matrix,
    classification_report,
    roc_auc_score,
)


# ============================================================
# CONFIGURATION
# ============================================================

ROOT = Path(__file__).resolve().parents[1]

DATA_DIR = (
        ROOT / "data" / "processed"
        / "nifty_matched_datasets_v1"
)

MODEL_DIR = (
        ROOT / "models"
        / "nifty_lightgbm_matched_v1"
)

REPORT_DIR = (
        ROOT / "reports"
        / "nifty_lightgbm_matched_v1"
)

HORIZONS = [5, 15, 30]

DATASETS = [
    "index_only",
    "index_plus_options",
]

# Chronological internal split within 2021-2023.
INTERNAL_TRAIN_END = "2022-12-31"
EARLY_STOP_START = "2023-01-01"
EARLY_STOP_END = "2023-12-31"

# Existing diagnostic validation.
FINAL_VALIDATION_START = "2024-01-01"
FINAL_VALIDATION_END = "2024-12-31"

# Label encoding is fixed and consistent across all models.
CLASS_TO_ID = {
    "DOWN": 0,
    "SIDEWAYS": 1,
    "UP": 2,
}

ID_TO_CLASS = {
    0: "DOWN",
    1: "SIDEWAYS",
    2: "UP",
}

NUM_CLASSES = 3

# LightGBM CPU settings.
N_ESTIMATORS = 3000
LEARNING_RATE = 0.03
EARLY_STOPPING_ROUNDS = 100

RANDOM_STATE = 42
N_JOBS = 4

# Save CSV predictions and reports.
SAVE_PREDICTIONS = True

# Convert infinities to NaN; do not clip finite values.
REPLACE_INFINITY_WITH_NAN = True


# ============================================================
# FEATURES
# ============================================================

INDEX_FEATURES = [
    "body_pct",
    "close",
    "close_vs_ema21_pct",
    "close_vs_ema50_pct",
    "close_vs_ema9_pct",
    "high",
    "high_low_range_15m",
    "high_low_range_30m",
    "high_low_range_5m",
    "high_low_range_60m",
    "logret_1m",
    "low",
    "lower_wick_pct",
    "negative_return_count_5m",
    "open",
    "positive_return_count_5m",
    "range_pct",
    "realized_vol_15m",
    "realized_vol_30m",
    "realized_vol_5m",
    "realized_vol_60m",
    "ret_1m",
    "return_15m",
    "return_30m",
    "return_5m",
    "return_60m",
    "rsi_14",
    "upper_wick_pct",
]

OPTIONS_FEATURES = [
    "selected_dte",
    "atm_distance_pct",
    "atm_straddle_premium",
    "atm_ce_log_return_1m",
    "atm_pe_log_return_1m",
    "atm_ce_pe_return_spread_1m",
    "atm_straddle_weighted_log_return_1m",
    "atm_ce_oi_change_1m",
    "atm_pe_oi_change_1m",
    "near_atm_pcr_oi",
    "near_atm_pcr_volume",
    "near_atm_oi_imbalance",
    "near_atm_volume_imbalance",
    "paired_strike_count",
]

FEATURES_BY_DATASET = {
    "index_only": INDEX_FEATURES,
    "index_plus_options": INDEX_FEATURES + OPTIONS_FEATURES,
}

METADATA_COLUMNS = [
    "timestamp_ist",
    "trading_day",
    "horizon_minutes",
    "label",
    "forward_return",
    "target_z",
]


# ============================================================
# GENERAL HELPERS
# ============================================================

def log(message):
    print(message, flush=True)


def ensure_input_files():
    missing = []

    for dataset in DATASETS:
        for split in ("train", "validation"):
            for horizon in HORIZONS:
                path = (
                        DATA_DIR
                        / dataset
                        / f"{split}_{horizon}m.parquet"
                )

                if not path.exists():
                    missing.append(str(path))

    if missing:
        raise FileNotFoundError(
            "Required matched dataset files are missing:\n"
            + "\n".join(missing)
        )


def ensure_output_directories_are_new():
    for directory in (MODEL_DIR, REPORT_DIR):
        if directory.exists() and any(directory.iterdir()):
            raise FileExistsError(
                f"Output directory is not empty:\n{directory}\n"
                "Move/rename it before starting a new run. "
                "Existing model files will not be overwritten."
            )


def create_output_directories():
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    REPORT_DIR.mkdir(parents=True, exist_ok=True)

    for dataset in DATASETS:
        (MODEL_DIR / dataset).mkdir(
            parents=True,
            exist_ok=True
        )

        (REPORT_DIR / dataset).mkdir(
            parents=True,
            exist_ok=True
        )


def load_parquet(path):
    """
    Load Parquet using DuckDB, avoiding a dependency on
    pandas' Parquet engine.
    """
    con = duckdb.connect(":memory:")
    try:
        df = con.execute(
            "SELECT * FROM read_parquet(?)",
            [str(path)]
        ).fetchdf()
    finally:
        con.close()

    return df


def validate_columns(df, features, path):
    required = set(features + METADATA_COLUMNS)

    missing = sorted(required - set(df.columns))

    if missing:
        raise RuntimeError(
            f"Missing columns in {path}:\n"
            + "\n".join(missing)
        )


def normalize_labels(series, context):
    labels = series.astype(str).str.upper().str.strip()

    unknown = sorted(
        set(labels.unique()) - set(CLASS_TO_ID.keys())
    )

    if unknown:
        raise RuntimeError(
            f"Unexpected labels in {context}: {unknown}"
        )

    return labels.map(CLASS_TO_ID).astype(np.int32)


def prepare_features(df, features, context):
    """
    Numeric conversion and infinity handling.

    Finite values are not clipped or winsorized.
    Missing values remain NaN for LightGBM.
    """
    X = df[features].copy()

    for col in features:
        X[col] = pd.to_numeric(
            X[col],
            errors="coerce"
        )

    infinity_counts = {}

    if REPLACE_INFINITY_WITH_NAN:
        for col in features:
            values = X[col].to_numpy(dtype=np.float64)

            count = int(np.isinf(values).sum())

            if count:
                infinity_counts[col] = count
                X[col] = X[col].replace(
                    [np.inf, -np.inf],
                    np.nan
                )

    missing_counts = {
        col: int(count)
        for col, count in X.isna().sum().items()
        if count > 0
    }

    log(
        f"{context}: rows={len(X):,}, "
        f"features={len(features)}, "
        f"columns with infinities={len(infinity_counts)}"
    )

    if infinity_counts:
        log(
            f"{context}: infinity values converted to NaN="
            f"{sum(infinity_counts.values()):,}"
        )

    return X, {
        "infinity_counts_by_feature": infinity_counts,
        "total_infinity_values_replaced": sum(
            infinity_counts.values()
        ),
        "missing_counts_by_feature": missing_counts,
        "total_missing_values": int(X.isna().sum().sum()),
    }


def get_class_distribution(y):
    counts = {}

    for class_id, class_name in ID_TO_CLASS.items():
        count = int((y == class_id).sum())

        counts[class_name] = {
            "count": count,
            "percentage": round(
                100.0 * count / len(y), 4
            ) if len(y) else 0.0,
        }

    return counts


def calculate_metrics(y_true, probabilities):
    predictions = np.argmax(probabilities, axis=1)

    metrics = {
        "rows": int(len(y_true)),
        "accuracy": float(
            accuracy_score(y_true, predictions)
        ),
        "balanced_accuracy": float(
            balanced_accuracy_score(y_true, predictions)
        ),
        "macro_f1": float(
            f1_score(
                y_true,
                predictions,
                average="macro",
                zero_division=0
            )
        ),
        "weighted_f1": float(
            f1_score(
                y_true,
                predictions,
                average="weighted",
                zero_division=0
            )
        ),
        "macro_precision": float(
            precision_score(
                y_true,
                predictions,
                average="macro",
                zero_division=0
            )
        ),
        "macro_recall": float(
            recall_score(
                y_true,
                predictions,
                average="macro",
                zero_division=0
            )
        ),
        "log_loss": float(
            log_loss(
                y_true,
                probabilities,
                labels=[0, 1, 2]
            )
        ),
    }

    try:
        metrics["macro_roc_auc_ovr"] = float(
            roc_auc_score(
                y_true,
                probabilities,
                labels=[0, 1, 2],
                multi_class="ovr",
                average="macro"
            )
        )
    except Exception:
        metrics["macro_roc_auc_ovr"] = None

    metrics["confusion_matrix"] = (
        confusion_matrix(
            y_true,
            predictions,
            labels=[0, 1, 2]
        ).tolist()
    )

    metrics["classification_report"] = (
        classification_report(
            y_true,
            predictions,
            labels=[0, 1, 2],
            target_names=["DOWN", "SIDEWAYS", "UP"],
            output_dict=True,
            zero_division=0
        )
    )

    metrics["actual_class_distribution"] = (
        get_class_distribution(y_true)
    )

    metrics["predicted_class_distribution"] = (
        get_class_distribution(predictions)
    )

    return metrics, predictions


def create_model(n_estimators):
    return lgb.LGBMClassifier(
        objective="multiclass",
        num_class=NUM_CLASSES,
        n_estimators=n_estimators,
        learning_rate=LEARNING_RATE,
        num_leaves=31,
        max_depth=-1,
        min_child_samples=100,
        subsample=0.8,
        subsample_freq=1,
        colsample_bytree=0.8,
        reg_alpha=0.1,
        reg_lambda=2.0,
        random_state=RANDOM_STATE,
        n_jobs=N_JOBS,
        verbosity=-1,
        importance_type="gain",
    )


def save_json(path, data):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, default=str)


# ============================================================
# TRAIN ONE MODEL
# ============================================================

def train_one_model(dataset, horizon):

    log("\n" + "=" * 80)
    log(f"TRAINING: {dataset.upper()} | {horizon}m")
    log("=" * 80)

    features = FEATURES_BY_DATASET[dataset]

    train_path = (
            DATA_DIR
            / dataset
            / f"train_{horizon}m.parquet"
    )

    validation_path = (
            DATA_DIR
            / dataset
            / f"validation_{horizon}m.parquet"
    )

    # --------------------------------------------------------
    # Load data
    # --------------------------------------------------------

    log("\nLoading training dataset...")
    train_df = load_parquet(train_path)

    log("Loading 2024 validation dataset...")
    validation_df = load_parquet(validation_path)

    validate_columns(train_df, features, train_path)
    validate_columns(
        validation_df,
        features,
        validation_path
    )

    if train_df.empty or validation_df.empty:
        raise RuntimeError("Empty training or validation dataset.")

    # Dates are ISO date strings in these datasets.
    train_df["trading_day"] = (
        train_df["trading_day"].astype(str)
    )

    validation_df["trading_day"] = (
        validation_df["trading_day"].astype(str)
    )

    # --------------------------------------------------------
    # Internal chronological split
    # --------------------------------------------------------

    fit_mask = (
            train_df["trading_day"] <= INTERNAL_TRAIN_END
    )

    early_stop_mask = (
            (train_df["trading_day"] >= EARLY_STOP_START)
            & (train_df["trading_day"] <= EARLY_STOP_END)
    )

    fit_df = train_df.loc[fit_mask].copy()
    early_stop_df = train_df.loc[early_stop_mask].copy()

    if fit_df.empty or early_stop_df.empty:
        raise RuntimeError(
            "Internal chronological split produced an empty partition."
        )

    log("\nInternal chronological split:")
    log(
        f"  Fit period       : {fit_df['trading_day'].min()} "
        f"to {fit_df['trading_day'].max()}"
    )
    log(
        f"  Early-stop period: {early_stop_df['trading_day'].min()} "
        f"to {early_stop_df['trading_day'].max()}"
    )

    log(f"  Fit rows         : {len(fit_df):,}")
    log(f"  Early-stop rows  : {len(early_stop_df):,}")
    log(f"  2024 rows        : {len(validation_df):,}")

    # --------------------------------------------------------
    # Labels
    # --------------------------------------------------------

    y_fit = normalize_labels(
        fit_df["label"], "internal fit"
    )

    y_early = normalize_labels(
        early_stop_df["label"], "internal early stop"
    )

    y_train_full = normalize_labels(
        train_df["label"], "full train"
    )

    y_validation = normalize_labels(
        validation_df["label"], "2024 validation"
    )

    for name, y in [
        ("fit", y_fit),
        ("early_stop", y_early),
        ("full_train", y_train_full),
        ("validation", y_validation),
    ]:
        if set(y.unique()) != {0, 1, 2}:
            raise RuntimeError(
                f"{name} does not contain all three classes: "
                f"{get_class_distribution(y)}"
            )

    log("\nInternal fit class distribution:")
    log(json.dumps(get_class_distribution(y_fit), indent=2))

    log("\nInternal early-stop class distribution:")
    log(json.dumps(get_class_distribution(y_early), indent=2))

    # --------------------------------------------------------
    # Feature preparation
    # --------------------------------------------------------

    X_fit, fit_quality = prepare_features(
        fit_df,
        features,
        "FIT"
    )

    X_early, early_quality = prepare_features(
        early_stop_df,
        features,
        "EARLY_STOP"
    )

    # --------------------------------------------------------
    # Class weights
    #
    # Balanced weights are computed from the fit partition only.
    # Same weighting approach is used for both model families.
    # --------------------------------------------------------

    fit_weights = compute_sample_weight(
        class_weight="balanced",
        y=y_fit
    )

    early_weights = compute_sample_weight(
        class_weight="balanced",
        y=y_early
    )

    # --------------------------------------------------------
    # Early stopping
    # --------------------------------------------------------

    log("\nStarting LightGBM early-stopping training...")

    early_model = create_model(N_ESTIMATORS)

    early_model.fit(
        X_fit,
        y_fit,
        sample_weight=fit_weights,
        eval_set=[(X_early, y_early)],
        eval_sample_weight=[early_weights],
        eval_metric="multi_logloss",
        callbacks=[
            lgb.early_stopping(
                EARLY_STOPPING_ROUNDS,
                verbose=True
            ),
            lgb.log_evaluation(100),
        ],
    )

    best_iteration = early_model.best_iteration_

    if not best_iteration or best_iteration < 1:
        best_iteration = N_ESTIMATORS

    log(f"\nBest iteration: {best_iteration}")

    del early_model
    del X_fit, X_early
    del fit_weights, early_weights
    gc.collect()

    # --------------------------------------------------------
    # Refit on all 2021-2023 training data
    # --------------------------------------------------------

    log("\nPreparing complete 2021-2023 training data...")

    X_train_full, full_train_quality = prepare_features(
        train_df,
        features,
        "FULL_TRAIN"
    )

    X_validation, validation_quality = prepare_features(
        validation_df,
        features,
        "VALIDATION_2024"
    )

    full_train_weights = compute_sample_weight(
        class_weight="balanced",
        y=y_train_full
    )

    log(
        "\nRefitting on complete 2021-2023 training period "
        f"using {best_iteration} boosting rounds..."
    )

    final_model = create_model(best_iteration)

    final_model.fit(
        X_train_full,
        y_train_full,
        sample_weight=full_train_weights,
    )

    # --------------------------------------------------------
    # Evaluate on 2024
    # --------------------------------------------------------

    log("\nEvaluating on 2024 validation data...")

    probabilities = final_model.predict_proba(
        X_validation
    )

    metrics, predictions = calculate_metrics(
        y_validation,
        probabilities
    )

    log("\n2024 validation metrics:")
    log(
        json.dumps(
            {
                key: value
                for key, value in metrics.items()
                if key not in (
                "classification_report",
                "confusion_matrix",
                "actual_class_distribution",
                "predicted_class_distribution",
            )
            },
            indent=2
        )
    )

    log("\n2024 predicted class distribution:")
    log(
        json.dumps(
            metrics["predicted_class_distribution"],
            indent=2
        )
    )

    # --------------------------------------------------------
    # Save model
    # --------------------------------------------------------

    model_path = (
            MODEL_DIR
            / dataset
            / f"lightgbm_{dataset}_{horizon}m.txt"
    )

    final_model.booster_.save_model(
        str(model_path)
    )

    # --------------------------------------------------------
    # Save feature importance
    # --------------------------------------------------------

    importance_df = pd.DataFrame({
        "feature": features,
        "importance_gain": (
            final_model.booster_.feature_importance(
                importance_type="gain"
            )
        ),
        "importance_split": (
            final_model.booster_.feature_importance(
                importance_type="split"
            )
        ),
    }).sort_values(
        "importance_gain",
        ascending=False
    )

    importance_path = (
            REPORT_DIR
            / dataset
            / f"feature_importance_{horizon}m.csv"
    )

    importance_df.to_csv(
        importance_path,
        index=False
    )

    # --------------------------------------------------------
    # Save validation predictions
    # --------------------------------------------------------

    if SAVE_PREDICTIONS:

        prediction_df = validation_df[
            METADATA_COLUMNS
        ].copy()

        prediction_df["actual_class"] = (
            y_validation.map(ID_TO_CLASS).values
        )

        prediction_df["predicted_class"] = [
            ID_TO_CLASS[int(x)]
            for x in predictions
        ]

        prediction_df["prob_down"] = probabilities[:, 0]
        prediction_df["prob_sideways"] = probabilities[:, 1]
        prediction_df["prob_up"] = probabilities[:, 2]

        prediction_path = (
                REPORT_DIR
                / dataset
                / f"validation_predictions_{horizon}m.csv"
        )

        prediction_df.to_csv(
            prediction_path,
            index=False
        )

    # --------------------------------------------------------
    # Save metrics
    # --------------------------------------------------------

    result = {
        "dataset": dataset,
        "horizon_minutes": horizon,
        "model": "LightGBM multiclass",
        "created_utc": datetime.now(
            timezone.utc
        ).isoformat(),
        "features": features,
        "feature_count": len(features),
        "class_mapping": CLASS_TO_ID,
        "training_period": {
            "start": str(train_df["trading_day"].min()),
            "end": str(train_df["trading_day"].max()),
            "rows": int(len(train_df)),
        },
        "internal_fit_period": {
            "end": INTERNAL_TRAIN_END,
            "rows": int(len(fit_df)),
            "class_distribution": get_class_distribution(y_fit),
        },
        "early_stopping_period": {
            "start": EARLY_STOP_START,
            "end": EARLY_STOP_END,
            "rows": int(len(early_stop_df)),
            "class_distribution": get_class_distribution(y_early),
        },
        "validation_period": {
            "start": FINAL_VALIDATION_START,
            "end": FINAL_VALIDATION_END,
            "rows": int(len(validation_df)),
            "class_distribution": get_class_distribution(y_validation),
        },
        "training_configuration": {
            "n_estimators_initial": N_ESTIMATORS,
            "best_iteration": int(best_iteration),
            "learning_rate": LEARNING_RATE,
            "num_leaves": 31,
            "min_child_samples": 100,
            "colsample_bytree": 0.8,
            "subsample": 0.8,
            "reg_alpha": 0.1,
            "reg_lambda": 2.0,
            "class_weighting": "balanced sample weights",
            "random_state": RANDOM_STATE,
            "n_jobs": N_JOBS,
        },
        "data_quality": {
            "fit": fit_quality,
            "early_stop": early_quality,
            "full_train": full_train_quality,
            "validation": validation_quality,
        },
        "validation_metrics": metrics,
        "model_file": str(model_path),
        "feature_importance_file": str(importance_path),
    }

    metrics_path = (
            REPORT_DIR
            / dataset
            / f"metrics_{horizon}m.json"
    )

    save_json(metrics_path, result)

    log("\nSaved:")
    log(f"  Model      : {model_path}")
    log(f"  Metrics    : {metrics_path}")
    log(f"  Importance : {importance_path}")

    if SAVE_PREDICTIONS:
        log(f"  Predictions: {prediction_path}")

    # --------------------------------------------------------
    # Compact comparison row
    # --------------------------------------------------------

    comparison = {
        "dataset": dataset,
        "horizon_minutes": horizon,
        "train_rows": len(train_df),
        "validation_rows": len(validation_df),
        "feature_count": len(features),
        "best_iteration": int(best_iteration),
        "accuracy": metrics["accuracy"],
        "balanced_accuracy": metrics["balanced_accuracy"],
        "macro_f1": metrics["macro_f1"],
        "weighted_f1": metrics["weighted_f1"],
        "macro_precision": metrics["macro_precision"],
        "macro_recall": metrics["macro_recall"],
        "log_loss": metrics["log_loss"],
        "macro_roc_auc_ovr": metrics["macro_roc_auc_ovr"],
        "predicted_down_pct": (
            metrics["predicted_class_distribution"]["DOWN"]["percentage"]
        ),
        "predicted_sideways_pct": (
            metrics["predicted_class_distribution"]["SIDEWAYS"]["percentage"]
        ),
        "predicted_up_pct": (
            metrics["predicted_class_distribution"]["UP"]["percentage"]
        ),
        "total_infinity_values_replaced": (
                full_train_quality["total_infinity_values_replaced"]
                + validation_quality["total_infinity_values_replaced"]
        ),
        "model_file": str(model_path),
        "metrics_file": str(metrics_path),
    }

    # Free memory before the next model.
    del final_model
    del X_train_full, X_validation
    del train_df, validation_df
    del y_train_full, y_validation
    del probabilities
    if SAVE_PREDICTIONS:
        del prediction_df
    gc.collect()

    return comparison


# ============================================================
# MAIN
# ============================================================

def main():

    log("=" * 80)
    log("NIFTY LIGHTGBM MATCHED TRAINING V1")
    log("=" * 80)

    log(f"Project root : {ROOT}")
    log(f"Data         : {DATA_DIR}")
    log(f"Models       : {MODEL_DIR}")
    log(f"Reports      : {REPORT_DIR}")

    log(f"\nLightGBM version: {lgb.__version__}")
    log(f"Pandas version  : {pd.__version__}")
    log(f"NumPy version   : {np.__version__}")

    ensure_input_files()
    ensure_output_directories_are_new()
    create_output_directories()

    comparisons = []

    total_models = len(DATASETS) * len(HORIZONS)
    completed = 0

    for dataset in DATASETS:
        for horizon in HORIZONS:

            completed += 1

            log(
                f"\nMODEL {completed}/{total_models}: "
                f"{dataset} | {horizon}m"
            )

            result = train_one_model(
                dataset,
                horizon
            )

            comparisons.append(result)

            comparison_path = (
                    REPORT_DIR / "training_comparison_progress.csv"
            )

            pd.DataFrame(comparisons).to_csv(
                comparison_path,
                index=False
            )

    # --------------------------------------------------------
    # Final comparison report
    # --------------------------------------------------------

    comparison_df = pd.DataFrame(comparisons)

    comparison_path = (
            REPORT_DIR / "training_comparison.csv"
    )

    comparison_df.to_csv(
        comparison_path,
        index=False
    )

    log("\n" + "=" * 80)
    log("ALL SIX MODELS TRAINED")
    log("=" * 80)

    display_columns = [
        "dataset",
        "horizon_minutes",
        "best_iteration",
        "accuracy",
        "balanced_accuracy",
        "macro_f1",
        "log_loss",
        "macro_roc_auc_ovr",
        "predicted_down_pct",
        "predicted_sideways_pct",
        "predicted_up_pct",
    ]

    log("\nValidation comparison:")
    log(
        comparison_df[display_columns].to_string(
            index=False
        )
    )

    log("\nFinal comparison report:")
    log(str(comparison_path))

    log("\nTraining completed successfully.")
    log(
        "These are diagnostic 2024 validation results, "
        "not evidence of live trading profitability."
    )


if __name__ == "__main__":
    try:
        main()
    except Exception:
        log("\nTRAINING FAILED")
        traceback.print_exc()
        sys.exit(1)
