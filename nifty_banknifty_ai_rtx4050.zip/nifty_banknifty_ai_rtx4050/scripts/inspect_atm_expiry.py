from pathlib import Path
import pandas as pd

BASE = Path(__file__).resolve().parent.parent
REPORTS = BASE / "data" / "reports"

FILES = [
    "nifty_atm_coverage_by_expiry.csv",
    "banknifty_atm_coverage_by_expiry.csv",
]

for filename in FILES:
    path = REPORTS / filename

    print("\n" + "=" * 90)
    print(filename)
    print("=" * 90)

    if not path.exists():
        print(f"FILE NOT FOUND: {path}")
        continue

    df = pd.read_csv(path)

    print("\nColumns:")
    print(df.columns.tolist())

    print("\nTotal rows:", len(df))

    print("\nFirst 15 records:")
    print(df.head(15).to_string(index=False))

    print("\nData types:")
    print(df.dtypes.to_string())

print("\nEXPIRY REPORT INSPECTION FINISHED")