$ErrorActionPreference = "Stop"
py -3.12 -m venv .venv
& .\.venv\Scripts\python.exe -m pip install --upgrade pip setuptools wheel
& .\.venv\Scripts\python.exe -m pip install -e ".[dev,kite]"
Write-Host "Setup complete. Activate with .\.venv\Scripts\Activate.ps1"
