
"""
NIFTY MONTHLY / QUARTERLY DIRECTIONAL STABILITY AUDIT V1

Uses all nine saved 2024 prediction files.
No model training.
No threshold optimization.

Outputs:
- monthly_directional_stability.csv
- quarterly_directional_stability.csv
- overall_directional_stability.csv
- stability_summary.json
"""

from pathlib import Path
import json

import numpy as np
import pandas as pd

from sklearn.metrics import (
    roc_auc_score,
    average_precision_score,
)

ROOT = Path(__file__).resolve().parents[1]

REPORT_ROOT = ROOT / "reports" / "nifty_feature_ablation_v1"

CLASSES = ["DOWN", "UP"]

PROBABILITY_COLUMNS = {
    "DOWN": "prob_down",
    "UP": "prob_up",
}

TOP_FRACTION = 0.10
MIN_MONTHLY_ROWS = 1000


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def find_latest_run():
    runs = [
        path for path in REPORT_ROOT.iterdir()
        if path.is_dir()
           and list(path.glob("*_predictions.parquet"))
    ]

    require(runs, "No prediction run folders found")

    return max(
        runs,
        key=lambda path: path.stat().st_mtime,
    )


def load_model_predictions(path):
    df = pd.read_parquet(path)

    required = [
        "timestamp_ist",
        "trading_day",
        "label",
        "prob_down",
        "prob_up",
    ]

    missing = set(required) - set(df.columns)

    require(
        not missing,
        f"{path.name}: missing {sorted(missing)}",
    )

    require(
        df["label"].isin(
            ["DOWN", "SIDEWAYS", "UP"]
        ).all(),
        "Unexpected label",
    )

    df["timestamp_ist"] = pd.to_datetime(
        df["timestamp_ist"],
        utc=True,
    ).dt.tz_convert("Asia/Kolkata")

    df["trading_day"] = pd.to_datetime(
        df["trading_day"],
        errors="raise",
    )

    for column in ["prob_down", "prob_up"]:
        df[column] = pd.to_numeric(
            df[column],
            errors="raise",
        )

        require(
            np.isfinite(df[column]).all(),
            f"Invalid values in {column}",
        )

        require(
            df[column].between(0, 1).all(),
            f"Out-of-range values in {column}",
        )

    require(
        not df["timestamp_ist"].duplicated().any(),
        "Duplicate timestamps found",
    )

    df["month"] = (
        df["trading_day"].dt.to_period("M").astype(str)
    )

    df["quarter"] = (
        df["trading_day"].dt.to_period("Q").astype(str)
    )

    return df


def evaluate_period(df, model, period_type, period_name):
    rows = []

    if len(df) < MIN_MONTHLY_ROWS:
        return rows

    for class_name in CLASSES:
        probability_column = (
            PROBABILITY_COLUMNS[class_name]
        )

        y = (
                df["label"].to_numpy() == class_name
        ).astype(np.int8)

        scores = df[
            probability_column
        ].to_numpy(dtype=np.float64)

        positives = int(y.sum())
        negatives = len(y) - positives

        if positives == 0 or negatives == 0:
            continue

        auc = roc_auc_score(y, scores)

        average_precision = average_precision_score(
            y,
            scores,
        )

        prevalence = float(y.mean())

        # Top 10% observations by directional probability.
        cutoff = np.quantile(
            scores,
            1.0 - TOP_FRACTION,
            )

        selected = scores >= cutoff

        # Include all observations tied at the cutoff.
        selected_count = int(selected.sum())

        tp = int(np.sum(selected & (y == 1)))

        precision = (
            tp / selected_count
            if selected_count else 0.0
        )

        recall = (
            tp / positives
            if positives else 0.0
        )

        lift = (
            precision / prevalence
            if prevalence > 0 else 0.0
        )

        positive_mean = float(
            scores[y == 1].mean()
        )

        negative_mean = float(
            scores[y == 0].mean()
        )

        rows.append({
            "model": model,
            "period_type": period_type,
            "period": period_name,
            "class": class_name,
            "observations": len(df),
            "positive_observations": positives,
            "prevalence": prevalence,
            "roc_auc": float(auc),
            "average_precision": float(
                average_precision
            ),
            "top10_cutoff": float(cutoff),
            "top10_selected_count": selected_count,
            "top10_actual_precision": float(precision),
            "top10_recall": float(recall),
            "top10_lift_vs_prevalence": float(lift),
            "positive_mean_probability": positive_mean,
            "negative_mean_probability": negative_mean,
            "probability_difference": (
                    positive_mean - negative_mean
            ),
        })

    return rows


def main():
    run_dir = find_latest_run()

    output_dir = (
            run_dir / "monthly_stability_audit_v1"
    )

    output_dir.mkdir(
        parents=True,
        exist_ok=False,
    )

    prediction_files = sorted(
        run_dir.glob("*_predictions.parquet")
    )

    require(
        len(prediction_files) == 9,
        f"Expected 9 models, found {len(prediction_files)}",
        )

    monthly_rows = []
    quarterly_rows = []
    overall_rows = []

    print("=" * 80)
    print("NIFTY CHRONOLOGICAL STABILITY AUDIT")
    print("=" * 80)
    print(f"Source: {run_dir}")

    for path in prediction_files:
        model = path.stem.replace(
            "_predictions", ""
        )

        print(f"\nProcessing {model}")

        df = load_model_predictions(path)

        # Overall period
        overall_rows.extend(
            evaluate_period(
                df,
                model,
                "overall",
                "2024",
            )
        )

        # Monthly periods
        for month, group in df.groupby(
                "month",
                sort=True,
        ):
            monthly_rows.extend(
                evaluate_period(
                    group,
                    model,
                    "month",
                    month,
                )
            )

        # Quarterly periods
        for quarter, group in df.groupby(
                "quarter",
                sort=True,
        ):
            quarterly_rows.extend(
                evaluate_period(
                    group,
                    model,
                    "quarter",
                    quarter,
                )
            )

    monthly = pd.DataFrame(monthly_rows)
    quarterly = pd.DataFrame(quarterly_rows)
    overall = pd.DataFrame(overall_rows)

    require(
        not monthly.empty,
        "No monthly results generated",
    )

    monthly.to_csv(
        output_dir / "monthly_directional_stability.csv",
        index=False,
        )

    quarterly.to_csv(
        output_dir / "quarterly_directional_stability.csv",
        index=False,
        )

    overall.to_csv(
        output_dir / "overall_directional_stability.csv",
        index=False,
        )

    # Stability summary
    stability = (
        monthly.groupby(
            ["model", "class"],
            as_index=False,
        )
        .agg(
            months=("period", "nunique"),
            mean_monthly_auc=("roc_auc", "mean"),
            median_monthly_auc=("roc_auc", "median"),
            std_monthly_auc=("roc_auc", "std"),
            min_monthly_auc=("roc_auc", "min"),
            max_monthly_auc=("roc_auc", "max"),
            months_auc_above_050=(
                "roc_auc",
                lambda x: int((x > 0.50).sum()),
            ),
            mean_monthly_ap=(
                "average_precision",
                "mean",
            ),
            mean_top10_lift=(
                "top10_lift_vs_prevalence",
                "mean",
            ),
        )
    )

    stability.to_csv(
        output_dir / "stability_summary.csv",
        index=False,
        )

    summary = {
        "source_run": str(run_dir),
        "models": len(prediction_files),
        "monthly_rows": len(monthly),
        "quarterly_rows": len(quarterly),
        "top_fraction": TOP_FRACTION,
        "minimum_monthly_observations": MIN_MONTHLY_ROWS,
        "notes": [
            "All results use 2024 diagnostic predictions.",
            "Monthly top-10% cutoffs are descriptive, not trading thresholds.",
            "Monthly observations are not independent because forward labels overlap.",
            "No thresholds were selected for deployment.",
            "No profitability or execution-cost assumptions are included.",
        ],
    }

    (output_dir / "stability_summary.json").write_text(
        json.dumps(summary, indent=2),
        encoding="utf-8",
    )

    print("\n" + "=" * 80)
    print("STABILITY AUDIT COMPLETE")
    print("=" * 80)

    print(f"Output: {output_dir}")

    print("\nStability summary:")
    print(
        stability.to_string(
            index=False,
            float_format=lambda x: f"{x:.4f}",
        )
    )


if __name__ == "__main__":
    main()
