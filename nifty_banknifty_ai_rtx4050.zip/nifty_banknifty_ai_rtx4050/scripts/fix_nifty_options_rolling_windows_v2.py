
from __future__ import annotations

import json
import sys
import traceback
from datetime import datetime
from pathlib import Path

import duckdb
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]

INPUT_FILE = (
        ROOT / "data/processed/nifty_options_features_v1/"
               "nifty_options_features_v1.parquet"
)

OUTPUT_DIR = ROOT / "data/processed/nifty_options_features_v2"
OUTPUT_FILE = OUTPUT_DIR / "nifty_options_features_v2.parquet"

REPORT_DIR = ROOT / "reports/nifty_options_features_v2"

TIME_COLUMN = "timestamp_ist"
DAY_COLUMN = "trading_date"

WINDOWS = {
    5: 4,
    15: 14,
    30: 29,
}


def log(message: str):
    print(f"[{datetime.now():%H:%M:%S}] {message}")


def main():
    if not INPUT_FILE.exists():
        raise FileNotFoundError(INPUT_FILE)

    # Never overwrite previous output.
    if OUTPUT_FILE.exists():
        raise FileExistsError(
            f"Output already exists: {OUTPUT_FILE}\n"
            "Preserve it and use a new version directory."
        )

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    REPORT_DIR.mkdir(parents=True, exist_ok=True)

    con = duckdb.connect(":memory:")
    con.execute("SET TimeZone='Asia/Kolkata'")
    con.execute("SET threads TO 4")

    try:
        input_path = str(INPUT_FILE).replace("\\", "/").replace("'", "''")
        output_path = str(OUTPUT_FILE).replace("\\", "/").replace("'", "''")

        schema = con.execute(
            f"DESCRIBE SELECT * FROM read_parquet('{input_path}')"
        ).fetchall()

        columns = {row[0]: row[1] for row in schema}

        required = [
            TIME_COLUMN,
            DAY_COLUMN,
            "atm_ce_volume",
            "atm_pe_volume",
        ]

        missing = [c for c in required if c not in columns]

        if missing:
            raise ValueError(f"Missing required columns: {missing}")

        derived_columns = []

        for window in WINDOWS:
            derived_columns.extend([
                f"atm_ce_volume_sum_{window}m",
                f"atm_pe_volume_sum_{window}m",
                f"atm_volume_imbalance_{window}m",
            ])

        missing_derived = [
            c for c in derived_columns if c not in columns
        ]

        if missing_derived:
            raise ValueError(
                "Expected v1 rolling feature columns not found: "
                f"{missing_derived}"
            )

        log("Reading v1 options feature dataset")

        con.execute(f"""
            CREATE VIEW source_data AS
            SELECT *
            FROM read_parquet('{input_path}')
        """)

        input_rows = con.execute(
            "SELECT COUNT(*) FROM source_data"
        ).fetchone()[0]

        duplicate_groups = con.execute(f"""
            SELECT COUNT(*)
            FROM (
                SELECT "{TIME_COLUMN}"
                FROM source_data
                GROUP BY "{TIME_COLUMN}"
                HAVING COUNT(*) > 1
            )
        """).fetchone()[0]

        if duplicate_groups:
            raise ValueError(
                f"Found {duplicate_groups} duplicate timestamps. "
                "Cannot safely calculate rolling windows."
            )

        # Build window expressions.
        expressions = []

        for window, offset in WINDOWS.items():

            expressions.extend([
                f"""
                LAG("{TIME_COLUMN}", {offset}) OVER (
                    PARTITION BY "{DAY_COLUMN}"
                    ORDER BY "{TIME_COLUMN}"
                ) AS prior_timestamp_{window}m
                """,

                f"""
                COUNT(atm_ce_volume) OVER (
                    PARTITION BY "{DAY_COLUMN}"
                    ORDER BY "{TIME_COLUMN}"
                    ROWS BETWEEN {offset} PRECEDING AND CURRENT ROW
                ) AS ce_count_{window}m
                """,

                f"""
                COUNT(atm_pe_volume) OVER (
                    PARTITION BY "{DAY_COLUMN}"
                    ORDER BY "{TIME_COLUMN}"
                    ROWS BETWEEN {offset} PRECEDING AND CURRENT ROW
                ) AS pe_count_{window}m
                """,

                f"""
                SUM(atm_ce_volume) OVER (
                    PARTITION BY "{DAY_COLUMN}"
                    ORDER BY "{TIME_COLUMN}"
                    ROWS BETWEEN {offset} PRECEDING AND CURRENT ROW
                ) AS ce_sum_candidate_{window}m
                """,

                f"""
                SUM(atm_pe_volume) OVER (
                    PARTITION BY "{DAY_COLUMN}"
                    ORDER BY "{TIME_COLUMN}"
                    ROWS BETWEEN {offset} PRECEDING AND CURRENT ROW
                ) AS pe_sum_candidate_{window}m
                """,
            ])

        log("Calculating rolling windows with clock continuity")

        con.execute(f"""
            CREATE TEMP TABLE rolling_candidates AS
            SELECT
                *,
                {",".join(expressions)}
            FROM source_data
        """)

        # Calculate exact clock continuity and guarded sums.
        guarded_expressions = []

        for window, offset in WINDOWS.items():

            contiguous = f"""
                prior_timestamp_{window}m IS NOT NULL
                AND DATE_DIFF(
                    'minute',
                    prior_timestamp_{window}m,
                    "{TIME_COLUMN}"
                ) = {offset}
            """

            complete = f"""
                ce_count_{window}m = {window}
                AND pe_count_{window}m = {window}
            """

            guarded_expressions.extend([
                f"""
                CASE
                    WHEN ({contiguous}) AND ({complete})
                    THEN ce_sum_candidate_{window}m
                    ELSE NULL
                END AS atm_ce_volume_sum_{window}m
                """,

                f"""
                CASE
                    WHEN ({contiguous}) AND ({complete})
                    THEN pe_sum_candidate_{window}m
                    ELSE NULL
                END AS atm_pe_volume_sum_{window}m
                """,

                f"""
                CASE
                    WHEN ({contiguous})
                     AND ({complete})
                     AND (
                         ce_sum_candidate_{window}m
                         + pe_sum_candidate_{window}m
                     ) > 0
                    THEN
                        (
                            ce_sum_candidate_{window}m
                            - pe_sum_candidate_{window}m
                        )
                        /
                        (
                            ce_sum_candidate_{window}m
                            + pe_sum_candidate_{window}m
                        )
                    ELSE NULL
                END AS atm_volume_imbalance_{window}m
                """,
            ])

        # Remove the old rolling outputs and replace with guarded values.
        excluded = ", ".join(f'"{c}"' for c in derived_columns)

        log("Writing corrected v2 Parquet")

        con.execute(f"""
            COPY (
                SELECT
                    * EXCLUDE ({excluded}),
                    {",".join(guarded_expressions)}
                FROM rolling_candidates
            )
            TO '{output_path}'
            (FORMAT PARQUET, COMPRESSION ZSTD)
        """)

        # ----------------------------------------------------
        # Audit corrected output
        # ----------------------------------------------------

        con.execute(f"""
            CREATE VIEW output_data AS
            SELECT *
            FROM read_parquet('{output_path}')
        """)

        output_rows = con.execute(
            "SELECT COUNT(*) FROM output_data"
        ).fetchone()[0]

        audit_results = []

        for window, offset in WINDOWS.items():

            query = f"""
                WITH checked AS (
                    SELECT
                        *,
                        LAG("{TIME_COLUMN}", {offset}) OVER (
                            PARTITION BY "{DAY_COLUMN}"
                            ORDER BY "{TIME_COLUMN}"
                        ) AS prior_ts
                    FROM output_data
                )
                SELECT
                    {window} AS window_minutes,
                    COUNT(*) AS total_rows,

                    COUNT(*) FILTER (
                        WHERE atm_ce_volume_sum_{window}m IS NOT NULL
                          AND atm_pe_volume_sum_{window}m IS NOT NULL
                    ) AS nonnull_rolling_sum_rows,

                    COUNT(*) FILTER (
                        WHERE atm_ce_volume_sum_{window}m IS NOT NULL
                          AND atm_pe_volume_sum_{window}m IS NOT NULL
                          AND (
                              prior_ts IS NULL
                              OR DATE_DIFF(
                                  'minute',
                                  prior_ts,
                                  "{TIME_COLUMN}"
                              ) <> {offset}
                          )
                    ) AS rolling_sum_present_across_clock_gap,

                    COUNT(*) FILTER (
                        WHERE atm_volume_imbalance_{window}m IS NOT NULL
                          AND (
                              prior_ts IS NULL
                              OR DATE_DIFF(
                                  'minute',
                                  prior_ts,
                                  "{TIME_COLUMN}"
                              ) <> {offset}
                          )
                    ) AS imbalance_present_across_clock_gap

                FROM checked
            """

            result = con.execute(query).df().iloc[0].to_dict()
            audit_results.append(result)

        audit_df = pd.DataFrame(audit_results)
        audit_df.to_csv(
            REPORT_DIR / "rolling_window_validation_v2.csv",
            index=False,
            )

        # Check schema and feature count.
        output_schema = con.execute(
            f"DESCRIBE SELECT * FROM read_parquet('{output_path}')"
        ).fetchall()

        schema_df = pd.DataFrame(
            [
                {"column_name": row[0], "column_type": row[1]}
                for row in output_schema
            ]
        )

        schema_df.to_csv(
            REPORT_DIR / "options_feature_schema_v2.csv",
            index=False,
            )

        checks = {
            "row_count_preserved": input_rows == output_rows,
            "no_duplicate_timestamps": duplicate_groups == 0,
            "no_rolling_sum_across_clock_gap": (
                    int(audit_df[
                            "rolling_sum_present_across_clock_gap"
                        ].sum()) == 0
            ),
            "no_imbalance_across_clock_gap": (
                    int(audit_df[
                            "imbalance_present_across_clock_gap"
                        ].sum()) == 0
            ),
        }

        summary = {
            "generated_at": datetime.now().isoformat(),
            "input_file": str(INPUT_FILE),
            "output_file": str(OUTPUT_FILE),
            "input_rows": input_rows,
            "output_rows": output_rows,
            "duplicate_timestamp_groups": duplicate_groups,
            "rolling_window_results": audit_results,
            "checks": checks,
            "overall_status": (
                "PASS" if all(checks.values()) else "REVIEW_REQUIRED"
            ),
            "source_modified": False,
            "labels_modified": False,
            "rolling_policy": (
                "A rolling feature is non-null only when all observations "
                "are present and the first-to-current timestamp interval "
                "equals the expected number of clock minutes."
            ),
            "imbalance_formula": (
                "(CE rolling volume - PE rolling volume) / "
                "(CE rolling volume + PE rolling volume)"
            ),
        }

        summary_path = (
                REPORT_DIR / "options_feature_v2_summary.json"
        )

        with open(summary_path, "w", encoding="utf-8") as f:
            json.dump(summary, f, indent=2, default=str)

        print("\n" + "=" * 72)
        print("NIFTY OPTIONS FEATURE V2")
        print("=" * 72)
        print(f"Input rows : {input_rows:,}")
        print(f"Output rows: {output_rows:,}")
        print("\nRolling audit:")
        print(audit_df.to_string(index=False))
        print("\nChecks:")

        for name, passed in checks.items():
            print(f"{'PASS' if passed else 'FAIL'} : {name}")

        print(f"\nOverall status: {summary['overall_status']}")
        print(f"Output: {OUTPUT_FILE}")
        print(f"Reports: {REPORT_DIR}")
        print("=" * 72)

    finally:
        con.close()


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print("\nOPTIONS FEATURE V2 FAILED")
        print(str(exc))
        traceback.print_exc()
        sys.exit(1)
