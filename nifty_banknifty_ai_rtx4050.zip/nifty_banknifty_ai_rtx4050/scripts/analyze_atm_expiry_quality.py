
from pathlib import Path
import pandas as pd

BASE = Path(__file__).resolve().parent.parent
REPORTS = BASE / "data" / "reports"

DATASETS = {
    "NIFTY": "nifty_atm_coverage_by_expiry.csv",
    "BANKNIFTY": "banknifty_atm_coverage_by_expiry.csv",
}

BANDS = [0.5, 1.0, 2.0]

def analyze(name, filename):
    path = REPORTS / filename
    df = pd.read_csv(path)

    df["trading_day"] = pd.to_datetime(df["trading_day"])
    df["expiry"] = pd.to_datetime(df["expiry"])

    print("\n" + "=" * 95)
    print(f"{name} EXPIRY QUALITY ANALYSIS")
    print("=" * 95)

    # 1. Coverage by days to expiry
    df["expiry_bucket"] = pd.cut(
        df["days_to_expiry"],
        bins=[-1, 1, 3, 7, 14, 30, 1000],
        labels=[
            "0-1 days",
            "2-3 days",
            "4-7 days",
            "8-14 days",
            "15-30 days",
            "Above 30 days",
        ],
    )

    print("\n1. EXPIRY DISTANCE COVERAGE")

    for band in BANDS:
        subset = df[df["band_pct"] == band]

        summary = (
            subset.groupby("expiry_bucket", observed=False)
            .agg(
                trading_days=("trading_day", "nunique"),
                expiry_records=("expiry", "count"),
                avg_paired_coverage=("paired_slot_percentage", "mean"),
                median_paired_coverage=("paired_slot_percentage", "median"),
                avg_strikes=("strikes_in_band", "mean"),
                avg_paired_minutes=("minutes_with_same_strike_ce_pe", "mean"),
            )
            .reset_index()
        )

        print(f"\nATM BAND: +/-{band}%")
        print(summary.to_string(index=False, float_format="%.2f"))

    # 2. Nearest expiry on each trading day
    print("\n2. NEAREST EXPIRY QUALITY")

    nearest = (
        df.sort_values(
            ["trading_day", "days_to_expiry", "expiry"]
        )
        .drop_duplicates(["trading_day", "band_pct"], keep="first")
    )

    nearest_reports = []

    for band in BANDS:
        subset = nearest[nearest["band_pct"] == band].copy()

        stats = {
            "index": name,
            "band_pct": band,
            "days_with_nearest_expiry": subset["trading_day"].nunique(),
            "avg_days_to_expiry": subset["days_to_expiry"].mean(),
            "avg_paired_slot_pct": subset["paired_slot_percentage"].mean(),
            "median_paired_slot_pct": subset["paired_slot_percentage"].median(),
            "days_below_90pct": (
                    subset["paired_slot_percentage"] < 90
            ).sum(),
            "days_below_95pct": (
                    subset["paired_slot_percentage"] < 95
            ).sum(),
            "days_above_98pct": (
                    subset["paired_slot_percentage"] >= 98
            ).sum(),
        }

        nearest_reports.append(stats)

        print(f"\nATM BAND: +/-{band}%")
        print(pd.DataFrame([stats]).to_string(index=False))

    # 3. Year-wise nearest expiry coverage
    print("\n3. YEAR-WISE NEAREST EXPIRY COVERAGE")

    nearest["year"] = nearest["trading_day"].dt.year

    yearly = (
        nearest[nearest["band_pct"] == 0.5]
        .groupby("year")
        .agg(
            trading_days=("trading_day", "nunique"),
            avg_paired_coverage=("paired_slot_percentage", "mean"),
            median_paired_coverage=("paired_slot_percentage", "median"),
            days_below_90pct=(
                "paired_slot_percentage",
                lambda x: (x < 90).sum(),
            ),
        )
        .reset_index()
    )

    print(yearly.to_string(index=False, float_format="%.2f"))

    # 4. Worst nearest-expiry dates
    print("\n4. LOWEST NEAREST-EXPIRY COVERAGE DAYS (+/-0.5%)")

    worst = nearest[nearest["band_pct"] == 0.5].nsmallest(
        20, "paired_slot_percentage"
    )

    columns = [
        "trading_day",
        "expiry",
        "days_to_expiry",
        "eligible_contract_minute_slots",
        "paired_slot_percentage",
        "strikes_in_band",
        "minutes_with_same_strike_ce_pe",
    ]

    print(worst[columns].to_string(index=False))

    # Save nearest-expiry data
    nearest.to_csv(
        REPORTS / f"{name.lower()}_nearest_expiry_quality.csv",
        index=False,
        )

    pd.DataFrame(nearest_reports).to_csv(
        REPORTS / f"{name.lower()}_nearest_expiry_summary.csv",
        index=False,
        )

    yearly.to_csv(
        REPORTS / f"{name.lower()}_nearest_expiry_yearly.csv",
        index=False,
        )


if __name__ == "__main__":
    for name, filename in DATASETS.items():
        analyze(name, filename)

    print("\nEXPIRY QUALITY ANALYSIS FINISHED")
