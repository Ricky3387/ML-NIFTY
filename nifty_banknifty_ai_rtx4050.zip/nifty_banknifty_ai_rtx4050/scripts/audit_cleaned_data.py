
from pathlib import Path
import pandas as pd

BASE = Path(__file__).resolve().parent.parent
ROOT = BASE / "data" / "processed"
REPORTS = BASE / "data" / "reports"

OHLC = ["open", "high", "low", "close"]
OPTION_KEY = ["timestamp", "symbol", "expiry", "strike", "option_type"]
INDEX_KEY = ["timestamp", "symbol"]


def audit_file(file):
    relative = file.relative_to(ROOT)
    parts = relative.parts

    index_name = parts[0]
    data_type = parts[1]

    key = OPTION_KEY if data_type == "options" else INDEX_KEY

    result = {
        "index": index_name,
        "data_type": data_type,
        "file": str(relative),
        "status": "SUCCESS"
    }

    try:
        df = pd.read_parquet(file)

        missing = set(key + OHLC) - set(df.columns)
        if missing:
            raise ValueError(f"Missing columns: {sorted(missing)}")

        prices = df[OHLC].apply(pd.to_numeric, errors="coerce")

        invalid_ohlc = (
                prices.isna().any(axis=1)
                | (prices <= 0).any(axis=1)
                | (prices["high"] < prices["low"])
                | (
                        prices["high"]
                        < prices[["open", "close"]].max(axis=1)
                )
                | (
                        prices["low"]
                        > prices[["open", "close"]].min(axis=1)
                )
        )

        timestamp = pd.to_datetime(
            df["timestamp"], errors="coerce"
        )

        result.update({
            "rows": len(df),
            "columns": len(df.columns),
            "null_cells": int(df.isna().sum().sum()),
            "duplicate_exact_excess": (
                    len(df) - len(df.drop_duplicates())
            ),
            "duplicate_key_excess": int(
                df.duplicated(subset=key).sum()
            ),
            "invalid_ohlc": int(invalid_ohlc.sum()),
            "invalid_timestamps": int(timestamp.isna().sum()),
            "negative_volume": (
                int((df["volume"] < 0).sum())
                if "volume" in df.columns else -1
            ),
            "negative_oi": (
                int((df["open_interest"] < 0).sum())
                if "open_interest" in df.columns else -1
            ),
            "timestamp_min": str(timestamp.min()),
            "timestamp_max": str(timestamp.max()),
            "symbols": (
                df["symbol"].nunique()
                if "symbol" in df.columns else -1
            ),
            "option_types": (
                ",".join(
                    sorted(df["option_type"].dropna().astype(str).unique())
                )
                if data_type == "options" else ""
            )
        })

    except Exception as exc:
        result["status"] = "FAILED"
        result["error"] = str(exc)

    return result


def main():
    REPORTS.mkdir(parents=True, exist_ok=True)

    files = sorted(ROOT.rglob("*.parquet"))

    results = []

    print(f"Auditing {len(files)} Parquet files...\n")

    for i, file in enumerate(files, 1):
        print(f"[{i}/{len(files)}] {file.name}")
        results.append(audit_file(file))

    report = pd.DataFrame(results)

    output = REPORTS / "cleaned_data_audit.csv"
    report.to_csv(output, index=False)

    print("\n========== AUDIT SUMMARY ==========")

    print("Files:", len(report))
    print("Successful:", (report["status"] == "SUCCESS").sum())
    print("Failed:", (report["status"] == "FAILED").sum())

    successful = report[report["status"] == "SUCCESS"]

    for column in [
        "rows",
        "null_cells",
        "duplicate_exact_excess",
        "duplicate_key_excess",
        "invalid_ohlc",
        "invalid_timestamps",
        "negative_volume",
        "negative_oi"
    ]:
        if column in successful:
            print(f"{column}: {successful[column].sum():,}")

    print("\nBy index and data type:")

    print(
        successful.groupby(
            ["index", "data_type"]
        )["rows"].sum().to_string()
    )

    print("\nReport saved:", output)


if __name__ == "__main__":
    main()
