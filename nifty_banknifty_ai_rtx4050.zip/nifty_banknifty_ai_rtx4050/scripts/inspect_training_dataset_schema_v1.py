
from pathlib import Path
import duckdb

ROOT = Path(__file__).resolve().parents[1]

FILES = [
    ROOT / "data/processed/nifty_walkforward_v1/train_5m.parquet",
    ROOT / "data/processed/nifty_walkforward_v1/validation_5m.parquet",
    ROOT / "data/processed/nifty_walkforward_v1/train_15m.parquet",
    ROOT / "data/processed/nifty_walkforward_v1/validation_15m.parquet",
    ROOT / "data/processed/nifty_walkforward_v1/train_30m.parquet",
    ROOT / "data/processed/nifty_walkforward_v1/validation_30m.parquet",
    ROOT / "data/processed/nifty_features_experimental_v1/nifty_features_labels_experimental_v1.parquet",
    ]

con = duckdb.connect()

for path in FILES:
    print("\n" + "=" * 90)
    print(path.name)
    print("=" * 90)

    if not path.exists():
        print("FILE NOT FOUND:", path)
        continue

    p = str(path).replace("\\", "/").replace("'", "''")

    schema = con.execute(
        f"DESCRIBE SELECT * FROM read_parquet('{p}')"
    ).fetchdf()

    print(schema.to_string(index=False))

    count = con.execute(
        f"SELECT COUNT(*) FROM read_parquet('{p}')"
    ).fetchone()[0]

    print("\nROWS:", count)

con.close()
