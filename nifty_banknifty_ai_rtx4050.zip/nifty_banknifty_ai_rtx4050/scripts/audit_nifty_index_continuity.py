
from pathlib import Path
import json
import sys

import duckdb
import numpy as np
import pandas as pd


# ============================================================
# CONFIGURATION
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parents[1]

DB_PATH = (
        PROJECT_ROOT
        / "data"
        / "database"
        / "nifty_options.duckdb"
)

OUTPUT_DIR = (
        PROJECT_ROOT
        / "data"
        / "reports"
        / "nifty_index_continuity"
)

TABLE_NAME = "nifty_index"

START_DATE = "2021-01-01"
END_DATE = "2024-12-31"

TIMEZONE = "Asia/Kolkata"

SESSION_START = "09:15"
EXPECTED_SESSION_MINUTES = 375

GAP_BUCKETS = {
    "gap_2_to_5_min": (2, 5),
    "gap_6_to_15_min": (6, 15),
    "gap_over_15_min": (16, 10**9),
}


# ============================================================
# HELPERS
# ============================================================

def stop(message):
    print("\nERROR:", message)
    sys.exit(1)


def write_csv(df, filename):
    path = OUTPUT_DIR / filename
    df.to_csv(path, index=False)
    print(f"Generated: {path}")


def parse_timestamp_column(series):
    """
    Convert timestamps to timezone-aware IST.

    Handles timestamps stored as strings with offsets,
    such as 2021-05-07 09:15:00+05:30.
    """
    parsed = pd.to_datetime(
        series,
        errors="coerce",
        utc=True
    )

    return parsed.dt.tz_convert(TIMEZONE)


def get_expected_session(day):
    start = pd.Timestamp(
        f"{day} {SESSION_START}",
        tz=TIMEZONE
    )

    return pd.date_range(
        start=start,
        periods=EXPECTED_SESSION_MINUTES,
        freq="min"
    )


# ============================================================
# LOAD DATA
# ============================================================

def load_data():

    if not DB_PATH.exists():
        stop(f"DuckDB database not found: {DB_PATH}")

    print("=" * 75)
    print("NIFTY INDEX MINUTE CONTINUITY AUDIT")
    print("=" * 75)

    print(f"Database : {DB_PATH}")
    print(f"Table    : {TABLE_NAME}")
    print(f"Period   : {START_DATE} to {END_DATE}")
    print(f"Timezone : {TIMEZONE}")
    print(
        f"Session  : {SESSION_START} to 15:29 "
        f"({EXPECTED_SESSION_MINUTES} minutes)"
    )

    con = duckdb.connect(
        str(DB_PATH),
        read_only=True
    )

    try:

        # ----------------------------------------------------
        # Inspect table schema
        # ----------------------------------------------------

        schema = con.execute(
            f"DESCRIBE SELECT * FROM {TABLE_NAME}"
        ).fetchdf()

        available_columns = {
            str(column).lower()
            for column in schema["column_name"]
        }

        required_columns = {
            "timestamp",
            "trading_day",
            "open",
            "high",
            "low",
            "close",
            "volume"
        }

        missing_columns = (
                required_columns - available_columns
        )

        if missing_columns:
            stop(
                "Missing required columns: "
                + str(missing_columns)
            )

        if "symbol" in available_columns:
            symbol_expression = (
                "CAST(symbol AS VARCHAR) AS symbol"
            )
        else:
            symbol_expression = "'NIFTY' AS symbol"

        # ----------------------------------------------------
        # IMPORTANT FIX:
        #
        # trading_day may be VARCHAR in DuckDB.
        # Convert it explicitly to DATE before filtering.
        #
        # TRY_CAST prevents invalid strings from causing
        # a conversion exception.
        # ----------------------------------------------------

        query = f"""
            SELECT
                CAST(timestamp AS VARCHAR) AS timestamp_text,

                TRY_CAST(trading_day AS DATE)
                    AS trading_day_date,

                {symbol_expression},

                TRY_CAST(open AS DOUBLE) AS open,
                TRY_CAST(high AS DOUBLE) AS high,
                TRY_CAST(low AS DOUBLE) AS low,
                TRY_CAST(close AS DOUBLE) AS close,
                TRY_CAST(volume AS DOUBLE) AS volume

            FROM {TABLE_NAME}

            WHERE TRY_CAST(trading_day AS DATE)
                BETWEEN DATE '{START_DATE}'
                AND DATE '{END_DATE}'

            ORDER BY trading_day_date, timestamp
        """

        print("\nExecuting DuckDB query...")

        df = con.execute(query).fetchdf()

    except Exception as exc:
        stop(
            "Unable to load NIFTY index data.\n"
            f"DuckDB error: {exc}"
        )

    finally:
        con.close()

    if df.empty:
        stop(
            "No NIFTY index records found for "
            f"{START_DATE} to {END_DATE}."
        )

    # --------------------------------------------------------
    # Parse timestamps
    # --------------------------------------------------------

    print("Converting timestamps to IST...")

    df["timestamp"] = parse_timestamp_column(
        df["timestamp_text"]
    )

    df["trading_day"] = pd.to_datetime(
        df["trading_day_date"],
        errors="coerce"
    ).dt.date

    df.drop(
        columns=[
            "timestamp_text",
            "trading_day_date"
        ],
        inplace=True
    )

    invalid_timestamp = df["timestamp"].isna()
    invalid_trading_day = df["trading_day"].isna()

    if invalid_timestamp.any():
        print(
            "WARNING: Invalid timestamps:",
            int(invalid_timestamp.sum())
        )

    if invalid_trading_day.any():
        print(
            "WARNING: Invalid trading dates:",
            int(invalid_trading_day.sum())
        )

    df = df.loc[
        ~(invalid_timestamp | invalid_trading_day)
    ].copy()

    if df.empty:
        stop("No valid timestamp/trading-day records remain.")

    # --------------------------------------------------------
    # Numeric conversion
    # --------------------------------------------------------

    for col in [
        "open",
        "high",
        "low",
        "close",
        "volume"
    ]:
        df[col] = pd.to_numeric(
            df[col],
            errors="coerce"
        )

    # --------------------------------------------------------
    # Sort data
    # --------------------------------------------------------

    df.sort_values(
        ["symbol", "trading_day", "timestamp"],
        inplace=True
    )

    df.reset_index(drop=True, inplace=True)

    print("\nDATA LOADED")
    print("-" * 60)
    print(f"Rows       : {len(df):,}")
    print(f"Trading days: {df['trading_day'].nunique():,}")
    print(f"Symbols    : {df['symbol'].nunique():,}")

    print("\nSymbol distribution:")
    print(df["symbol"].value_counts().to_string())

    return df


# ============================================================
# OHLC / VOLUME INTEGRITY
# ============================================================

def audit_ohlc(df):

    ohlc = [
        "open",
        "high",
        "low",
        "close"
    ]

    null_ohlc = df[ohlc].isna().any(axis=1)

    null_volume = df["volume"].isna()

    nonpositive_prices = (
        (df[ohlc] <= 0).any(axis=1)
    )

    invalid_high_low = (
            df["high"] < df["low"]
    )

    high_below_body = (
            df["high"]
            < df[["open", "close"]].max(axis=1)
    )

    low_above_body = (
            df["low"]
            > df[["open", "close"]].min(axis=1)
    )

    negative_volume = df["volume"] < 0

    zero_volume = df["volume"] == 0

    bad = (
            null_ohlc
            | null_volume
            | nonpositive_prices
            | invalid_high_low
            | high_below_body
            | low_above_body
            | negative_volume
    )

    bad_rows = df.loc[bad].copy()

    checks = {
        "null_ohlc_rows": int(null_ohlc.sum()),

        "null_volume_rows": int(
            null_volume.sum()
        ),

        "nonpositive_price_rows": int(
            nonpositive_prices.sum()
        ),

        "high_below_low_rows": int(
            invalid_high_low.sum()
        ),

        "high_below_open_or_close_rows": int(
            high_below_body.sum()
        ),

        "low_above_open_or_close_rows": int(
            low_above_body.sum()
        ),

        "negative_volume_rows": int(
            negative_volume.sum()
        ),

        "zero_volume_rows": int(
            zero_volume.sum()
        ),

        "total_invalid_ohlc_volume_rows": int(
            bad.sum()
        )
    }

    return checks, bad_rows


# ============================================================
# DUPLICATE AND TRADING-DATE AUDIT
# ============================================================

def audit_duplicates_and_dates(df):

    duplicate_mask = df.duplicated(
        subset=[
            "symbol",
            "timestamp"
        ],
        keep=False
    )

    duplicate_rows = df.loc[
        duplicate_mask
    ].copy()

    timestamp_date = df["timestamp"].dt.date

    date_mismatch = (
            timestamp_date != df["trading_day"]
    )

    duplicate_groups = (
        df.loc[duplicate_mask]
        .groupby(
            ["symbol", "timestamp"]
        )
        .ngroups
    )

    result = {
        "duplicate_timestamp_rows": int(
            duplicate_mask.sum()
        ),

        "duplicate_timestamp_groups": int(
            duplicate_groups
        ),

        "timestamp_trading_day_mismatch_rows": int(
            date_mismatch.sum()
        )
    }

    return (
        result,
        duplicate_rows,
        df.loc[date_mismatch].copy()
    )


# ============================================================
# DAILY CONTINUITY AUDIT
# ============================================================

def audit_daily_continuity(df):

    daily_rows = []
    missing_rows = []
    unexpected_rows = []

    minute_coverage = np.zeros(
        EXPECTED_SESSION_MINUTES,
        dtype=np.int64
    )

    total_days = 0

    grouped = df.groupby(
        ["symbol", "trading_day"],
        sort=True
    )

    for (symbol, day), group in grouped:

        total_days += 1

        observed = pd.DatetimeIndex(
            group["timestamp"]
            .drop_duplicates()
            .sort_values()
        )

        expected = get_expected_session(day)

        matched = expected.intersection(observed)

        missing = expected.difference(observed)

        unexpected = observed.difference(expected)

        # ----------------------------------------------------
        # Minute-of-session coverage
        # ----------------------------------------------------

        if len(matched) > 0:

            offsets = (
                    (matched - expected[0])
                    .total_seconds()
                    / 60
            ).astype(int)

            valid_offsets = offsets[
                (offsets >= 0)
                & (offsets < EXPECTED_SESSION_MINUTES)
                ]

            np.add.at(
                minute_coverage,
                valid_offsets,
                1
            )

        # ----------------------------------------------------
        # Gap calculations
        # ----------------------------------------------------

        differences = (
                observed.to_series()
                .diff()
                .dt.total_seconds()
                / 60
        )

        differences = differences.dropna()

        gap_intervals = differences[
            differences > 1
            ]

        missing_clock_minutes = int(
            (gap_intervals - 1)
            .clip(lower=0)
            .sum()
        )

        gap_counts = {}

        for name, (low, high) in GAP_BUCKETS.items():

            gap_counts[name] = int(
                (
                        (differences >= low)
                        & (differences <= high)
                ).sum()
            )

        # ----------------------------------------------------
        # Daily completeness
        # ----------------------------------------------------

        if len(observed) > 0:
            first_ts = observed.min()
            last_ts = observed.max()
        else:
            first_ts = pd.NaT
            last_ts = pd.NaT

        completeness = (
                len(matched)
                / EXPECTED_SESSION_MINUTES
                * 100
        )

        if (
                len(observed) == EXPECTED_SESSION_MINUTES
                and len(missing) == 0
                and len(unexpected) == 0
        ):
            status = "PASS"
        else:
            status = "REVIEW"

        daily_rows.append({

            "symbol": symbol,

            "trading_day": str(day),

            "observed_unique_minutes": len(observed),

            "expected_regular_session_minutes":
                EXPECTED_SESSION_MINUTES,

            "matched_session_minutes": len(matched),

            "missing_session_minutes": len(missing),

            "unexpected_or_out_of_session_minutes":
                len(unexpected),

            "session_completeness_pct":
                round(completeness, 4),

            "first_timestamp_ist": str(first_ts),

            "last_timestamp_ist": str(last_ts),

            "gap_intervals_total": len(gap_intervals),

            "missing_clock_minutes_between_bars":
                missing_clock_minutes,

            **gap_counts,

            "status": status
        })

        # ----------------------------------------------------
        # Save missing timestamps
        # ----------------------------------------------------

        for ts in missing:

            missing_rows.append({

                "symbol": symbol,

                "trading_day": str(day),

                "missing_timestamp_ist": str(ts)

            })

        # ----------------------------------------------------
        # Save unexpected timestamps
        # ----------------------------------------------------

        for ts in unexpected:

            unexpected_rows.append({

                "symbol": symbol,

                "trading_day": str(day),

                "unexpected_timestamp_ist": str(ts)

            })

    # --------------------------------------------------------
    # Build output DataFrames
    # --------------------------------------------------------

    daily_df = pd.DataFrame(daily_rows)

    missing_df = pd.DataFrame(missing_rows)

    unexpected_df = pd.DataFrame(
        unexpected_rows
    )

    coverage_df = pd.DataFrame({

        "minute_from_session_open": np.arange(
            EXPECTED_SESSION_MINUTES
        ),

        "session_time": [
            (
                    pd.Timestamp("2000-01-01 09:15")
                    + pd.Timedelta(minutes=i)
            ).strftime("%H:%M")

            for i in range(
                EXPECTED_SESSION_MINUTES
            )
        ],

        "days_with_observation": minute_coverage,

        "total_trading_days": total_days,

        "coverage_pct": (
            minute_coverage / total_days * 100
            if total_days
            else 0
        )
    })

    return (
        daily_df,
        missing_df,
        unexpected_df,
        coverage_df
    )


# ============================================================
# MAIN
# ============================================================

def main():

    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    # --------------------------------------------------------
    # Load data
    # --------------------------------------------------------

    df = load_data()

    # --------------------------------------------------------
    # OHLC audit
    # --------------------------------------------------------

    print("\nRunning OHLC and volume checks...")

    ohlc_checks, bad_ohlc = audit_ohlc(df)

    # --------------------------------------------------------
    # Duplicate audit
    # --------------------------------------------------------

    print("\nRunning duplicate and trading-date checks...")

    (
        duplicate_checks,
        duplicate_rows,
        date_mismatches
    ) = audit_duplicates_and_dates(df)

    # --------------------------------------------------------
    # Continuity audit
    # --------------------------------------------------------

    print("\nRunning daily minute-continuity checks...")

    (
        daily,
        missing,
        unexpected,
        minute_coverage
    ) = audit_daily_continuity(df)

    # --------------------------------------------------------
    # Save CSV reports
    # --------------------------------------------------------

    print("\nSaving reports...")

    write_csv(
        daily,
        "nifty_index_daily_continuity.csv"
    )

    write_csv(
        missing,
        "nifty_index_missing_minutes.csv"
    )

    write_csv(
        unexpected,
        "nifty_index_unexpected_minutes.csv"
    )

    write_csv(
        minute_coverage,
        "nifty_index_minute_coverage.csv"
    )

    write_csv(
        bad_ohlc,
        "nifty_index_invalid_ohlc_rows.csv"
    )

    write_csv(
        duplicate_rows,
        "nifty_index_duplicate_timestamp_rows.csv"
    )

    write_csv(
        date_mismatches,
        "nifty_index_trading_day_mismatches.csv"
    )

    # --------------------------------------------------------
    # Build summary
    # --------------------------------------------------------

    summary = {

        "dataset": "NIFTY index",

        "period": {
            "start": START_DATE,
            "end": END_DATE
        },

        "timezone": TIMEZONE,

        "regular_session": {
            "start": SESSION_START,
            "end": "15:29",
            "expected_minutes": EXPECTED_SESSION_MINUTES
        },

        "total_rows": int(len(df)),

        "total_trading_days": int(
            df["trading_day"].nunique()
        ),

        "symbols": sorted(
            df["symbol"]
            .dropna()
            .unique()
            .tolist()
        ),

        "daily_continuity": {

            "days_audited": int(len(daily)),

            "days_passed": int(
                (daily["status"] == "PASS").sum()
            ),

            "days_requiring_review": int(
                (daily["status"] == "REVIEW").sum()
            ),

            "total_missing_session_minutes": int(
                daily["missing_session_minutes"].sum()
            ),

            "total_unexpected_minutes": int(
                daily[
                    "unexpected_or_out_of_session_minutes"
                ].sum()
            ),

            "total_gap_intervals": int(
                daily["gap_intervals_total"].sum()
            ),

            "total_missing_clock_minutes_between_bars": int(
                daily[
                    "missing_clock_minutes_between_bars"
                ].sum()
            ),

            "average_session_completeness_pct": round(
                float(
                    daily[
                        "session_completeness_pct"
                    ].mean()
                ),
                4
            )
        },

        "ohlc_volume_checks": ohlc_checks,

        "duplicate_and_date_checks": duplicate_checks,

        "interpretation": (
            "A REVIEW day is not automatically corrupt. "
            "It may be a partial session, special session, "
            "holiday-related session or contain missing bars. "
            "Review the daily CSV before excluding any day."
        )
    }

    summary_path = (
            OUTPUT_DIR
            / "nifty_index_continuity_summary.json"
    )

    with open(
            summary_path,
            "w",
            encoding="utf-8"
    ) as f:

        json.dump(
            summary,
            f,
            indent=4,
            default=str
        )

    print(f"\nGenerated: {summary_path}")

    # --------------------------------------------------------
    # Print final summary
    # --------------------------------------------------------

    print("\n" + "=" * 75)
    print("NIFTY INDEX CONTINUITY AUDIT SUMMARY")
    print("=" * 75)

    print(json.dumps(
        summary,
        indent=4,
        default=str
    ))

    print("\n" + "=" * 75)
    print("AUDIT COMPLETE")
    print("=" * 75)

    print(f"Reports directory: {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
