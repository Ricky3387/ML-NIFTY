from pathlib import Path
import json
import sys

import duckdb
import numpy as np
import pandas as pd

# ============================================================
# CONFIGURATION
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DB_PATH = PROJECT_ROOT / "data" / "database" / "nifty_options.duckdb"
OUTPUT_DIR = PROJECT_ROOT / "data" / "reports" / "nifty_index_calendar_validation"
TABLE_NAME = "nifty_index"

# The supplied continuity file starts on 2021-05-24. The source dataset
# is known to contain NIFTY index data from 2021-05-07.
START_DATE = "2021-05-24"
END_DATE = "2024-12-31"
TIMEZONE = "Asia/Kolkata"

# Provisional minute-start convention for ordinary sessions:
# 09:15, 09:16, ... 15:29 = 375 bars.
# Keep this convention until the dataset provider's timestamp semantics
# are independently confirmed.
NORMAL_START = "09:15"
NORMAL_MINUTES = 375

# NSE Capital Market weekday holidays. This list is for the configured
# period. 2023 Bakri Id was revised from June 28 to June 29.
HOLIDAYS = set("""
2021-05-13 2021-07-21 2021-08-19 2021-09-10 2021-10-15
2021-11-05 2021-11-19
2022-01-26 2022-03-01 2022-03-18 2022-04-14 2022-04-15
2022-05-03 2022-08-09 2022-08-15 2022-08-31 2022-10-05
2022-10-26 2022-11-08
2023-01-26 2023-03-07 2023-03-30 2023-04-04 2023-04-07
2023-04-14 2023-05-01 2023-06-29 2023-08-15 2023-09-19
2023-10-02 2023-10-24 2023-11-14 2023-11-27 2023-12-25
2024-01-22 2024-01-26 2024-03-08 2024-03-25 2024-03-29
2024-04-11 2024-04-17 2024-05-01 2024-05-20 2024-06-17
2024-07-17 2024-08-15 2024-10-02 2024-11-15 2024-12-25 2024-11-20
""".split())

# Special sessions, with expected minute-start labels for the NIFTY index.
# Muhurat sessions are identified separately and are NOT compared with the
# normal 375-minute day. Their exact timings can differ by year.
SPECIAL_SESSIONS = {
    "2021-11-04": {
        "kind": "MUHURAT",
        "windows": [],
        "note": "Muhurat session; review its evening timestamps separately",
    },
    "2022-10-24": {
        "kind": "MUHURAT",
        "windows": [],
        "note": "Muhurat session; review its evening timestamps separately",
    },
    "2023-11-12": {
        "kind": "MUHURAT",
        "windows": [],
        "note": "Sunday Muhurat session; review its evening timestamps separately",
    },
    "2024-11-01": {
        "kind": "MUHURAT",
        "windows": [],
        "note": "Muhurat session; review its evening timestamps separately",
    },
    # Jan 20 was a Saturday trading day. The revised session was a regular
    # full trading day. Treat it as exceptional calendar date, not weekend.
    "2024-01-20": {
        "kind": "SPECIAL_FULL_DAY",
        "windows": [
            ("09:15", 375)
        ],
        "note": "Regular full trading session; DR switchover cancelled"
    },
    # Special live sessions with primary/DR windows. These are cash-market
    # index windows, represented as minute-start labels.
    "2024-03-02": {
        "kind": "SPECIAL_SPLIT_SESSION",
        "windows": [("09:15", 45), ("11:30", 60)],
        "note": "Primary-site and DR-site split session",
    },
    "2024-05-18": {
        "kind": "SPECIAL_SPLIT_SESSION",
        "windows": [("09:15", 45), ("11:30", 60)],
        "note": "Primary-site and DR-site split session",
        "note": "Primary-site and DR-site split session",
    },
}

GAP_BUCKETS = {
    "gap_2_to_5_min": (2, 5),
    "gap_6_to_15_min": (6, 15),
    "gap_over_15_min": (16, 10**9),
}


# ============================================================
# HELPERS
# ============================================================

def stop(message):
    print("\nERROR:", message)
    sys.exit(1)


def write_csv(df, filename):
    path = OUTPUT_DIR / filename
    df.to_csv(path, index=False)
    print(f"Generated: {path}")


def parse_timestamp_column(series):
    parsed = pd.to_datetime(series, errors="coerce", utc=True)
    return parsed.dt.tz_convert(TIMEZONE)


def expected_window(day, start, minutes):
    first = pd.Timestamp(f"{day} {start}", tz=TIMEZONE)
    return pd.date_range(first, periods=minutes, freq="min")


def expected_for_special(day):
    pieces = []
    for start, minutes in SPECIAL_SESSIONS[day]["windows"]:
        pieces.append(expected_window(day, start, minutes))
    if not pieces:
        return pd.DatetimeIndex([], tz=TIMEZONE)
    result = pieces[0]
    for piece in pieces[1:]:
        result = result.union(piece)
    return result.sort_values()


def date_class(day):
    day = str(day)
    if day in SPECIAL_SESSIONS:
        return SPECIAL_SESSIONS[day]["kind"]
    if day in HOLIDAYS:
        return "EXCHANGE_HOLIDAY"
    if pd.Timestamp(day).weekday() >= 5:
        return "WEEKEND_NON_TRADING_DAY"
    return "NORMAL_TRADING_DAY"


# ============================================================
# LOAD DATA
# ============================================================

def load_data():
    if not DB_PATH.exists():
        stop(f"DuckDB database not found: {DB_PATH}")

    con = duckdb.connect(str(DB_PATH), read_only=True)
    try:
        schema = con.execute(
            f"DESCRIBE SELECT * FROM {TABLE_NAME}"
        ).fetchdf()
        available = {str(x).lower() for x in schema["column_name"]}

        required = {
            "timestamp", "trading_day", "open", "high",
            "low", "close", "volume",
        }
        missing = required - available
        if missing:
            stop(f"Missing required columns: {missing}")

        symbol_expr = (
            "CAST(symbol AS VARCHAR) AS symbol"
            if "symbol" in available else "'NIFTY' AS symbol"
        )

        query = f"""
            SELECT
                CAST(timestamp AS VARCHAR) AS timestamp_text,
                TRY_CAST(trading_day AS DATE) AS trading_day_date,
                {symbol_expr},
                TRY_CAST(open AS DOUBLE) AS open,
                TRY_CAST(high AS DOUBLE) AS high,
                TRY_CAST(low AS DOUBLE) AS low,
                TRY_CAST(close AS DOUBLE) AS close,
                TRY_CAST(volume AS DOUBLE) AS volume
            FROM {TABLE_NAME}
            WHERE TRY_CAST(trading_day AS DATE)
                BETWEEN DATE '{START_DATE}' AND DATE '{END_DATE}'
            ORDER BY trading_day_date, timestamp
        """
        df = con.execute(query).fetchdf()
    except Exception as exc:
        stop(f"Unable to load {TABLE_NAME}: {exc}")
    finally:
        con.close()

    if df.empty:
        stop(f"No rows found from {START_DATE} to {END_DATE}")

    df["timestamp"] = parse_timestamp_column(df["timestamp_text"])
    df["trading_day"] = pd.to_datetime(
        df["trading_day_date"], errors="coerce"
    ).dt.date
    df.drop(columns=["timestamp_text", "trading_day_date"], inplace=True)

    invalid = df["timestamp"].isna() | pd.isna(df["trading_day"])
    print("Invalid timestamp/date rows removed:", int(invalid.sum()))
    df = df.loc[~invalid].copy()

    for col in ["open", "high", "low", "close", "volume"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    df.sort_values(["symbol", "trading_day", "timestamp"], inplace=True)
    df.reset_index(drop=True, inplace=True)
    print(f"Loaded rows: {len(df):,}")
    print("Observed dates:", df["trading_day"].nunique())
    print("Symbols:", df["symbol"].dropna().unique().tolist())
    return df


# ============================================================
# DATA INTEGRITY CHECKS
# ============================================================

def audit_ohlc(df):
    ohlc = ["open", "high", "low", "close"]
    null_ohlc = df[ohlc].isna().any(axis=1)
    null_volume = df["volume"].isna()
    nonpositive = (df[ohlc] <= 0).any(axis=1)
    high_low = df["high"] < df["low"]
    high_body = df["high"] < df[["open", "close"]].max(axis=1)
    low_body = df["low"] > df[["open", "close"]].min(axis=1)
    negative_volume = df["volume"] < 0
    zero_volume = df["volume"] == 0

    bad = (
        null_ohlc | null_volume | nonpositive | high_low |
        high_body | low_body | negative_volume
    )
    checks = {
        "null_ohlc_rows": int(null_ohlc.sum()),
        "null_volume_rows": int(null_volume.sum()),
        "nonpositive_price_rows": int(nonpositive.sum()),
        "high_below_low_rows": int(high_low.sum()),
        "high_below_open_or_close_rows": int(high_body.sum()),
        "low_above_open_or_close_rows": int(low_body.sum()),
        "negative_volume_rows": int(negative_volume.sum()),
        "zero_volume_rows": int(zero_volume.sum()),
        "total_invalid_ohlc_volume_rows": int(bad.sum()),
        "note": "Zero index volume is not evidence of traded participation; do not use as volume features without source verification.",
    }
    return checks, df.loc[bad].copy()


def audit_duplicates_and_dates(df):
    duplicate = df.duplicated(["symbol", "timestamp"], keep=False)
    date_mismatch = df["timestamp"].dt.date != df["trading_day"]
    duplicate_groups = (
        df.loc[duplicate].groupby(["symbol", "timestamp"]).ngroups
    )
    checks = {
        "duplicate_timestamp_rows": int(duplicate.sum()),
        "duplicate_timestamp_groups": int(duplicate_groups),
        "timestamp_trading_day_mismatch_rows": int(date_mismatch.sum()),
    }
    return checks, df.loc[duplicate].copy(), df.loc[date_mismatch].copy()


# ============================================================
# CALENDAR-AWARE CONTINUITY
# ============================================================

def gap_metrics(observed):
    differences = (
        observed.to_series().diff().dt.total_seconds() / 60
    ).dropna()
    gaps = differences[differences > 1]
    result = {
        "gap_intervals_total": int(len(gaps)),
        "missing_clock_minutes_between_bars": int((gaps - 1).sum()),
    }
    for name, (low, high) in GAP_BUCKETS.items():
        result[name] = int(((differences >= low) & (differences <= high)).sum())
    return result


def audit_calendar_continuity(df):
    daily_rows, missing_rows, unexpected_rows, anomaly_rows = [], [], [], []
    coverage = np.zeros(NORMAL_MINUTES, dtype=np.int64)

    symbols = sorted(df["symbol"].dropna().unique().tolist())
    grouped = {
        (symbol, day): group
        for (symbol, day), group in df.groupby(["symbol", "trading_day"], sort=True)
    }

    calendar_days = pd.date_range(START_DATE, END_DATE, freq="D")
    expected_normal_dates = [
        d.strftime("%Y-%m-%d")
        for d in calendar_days
        if d.weekday() < 5
        and d.strftime("%Y-%m-%d") not in HOLIDAYS
        and d.strftime("%Y-%m-%d") not in SPECIAL_SESSIONS
    ]

    # Normal weekday sessions, including dates with no rows at all.
    for symbol in symbols:
        for day_text in expected_normal_dates:
            day = pd.Timestamp(day_text).date()
            group = grouped.get((symbol, day))
            expected = expected_window(day_text, NORMAL_START, NORMAL_MINUTES)

            if group is None:
                daily_rows.append({
                    "symbol": symbol,
                    "trading_day": day_text,
                    "calendar_status": "NORMAL_TRADING_DAY",
                    "observed_unique_minutes": 0,
                    "expected_session_minutes": NORMAL_MINUTES,
                    "matched_session_minutes": 0,
                    "missing_session_minutes": NORMAL_MINUTES,
                    "out_of_session_minutes": 0,
                    "session_completeness_pct": 0.0,
                    "first_timestamp_ist": "",
                    "last_timestamp_ist": "",
                    **gap_metrics(pd.DatetimeIndex([], tz=TIMEZONE)),
                    "status": "MISSING_EXPECTED_TRADING_DAY",
                })
                anomaly_rows.append({
                    "symbol": symbol,
                    "trading_day": day_text,
                    "anomaly": "NO_ROWS_ON_EXPECTED_TRADING_DAY",
                })
                continue

            observed = pd.DatetimeIndex(
                group["timestamp"].drop_duplicates().sort_values()
            )
            matched = expected.intersection(observed)
            missing = expected.difference(observed)
            extra = observed.difference(expected)

            offsets = (
                (matched - expected[0]).total_seconds() / 60
            ).astype(int)
            if len(offsets):
                np.add.at(coverage, offsets, 1)

            metrics = gap_metrics(matched)
            completeness = len(matched) / NORMAL_MINUTES * 100

            if len(missing) == 0 and len(extra) == 0:
                status = "PASS"
            elif len(missing) == 0:
                status = "COMPLETE_SESSION_WITH_EXTRA_TIMESTAMPS"
            else:
                status = "MISSING_INTRADAY_BARS"

            daily_rows.append({
                "symbol": symbol,
                "trading_day": day_text,
                "calendar_status": "NORMAL_TRADING_DAY",
                "observed_unique_minutes": len(observed),
                "expected_session_minutes": NORMAL_MINUTES,
                "matched_session_minutes": len(matched),
                "missing_session_minutes": len(missing),
                "out_of_session_minutes": len(extra),
                "session_completeness_pct": round(completeness, 4),
                "first_timestamp_ist": str(observed.min()),
                "last_timestamp_ist": str(observed.max()),
                **metrics,
                "status": status,
            })

            for ts in missing:
                missing_rows.append({
                    "symbol": symbol,
                    "trading_day": day_text,
                    "missing_timestamp_ist": str(ts),
                })
            for ts in extra:
                unexpected_rows.append({
                    "symbol": symbol,
                    "trading_day": day_text,
                    "timestamp_ist": str(ts),
                    "reason": "OUTSIDE_NORMAL_SESSION",
                })

    # Observed weekends, exchange holidays and special sessions.
    for (symbol, day), group in grouped.items():
        day_text = str(day)
        kind = date_class(day_text)
        if kind == "NORMAL_TRADING_DAY":
            continue

        observed = pd.DatetimeIndex(
            group["timestamp"].drop_duplicates().sort_values()
        )

        if kind in {"SPECIAL_FULL_DAY", "SPECIAL_SPLIT_SESSION"}:
            expected = expected_for_special(day_text)
            matched = expected.intersection(observed)
            missing = expected.difference(observed)
            extra = observed.difference(expected)
            completeness = (
                len(matched) / len(expected) * 100 if len(expected) else np.nan
            )
            status = (
                "SPECIAL_SESSION_MATCHED"
                if len(expected) and len(missing) == 0
                else "SPECIAL_SESSION_REVIEW"
            )
            for ts in missing:
                missing_rows.append({
                    "symbol": symbol,
                    "trading_day": day_text,
                    "missing_timestamp_ist": str(ts),
                })
            for ts in extra:
                unexpected_rows.append({
                    "symbol": symbol,
                    "trading_day": day_text,
                    "timestamp_ist": str(ts),
                    "reason": "OUTSIDE_CONFIGURED_SPECIAL_SESSION_WINDOWS",
                })
            metrics = gap_metrics(matched)
            daily_rows.append({
                "symbol": symbol,
                "trading_day": day_text,
                "calendar_status": kind,
                "observed_unique_minutes": len(observed),
                "expected_session_minutes": len(expected),
                "matched_session_minutes": len(matched),
                "missing_session_minutes": len(missing),
                "out_of_session_minutes": len(extra),
                "session_completeness_pct": (
                    round(completeness, 4) if pd.notna(completeness) else np.nan
                ),
                "first_timestamp_ist": str(observed.min()),
                "last_timestamp_ist": str(observed.max()),
                **metrics,
                "status": status,
            })
        elif kind == "MUHURAT":
            # Exact session windows are intentionally not assumed here.
            # These rows are classified and preserved for a separate audit.
            daily_rows.append({
                "symbol": symbol,
                "trading_day": day_text,
                "calendar_status": kind,
                "observed_unique_minutes": len(observed),
                "expected_session_minutes": np.nan,
                "matched_session_minutes": np.nan,
                "missing_session_minutes": np.nan,
                "out_of_session_minutes": np.nan,
                "session_completeness_pct": np.nan,
                "first_timestamp_ist": str(observed.min()),
                "last_timestamp_ist": str(observed.max()),
                **gap_metrics(observed),
                "status": "MUHURAT_SESSION_SEPARATE_REVIEW",
            })
            for ts in observed:
                unexpected_rows.append({
                    "symbol": symbol,
                    "trading_day": day_text,
                    "timestamp_ist": str(ts),
                    "reason": "MUHURAT_SESSION_NOT_COMPARED_TO_NORMAL_SESSION",
                })
        else:
            # Any rows on an ordinary weekend or exchange holiday are surfaced.
            daily_rows.append({
                "symbol": symbol,
                "trading_day": day_text,
                "calendar_status": kind,
                "observed_unique_minutes": len(observed),
                "expected_session_minutes": 0,
                "matched_session_minutes": 0,
                "missing_session_minutes": 0,
                "out_of_session_minutes": len(observed),
                "session_completeness_pct": np.nan,
                "first_timestamp_ist": str(observed.min()),
                "last_timestamp_ist": str(observed.max()),
                **gap_metrics(observed),
                "status": "OBSERVED_ON_NON_TRADING_DATE",
            })
            for ts in observed:
                unexpected_rows.append({
                    "symbol": symbol,
                    "trading_day": day_text,
                    "timestamp_ist": str(ts),
                    "reason": kind,
                })

        anomaly_rows.append({
            "symbol": symbol,
            "trading_day": day_text,
            "anomaly": kind,
        })

    daily = pd.DataFrame(daily_rows)
    missing_df = pd.DataFrame(missing_rows)
    unexpected_df = pd.DataFrame(unexpected_rows)
    anomalies = pd.DataFrame(anomaly_rows)

    coverage_df = pd.DataFrame({
        "minute_from_session_open": np.arange(NORMAL_MINUTES),
        "session_time": [
            (pd.Timestamp("2000-01-01 09:15") + pd.Timedelta(minutes=i)).strftime("%H:%M")
            for i in range(NORMAL_MINUTES)
        ],
        "days_with_observation": coverage,
        "normal_expected_trading_days_per_symbol": len(expected_normal_dates),
        "coverage_pct": (
            coverage / len(expected_normal_dates) * 100
            if expected_normal_dates else 0
        ),
    })

    missing_date_rows = daily[
        daily["status"] == "MISSING_EXPECTED_TRADING_DAY"
    ][["symbol", "trading_day"]].rename(
        columns={"trading_day": "missing_expected_trading_day"}
    )

    return daily, missing_df, unexpected_df, coverage_df, anomalies, missing_date_rows


# ============================================================
# MAIN
# ============================================================

def main():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    df = load_data()

    print("\nRunning OHLC checks...")
    ohlc_checks, bad_ohlc = audit_ohlc(df)

    print("\nRunning duplicate/date checks...")
    duplicate_checks, duplicate_rows, date_mismatches = audit_duplicates_and_dates(df)

    print("\nRunning calendar-aware continuity checks...")
    daily, missing, unexpected, coverage, anomalies, missing_dates = (
        audit_calendar_continuity(df)
    )

    write_csv(daily, "nifty_index_daily_calendar_continuity.csv")
    write_csv(missing, "nifty_index_missing_minutes.csv")
    write_csv(unexpected, "nifty_index_unexpected_timestamps.csv")
    write_csv(coverage, "nifty_index_minute_coverage.csv")
    write_csv(anomalies, "nifty_index_calendar_anomalies.csv")
    write_csv(missing_dates, "nifty_index_missing_expected_trading_dates.csv")
    write_csv(bad_ohlc, "nifty_index_invalid_ohlc_rows.csv")
    write_csv(duplicate_rows, "nifty_index_duplicate_timestamp_rows.csv")
    write_csv(date_mismatches, "nifty_index_trading_day_mismatches.csv")

    normal = daily[daily["calendar_status"] == "NORMAL_TRADING_DAY"]
    special = daily[daily["calendar_status"].isin(
        ["SPECIAL_FULL_DAY", "SPECIAL_SPLIT_SESSION", "MUHURAT"]
    )]
    nontrading_observed = daily[daily["calendar_status"].isin(
        ["WEEKEND_NON_TRADING_DAY", "EXCHANGE_HOLIDAY"]
    )]

    summary = {
        "dataset": "NIFTY index",
        "period": {"start": START_DATE, "end": END_DATE},
        "timezone": TIMEZONE,
        "normal_session_assumption": {
            "timestamp_convention": "minute_start_provisional",
            "start": NORMAL_START,
            "end": "15:29",
            "expected_minutes": NORMAL_MINUTES,
            "confirm_against_source_timestamp_definition": True,
        },
        "calendar": {
            "holiday_count_in_configured_range": len(HOLIDAYS),
            "special_session_dates": SPECIAL_SESSIONS,
            "2023_bakri_id_revision": "Holiday moved from 2023-06-28 to 2023-06-29",
        },
        "total_rows": int(len(df)),
        "observed_dates": int(df["trading_day"].nunique()),
        "symbols": sorted(df["symbol"].dropna().unique().tolist()),
        "normal_session_validation": {
            "symbol_day_records": int(len(normal)),
            "missing_expected_trading_day_records": int(
                (normal["status"] == "MISSING_EXPECTED_TRADING_DAY").sum()
            ),
            "days_with_intraday_gaps": int(
                (normal["status"] == "MISSING_INTRADAY_BARS").sum()
            ),
            "complete_days_with_extra_timestamps": int(
                (normal["status"] == "COMPLETE_SESSION_WITH_EXTRA_TIMESTAMPS").sum()
            ),
            "total_missing_regular_minutes": int(
                pd.to_numeric(normal["missing_session_minutes"], errors="coerce").fillna(0).sum()
            ),
            "total_extra_normal_day_timestamps": int(
                pd.to_numeric(normal["out_of_session_minutes"], errors="coerce").fillna(0).sum()
            ),
            "average_session_completeness_pct": round(
                float(pd.to_numeric(
                    normal["session_completeness_pct"], errors="coerce"
                ).mean()), 4
            ) if len(normal) else 0.0,
        },
        "special_sessions": {
            "observed_special_day_records": int(len(special)),
            "observed_weekend_or_holiday_records": int(len(nontrading_observed)),
        },
        "ohlc_volume_checks": ohlc_checks,
        "duplicate_and_date_checks": duplicate_checks,
        "interpretation": (
            "Weekends and exchange holidays are not expected normal sessions. "
            "Special full-day/split sessions use separately configured windows. "
            "Muhurat sessions are classified separately and are not compared "
            "with the normal 375-minute session. Out-of-session timestamps are "
            "reported, never silently deleted. The 09:15-15:29 minute-start "
            "convention remains provisional pending source confirmation."
        ),
    }

    summary_path = OUTPUT_DIR / "nifty_index_calendar_validation_summary.json"
    with open(summary_path, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=4, default=str)

    print(f"\nGenerated: {summary_path}")
    print("\n" + "=" * 75)
    print("NIFTY INDEX CALENDAR VALIDATION SUMMARY")
    print("=" * 75)
    print(json.dumps(summary, indent=4, default=str))
    print("\nAUDIT COMPLETE")
    print("Reports directory:", OUTPUT_DIR)


if __name__ == "__main__":
    main()
