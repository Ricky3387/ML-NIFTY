
from pathlib import Path
from collections import defaultdict
import pyarrow.parquet as pq
import csv

ROOT = Path("data/raw/india-index-options-1m")
REPORT_DIR = Path("data/reports")

REPORT_DIR.mkdir(parents=True, exist_ok=True)

files = sorted(ROOT.rglob("*.parquet"))

if not files:
    raise SystemExit(
        f"No Parquet files found in {ROOT.resolve()}. "
        "Run the download script first."
    )

schema_inventory = defaultdict(list)
report_rows = []

print(f"\nFound {len(files)} Parquet files\n")

for index, path in enumerate(files, start=1):
    parquet = pq.ParquetFile(path)
    schema = parquet.schema_arrow

    relative_path = str(path.relative_to(ROOT))
    columns = schema.names
    row_count = parquet.metadata.num_rows
    row_groups = parquet.num_row_groups

    print("=" * 80)
    print(f"[{index}/{len(files)}] {relative_path}")
    print(f"Rows: {row_count:,}")
    print(f"Row groups: {row_groups}")

    for field in schema:
        schema_inventory[field.name].append(str(field.type))
        print(f"  {field.name}: {field.type}")

    # Read only a maximum of five sample rows
    sample_text = ""
    if row_groups:
        sample = parquet.read_row_group(0).slice(0, 5)
        sample_text = str(sample.to_pydict())

    print("\nSample:")
    print(sample_text[:2000])

    report_rows.append({
        "file": relative_path,
        "rows": row_count,
        "row_groups": row_groups,
        "columns": ",".join(columns),
        "sample": sample_text[:2000],
    })

# Write per-file inventory
with open(REPORT_DIR / "file_inventory.csv", "w",
          newline="", encoding="utf-8") as output:
    writer = csv.DictWriter(
        output,
        fieldnames=["file", "rows", "row_groups", "columns", "sample"]
    )
    writer.writeheader()
    writer.writerows(report_rows)

# Write a consolidated schema report
with open(REPORT_DIR / "schema_inventory.txt",
          "w", encoding="utf-8") as output:
    output.write("CONSOLIDATED DATASET SCHEMA\n")
    output.write("=" * 80 + "\n")

    for column, types in sorted(schema_inventory.items()):
        output.write(
            f"{column}: {', '.join(sorted(set(types)))}\n"
        )

print("\n" + "=" * 80)
print("PROFILING COMPLETED")
print(f"Files inspected: {len(files)}")
print(f"Reports saved in: {REPORT_DIR.resolve()}")
print("  - file_inventory.csv")
print("  - schema_inventory.txt")
