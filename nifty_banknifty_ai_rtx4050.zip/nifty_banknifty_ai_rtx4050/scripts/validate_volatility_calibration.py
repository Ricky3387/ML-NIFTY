
from pathlib import Path
import duckdb
import pandas as pd
import math

ROOT = Path(__file__).resolve().parents[1]

INPUT_DIR = ROOT / "data" / "training" / "index_features"
OUTPUT_DIR = ROOT / "data" / "training" / "volatility_calibration"

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

DATABASE = ROOT / "data" / "database" / "nifty_options.duckdb"

INDEX_FILES = {
    "NIFTY": INPUT_DIR / "nifty_index_features.parquet",
    "BANKNIFTY": INPUT_DIR / "banknifty_index_features.parquet",
}

HORIZONS = [5, 15, 30]
VOLATILITY_WINDOWS = [5, 15, 30, 60]

con = duckdb.connect(str(DATABASE))
con.execute("SET TimeZone = 'Asia/Calcutta'")
con.execute("SET memory_limit = '4GB'")
con.execute("SET threads = 4")


def path_sql(path):
    return str(path.resolve()).replace("\\", "/").replace("'", "''")


def analyze_index(index_name, parquet_path):
    print("\n" + "=" * 90)
    print(f"VOLATILITY CALIBRATION: {index_name}")
    print("=" * 90)

    view = f"{index_name.lower()}_calibration"

    con.execute(f"""
        CREATE OR REPLACE VIEW {view} AS
        SELECT *
        FROM read_parquet('{path_sql(parquet_path)}')
    """)

    overall_rows = []
    yearly_rows = []
    volatility_rows = []

    for horizon in HORIZONS:
        return_col = f"future_return_{horizon}m"
        valid_col = f"label_valid_{horizon}m"

        for window in VOLATILITY_WINDOWS:
            vol_col = f"volatility_{window}m"

            # Assumption under test:
            # volatility_*m is a standard deviation of 1-minute
            # returns over the trailing window.
            #
            # Therefore estimated horizon sigma =
            # trailing 1-minute sigma * sqrt(future horizon).

            scale = math.sqrt(horizon)

            temp_view = f"{view}_{horizon}_{window}"

            con.execute(f"""
                CREATE OR REPLACE TEMP VIEW {temp_view} AS
                SELECT
                    CAST(trading_day AS DATE) AS trading_day,
                    {return_col} AS future_return,
                    {vol_col} AS past_volatility,

                    {vol_col} * {scale}
                        AS estimated_horizon_sigma,

                    {return_col} /
                        NULLIF({vol_col} * {scale}, 0)
                        AS normalized_return

                FROM {view}

                WHERE eligible_for_index_model IS TRUE
                  AND {valid_col} IS TRUE
                  AND {return_col} IS NOT NULL
                  AND {vol_col} > 0
                  AND ISFINITE({vol_col})
                  AND ISFINITE({return_col})
            """)

            overall = con.execute(f"""
                SELECT
                    '{index_name}' AS index_name,
                    {horizon} AS future_horizon_minutes,
                    {window} AS past_volatility_window,

                    COUNT(*) AS observations,

                    AVG(past_volatility) AS avg_past_volatility,
                    quantile_cont(
                        past_volatility, 0.50
                    ) AS median_past_volatility,

                    quantile_cont(
                        past_volatility, 0.10
                    ) AS p10_past_volatility,

                    quantile_cont(
                        past_volatility, 0.90
                    ) AS p90_past_volatility,

                    AVG(estimated_horizon_sigma)
                        AS avg_estimated_horizon_sigma,

                    STDDEV_SAMP(normalized_return)
                        AS normalized_std,

                    AVG(normalized_return)
                        AS normalized_mean,

                    quantile_cont(
                        ABS(normalized_return), 0.50
                    ) AS abs_normalized_p50,

                    quantile_cont(
                        ABS(normalized_return), 0.90
                    ) AS abs_normalized_p90,

                    quantile_cont(
                        ABS(normalized_return), 0.99
                    ) AS abs_normalized_p99,

                    COUNT(*) FILTER (
                        WHERE ABS(normalized_return) <= 0.50
                    ) * 100.0 / COUNT(*)
                        AS within_0_5_sigma_pct,

                    COUNT(*) FILTER (
                        WHERE ABS(normalized_return) <= 1.00
                    ) * 100.0 / COUNT(*)
                        AS within_1_sigma_pct

                FROM {temp_view}
            """).fetchdf()

            overall_rows.append(overall)

            yearly = con.execute(f"""
                SELECT
                    '{index_name}' AS index_name,
                    {horizon} AS future_horizon_minutes,
                    {window} AS past_volatility_window,

                    YEAR(trading_day) AS year,

                    COUNT(*) AS observations,

                    AVG(past_volatility)
                        AS avg_past_volatility,

                    STDDEV_SAMP(normalized_return)
                        AS normalized_std,

                    AVG(normalized_return)
                        AS normalized_mean,

                    quantile_cont(
                        ABS(normalized_return), 0.50
                    ) AS abs_normalized_p50,

                    quantile_cont(
                        ABS(normalized_return), 0.90
                    ) AS abs_normalized_p90

                FROM {temp_view}

                GROUP BY YEAR(trading_day)
                ORDER BY year
            """).fetchdf()

            yearly_rows.append(yearly)

    # --------------------------------------------------------
    # Raw volatility distribution and invalid values
    # --------------------------------------------------------

    for window in VOLATILITY_WINDOWS:
        vol_col = f"volatility_{window}m"

        result = con.execute(f"""
            SELECT
                '{index_name}' AS index_name,
                {window} AS volatility_window,

                COUNT(*) AS total_rows,

                COUNT({vol_col}) AS non_null_rows,

                COUNT(*) FILTER (
                    WHERE {vol_col} IS NULL
                ) AS null_rows,

                COUNT(*) FILTER (
                    WHERE {vol_col} <= 0
                ) AS non_positive_rows,

                COUNT(*) FILTER (
                    WHERE {vol_col} IS NOT NULL
                      AND NOT ISFINITE({vol_col})
                ) AS non_finite_rows,

                quantile_cont(
                    {vol_col}, 0.10
                ) FILTER (
                    WHERE {vol_col} > 0
                      AND ISFINITE({vol_col})
                ) AS p10,

                quantile_cont(
                    {vol_col}, 0.50
                ) FILTER (
                    WHERE {vol_col} > 0
                      AND ISFINITE({vol_col})
                ) AS p50,

                quantile_cont(
                    {vol_col}, 0.90
                ) FILTER (
                    WHERE {vol_col} > 0
                      AND ISFINITE({vol_col})
                ) AS p90

            FROM {view}
        """).fetchdf()

        volatility_rows.append(result)

    overall_df = pd.concat(overall_rows, ignore_index=True)
    yearly_df = pd.concat(yearly_rows, ignore_index=True)
    volatility_df = pd.concat(volatility_rows, ignore_index=True)

    # Express volatility values in percentage units for readability.
    vol_columns = [
        "avg_past_volatility",
        "median_past_volatility",
        "p10_past_volatility",
        "p90_past_volatility",
        "avg_estimated_horizon_sigma",
    ]

    overall_df[vol_columns] *= 100

    yearly_df["avg_past_volatility"] *= 100

    volatility_df[["p10", "p50", "p90"]] *= 100

    files = {
        "overall_calibration": overall_df,
        "yearly_calibration": yearly_df,
        "raw_volatility_quality": volatility_df,
    }

    for suffix, dataframe in files.items():
        output = OUTPUT_DIR / (
            f"{index_name.lower()}_{suffix}.csv"
        )
        dataframe.to_csv(output, index=False)
        print(f"Generated: {output}")

    print("\nOVERALL CALIBRATION")
    print(overall_df.to_string(index=False))

    print("\nYEARLY CALIBRATION")
    print(yearly_df.to_string(index=False))

    print("\nRAW VOLATILITY QUALITY")
    print(volatility_df.to_string(index=False))


try:
    for name, path in INDEX_FILES.items():
        analyze_index(name, path)

    print("\n" + "=" * 90)
    print("VOLATILITY CALIBRATION VALIDATION COMPLETED")
    print("=" * 90)

finally:
    con.close()
