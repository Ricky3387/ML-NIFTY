
from pathlib import Path
import duckdb
import sys

# ============================================================
# CONFIGURATION
# ============================================================

BASE = Path(__file__).resolve().parent.parent

DB = BASE / "data" / "database" / "nifty_options.duckdb"
OUT = BASE / "data" / "reports"

OUT.mkdir(parents=True, exist_ok=True)

DATASETS = [
    "nifty_options",
    "banknifty_options"
]

THREADS = 4

# ============================================================
# HELPERS
# ============================================================

def run_query(con, sql, description, output_file=None):
    print(f"\n{description}")
    print("-" * 75)

    try:
        df = con.execute(sql).fetchdf()
        print(df.to_string(index=False))

        if output_file:
            path = OUT / output_file
            df.to_csv(path, index=False)
            print(f"Saved: {path}")

        return df

    except Exception as exc:
        print(f"ERROR: {exc}")
        raise


# ============================================================
# MAIN
# ============================================================

def main():

    if not DB.exists():
        print(f"Database not found: {DB}")
        sys.exit(1)

    print("Starting market timestamp validation...")
    print("Database:", DB)

    con = duckdb.connect(str(DB), read_only=True)

    try:

        con.execute(f"SET threads = {THREADS}")

        # ----------------------------------------------------
        # 1. TIMEZONE INFORMATION
        # ----------------------------------------------------

        run_query(
            con,
            """
            SELECT
                current_setting('TimeZone') AS session_timezone,
                version() AS duckdb_version
            """,
            "DUCKDB CONFIGURATION"
        )

        # ----------------------------------------------------
        # 2. TIMESTAMP REPRESENTATION
        # ----------------------------------------------------

        for table in DATASETS:

            print("\n" + "=" * 85)
            print(table.upper())
            print("=" * 85)

            run_query(
                con,
                f"""
                SELECT
                    CAST(timestamp AS VARCHAR) AS timestamp_string,
                    strftime(
                        timestamp,
                        '%Y-%m-%d %H:%M:%S %Z'
                    ) AS formatted_timestamp,
                    epoch(
                        CAST(timestamp AS TIMESTAMPTZ)
                    ) AS epoch_seconds,
                    CAST(trading_day AS VARCHAR) AS trading_day
                FROM {table}
                ORDER BY timestamp
                LIMIT 10
                """,
                "TIMESTAMP REPRESENTATION"
            )

            # ------------------------------------------------
            # 3. LOWEST ROW-COUNT TRADING DAYS
            # ------------------------------------------------

            run_query(
                con,
                f"""
                SELECT
                    trading_day,
                    COUNT(*) AS rows,
                    COUNT(DISTINCT strftime(
                        timestamp,
                        '%H:%M:%S'
                    )) AS distinct_minutes,
                    MIN(strftime(
                        timestamp,
                        '%H:%M'
                    )) AS first_time,
                    MAX(strftime(
                        timestamp,
                        '%H:%M'
                    )) AS last_time
                FROM {table}
                GROUP BY trading_day
                ORDER BY rows ASC
                LIMIT 30
                """,
                "LOWEST ROW-COUNT TRADING DAYS",
                f"{table}_lowest_coverage_days.csv"
            )

            # ------------------------------------------------
            # 4. DAILY ROW-COUNT DISTRIBUTION
            # ------------------------------------------------

            run_query(
                con,
                f"""
                WITH daily AS (
                    SELECT
                        trading_day,
                        COUNT(*) AS rows
                    FROM {table}
                    GROUP BY trading_day
                )
                SELECT
                    COUNT(*) AS trading_days,
                    ROUND(AVG(rows), 0) AS average_rows,
                    MIN(rows) AS minimum_rows,
                    MAX(rows) AS maximum_rows,
                    APPROX_QUANTILE(rows, 0.10)
                        AS percentile_10,
                    APPROX_QUANTILE(rows, 0.25)
                        AS percentile_25,
                    APPROX_QUANTILE(rows, 0.50)
                        AS median_rows,
                    APPROX_QUANTILE(rows, 0.75)
                        AS percentile_75,
                    APPROX_QUANTILE(rows, 0.90)
                        AS percentile_90
                FROM daily
                """,
                "DAILY ROW-COUNT STATISTICS",
                f"{table}_daily_statistics.csv"
            )

            # ------------------------------------------------
            # 5. CONTRACT-LEVEL TIME GAPS
            # ------------------------------------------------

            run_query(
                con,
                f"""
                WITH source AS (
                    SELECT
                        trading_day,
                        expiry,
                        strike,
                        option_type,

                        strptime(
                            strftime(timestamp, '%Y-%m-%d %H:%M:%S'),
                            '%Y-%m-%d %H:%M:%S'
                        ) AS ts

                    FROM {table}
                ),

                ordered AS (
                    SELECT
                        trading_day,
                        expiry,
                        strike,
                        option_type,
                        ts,

                        LAG(ts) OVER (
                            PARTITION BY
                                trading_day,
                                expiry,
                                strike,
                                option_type
                            ORDER BY ts
                        ) AS previous_ts

                    FROM source
                ),

                gaps AS (
                    SELECT
                        date_diff(
                            'second',
                            previous_ts,
                            ts
                        ) AS gap_seconds

                    FROM ordered
                    WHERE previous_ts IS NOT NULL
                )

                SELECT
                    COUNT(*) AS intervals,

                    COUNT(*) FILTER (
                        WHERE gap_seconds > 60
                    ) AS gaps_over_1m,

                    COUNT(*) FILTER (
                        WHERE gap_seconds > 120
                    ) AS gaps_over_2m,

                    COUNT(*) FILTER (
                        WHERE gap_seconds > 300
                    ) AS gaps_over_5m,

                    COUNT(*) FILTER (
                        WHERE gap_seconds > 900
                    ) AS gaps_over_15m,

                    MAX(gap_seconds) AS maximum_gap_seconds

                FROM gaps
                """,
                "CONTRACT-LEVEL TIMESTAMP GAPS",
                f"{table}_timestamp_gaps.csv"
            )

            # ------------------------------------------------
            # 6. TRADING DAY VS TIMESTAMP DATE
            # ------------------------------------------------

            run_query(
                con,
                f"""
                SELECT
                    COUNT(*) AS total_rows,

                    COUNT(*) FILTER (
                        WHERE CAST(timestamp AS DATE)
                              = CAST(trading_day AS DATE)
                    ) AS same_date_rows,

                    COUNT(*) FILTER (
                        WHERE CAST(timestamp AS DATE)
                              <> CAST(trading_day AS DATE)
                    ) AS different_date_rows

                FROM {table}
                """,
                "TRADING DATE VALIDATION"
            )

    finally:
        con.close()

    print("\n" + "=" * 85)
    print("MARKET TIMESTAMP VALIDATION COMPLETED")
    print("=" * 85)

    print("\nReports saved in:")
    print(OUT)


if __name__ == "__main__":
    main()
