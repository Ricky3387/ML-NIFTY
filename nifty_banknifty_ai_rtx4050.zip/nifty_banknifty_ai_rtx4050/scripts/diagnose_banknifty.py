
from pathlib import Path
import pandas as pd
import pyarrow.parquet as pq
import csv
import gc
import sys

ROOT = Path(
    sys.argv[1] if len(sys.argv) > 1
    else "data/raw/india-index-options-1m/options/BANKNIFTY"
)

REPORT = Path("data/reports")
REPORT.mkdir(parents=True, exist_ok=True)

KEY = ["timestamp", "symbol", "expiry", "strike", "option_type"]

files = sorted(ROOT.rglob("*.parquet"))

if not files:
    raise SystemExit(f"No Parquet files found: {ROOT.resolve()}")

results = []

for number, path in enumerate(files, 1):
    print(f"\n[{number}/{len(files)}] {path.name}")

    df = None

    try:
        df = pq.read_table(path).to_pandas()
        df["timestamp"] = pd.to_datetime(
            df["timestamp"], errors="coerce"
        )

        if not set(KEY).issubset(df.columns):
            raise ValueError("Required contract key columns missing")

        # 1. Exact duplicate records
        exact_extra = int(df.duplicated(keep="first").sum())

        # 2. Duplicate contract/timestamp records
        key_extra = int(
            df.duplicated(subset=KEY, keep="first").sum()
        )

        duplicate_mask = df.duplicated(
            subset=KEY, keep=False
        )

        duplicate_groups = df.loc[
            duplicate_mask, KEY
        ].drop_duplicates().shape[0]

        # 3. Conflicting records:
        # Same contract/timestamp, different remaining values
        duplicate_records = df.loc[duplicate_mask]

        unique_records = duplicate_records.drop_duplicates()

        conflicting_groups = 0

        if not unique_records.empty:
            group_sizes = unique_records.groupby(
                KEY, dropna=False
            ).size()

            conflicting_groups = int(
                (group_sizes > 1).sum()
            )

        conflicting_extra = max(0, key_extra - exact_extra)

        # 4. Gap analysis within trading day
        required = KEY + ["trading_day"]

        if set(required).issubset(df.columns):

            clean_times = df.dropna(
                subset=required
            ).drop_duplicates(
                subset=KEY,
                keep="first"
            )

            clean_times = clean_times.sort_values(
                ["symbol", "expiry", "strike",
                 "option_type", "trading_day", "timestamp"]
            )

            gaps = clean_times.groupby(
                ["symbol", "expiry", "strike",
                 "option_type", "trading_day"],
                dropna=False
            )["timestamp"].diff()

            gap_2_5 = int(
                ((gaps > pd.Timedelta(minutes=1)) &
                 (gaps <= pd.Timedelta(minutes=5))).sum()
            )

            gap_5_15 = int(
                ((gaps > pd.Timedelta(minutes=5)) &
                 (gaps <= pd.Timedelta(minutes=15))).sum()
            )

            gap_over_15 = int(
                (gaps > pd.Timedelta(minutes=15)).sum()
            )

            total_gaps = gap_2_5 + gap_5_15 + gap_over_15

        else:
            total_gaps = gap_2_5 = gap_5_15 = gap_over_15 = 0

        # 5. Capture invalid OHLC examples
        prices = df[["open", "high", "low", "close"]].apply(
            pd.to_numeric, errors="coerce"
        )

        invalid = (
            prices.isna().any(axis=1) |
            (prices <= 0).any(axis=1) |
            (prices["high"] < prices["low"]) |
            (prices["high"] < prices[["open", "close"]].max(axis=1)) |
            (prices["low"] > prices[["open", "close"]].min(axis=1))
        )

        invalid_count = int(invalid.sum())

        if invalid_count:
            print("Invalid OHLC examples:")
            print(
                df.loc[
                    invalid,
                    KEY + ["open", "high", "low", "close"]
                ].head(5).to_string(index=False)
            )

        result = {
            "file": path.name,
            "rows": len(df),
            "exact_duplicate_excess": exact_extra,
            "duplicate_key_excess": key_extra,
            "duplicate_key_groups": duplicate_groups,
            "conflicting_duplicate_groups": conflicting_groups,
            "conflicting_duplicate_excess": conflicting_extra,
            "gaps_2_to_5_min": gap_2_5,
            "gaps_5_to_15_min": gap_5_15,
            "gaps_over_15_min": gap_over_15,
            "total_same_day_gaps": total_gaps,
            "invalid_ohlc": invalid_count,
        }

        results.append(result)

        print("Exact duplicate excess:", exact_extra)
        print("Duplicate key groups:", duplicate_groups)
        print("Conflicting duplicate groups:", conflicting_groups)
        print("Same-day gaps:", total_gaps)

    except Exception as exc:
        print("ERROR:", exc)

        results.append({
            "file": path.name,
            "error": str(exc)
        })

    finally:
        if df is not None:
            del df
        gc.collect()

# Save detailed report
output = REPORT / "banknifty_diagnostics.csv"

with open(output, "w", newline="", encoding="utf-8") as f:
    fields = list(dict.fromkeys(
        key for row in results for key in row
    ))
    writer = csv.DictWriter(f, fieldnames=fields)
    writer.writeheader()
    writer.writerows(results)

report = pd.DataFrame(results)

print("\n========== OVERALL DIAGNOSTICS ==========")

for column in [
    "rows",
    "exact_duplicate_excess",
    "duplicate_key_excess",
    "duplicate_key_groups",
    "conflicting_duplicate_groups",
    "conflicting_duplicate_excess",
    "gaps_2_to_5_min",
    "gaps_5_to_15_min",
    "gaps_over_15_min",
    "total_same_day_gaps",
    "invalid_ohlc",
]:
    if column in report.columns:
        print(column, ":", report[column].sum())

print("\nSaved:", output.resolve())
