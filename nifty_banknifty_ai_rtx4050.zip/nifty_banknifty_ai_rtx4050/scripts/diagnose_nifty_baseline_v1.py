#!/usr/bin/env python3
"""
NIFTY baseline diagnostics v1.

Save under <project_root>/scripts/
Run:
    python scripts/diagnose_nifty_baseline_v1.py

Reads:
  data/processed/nifty_walkforward_v1/train_{5,15,30}m.parquet
  data/processed/nifty_walkforward_v1/validation_{5,15,30}m.parquet
  models/nifty_baseline_v1/model_{5,15,30}m.txt

Writes:
  reports/nifty_diagnostics_v1/
    label_distribution_by_year.csv
    label_distribution_by_volatility.csv
    prediction_distribution.csv
    class_probability_summary.csv
    feature_class_separation.csv
    feature_correlation.csv
    per_year_metrics.csv
    confusion_matrices.csv
    diagnostics_summary.json

This is diagnostic only. It does not retrain or overwrite v1 models.
"""
from pathlib import Path
import json
import time
import logging
import numpy as np
import pandas as pd
import lightgbm as lgb
from sklearn.metrics import (
    accuracy_score, balanced_accuracy_score, f1_score,
    confusion_matrix, log_loss
)

START = time.time()
HORIZONS = (5, 15, 30)
LABELS = ["DOWN", "SIDEWAYS", "UP"]
LABEL_TO_ID = {x: i for i, x in enumerate(LABELS)}
FEATURES = [
    "ret_1m", "logret_1m", "range_pct", "body_pct",
    "upper_wick_pct", "lower_wick_pct",
    "return_5m", "return_15m", "return_30m", "return_60m",
    "realized_vol_5m", "realized_vol_15m", "realized_vol_30m", "realized_vol_60m",
    "high_low_range_5m", "high_low_range_15m", "high_low_range_30m", "high_low_range_60m",
    "close_vs_ema9_pct", "close_vs_ema21_pct", "close_vs_ema50_pct",
    "rsi_14", "positive_return_count_5m", "negative_return_count_5m"
]

def safe_div(a, b):
    return float(a / b) if b else None

def main():
    script_dir = Path(__file__).resolve().parent
    root = script_dir.parent if script_dir.name.lower() == "scripts" else script_dir
    data_dir = root / "data" / "processed" / "nifty_walkforward_v1"
    model_dir = root / "models" / "nifty_baseline_v1"
    out = root / "reports" / "nifty_diagnostics_v1"
    out.mkdir(parents=True, exist_ok=True)

    logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(message)s")
    log = logging.getLogger("nifty_diagnostics")
    frames = []
    label_year_rows, label_vol_rows, pred_rows = [], [], []
    prob_rows, sep_rows, corr_rows, yearly_rows, cm_rows = [], [], [], [], []
    summary = {
        "status": "DIAGNOSTICS_COMPLETED_REVIEW_REQUIRED",
        "note": "Diagnostics use existing v1 models and datasets; no model is retrained.",
        "horizons": {},
        "limitations": [
            "2024 was used for early stopping in v1; its metrics remain model-selection diagnostics, not untouched test performance.",
            "Feature separation is descriptive and does not establish causal or predictive value.",
            "Volatility buckets are quantiles of the training distribution, applied to validation."
        ]
    }

    for h in HORIZONS:
        log.info("Horizon %sm: loading data and model", h)
        train_path = data_dir / f"train_{h}m.parquet"
        valid_path = data_dir / f"validation_{h}m.parquet"
        model_path = model_dir / f"model_{h}m.txt"
        if not all(p.exists() for p in (train_path, valid_path, model_path)):
            raise FileNotFoundError(f"Missing train/validation/model artifact for horizon {h}m")

        train = pd.read_parquet(train_path, columns=FEATURES + ["label", "timestamp_ist", "trading_day", "target_z", "target_vol_scale"])
        valid = pd.read_parquet(valid_path, columns=FEATURES + ["label", "timestamp_ist", "trading_day", "target_z", "target_vol_scale"])
        train["split"] = "TRAIN"
        valid["split"] = "VALIDATION"
        model = lgb.Booster(model_file=str(model_path))

        # Verify feature order exactly matches the stored booster.
        if model.feature_name() != FEATURES:
            raise RuntimeError(
                f"Feature order mismatch for {h}m. Model={model.feature_name()} expected={FEATURES}"
            )

        for split, df in (("TRAIN", train), ("VALIDATION", valid)):
            vc = df["label"].value_counts(normalize=True)
            for cls in LABELS:
                label_year_rows.append({
                    "horizon_minutes": h, "split": split,
                    "year": "ALL", "class": cls,
                    "samples": int((df["label"] == cls).sum()),
                    "percentage": float(vc.get(cls, 0.0) * 100)
                })
            df["year"] = pd.to_datetime(df["trading_day"]).dt.year
            for (year, cls), n in df.groupby(["year", "label"]).size().items():
                total = int((df["year"] == year).sum())
                label_year_rows.append({
                    "horizon_minutes": h, "split": split,
                    "year": int(year), "class": cls,
                    "samples": int(n), "percentage": float(n / total * 100)
                })

        # Define volatility regimes from training quantiles only.
        train_vol = train["realized_vol_60m"].replace([np.inf, -np.inf], np.nan).dropna()
        q1, q2 = train_vol.quantile([1/3, 2/3]).tolist()
        for split, df in (("TRAIN", train), ("VALIDATION", valid)):
            vol = df["realized_vol_60m"]
            regime = pd.cut(vol, bins=[-np.inf, q1, q2, np.inf],
                            labels=["LOW", "MEDIUM", "HIGH"], include_lowest=True)
            temp = df.assign(volatility_regime=regime)
            for (bucket, cls), n in temp.groupby(["volatility_regime", "label"], observed=False).size().items():
                total = int((temp["volatility_regime"] == bucket).sum())
                label_vol_rows.append({
                    "horizon_minutes": h, "split": split,
                    "volatility_regime": str(bucket), "class": cls,
                    "samples": int(n),
                    "percentage": safe_div(n, total) * 100 if total else 0
                })

        X_train = train[FEATURES].replace([np.inf, -np.inf], np.nan)
        X_valid = valid[FEATURES].replace([np.inf, -np.inf], np.nan)
        if X_train.isna().any().any() or X_valid.isna().any().any():
            raise RuntimeError(f"Missing features detected for {h}m diagnostics")

        y_train = train["label"].map(LABEL_TO_ID).to_numpy()
        y_valid = valid["label"].map(LABEL_TO_ID).to_numpy()
        p_train = model.predict(X_train, num_threads=-1)
        p_valid = model.predict(X_valid, num_threads=-1)
        pred_train, pred_valid = p_train.argmax(axis=1), p_valid.argmax(axis=1)

        for split, y, probs, pred in (
            ("TRAIN", y_train, p_train, pred_train),
            ("VALIDATION", y_valid, p_valid, pred_valid)
        ):
            pred_dist = pd.Series(pred).value_counts(normalize=True)
            for cls_id, cls in enumerate(LABELS):
                class_probs = probs[:, cls_id]
                pred_rows.append({
                    "horizon_minutes": h, "split": split, "class": cls,
                    "predicted_count": int((pred == cls_id).sum()),
                    "predicted_percentage": float(pred_dist.get(cls_id, 0) * 100),
                    "actual_count": int((y == cls_id).sum()),
                    "actual_percentage": float((y == cls_id).mean() * 100),
                    "mean_probability": float(class_probs.mean()),
                    "median_probability": float(np.median(class_probs))
                })
                prob_rows.append({
                    "horizon_minutes": h, "split": split, "class": cls,
                    "prob_mean": float(class_probs.mean()),
                    "prob_std": float(class_probs.std()),
                    "prob_p05": float(np.quantile(class_probs, .05)),
                    "prob_p25": float(np.quantile(class_probs, .25)),
                    "prob_p50": float(np.quantile(class_probs, .50)),
                    "prob_p75": float(np.quantile(class_probs, .75)),
                    "prob_p95": float(np.quantile(class_probs, .95)),
                    "mean_probability_when_actual_class": float(class_probs[y == cls_id].mean()) if (y == cls_id).any() else None,
                    "mean_probability_when_not_actual_class": float(class_probs[y != cls_id].mean()) if (y != cls_id).any() else None
                })

            cm = confusion_matrix(y, pred, labels=[0,1,2])
            for i, actual in enumerate(LABELS):
                for j, predicted in enumerate(LABELS):
                    cm_rows.append({
                        "horizon_minutes": h, "split": split,
                        "actual": actual, "predicted": predicted,
                        "count": int(cm[i, j])
                    })

        # Validation per-calendar-year metrics.
        valid_years = pd.to_datetime(valid["trading_day"]).dt.year
        for year in sorted(valid_years.unique()):
            mask = (valid_years == year).to_numpy()
            yy, pp = y_valid[mask], pred_valid[mask]
            yearly_rows.append({
                "horizon_minutes": h, "year": int(year),
                "samples": int(mask.sum()),
                "accuracy": float(accuracy_score(yy, pp)),
                "balanced_accuracy": float(balanced_accuracy_score(yy, pp)),
                "macro_f1": float(f1_score(yy, pp, labels=[0,1,2], average="macro", zero_division=0)),
                "down_recall": float(((yy == 0) & (pp == 0)).sum() / max((yy == 0).sum(), 1)),
                "sideways_recall": float(((yy == 1) & (pp == 1)).sum() / max((yy == 1).sum(), 1)),
                "up_recall": float(((yy == 2) & (pp == 2)).sum() / max((yy == 2).sum(), 1))
            })

        # Descriptive feature separation: class-specific mean/std and standardized
        # mean difference vs all other classes on TRAIN and VALIDATION.
        for split, df in (("TRAIN", train), ("VALIDATION", valid)):
            for feat in FEATURES:
                values = df[feat].astype(float)
                overall_std = float(values.std(ddof=1))
                for cls in LABELS:
                    a = values[df["label"] == cls]
                    b = values[df["label"] != cls]
                    pooled = np.sqrt((a.var(ddof=1) + b.var(ddof=1)) / 2)
                    sep_rows.append({
                        "horizon_minutes": h, "split": split, "feature": feat,
                        "class": cls, "class_mean": float(a.mean()),
                        "other_mean": float(b.mean()),
                        "standardized_mean_difference": float((a.mean() - b.mean()) / pooled) if pooled and np.isfinite(pooled) else None,
                        "overall_std": overall_std
                    })

        corr = train[FEATURES].corr(method="spearman")
        for i, f1 in enumerate(FEATURES):
            for f2 in FEATURES[i+1:]:
                corr_rows.append({
                    "horizon_minutes": h, "feature_1": f1, "feature_2": f2,
                    "spearman_correlation": float(corr.loc[f1, f2])
                })

        summary["horizons"][str(h)] = {
            "train_rows": len(train), "validation_rows": len(valid),
            "volatility_tercile_edges_from_train": [float(q1), float(q2)],
            "validation_prediction_distribution": {
                cls: float((pred_valid == i).mean() * 100) for i, cls in enumerate(LABELS)
            },
            "validation_actual_distribution": {
                cls: float((y_valid == i).mean() * 100) for i, cls in enumerate(LABELS)
            },
            "validation_metrics": {
                "accuracy": float(accuracy_score(y_valid, pred_valid)),
                "balanced_accuracy": float(balanced_accuracy_score(y_valid, pred_valid)),
                "macro_f1": float(f1_score(y_valid, pred_valid, labels=[0,1,2], average="macro", zero_division=0)),
                "log_loss": float(log_loss(y_valid, p_valid, labels=[0,1,2]))
            }
        }
        log.info("Completed diagnostics for %sm", h)
        del train, valid, X_train, X_valid, model, p_train, p_valid

    print("[WRITE] Saving diagnostic CSVs", flush=True)
    pd.DataFrame(label_year_rows).to_csv(out / "label_distribution_by_year.csv", index=False)
    pd.DataFrame(label_vol_rows).to_csv(out / "label_distribution_by_volatility.csv", index=False)
    pd.DataFrame(pred_rows).to_csv(out / "prediction_distribution.csv", index=False)
    pd.DataFrame(prob_rows).to_csv(out / "class_probability_summary.csv", index=False)
    pd.DataFrame(sep_rows).to_csv(out / "feature_class_separation.csv", index=False)
    pd.DataFrame(corr_rows).to_csv(out / "feature_correlation.csv", index=False)
    pd.DataFrame(yearly_rows).to_csv(out / "per_year_metrics.csv", index=False)
    pd.DataFrame(cm_rows).to_csv(out / "confusion_matrices.csv", index=False)
    summary["elapsed_seconds"] = round(time.time() - START, 2)
    (out / "diagnostics_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))
    print(f"REPORTS: {out}")

if __name__ == "__main__":
    main()
