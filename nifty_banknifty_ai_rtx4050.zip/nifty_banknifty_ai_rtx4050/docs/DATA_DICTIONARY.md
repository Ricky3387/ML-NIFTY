# Data dictionary

## Index candle table
- timestamp: timestamp of bar; consistently interpret in Asia/Kolkata
- symbol: NIFTY or BANKNIFTY
- open/high/low/close: index candle prices
- volume: source-specific traded volume; some index feeds may not provide meaningful volume
- oi: optional; normally relevant to derivative contracts, not spot index

## Options contract table
- timestamp
- underlying: NIFTY / BANKNIFTY
- expiry: contract expiry date
- strike: numeric strike
- option_type: CE / PE
- open/high/low/close
- volume
- oi
- bid/ask and depth: only when genuinely captured from a quote/depth source

## Identity
Use a stable contract key based on underlying, expiry, strike and option type. Broker instrument tokens can change and must be mapped using a dated instrument master.
