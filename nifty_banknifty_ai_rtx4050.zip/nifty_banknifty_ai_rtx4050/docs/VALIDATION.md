# Validation checklist

- [ ] Timestamps parsed consistently and exchange timezone documented
- [ ] Duplicate bars removed with provenance retained
- [ ] Missing intervals and market holidays checked
- [ ] Contract expiry and strike identities validated
- [ ] No future-derived feature columns
- [ ] Label horizon and split embargo verified
- [ ] Walk-forward folds tested across multiple regimes
- [ ] Probability calibration evaluated out of sample
- [ ] Brokerage, STT, exchange charges, GST, stamp duty and slippage modelled
- [ ] Options fills based on executable bid/ask, not candle close
- [ ] Model compared against simple baselines
- [ ] Paper-trading sample sufficiently large before considering real capital
