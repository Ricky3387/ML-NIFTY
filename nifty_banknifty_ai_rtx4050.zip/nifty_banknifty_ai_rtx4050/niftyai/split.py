import pandas as pd

def chronological_split(df: pd.DataFrame, horizon: int, val_fraction=.15, test_fraction=.15):
    d = df.sort_values("timestamp").reset_index(drop=True)
    n = len(d)
    test_start = int(n * (1-test_fraction))
    val_start = int(n * (1-test_fraction-val_fraction))
    # Embargo at least horizon rows at each boundary to reduce overlapping-label contamination.
    train = d.iloc[:max(0, val_start-horizon)].copy()
    val = d.iloc[val_start+horizon:test_start-horizon].copy()
    test = d.iloc[test_start+horizon:].copy()
    if min(len(train), len(val), len(test)) == 0:
        raise ValueError("Not enough rows for chronological split; supply more history.")
    return train, val, test
