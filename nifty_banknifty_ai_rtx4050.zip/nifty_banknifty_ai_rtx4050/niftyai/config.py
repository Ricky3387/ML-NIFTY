import os
from pathlib import Path
DATA_DIR = Path(os.getenv("NIFTYAI_DATA_DIR", "data"))
ARTIFACT_DIR = Path(os.getenv("NIFTYAI_ARTIFACT_DIR", "artifacts"))
DATA_DIR.mkdir(parents=True, exist_ok=True)
ARTIFACT_DIR.mkdir(parents=True, exist_ok=True)
