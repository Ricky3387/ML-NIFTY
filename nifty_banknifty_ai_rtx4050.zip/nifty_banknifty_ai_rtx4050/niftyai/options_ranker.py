import numpy as np
import pandas as pd

def rank_options(contracts: pd.DataFrame, spot: float):
    required = {"strike", "option_type", "close", "volume", "oi"}
    missing = required - set(contracts.columns)
    if missing:
        raise ValueError(f"Missing option columns: {sorted(missing)}")
    d = contracts.copy()
    d["moneyness_pct"] = (d["strike"] - spot) / spot
    d["spread_pct"] = np.nan  # Requires real bid/ask; never infer from OHLC.
    d["liquidity_score"] = np.log1p(d["volume"].clip(lower=0)) + .5*np.log1p(d["oi"].clip(lower=0))
    d["distance_penalty"] = d["moneyness_pct"].abs() * 100
    d["research_score"] = d["liquidity_score"] - d["distance_penalty"]
    return d.sort_values("research_score", ascending=False)
