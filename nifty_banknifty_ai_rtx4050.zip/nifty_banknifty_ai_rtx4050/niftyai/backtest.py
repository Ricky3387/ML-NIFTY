import numpy as np
import pandas as pd

def simple_direction_backtest(df, probabilities, threshold=.55, cost_bps=8):
    # Educational baseline only: next-horizon close return is not an executable fill.
    d = df.copy()
    p = np.asarray(probabilities)
    d["p_down"], d["p_side"], d["p_up"] = p[:,0], p[:,1], p[:,2]
    d["signal"] = np.where(d["p_up"] >= threshold, 1,
                    np.where(d["p_down"] >= threshold, -1, 0))
    d["gross_return"] = d["signal"] * d["forward_return"]
    d["net_return"] = d["gross_return"] - (d["signal"] != 0) * cost_bps / 10000
    d["equity"] = (1 + d["net_return"].fillna(0)).cumprod()
    d["drawdown"] = d["equity"] / d["equity"].cummax() - 1
    trades = d[d["signal"] != 0]
    return {
        "trades": int(len(trades)),
        "win_rate": float((trades["net_return"] > 0).mean()) if len(trades) else 0.0,
        "mean_net_return_per_bar": float(trades["net_return"].mean()) if len(trades) else 0.0,
        "max_drawdown": float(d["drawdown"].min()),
        "final_equity_multiple": float(d["equity"].iloc[-1]) if len(d) else 1.0
    }
