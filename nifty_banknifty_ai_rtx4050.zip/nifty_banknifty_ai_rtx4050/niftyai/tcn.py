# Optional experimental TCN. Install PyTorch separately from pytorch.org.
import torch
from torch import nn

class Chomp1d(nn.Module):
    def __init__(self, n): super().__init__(); self.n=n
    def forward(self, x): return x[:, :, :-self.n] if self.n else x

class TemporalBlock(nn.Module):
    def __init__(self, in_ch, out_ch, kernel=3, dilation=1, dropout=.1):
        super().__init__()
        pad=(kernel-1)*dilation
        self.net=nn.Sequential(
            nn.Conv1d(in_ch,out_ch,kernel,padding=pad,dilation=dilation),
            Chomp1d(pad), nn.ReLU(), nn.Dropout(dropout),
            nn.Conv1d(out_ch,out_ch,kernel,padding=pad,dilation=dilation),
            Chomp1d(pad), nn.ReLU(), nn.Dropout(dropout))
        self.down=nn.Conv1d(in_ch,out_ch,1) if in_ch != out_ch else nn.Identity()
        self.act=nn.ReLU()
    def forward(self,x): return self.act(self.net(x)+self.down(x))

class SmallTCN(nn.Module):
    def __init__(self, n_features, channels=64, classes=3):
        super().__init__()
        self.blocks=nn.Sequential(
            TemporalBlock(n_features,channels,dilation=1),
            TemporalBlock(channels,channels,dilation=2),
            TemporalBlock(channels,channels,dilation=4))
        self.head=nn.Sequential(nn.AdaptiveAvgPool1d(1),nn.Flatten(),nn.Linear(channels,classes))
    def forward(self,x): return self.head(self.blocks(x))

def choose_device():
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")
