import numpy as np
import pandas as pd

def build_features(df: pd.DataFrame) -> pd.DataFrame:
    d = df.sort_values(["symbol", "timestamp"]).copy()
    if "oi" not in d:
        d["oi"] = np.nan
    g = d.groupby("symbol", group_keys=False)
    d["ret_1"] = g["close"].pct_change()
    for n in [2, 3, 5, 10, 15, 30]:
        d[f"ret_{n}"] = g["close"].pct_change(n)
        d[f"volatility_{n}"] = g["ret_1"].transform(lambda s: s.rolling(n, min_periods=n).std())
        d[f"volume_change_{n}"] = g["volume"].pct_change(n)
    d["range_pct"] = (d["high"] - d["low"]) / d["close"].replace(0, np.nan)
    d["body_pct"] = (d["close"] - d["open"]) / d["open"].replace(0, np.nan)
    d["sma_5_dist"] = d["close"] / g["close"].transform(lambda s: s.rolling(5).mean()) - 1
    d["sma_20_dist"] = d["close"] / g["close"].transform(lambda s: s.rolling(20).mean()) - 1
    d["ema_12_dist"] = d["close"] / g["close"].transform(lambda s: s.ewm(span=12, adjust=False).mean()) - 1
    d["vwap_proxy"] = (d["close"] * d["volume"]).groupby(d["symbol"]).cumsum() / d["volume"].groupby(d["symbol"]).cumsum().replace(0, np.nan)
    d["oi_change"] = g["oi"].diff()
    d["oi_change_pct"] = g["oi"].pct_change()
    # Time features use only the timestamp of the current bar.
    d["minute_of_day"] = d["timestamp"].dt.hour * 60 + d["timestamp"].dt.minute
    d["minute_sin"] = np.sin(2 * np.pi * d["minute_of_day"] / 1440)
    d["minute_cos"] = np.cos(2 * np.pi * d["minute_of_day"] / 1440)
    return d.replace([np.inf, -np.inf], np.nan)

FEATURES = [
    "ret_1","ret_2","ret_3","ret_5","ret_10","ret_15","ret_30",
    "volatility_2","volatility_3","volatility_5","volatility_10","volatility_15","volatility_30",
    "volume_change_2","volume_change_3","volume_change_5","volume_change_10","volume_change_15","volume_change_30",
    "range_pct","body_pct","sma_5_dist","sma_20_dist","ema_12_dist",
    "oi_change","oi_change_pct","minute_sin","minute_cos"
]
