from pathlib import Path
import pandas as pd
import duckdb

REQUIRED = ["timestamp", "open", "high", "low", "close", "volume"]

def load_market_file(path: str, symbol: str | None = None) -> pd.DataFrame:
    p = Path(path)
    df = pd.read_parquet(p) if p.suffix.lower() in {".parquet", ".pq"} else pd.read_csv(p)
    df.columns = [str(c).strip().lower() for c in df.columns]
    missing = [c for c in REQUIRED if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")
    if "symbol" not in df.columns:
        if not symbol:
            raise ValueError("symbol column or --symbol is required")
        df["symbol"] = symbol.upper()
    df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
    for c in ["open", "high", "low", "close", "volume", "oi"]:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")
    df = df.dropna(subset=["timestamp", "open", "high", "low", "close"])
    df = df.sort_values(["symbol", "timestamp"]).drop_duplicates(["symbol", "timestamp"], keep="last")
    df["symbol"] = df["symbol"].astype(str).str.upper()
    return df.reset_index(drop=True)

def save_parquet(df: pd.DataFrame, path: str):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    df.to_parquet(path, index=False)

def duckdb_query(path: str, sql: str):
    con = duckdb.connect()
    try:
        return con.execute(sql.replace("$DATA", path)).df()
    finally:
        con.close()
