from pathlib import Path
import numpy as np
import pandas as pd

def make_demo(days=30, out_dir="data/demo"):
    # Synthetic data are solely for testing software plumbing; never use for model research.
    rng = np.random.default_rng(7)
    n = days * 375
    start = pd.Timestamp("2025-01-01 09:15")
    ts = pd.date_range(start, periods=n, freq="min")
    ret = rng.normal(0, .00045, n) + .00001
    close = 23000 * np.exp(np.cumsum(ret))
    open_ = np.r_[close[0], close[:-1]]
    spread = np.abs(rng.normal(.00025, .0001, n))
    df = pd.DataFrame({
        "timestamp": ts, "symbol": "NIFTY", "open": open_,
        "high": np.maximum(open_, close) * (1+spread),
        "low": np.minimum(open_, close) * (1-spread),
        "close": close, "volume": rng.integers(100, 10000, n),
        "oi": rng.integers(100000, 200000, n)
    })
    # A second synthetic series, not an actual BANKNIFTY price history.
    b = df.copy()
    b["symbol"] = "BANKNIFTY"
    b[["open","high","low","close"]] *= 2.1
    Path(out_dir).mkdir(parents=True, exist_ok=True)
    df.to_parquet(Path(out_dir)/"nifty_1m.parquet", index=False)
    b.to_parquet(Path(out_dir)/"banknifty_1m.parquet", index=False)
    return out_dir
