import argparse, json
from pathlib import Path
import pandas as pd
from .data import load_market_file, save_parquet
from .features import build_features, FEATURES
from .labels import add_forward_labels
from .split import chronological_split
from .models import train_model, evaluate, save_model, load_model
from .demo import make_demo
from .config import ARTIFACT_DIR, DATA_DIR
from .backtest import simple_direction_backtest

def cmd_ingest(a):
    df = load_market_file(a.input, a.symbol)
    out = DATA_DIR / "normalized" / f"{a.symbol.upper()}.parquet"
    save_parquet(df, str(out))
    print(f"Saved {len(df):,} rows to {out}")

def cmd_train(a):
    raw = load_market_file(a.input, a.symbol)
    d = add_forward_labels(build_features(raw), a.horizon)
    d = d.dropna(subset=FEATURES + ["target", "forward_return"])
    d = d[d["target"].isin([0,1,2])]
    if a.max_rows and len(d) > a.max_rows:
        d = d.tail(a.max_rows)
    train, val, test = chronological_split(d, a.horizon)
    model = train_model(a.model, train[FEATURES], train["target"].astype(int),
                        val[FEATURES], val["target"].astype(int), a.allow_cpu_fallback)
    metrics = evaluate(model, test[FEATURES], test["target"].astype(int))
    path = ARTIFACT_DIR / f"{a.symbol}_{a.horizon}_{a.model}.joblib"
    metadata = {"symbol": a.symbol, "horizon": a.horizon, "features": FEATURES,
                "metrics": metrics, "synthetic_warning": "Check input provenance before use."}
    save_model(model, path, metadata)
    print(json.dumps({"artifact": str(path), "metrics": metrics}, indent=2))

def cmd_predict(a):
    bundle = load_model(a.model)
    meta, model = bundle["metadata"], bundle["model"]
    raw = load_market_file(a.input, meta["symbol"])
    d = build_features(raw).dropna(subset=meta["features"])
    row = d.iloc[[-1]]
    probs = model.predict_proba(row[meta["features"]])[0]
    print(json.dumps({"symbol": meta["symbol"], "horizon": meta["horizon"],
        "timestamp": str(row.iloc[0]["timestamp"]),
        "probabilities": {"DOWN": float(probs[0]), "SIDEWAYS": float(probs[1]), "UP": float(probs[2])},
        "model_metrics": meta["metrics"]}, indent=2))

def cmd_backtest(a):
    raw = load_market_file(a.input, a.symbol)
    d = add_forward_labels(build_features(raw), a.horizon).dropna(subset=FEATURES+["target","forward_return"])
    tr, va, te = chronological_split(d, a.horizon)
    model = train_model("lightgbm", tr[FEATURES], tr["target"].astype(int), va[FEATURES], va["target"].astype(int))
    result = simple_direction_backtest(te, model.predict_proba(te[FEATURES]), a.threshold, a.cost_bps)
    print(json.dumps(result, indent=2))

def main():
    p = argparse.ArgumentParser(prog="niftyai")
    sub = p.add_subparsers(dest="cmd", required=True)
    x = sub.add_parser("make-demo"); x.add_argument("--days", type=int, default=30); x.set_defaults(func=lambda a: print(make_demo(a.days)))
    x = sub.add_parser("ingest"); x.add_argument("--input", required=True); x.add_argument("--symbol", required=True); x.set_defaults(func=cmd_ingest)
    x = sub.add_parser("train"); x.add_argument("--input", required=True); x.add_argument("--symbol", required=True); x.add_argument("--horizon", type=int, choices=[5,15,30], required=True); x.add_argument("--model", choices=["lightgbm","xgb"], default="lightgbm"); x.add_argument("--allow-cpu-fallback", action="store_true"); x.add_argument("--max-rows", type=int, default=1000000); x.set_defaults(func=cmd_train)
    x = sub.add_parser("predict"); x.add_argument("--model", required=True); x.add_argument("--input", required=True); x.set_defaults(func=cmd_predict)
    x = sub.add_parser("backtest"); x.add_argument("--input", required=True); x.add_argument("--symbol", required=True); x.add_argument("--horizon", type=int, choices=[5,15,30], required=True); x.add_argument("--threshold", type=float, default=.55); x.add_argument("--cost-bps", type=float, default=8); x.set_defaults(func=cmd_backtest)
    x = sub.add_parser("collect-kite"); x.add_argument("--config", default="config/kite_instruments.json"); x.set_defaults(func=lambda a: __import__("niftyai.kite_collector", fromlist=["run_collector"]).run_collector(a.config))
    a = p.parse_args(); a.func(a)

if __name__ == "__main__":
    main()
