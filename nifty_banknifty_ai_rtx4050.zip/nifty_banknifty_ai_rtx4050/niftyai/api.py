from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from pathlib import Path
from .models import load_model
from .data import load_market_file
from .features import build_features
from .config import ARTIFACT_DIR

app = FastAPI(title="NIFTY/BANKNIFTY AI Research API", version="0.1.0")

class PredictRequest(BaseModel):
    input_path: str
    symbol: str
    horizon: int

@app.get("/health")
def health():
    return {"status": "ok", "mode": "research/paper-only", "live_orders": False}

@app.post("/predict")
def predict(req: PredictRequest):
    if req.horizon not in (5,15,30):
        raise HTTPException(400, "horizon must be 5, 15 or 30")
    path = ARTIFACT_DIR / f"{req.symbol.upper()}_{req.horizon}_lightgbm.joblib"
    if not path.exists():
        raise HTTPException(404, f"Model not found: {path}")
    bundle = load_model(path)
    meta, model = bundle["metadata"], bundle["model"]
    df = build_features(load_market_file(req.input_path, req.symbol)).dropna(subset=meta["features"])
    if df.empty:
        raise HTTPException(400, "Not enough valid rows to calculate features")
    row = df.iloc[[-1]]
    p = model.predict_proba(row[meta["features"]])[0]
    return {"symbol": req.symbol.upper(), "horizon": req.horizon,
            "timestamp": str(row.iloc[0]["timestamp"]),
            "probabilities": {"DOWN": float(p[0]), "SIDEWAYS": float(p[1]), "UP": float(p[2])},
            "warning": "Research output only; not a recommendation or guaranteed profitable signal."}
