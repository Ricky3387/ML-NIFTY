from pathlib import Path
import joblib
import numpy as np
from sklearn.metrics import accuracy_score, balanced_accuracy_score, f1_score, log_loss
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.ensemble import HistGradientBoostingClassifier

def train_model(kind, X_train, y_train, X_val, y_val, allow_cpu_fallback=False):
    if kind == "lightgbm":
        from lightgbm import LGBMClassifier
        model = Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("model", LGBMClassifier(
                n_estimators=500, learning_rate=.03, num_leaves=31,
                max_depth=-1, subsample=.8, colsample_bytree=.8,
                reg_lambda=5, class_weight="balanced", n_jobs=4,
                verbosity=-1, random_state=42
            ))
        ])
        model.fit(X_train, y_train)
    elif kind == "xgb":
        from xgboost import XGBClassifier
        import xgboost as xgb
        use_cuda = False
        try:
            import torch
            use_cuda = torch.cuda.is_available()
        except Exception:
            pass
        kwargs = dict(
            objective="multi:softprob", num_class=3, n_estimators=600,
            max_depth=5, learning_rate=.03, subsample=.8,
            colsample_bytree=.8, min_child_weight=10, reg_lambda=5,
            max_bin=128, tree_method="hist", eval_metric="mlogloss",
            n_jobs=4, random_state=42
        )
        if use_cuda:
            kwargs["device"] = "cuda"
        else:
            kwargs["device"] = "cpu"
        model = Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("model", XGBClassifier(**kwargs))
        ])
        try:
            model.fit(X_train, y_train)
        except Exception:
            if not allow_cpu_fallback or kwargs["device"] == "cpu":
                raise
            kwargs["device"] = "cpu"
            model = Pipeline([
                ("imputer", SimpleImputer(strategy="median")),
                ("model", XGBClassifier(**kwargs))
            ])
            model.fit(X_train, y_train)
    else:
        raise ValueError("kind must be lightgbm or xgb")
    return model

def evaluate(model, X, y):
    pred = model.predict(X)
    probs = model.predict_proba(X)
    return {
        "accuracy": float(accuracy_score(y, pred)),
        "balanced_accuracy": float(balanced_accuracy_score(y, pred)),
        "macro_f1": float(f1_score(y, pred, average="macro", zero_division=0)),
        "log_loss": float(log_loss(y, probs, labels=[0,1,2])),
        "rows": int(len(y))
    }

def save_model(model, path, metadata):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    joblib.dump({"model": model, "metadata": metadata}, path)

def load_model(path):
    return joblib.load(path)
