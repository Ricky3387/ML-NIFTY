import numpy as np
import pandas as pd

def add_forward_labels(df: pd.DataFrame, horizon: int, sideways_threshold: float = 0.00025):
    if horizon not in (5, 15, 30):
        raise ValueError("Supported horizons are 5, 15, 30 minutes")
    d = df.sort_values(["symbol", "timestamp"]).copy()
    future = d.groupby("symbol")["close"].shift(-horizon)
    d["forward_return"] = future / d["close"] - 1
    # Fixed threshold is a starter only; production labels should be volatility- and cost-aware.
    d["target"] = np.select(
        [d["forward_return"] > sideways_threshold,
         d["forward_return"] < -sideways_threshold],
        [2, 0], default=1
    )
    return d
