import os, json, time
from pathlib import Path
from datetime import datetime, timezone

def run_collector(config_path="config/kite_instruments.json", out_dir="data/live"):
    try:
        from kiteconnect import KiteTicker
    except ImportError as e:
        raise RuntimeError('Install optional dependency: pip install -e ".[kite]"') from e
    api_key = os.getenv("KITE_API_KEY")
    access_token = os.getenv("KITE_ACCESS_TOKEN")
    if not api_key or not access_token:
        raise RuntimeError("Set KITE_API_KEY and KITE_ACCESS_TOKEN environment variables.")
    instruments = json.loads(Path(config_path).read_text())
    tokens = [int(x["instrument_token"]) for x in instruments]
    token_map = {int(x["instrument_token"]): x for x in instruments}
    Path(out_dir).mkdir(parents=True, exist_ok=True)
    path = Path(out_dir) / f"kite_depth_{datetime.now().strftime('%Y%m%d')}.jsonl"
    f = path.open("a", buffering=1, encoding="utf-8")
    kws = KiteTicker(api_key, access_token)

    def on_connect(ws, response):
        ws.subscribe(tokens)
        ws.set_mode(ws.MODE_FULL, tokens)

    def on_ticks(ws, ticks):
        received = datetime.now(timezone.utc).isoformat()
        for tick in ticks:
            tick["received_at_utc"] = received
            tick["instrument"] = token_map.get(tick.get("instrument_token"), {})
            f.write(json.dumps(tick, default=str) + "\n")

    def on_close(ws, code, reason):
        f.flush()

    kws.on_connect = on_connect
    kws.on_ticks = on_ticks
    kws.on_close = on_close
    try:
        kws.connect(threaded=False)
    finally:
        f.close()
