# NIFTY AI Prediction Project --- Work Completed So Far

**Project:** Personal-use NIFTY/BANKNIFTY AI prediction application\
**Current focus:** NIFTY only; BANKNIFTY is deferred until NIFTY is
stable\
**Status:** Historical data preparation, feature engineering, dataset
audits, model training experiments, and threshold-robustness diagnostics
are complete. Cost-aware walk-forward backtesting is the next major
phase.\
**Last updated:** 12 November 2026

------------------------------------------------------------------------

## 1. Project objective and development environment

The goal is to build a personal-use AI application that predicts NIFTY
direction over **5-minute, 15-minute, and 30-minute horizons**. The
intended sequence is research, offline validation, paper trading, and
only then consideration of live use.

### Development environment

-   Windows
-   16 GB RAM
-   NVIDIA GeForce RTX 4050, 6 GB VRAM
-   Python, pandas, DuckDB, PyArrow, LightGBM, scikit-learn
-   DuckDB database: `data/database/nifty_options.duckdb`
-   Timezone: `Asia/Kolkata`

The LightGBM experiments completed so far used CPU training. GPU
training was not necessary for these datasets and models.

### Project boundaries

-   Current modeling scope: NIFTY.
-   Current cleaned historical scope: **2021-05-24 through 2024-12-31**.
-   2025 and 2026 are deliberately outside the current cleaned training
    scope.
-   Personal research use; respect the dataset licence and attribution
    requirements.
-   No live orders have been placed as part of this work.
-   No profitability or tradable edge has been established.
-   Historical option bid/ask quotes are unavailable in the current
    dataset; they must not be fabricated.

------------------------------------------------------------------------

## 2. Historical data source and database

Historical source used:

`thetrademarkk/india-index-options-1m` on Hugging Face.

The dataset was identified as **CC BY-NC 4.0**. Use remains subject to
the licence and attribution terms.

DuckDB database:

`data/database/nifty_options.duckdb`

Views used:

-   `nifty_index`
-   `nifty_options`
-   `banknifty_index`
-   `banknifty_options`

NIFTY was prioritized because its usable historical coverage was more
suitable for this workflow. BANKNIFTY remains a secondary project.

------------------------------------------------------------------------

## 3. Data cleaning, session rules, and calendar validation

### Final session policy

The cleaned normal-session dataset follows these rules:

-   Include only regular-session minute-start bars from **09:15 through
    15:29 IST**.
-   Exclude pre-open and post-session records.
-   Exclude special/Muhurat sessions from the normal-session dataset.
-   Convert timezone-aware source timestamps to `Asia/Kolkata`; do not
    manually add 5 hours 30 minutes.
-   Keep original source data unchanged.
-   Do not treat synthetic/forward-filled bars as real trades.

Special dates excluded from normal-session training:

-   2021-11-04
-   2022-10-24
-   2023-11-12
-   2024-11-01
-   2024-01-20
-   2024-03-02
-   2024-05-18

Additional calendar corrections:

-   2024-01-20 was a full-day special session.
-   2024-03-02 and 2024-05-18 were split sessions.
-   2024-11-20 was corrected as a missed holiday; 375 synthetic bars
    were removed.
-   2022-03-07 had 40 missing regular-session bars and was excluded as a
    full day from continuous intraday training.
-   2023-03-28 had one missing minute; windows crossing that gap were
    excluded.

### Synthetic-bar policy

Synthetic bars are forward-filled from the last observed close, with:

-   Open = High = Low = Close
-   Volume = 0
-   `is_synthetic` marked true

They are not treated as traded observations and are excluded by the
model eligibility guard.

### Final cleaned NIFTY index dataset

File:

`data/processed/nifty_index_cleaned/nifty_index_cleaned_final.parquet`

  Measure             Result
  ---------------- ---------
  Trading dates          893
  Rows               334,335
  Real rows          334,294
  Synthetic rows          41
  Duplicate rows           0
  Null OHLC rows           0

Raw-versus-cleaned verification confirmed 333,709 normal-session rows
matched exact OHLCV at exact IST timestamps. The remaining 41 synthetic
rows corresponded to the identified missing bars on two dates. The
cleaned file was verified and not rebuilt unnecessarily.

------------------------------------------------------------------------

## 4. Initial index-only features and labels

**Builder script:** `scripts/build_nifty_features_v1.py`

**Output:**

`data/processed/nifty_features_v1/nifty_features_labels_long.parquet`

The feature/label dataset contains three target horizons: 5m, 15m, and
30m.

Labels use forward close-to-close returns normalized by past 60-minute
return volatility. The normalized target is `target_z`; class boundaries
use ±0.5:

-   DOWN
-   SIDEWAYS
-   UP

The prediction assumption is that the current one-minute bar has
completed before the prediction is made.

  Measure                                   Rows
  ---------------------------------- -----------
  Total rows across three horizons     1,003,005
  Eligible rows                          796,412
  Excluded rows                          206,593

Eligible rows by horizon:

  Horizon     Eligible rows
  --------- ---------------
  5m                275,853
  15m               266,953
  30m               253,606

### Target-alignment audit

**Script:** `scripts/audit_nifty_target_alignment_v1.py`\
**Reports:** `reports/nifty_target_alignment_v1/`

All 796,412 eligible rows passed the checks for current close, future
close, future timestamp, same-trading-day alignment, real future bars,
and forward-return calculation.

Important detail: `forward_return` is the simple return
`(future_close/current_close)-1`, not the log return. This was verified
and is not an error. Existing targets and labels were retained
unchanged.

------------------------------------------------------------------------

## 5. Walk-forward dataset validation

**Script:** `scripts/validate_nifty_walkforward_v1.py`

**Output folder:** `data/processed/nifty_walkforward_v1/`

Created train and validation datasets for each horizon.

-   TRAIN: 2021-05-24 through 2023-12-31
-   VALIDATION: 2024-01-01 through 2024-12-31
-   TEST: 2025 --- not included in current cleaned input
-   RECENT_HOLDOUT: 2026 --- not included in current cleaned input

Audits confirmed:

-   No duplicate timestamp/horizon groups.
-   No eligibility guard failures.
-   No eligible rows from the excluded 2022-03-07 day.
-   No chronological split issues.

The 2024 period is diagnostic validation, not an untouched final test
set. Purge/embargo checks must be revisited if split dates or target
windows change.

------------------------------------------------------------------------

## 6. Initial index-only LightGBM baseline

The first LightGBM baseline trained separate 5m, 15m, and 30m multiclass
models.

The initial full-sample models tended to predict SIDEWAYS excessively
(roughly 93.6%--98.8% in the initial runs). Directional recall and
probability discrimination were weak.

This established an important baseline: index-only features with the
original volatility labels did not produce a convincing directional
signal.

Further feature-ablation experiments gave only modest gains. No
tradeable edge was demonstrated.

------------------------------------------------------------------------

## 7. Options data feasibility and continuity audits

The options data was audited before using it as a source of predictors.

### NIFTY options audit scope

Normal-session scope: 2021-05-24 through 2024-12-31, with special dates
excluded.

  Measure                                      Result
  -------------------------------------- ------------
  Options rows                             52,768,448
  Trading days                                    889
  Unique timestamps                           333,374
  Expiries                                        190
  Strikes                                         334
  Duplicate contract-minute key groups              0
  Paired CE/PE contract-minute slots       13,287,697
  Paired-slot percentage                     33.6561%

Other findings:

-   Null timestamp, expiry, strike, close, volume, and OI checks were
    clean.
-   Invalid OHLC checks were clean.
-   Historical bid/ask data was unavailable.
-   IV and Greeks therefore cannot be reliably reconstructed from this
    dataset alone.
-   Volume decreases in many observations, indicating that it behaves
    like a per-bar quantity rather than a cumulative counter in the
    observed data. Provider semantics were not independently verified.
-   Missing options observations are not forward-filled.

### ATM coverage and continuity

The nearest-expiry DTE 0--7 ATM selection had high index-minute
coverage. The selected ATM CE/PE pair coverage was approximately 99.54%
of all index minutes. The options timestamp coverage was approximately
99.89%.

ATM selection and continuity checks were performed, including paired
CE/PE availability, positive OI, valid prices, and exact index timestamp
alignment.

------------------------------------------------------------------------

## 8. Options feature engineering

### Initial options feature builder

**Script:** `scripts/build_nifty_options_features_v1.py`

**Output:**

`data/processed/nifty_options_features_v1/nifty_options_features_v1.parquet`

The initial options feature set included:

-   Selected expiry and DTE
-   ATM strike and ATM distance
-   CE/PE prices and straddle premium
-   One-minute CE/PE log returns
-   CE/PE return spread
-   Weighted straddle return
-   CE/PE OI and OI changes
-   CE/PE volume
-   Paired strike counts
-   Near-ATM CE/PE OI and volume aggregates
-   PCR and imbalance measures
-   Rolling CE/PE volume sums and volume imbalance
-   Availability flags

No IV or Greeks were fabricated.

### Rolling-window continuity correction

The initial validation found rolling windows that crossed missing clock
minutes.

-   `scripts/fix_nifty_options_rolling_windows_v2.py` corrected
    clock-continuity handling but changed the original imbalance
    formula, so its output was not accepted as canonical.
-   A later v3 output was also not accepted for modeling because the
    imbalance formula differed from the original definition.
-   The accepted canonical output is **v4**.

### Canonical options feature v4

**Script:** `scripts/build_nifty_options_features_v4.py`

**Output:**

`data/processed/nifty_options_features_v4/nifty_options_features_v4.parquet`

**Reports:**

`reports/nifty_options_features_v4/`

The v4 audit passed all five checks:

-   Row count preserved.
-   No duplicate timestamps.
-   All nonrolling features exactly preserved.
-   No rolling feature calculated across a clock gap.
-   Rolling changes only converted invalid cross-gap values to NULL; no
    valid rolling values were altered.

**Use v4 for modeling. Do not use options feature v2 or v3 as canonical
modeling input.**

------------------------------------------------------------------------

## 9. Merge index and options features

**Builder script:** `scripts/merge_nifty_index_options_features_v1.py`

**Output:**

`data/processed/nifty_index_options_features_v1/nifty_index_options_features_v1.parquet`

The merge uses an exact `timestamp_ist` LEFT JOIN. It preserves index
labels and does not forward-fill options features.

  Measure                           Result
  ---------------------------- -----------
  Index rows across horizons     1,003,005
  Options timestamp rows           333,709
  Unique index timestamps          334,335
  Merged rows                    1,003,005
  Output columns                        99
  Added options columns                 57
  Matched index rows             1,001,127
  Missing join rows                  1,878

There were zero trading-day mismatches, zero spot-close mismatches, and
zero label-preservation differences. The merge audit passed 7/7 checks.

### Merged feature quality and leakage audits

Scripts:

-   `scripts/validate_nifty_index_options_features_v1.py`
-   `scripts/audit_nifty_index_options_features_v1.py`

Reports are under:

`reports/nifty_index_options_features_v1/`

Results included:

-   No duplicate keys.
-   No date mismatches.
-   No eligible rows missing labels.
-   No options feature values present without an options join.
-   Synthetic rows were correctly ineligible.
-   The name-based leakage scan found no options-feature leakage names,
    while identifying target/forward-looking fields that must not be
    predictors.

The first proposed options predictor group, called **O1**, contained 14
features:

1.  `selected_dte`
2.  `atm_distance_pct`
3.  `atm_straddle_premium_pct`
4.  `atm_ce_log_return_1m`
5.  `atm_pe_log_return_1m`
6.  `atm_ce_pe_return_spread_1m`
7.  `atm_straddle_weighted_log_return_1m`
8.  `atm_ce_oi_change_1m`
9.  `atm_pe_oi_change_1m`
10. `near_atm_pcr_oi`
11. `near_atm_pcr_volume`
12. `near_atm_oi_imbalance`
13. `near_atm_volume_imbalance`
14. `paired_strike_count`

Raw option prices, raw OI/volume levels, and availability flags were not
included in the initial O1 predictor group.

------------------------------------------------------------------------

## 10. Timestamp and prediction-time alignment

The dataset timestamps mark the **beginning** of each one-minute bar.

Example:

-   Source timestamp 09:15 represents the 09:15--09:16 bar.
-   The bar is complete at 09:16.
-   Earliest assumed decision time is 09:16, subject to actual data
    publication latency.
-   The future target close for a 5-minute horizon is timestamped 09:20.

The original source timestamps were retained. No source files were
shifted.

Provider publication latency is unknown and remains a live-deployment
consideration.

------------------------------------------------------------------------

## 11. Matched datasets for fair model comparison

### Matched datasets v1

**Script:** `scripts/build_nifty_matched_datasets_v1.py`

**Output:**

`data/processed/nifty_matched_datasets_v1/`

This created index-only and index-plus-options datasets using identical
rows and targets, requiring all O1 options features to be non-NULL.

Matched train/validation counts:

  Horizon       Train   Validation
  --------- --------- ------------
  5m          198,354       75,949
  15m         191,954       73,499
  30m         182,357       69,824

The index-only matched dataset is a fair matched-sample benchmark; it
does not replace the original full-sample baseline.

### Quantile labels v3

**Script:** `scripts/build_nifty_quantile_labels_v3.py`

Input:

`data/processed/nifty_index_options_features_v2/nifty_index_options_features_v2.parquet`

Output:

`data/processed/nifty_index_options_features_v3/nifty_index_options_features_v3.parquet`

The v3 correction addressed a temporal leakage issue in quantile
threshold estimation. Quantile thresholds were calculated using only
eligible 2021--2022 fit-period observations, then fixed for 2023 and
2024.

Thresholds:

  Horizon     Lower threshold   Upper threshold
  --------- ----------------- -----------------
  5m                -0.382202          0.426854
  15m               -0.365446          0.450825
  30m               -0.363304          0.472316

The v3 audit passed. The original volatility labels were preserved.

### Matched datasets v3

**Script:** `scripts/build_nifty_matched_datasets_v3.py`

**Output:**

`data/processed/nifty_matched_datasets_v3/`

This version used 24 index features and 14 options features, for 38
combined predictors. It used identical sample rows and targets for
index-only and index-plus-options comparisons, and excluded raw OHLC,
raw option prices, raw OI/volume, future target fields, thresholds, and
availability flags.

All dataset parity checks passed.

------------------------------------------------------------------------

## 12. LightGBM matched baseline training v1

**Important training script:**

`scripts/train_nifty_lightgbm_matched_v1.py`

Models:

-   Index-only: 5m, 15m, 30m
-   Index-plus-options: 5m, 15m, 30m

Output models:

`models/nifty_lightgbm_matched_v1/`

Reports:

`reports/nifty_lightgbm_matched_v1/`

Training chronology:

-   Internal fit: 2021--2022
-   Early stopping: 2023
-   Final refit: 2021--2023
-   Diagnostic evaluation: 2024

Balanced sample weights were used.

### Matched v1 results

  --------------------------------------------------------------------------
  Dataset        Horizon     Accuracy     Balanced     Macro F1      ROC-AUC
                                          accuracy              
  --------- ------------ ------------ ------------ ------------ ------------
  Index               5m       0.4297       0.3685       0.3426       0.5497
  only                                                          

  Index              15m       0.4218       0.3521       0.3309       0.5330
  only                                                          

  Index              30m       0.4237       0.3426       0.3089       0.5183
  only                                                          

  Index +             5m       0.4202       0.3722       0.3632       0.5545
  options                                                       

  Index +            15m       0.4179       0.3593       0.3443       0.5361
  options                                                       

  Index +            30m       0.3989       0.3494       0.3352       0.5171
  options                                                       
  --------------------------------------------------------------------------

Options improved macro F1 by approximately 2.06 percentage points at 5m,
1.34 points at 15m, and 2.63 points at 30m in this particular
experiment.

These results were not sufficient to establish a tradable edge. The
balanced-weighted models also produced a substantial SIDEWAYS prediction
share.

### Unweighted comparison

**Script:** `scripts/train_nifty_lightgbm_unweighted_v1.py`

Outputs:

-   `models/nifty_lightgbm_matched_unweighted_v1/`
-   `reports/nifty_lightgbm_matched_unweighted_v1/`

The unweighted models collapsed heavily toward SIDEWAYS (up to 100% for
some horizons). Balanced weighting gave better macro F1 and directional
recall in these experiments. Neither weighting choice demonstrated a
reliable trading signal.

------------------------------------------------------------------------

## 13. Quantile v3 model training

**Important training script:**

`scripts/train_nifty_lightgbm_quantile_v3.py`

Input:

`data/processed/nifty_matched_datasets_v3/`

Models:

`models/nifty_lightgbm_quantile_v3/`

Reports:

`reports/nifty_lightgbm_quantile_v3/`

Six models were trained: index-only and index-plus-options for 5m, 15m,
and 30m.

Training chronology:

-   Fit: 2021--2022
-   Early stopping: 2023
-   Final refit: 2021--2023
-   Diagnostic evaluation: 2024

### Quantile v3 results

  --------------------------------------------------------------------------
  Dataset        Horizon     Accuracy     Balanced     Macro F1      ROC-AUC
                                          accuracy              
  --------- ------------ ------------ ------------ ------------ ------------
  Index               5m       0.3752       0.3705       0.3688       0.5442
  only                                                          

  Index              15m       0.3614       0.3571       0.3555       0.5326
  only                                                          

  Index              30m       0.3454       0.3481       0.3447       0.5228
  only                                                          

  Index +             5m       0.3830       0.3735       0.3649       0.5536
  options                                                       

  Index +            15m       0.3712       0.3595       0.3556       0.5385
  options                                                       

  Index +            30m       0.3686       0.3561       0.3522       0.5241
  options                                                       
  --------------------------------------------------------------------------

Options slightly improved macro F1 at 30m, were nearly equal at 15m, and
reduced macro F1 at 5m. Log loss was better for the options models at
all three horizons in this experiment.

Probability discrimination remained weak. The models were not shown to
be profitable.

------------------------------------------------------------------------

## 14. Two-stage target design

### Two-stage labels v1

**Script:** `scripts/build_nifty_two_stage_labels_v1.py`

Input:

`data/processed/nifty_index_options_features_v3/nifty_index_options_features_v3.parquet`

Output:

`data/processed/nifty_index_options_features_v4/nifty_index_options_features_v4.parquet`

Reports:

`reports/nifty_two_stage_labels_v1/`

The two-stage target definition is:

**Stage 1:** SIDEWAYS versus MOVE\
**Stage 2:** DOWN versus UP, trained only on actual MOVE rows.

The Stage 1 threshold is the median absolute `target_z` calculated from
eligible 2021--2022 rows only, separately for each horizon:

  Horizon     Absolute target threshold
  --------- ---------------------------
  5m                           0.639658
  15m                          0.650263
  30m                          0.665702

The audit passed 10/10 checks. Existing v3 data and labels were not
modified.

### Two-stage matched datasets v1

**Script:** `scripts/build_nifty_two_stage_matched_datasets_v1.py`

Output:

`data/processed/nifty_two_stage_matched_datasets_v1/`

Reports:

`reports/nifty_two_stage_matched_datasets_v1/`

Created Stage 1 and Stage 2 datasets for both feature variants and all
horizons.

Stage 1 uses all eligible matched rows. Stage 2 uses actual MOVE rows
only.

Stage 1 counts:

  Horizon       Train   Validation
  --------- --------- ------------
  5m          198,354       75,949
  15m         191,954       73,499
  30m         182,357       69,824

Stage 2 counts:

  Horizon      Train   Validation
  --------- -------- ------------
  5m          97,796       34,796
  15m         94,419       32,253
  30m         89,617       29,251

All dataset audit, parity, and stage-relationship checks passed.

------------------------------------------------------------------------

## 15. Two-stage LightGBM model training v1

**Important training script:**

`scripts/train_nifty_two_stage_lightgbm_v1.py`

Models:

`models/nifty_two_stage_lightgbm_v1/`

Reports:

`reports/nifty_two_stage_lightgbm_v1/`

Twelve binary models were trained:

-   Stage 1: MOVE versus SIDEWAYS
-   Stage 2: UP versus DOWN, trained on actual MOVE rows
-   Index-only and index-plus-options
-   5m, 15m, and 30m

Training chronology:

-   Fit: 2021--2022
-   Early stopping: 2023
-   Final refit: 2021--2023
-   Diagnostic evaluation: 2024

Balanced sample weights were used.

### Stage 1 results (2024)

  ---------------------------------------------------------------------------
  Dataset      Horizon   Accuracy   Balanced   Macro F1       MOVE    ROC-AUC
                                    accuracy                recall 
  --------- ---------- ---------- ---------- ---------- ---------- ----------
  Index             5m     0.5536     0.5526     0.5521     0.5402     0.5757
  only                                                             

  Index            15m     0.5374     0.5402     0.5365     0.5624     0.5593
  only                                                             

  Index            30m     0.5246     0.5360     0.5244     0.6064     0.5523
  only                                                             

  Index +           5m     0.5637     0.5490     0.5412     0.3736     0.5797
  options                                                          

  Index +          15m     0.5448     0.5378     0.5378     0.4809     0.5562
  options                                                          

  Index +          30m     0.5518     0.5339     0.5337     0.4232     0.5478
  options                                                          
  ---------------------------------------------------------------------------

### Stage 2 results (2024, actual MOVE observations only)

  --------------------------------------------------------------------------
  Dataset        Horizon     Accuracy     Balanced     Macro F1      ROC-AUC
                                          accuracy              
  --------- ------------ ------------ ------------ ------------ ------------
  Index               5m       0.5159       0.5162       0.5157       0.5262
  only                                                          

  Index              15m       0.5072       0.5078       0.5068       0.5175
  only                                                          

  Index              30m       0.4867       0.4872       0.4855       0.4962
  only                                                          

  Index +             5m       0.5306       0.5307       0.5306       0.5457
  options                                                       

  Index +            15m       0.5222       0.5227       0.5219       0.5346
  options                                                       

  Index +            30m       0.5047       0.5048       0.5047       0.5199
  options                                                       
  --------------------------------------------------------------------------

Options improved conditional Stage 2 direction macro F1 across all
horizons in this experiment. Stage 2 results are conditional on actual
MOVE observations and must not be compared directly with Stage 1 or
three-class metrics.

------------------------------------------------------------------------

## 16. End-to-end two-stage evaluation

### V1 evaluation issue

**Script initially used:**
`scripts/evaluate_nifty_two_stage_end_to_end_v1.py`

The initial evaluator compared actual two-stage labels against Quantile
v3 labels. This was invalid because the target definitions differ:

-   Quantile v3 uses lower/upper target-z quantiles.
-   Two-stage v1 uses a median absolute target-z MOVE threshold and then
    direction.

The mismatch was correctly identified. Those labels are not
interchangeable.

### Corrected V2 end-to-end evaluation

**Script:** `scripts/evaluate_nifty_two_stage_end_to_end_v2.py`

Reports:

`reports/nifty_two_stage_end_to_end_v2/`

The corrected evaluation uses the two-stage model's own labels. All six
evaluations passed their alignment and probability checks.

The original argmax decision policy predicted SIDEWAYS for virtually all
observations at some horizons. This led to a separate threshold-policy
investigation.

------------------------------------------------------------------------

## 17. Threshold robustness V1 and its limitation

**Script:** `scripts/analyze_nifty_two_stage_threshold_robustness_v1.py`

Reports:

`reports/nifty_two_stage_threshold_robustness_v1/`

The V1 experiment selected thresholds using temporary models trained on
2021--2022 and 2023 threshold-selection predictions, but evaluated 2024
using predictions from the original final models trained on 2021--2023.

That model-history mismatch meant it was not a clean test of threshold
transfer for the same model. The limitation was identified and corrected
in V2. V1 reports were retained for historical comparison.

------------------------------------------------------------------------

## 18. Threshold robustness V2 --- corrected experiment

**Important script:**

`scripts/analyze_nifty_two_stage_threshold_robustness_v2.py`

Reports:

`reports/nifty_two_stage_threshold_robustness_v2/`

This experiment corrected the V1 mismatch.

Temporary models:

-   Fit on 2021
-   Early stopping on 2022
-   Final refit on 2021--2022
-   Generate both 2023 and 2024 predictions using the same fitted model
    objects
-   Select the MOVE threshold on 2023 only
-   Apply the selected threshold unchanged to 2024

Three policies were compared:

1.  Original probability argmax
2.  Fixed MOVE threshold 0.50
3.  MOVE threshold selected using 2023 macro F1

The threshold grid was 0.30 through 0.70 in 0.01 increments. Threshold
selection used macro F1, with balanced accuracy as the tie-break.

### V2 audit status

The uploaded V2 summary reported **PASS**:

-   All temporary models trained.
-   All dataset/horizon combinations completed.
-   All policy evaluations completed.
-   All audits passed.
-   Same temporary model objects used for 2023 and 2024.
-   Existing models and datasets were not modified.

### Selected thresholds

All six combinations selected 0.51:

  Dataset             Horizon   Selected threshold   2023 macro F1
  ----------------- --------- -------------------- ---------------
  Index only               5m                 0.51          0.3636
  Index only              15m                 0.51          0.3454
  Index only              30m                 0.51          0.3294
  Index + options          5m                 0.51          0.3730
  Index + options         15m                 0.51          0.3556
  Index + options         30m                 0.51          0.3533

### 2024 threshold-policy macro F1

  Dataset             Horizon   Fixed 0.50   Selected 0.51
  ----------------- --------- ------------ ---------------
  Index only               5m       0.3667          0.3668
  Index only              15m       0.3485          0.3542
  Index only              30m       0.3332          0.3485
  Index + options          5m       0.3685          0.3694
  Index + options         15m       0.3457          0.3535
  Index + options         30m       0.3431          0.3520

The selected 0.51 threshold improved 2024 macro F1 over fixed 0.50 in
all six combinations, but the improvements were modest, particularly at
5m.

### Threshold stability finding

The full 2023 threshold sensitivity file showed a relatively narrow
optimum around 0.51:

-   5m curves had 0.51--0.52 within 0.005 macro F1 of the optimum.
-   15m and 30m curves generally had only 0.51 within 0.005 of the
    optimum.

Therefore, 0.51 should not yet be treated as a permanently stable
production threshold. A narrow optimum can be sensitive to probability
shifts.

### V2 audit and distribution observations

-   No duplicate keys in the audited 2023 or 2024 datasets.
-   Probability sums were numerically correct (maximum error
    approximately 2.22e-16).
-   Mean predicted MOVE probability was slightly lower in 2024 than 2023
    across the six combinations.
-   Stage 2 probabilities are produced for all rows during end-to-end
    inference, including actual SIDEWAYS rows, although Stage 2 was
    trained only on actual MOVE rows. Conditional Stage 2 probabilities
    on SIDEWAYS rows are outside its training distribution.

### V2 report files

-   `threshold_robustness_summary_v2.json`
-   `selected_thresholds_2023_v2.csv`
-   `threshold_sensitivity_2023_v2.csv`
-   `threshold_policy_comparison_v2.csv`
-   `threshold_robustness_audit_v2.csv`
-   `temporary_model_training_v2.csv`
-   `predictions_2024_*.csv`
-   `metrics_*.json`

The temporary models were not saved. Existing models and datasets were
not changed.

------------------------------------------------------------------------

## 19. Important scripts --- consolidated inventory

The following are the important script names used in the workflow. They
are listed in logical execution order, not as a claim that every
exploratory script is included.

### A. Index cleaning, features, and validation

  --------------------------------------------------------------------------
  Script                                 Purpose
  -------------------------------------- -----------------------------------
  `build_nifty_features_v1.py`           Build index features and 5m/15m/30m
                                         labels

  `validate_nifty_walkforward_v1.py`     Build and validate chronological
                                         train/validation splits

  `audit_nifty_target_alignment_v1.py`   Verify current/future close and
                                         target alignment
  --------------------------------------------------------------------------

### B. Options data and feature engineering

  -----------------------------------------------------------------------------------
  Script                                          Purpose
  ----------------------------------------------- -----------------------------------
  `build_nifty_options_features_v1.py`            Initial NIFTY options features

  `fix_nifty_options_rolling_windows_v2.py`       Experimental clock-continuity
                                                  correction; not canonical

  `build_nifty_options_features_v4.py`            Accepted canonical options v4
                                                  rolling-window output

  `merge_nifty_index_options_features_v1.py`      Exact timestamp merge of index and
                                                  options features

  `validate_nifty_index_options_features_v1.py`   Merged dataset quality checks

  `audit_nifty_index_options_features_v1.py`      Feature inventory, eligibility, and
                                                  leakage review
  -----------------------------------------------------------------------------------

### C. Matched datasets and labels

  ------------------------------------------------------------------------------------
  Script                                           Purpose
  ------------------------------------------------ -----------------------------------
  `build_nifty_matched_datasets_v1.py`             Matched index-only/options datasets
                                                   for original labels

  `build_nifty_quantile_labels_v3.py`              Leakage-corrected quantile labels
                                                   using 2021--2022 thresholds

  `build_nifty_matched_datasets_v3.py`             Matched datasets for quantile v3

  `build_nifty_two_stage_labels_v1.py`             Create SIDEWAYS/MOVE and
                                                   conditional DOWN/UP labels

  `build_nifty_two_stage_matched_datasets_v1.py`   Create matched Stage 1 and Stage 2
                                                   training datasets
  ------------------------------------------------------------------------------------

### D. Model training

  -----------------------------------------------------------------------------
  Script                                    Purpose
  ----------------------------------------- -----------------------------------
  `train_nifty_lightgbm_matched_v1.py`      Original-label matched LightGBM
                                            models

  `train_nifty_lightgbm_unweighted_v1.py`   Unweighted comparison experiment

  `train_nifty_lightgbm_quantile_v3.py`     Quantile v3 multiclass models

  `train_nifty_two_stage_lightgbm_v1.py`    Main two-stage binary LightGBM
                                            training (12 models)
  -----------------------------------------------------------------------------

### E. End-to-end and threshold evaluation

  ------------------------------------------------------------------------------------------
  Script                                                 Purpose
  ------------------------------------------------------ -----------------------------------
  `evaluate_nifty_two_stage_end_to_end_v1.py`            Initial end-to-end evaluator;
                                                         target-definition mismatch
                                                         identified

  `evaluate_nifty_two_stage_end_to_end_v2.py`            Corrected end-to-end evaluation on
                                                         two-stage labels

  `analyze_nifty_two_stage_threshold_robustness_v1.py`   Initial threshold experiment;
                                                         model-history mismatch identified

  `analyze_nifty_two_stage_threshold_robustness_v2.py`   Corrected same-model 2023 threshold
                                                         selection and 2024 transfer
                                                         evaluation
  ------------------------------------------------------------------------------------------

### Most important training scripts to retain

If keeping a short list of model-training scripts, retain these as the
primary training entry points:

1.  `scripts/train_nifty_lightgbm_matched_v1.py`
2.  `scripts/train_nifty_lightgbm_unweighted_v1.py`
3.  `scripts/train_nifty_lightgbm_quantile_v3.py`
4.  `scripts/train_nifty_two_stage_lightgbm_v1.py`

The latest accepted model architecture experiment is the **two-stage
LightGBM v1**, with threshold robustness V2 as its diagnostic threshold
experiment. This does not mean it has been proven superior for trading.

------------------------------------------------------------------------

## 20. Current project artifacts and folders

Key data:

-   `data/database/nifty_options.duckdb`
-   `data/processed/nifty_index_cleaned/nifty_index_cleaned_final.parquet`
-   `data/processed/nifty_features_v1/`
-   `data/processed/nifty_options_features_v4/`
-   `data/processed/nifty_index_options_features_v1/`
-   `data/processed/nifty_index_options_features_v3/`
-   `data/processed/nifty_index_options_features_v4/`
-   `data/processed/nifty_matched_datasets_v1/`
-   `data/processed/nifty_matched_datasets_v3/`
-   `data/processed/nifty_two_stage_matched_datasets_v1/`

Key model folders:

-   `models/nifty_lightgbm_matched_v1/`
-   `models/nifty_lightgbm_matched_unweighted_v1/`
-   `models/nifty_lightgbm_quantile_v3/`
-   `models/nifty_two_stage_lightgbm_v1/`

Key report folders:

-   `reports/nifty_target_alignment_v1/`
-   `reports/nifty_options_features_v4/`
-   `reports/nifty_index_options_features_v1/`
-   `reports/nifty_matched_datasets_v1/`
-   `reports/nifty_matched_datasets_v3/`
-   `reports/nifty_two_stage_labels_v1/`
-   `reports/nifty_two_stage_matched_datasets_v1/`
-   `reports/nifty_two_stage_lightgbm_v1/`
-   `reports/nifty_two_stage_end_to_end_v2/`
-   `reports/nifty_two_stage_threshold_robustness_v1/`
-   `reports/nifty_two_stage_threshold_robustness_v2/`

------------------------------------------------------------------------

## 21. What has been established --- and what has not

### Established

-   The NIFTY index data was cleaned under explicit normal-session and
    holiday rules.
-   Synthetic bars are identified and excluded from eligible modeling
    observations.
-   Target alignment and forward-return calculations were audited.
-   Options data has useful ATM/near-ATM coverage, but no historical
    bid/ask quotes.
-   Canonical options feature v4 fixes rolling-window clock-gap handling
    while preserving nonrolling features.
-   Index/options merge and matched-sample parity checks passed.
-   Multiple LightGBM baselines and a two-stage model family were
    trained.
-   Quantile label thresholds were corrected to avoid using 2023 data in
    the fit-period threshold calculation.
-   Two-stage labels and matched datasets passed their audits.
-   The corrected threshold robustness V2 experiment used the same
    temporary models for 2023 threshold selection and 2024 evaluation.

### Not established

-   A profitable strategy.
-   A reliable directional edge.
-   Calibrated probabilities suitable for direct position sizing.
-   Realistic historical option fills, bid/ask spreads, or option
    slippage.
-   Performance on a genuinely untouched post-2024 test period.
-   Live-feed publication latency or live execution quality.

Classification metrics such as accuracy, macro F1, balanced accuracy,
and ROC-AUC do not by themselves demonstrate profitability.

------------------------------------------------------------------------

## 22. Recommended next phase at the Phase 1 close (historical recommendation)

The next major phase is a **chronological, cost-aware NIFTY backtest**,
followed by paper trading only if results justify it.

Recommended sequence:

1.  Freeze the current research datasets and model artifacts.
2.  Define signal timing precisely: the current one-minute bar must be
    completed; execution must occur no earlier than the next available
    bar.
3.  Build a walk-forward prediction process that trains only on data
    available before each evaluation period.
4.  Evaluate 5m, 15m, and 30m strategies separately.
5.  Define position overlap, exit rules, stop-loss, daily loss limit,
    and position sizing before evaluating outcomes.
6.  Include brokerage, STT, exchange charges, GST, slippage, and
    realistic execution assumptions.
7.  Benchmark against no-trade and simple index-based strategies.
8.  Report net P&L, maximum drawdown, Sharpe ratio, profit factor, win
    rate, trade count, exposure, and stability by year/regime.
9.  Do not fabricate historical option fills or bid/ask spreads. Start
    with an underlying NIFTY signal-level backtest or obtain defensible
    option quote/execution data.
10. Keep paper trading separate from live trading and require a
    sustained, independently evaluated result before considering live
    use.

**Current conclusion:** substantial data and modeling groundwork is
complete. The two-stage LightGBM approach is the latest architecture
explored, but evidence so far supports further controlled
backtesting---not a claim of a production-ready or profitable predictor.
------------------------------------------------------------------------

# Project status update --- 13 November 2026

This section extends the earlier project report with the work completed
in Phase 2.1 and Phase 2.1.1. Earlier sections are retained as a record
of the original experiments and their results. Where the next-step
recommendation in Section 22 differs from this update, this newer
section is the current project status.

## 23. Phase 2.1 --- NIFTY market regime analysis

### Objective

The objective was to understand whether the existing Phase 1 NIFTY
models behave differently across trend, volatility, momentum and
intraday time-of-day conditions. This was a read-only diagnostic phase:
no models were retrained and no Phase 1 data or artifacts were changed.

### Input and scope

- Canonical merged index/options feature dataset:
  `data/processed/nifty_index_options_features_v1/`
- Six end-to-end predictions from:
  `reports/nifty_two_stage_end_to_end_v2/`
- Existing Phase 1 model inventory from:
  `models/nifty_two_stage_lightgbm_v1/`
- Market scope: 2021-05-24 through 2024-12-31.
- Regular session: 09:15-15:29 IST.
- Market rows: 334,335 across 893 trading days.
- Prediction rows aligned: 438,544 across six model/horizon files.

### Regime definitions

Four independent regime dimensions were calculated from completed
index bars:

1. Trend: UP / DOWN / RANGE / WARMUP, based on trailing 30-minute
   return normalized by trailing realized volatility; thresholds +0.75
   and -0.75.
2. Volatility: LOW / NORMAL / HIGH / WARMUP, comparing trailing
   60-minute realized volatility with the 33rd and 67th percentiles of
   the prior 20 sessions at the same minute of the session, requiring
   at least 10 historical observations.
3. Momentum: POSITIVE / NEGATIVE / NEUTRAL / WARMUP, based on trailing
   5-minute return normalized by trailing volatility; thresholds +0.50
   and -0.50.
4. Time of day: OPENING (09:15-09:59), MORNING (10:00-11:29),
   AFTERNOON (11:30-13:59), CLOSING (14:00-15:29).

Intraday rolling features reset each trading day. Volatility thresholds
use prior sessions and are shifted so the current session does not
contribute to its own historical threshold. Warm-up rows remain
explicitly labelled rather than being silently classified.

### Regime observation counts

| Dimension | Regime | Rows |
|---|---|---:|
| Trend | RANGE | 169,558 |
| Trend | UP | 73,675 |
| Trend | DOWN | 64,312 |
| Trend | WARMUP | 26,790 |
| Volatility | LOW | 106,307 |
| Volatility | HIGH | 102,583 |
| Volatility | NORMAL | 81,960 |
| Volatility | WARMUP | 43,485 |
| Momentum | NEUTRAL | 128,143 |
| Momentum | POSITIVE | 96,197 |
| Momentum | NEGATIVE | 92,135 |
| Momentum | WARMUP | 17,860 |

Time-of-day counts: OPENING 40,185; MORNING 80,190; AFTERNOON
133,770; CLOSING 80,190.

### Phase 2.1 audit result

- 10 checks passed; 0 failed.
- Duplicate market timestamps: 0.
- Duplicate prediction keys: 0.
- Unmatched predictions: 0.
- Synthetic prediction rows: 0.
- All six Phase 1 prediction files were found and aligned.

Main outputs under `reports/nifty_market_regimes_v1/run_*/`:

- `market_regime_features.csv`
- `prediction_regime_alignment.csv`
- `regime_performance_metrics.csv`
- `trend_regime_confusion_matrices.csv`
- `regime_class_distributions.csv`
- `phase1_model_inventory.csv`
- `regime_analysis_audit.csv`
- `regime_analysis_summary.json`

Script: `scripts/analyze_nifty_market_regimes_v1.py`.

### Main observations

- The existing end-to-end hard predictions were still dominated by
  SIDEWAYS, especially at 15m and 30m.
- Some 5m regime slices showed relatively better probability ranking,
  particularly high-volatility and selected momentum/time-of-day
  groups, but the absolute discrimination remained weak.
- Regime-level results are diagnostic. Small groups and the repeatedly
  inspected 2024 validation year must not be treated as independent
  proof of a repeatable edge.

## 24. Phase 2.1.1 --- Probability and directional discrimination audit

### Objective and methodology

This phase investigated whether directional information existed in the
three-class probabilities even when the final argmax prediction was
SIDEWAYS. It used the six existing end-to-end prediction CSVs and the
Phase 2.1 regime file. No model was retrained and no thresholds were
optimised.

Definitions used:

- Directional probability: `max(P(UP), P(DOWN))`.
- Directional class: UP if P(UP) >= P(DOWN), otherwise DOWN.
- Directional margin: `abs(P(UP) - P(DOWN))`.
- Conditional UP probability: `P(UP) / (P(UP) + P(DOWN))`.
- Confidence bands were fixed descriptive bins, not selected by
  optimisation.
- Conditional direction ROC-AUC evaluated UP versus DOWN only, among
  observations whose actual class was UP or DOWN.

### Input and audit results

- Valid prediction rows: 438,544.
- Aligned prediction rows: 438,544.
- Model configurations: 6.
- Horizons: 5m, 15m, 30m.
- Actual-label mismatches between index-only and options variants:
  0 for paired samples.
- Probability sums: maximum absolute error approximately
  2.22e-16 before the script's tiny-drift normalization.
- Negative or non-finite probability values: none.
- Duplicate prediction keys: 0.
- Audit: 11 passed, 0 failed.

### Conditional UP-versus-DOWN ranking

| Horizon | Index-only ROC-AUC | Index + options ROC-AUC |
|---|---:|---:|
| 5m | 0.526170 | 0.545717 |
| 15m | 0.517511 | 0.534587 |
| 30m | 0.496252 | 0.519866 |

The options-enhanced model had higher conditional UP-versus-DOWN AUC
at all three horizons in this 2024 validation sample. The best result
was 0.545717 at 5m. These values are still weak and do not establish a
tradable edge or statistical significance.

Actual directional observations used for this conditional calculation:
5m 34,796; 15m 32,253; 30m 29,251. The actual UP share within these
UP/DOWN-only samples was approximately 50.7%, 50.8% and 50.5%,
respectively.

### Paired index-only versus index + options results

The comparison uses identical timestamps and actual labels.

| Horizon | Paired rows | Index log loss | Options log loss | Index Brier | Options Brier |
|---|---:|---:|---:|---:|---:|
| 5m | 75,949 | 1.001062 | 0.995626 | 0.597049 | 0.593378 |
| 15m | 73,499 | 0.990888 | 0.988916 | 0.589737 | 0.588460 |
| 30m | 69,824 | 0.978684 | 0.974092 | 0.580869 | 0.577575 |

Options minus index log-loss differences were -0.005436 (5m),
-0.001972 (15m), and -0.004592 (30m). Brier score also improved
slightly at all three horizons. Lower log loss and Brier are better.

Hard classification did not materially improve:

| Horizon | Index accuracy | Options accuracy | Index balanced accuracy | Options balanced accuracy |
|---|---:|---:|---:|---:|
| 5m | 0.541850 | 0.541864 | 0.333746 | 0.334024 |
| 15m | 0.561178 | 0.561178 | 0.333333 | 0.333333 |
| 30m | 0.581075 | 0.581075 | 0.333333 | 0.333333 |

### Mean probabilities and SIDEWAYS concentration

| Horizon | Model | Mean P(DOWN) | Mean P(SIDEWAYS) | Mean P(UP) |
|---|---|---:|---:|---:|
| 5m | Index-only | 0.248844 | 0.502393 | 0.248763 |
| 5m | Index + options | 0.233331 | 0.534097 | 0.232571 |
| 15m | Index-only | 0.248756 | 0.502391 | 0.248853 |
| 15m | Index + options | 0.244378 | 0.514290 | 0.241332 |
| 30m | Index-only | 0.248862 | 0.502427 | 0.248710 |
| 30m | Index + options | 0.240079 | 0.521469 | 0.238453 |

The options models assign somewhat more probability to SIDEWAYS and
less to the directional classes on average. This helps explain why
probability scoring improves slightly while argmax classification
remains SIDEWAYS-dominated.

### Phase 2.1.1 outputs

Under `reports/nifty_probability_discrimination_v1/run_*/`:

- `probability_discrimination_summary.json`
- `probability_discrimination_audit.csv`
- `input_file_audit.csv`
- `probability_distribution_summary.csv`
- `directional_confidence_bands.csv`
- `conditional_direction_ranking.csv`
- `class_probability_calibration.csv`
- `overall_and_yearly_metrics.csv`
- `regime_probability_metrics.csv`
- `paired_index_vs_options_comparison.csv`
- `prediction_regime_probability_alignment.csv`

Script: `scripts/analyze_nifty_probability_discrimination_v1.py`.

### Important reporting issue discovered

The uploaded `directional_confidence_bands.csv` contains duplicated
rows for the overall and yearly summaries because the available
prediction sample is 2024 and both groupings represent the same rows.
Some displayed coverage percentages exceed 100% (for example,
1.025435%). This is a reporting duplication, not actual prediction
coverage. The confidence-band output must not be used to infer a
coverage/threshold policy until corrected. In addition, the current
bands start at 0.33 and therefore do not fully describe low directional
probabilities below 0.33.

This is why the next analysis should correct confidence-band accounting
and include the full probability range before drawing conclusions from
confidence-selected subsets.

## 25. Current issues and challenges

The following are the main challenges established by the experiments
so far. They are grouped by data, target, model, validation and trading
readiness.

### A. Data limitations

1. **No historical bid/ask quotes.** The options dataset does not
   provide defensible historical bid/ask prices. This prevents reliable
   reconstruction of option spread, executable entry/exit prices and
   slippage.
2. **No complete options microstructure.** Historical order-book depth,
   trade aggressor, queue position and dependable order-flow information
   are not available in the current dataset.
3. **IV and Greeks are unavailable as observed fields.** They cannot be
   reliably recovered from the current OHLC/OI/volume data alone
   without assumptions about volatility, rates, dividends and
   contract-specific market inputs.
4. **Volume semantics need care.** The observed volume behaviour
   suggests per-bar volume rather than a cumulative counter, but the
   provider's semantics have not been independently confirmed.
5. **Provider publication latency is unverified.** The analysis assumes
   the minute bar is available after its interval completes. Actual
   feed arrival and publication delays must be measured before live
   prediction timing can be certified.
6. **Options coverage is not complete at every minute.** ATM pairing
   and options feature availability are high but not perfect. Missing
   values must remain missing; they must not be forward-filled into
   synthetic observations.

### B. Target and label challenges

1. **Market direction is noisy at 5m/15m/30m.** Short-horizon moves
   contain substantial noise and are difficult to separate from
   sideways movement.
2. **Label boundaries affect class balance.** Volatility-scaled and
   quantile labels describe different target definitions. Their
   metrics must not be compared as if the labels were interchangeable.
3. **Class imbalance encourages SIDEWAYS predictions.** Unweighted
   models collapsed heavily toward SIDEWAYS. Balanced weighting
   increased directional predictions but did not produce strong
   directional discrimination.
4. **The target is not a trade outcome.** Correctly predicting an
   index direction does not guarantee a profitable CE/PE trade after
   premium decay, spread, fees and slippage.
5. **Target horizon and decision timing must stay aligned.** Source
   timestamps mark the beginning of each minute bar; prediction is
   only after the bar completes. Actual live feed latency still needs
   verification.

### C. Model and probability challenges

1. **Hard predictions collapse to SIDEWAYS.** The end-to-end models
   often predict SIDEWAYS for nearly all observations, particularly
   at 15m and 30m. Accuracy is therefore misleading when viewed alone.
2. **Directional AUC remains weak.** The best current conditional
   UP-versus-DOWN AUC is approximately 0.5457 (5m index + options),
   which is only modestly above random ranking.
3. **Options improve probability scores only modestly.** Paired log
   loss and Brier scores improve at all horizons, but hard accuracy
   and balanced accuracy barely move.
4. **Probability calibration is not yet established.** The existing
   probabilities should not be used directly for position sizing or
   confidence claims until calibration is evaluated and corrected.
5. **Two-stage distribution mismatch.** Stage 2 was trained only on
   actual MOVE observations but, during end-to-end inference, its
   conditional direction probability is evaluated on all observations,
   including SIDEWAYS cases. Those Stage 2 inputs are outside its
   training target population; the end-to-end combination needs careful
   validation.
6. **Threshold sensitivity.** The experimental 0.51 MOVE threshold
   showed a narrow performance peak. It is not a production threshold
   and must not be repeatedly tuned on the same 2024 validation data.
7. **Regime slices can be small.** Splitting by trend, volatility,
   momentum, time of day, year and horizon creates many groups. Small
   sample counts can make apparently strong metrics unstable.
8. **Complexity is not the bottleneck yet.** A larger neural network or
   transformer is not justified until a repeatable information edge
   is demonstrated with the current features and careful validation.

### D. Validation and research-design challenges

1. **2024 is no longer an untouched test set.** It has been used for
   repeated diagnostics, comparisons and threshold experiments. It is
   useful for development analysis only.
2. **No untouched post-2024 holdout has been evaluated.** A future
   chronological period is required to establish generalisation.
3. **Regime and probability analyses are diagnostic.** They reveal
   where a model may behave differently, but do not prove causality,
   stability or future performance.
4. **Statistical significance has not yet been tested.** The paired
   options improvements need confidence intervals and paired tests;
   small metric differences may be sampling noise.
5. **Confidence-band reporting needs correction.** The current report
   duplicates overall/year rows for the 2024-only sample and has
   coverage values above 100%; the bands also omit probabilities below
   0.33.
6. **Multiple comparisons create false discoveries.** Testing many
   regimes, horizons, thresholds and features increases the chance of
   finding a seemingly good subgroup by chance. Any selected finding
   needs a separate untouched evaluation.

### E. Trading and deployment challenges

1. **No cost-aware backtest has established net profitability.**
   Brokerage, STT, exchange charges, GST, spread, slippage and fill
   assumptions have not been integrated into a validated strategy.
2. **Option-buying adds premium-specific risks.** Even correct NIFTY
   direction can lose money if the move is too small or slow, implied
   volatility falls, or time decay and spread overwhelm the move.
3. **Contract selection is not solved.** Strike, expiry, liquidity,
   premium, spread and time-to-expiry constraints need their own
   decision layer.
4. **Live operational reliability is untested.** Feed gaps, delayed
   bars, stale quotes, market halts, reconnect behaviour, clock
   synchronisation and risk controls need validation.
5. **Paper trading is not complete.** No sustained paper-trading record
   currently establishes live signal quality or execution behaviour.

## 26. Updated roadmap and next phase

### Immediate next phase: Phase 2.1.2 --- calibration and statistical
robustness

Before adding more features or training new models, correct and test
whether the modest probability improvements are statistically reliable.

Required work:

1. Correct confidence-band duplication and calculate coverage using
   unique prediction rows.
2. Cover the complete probability range, including low directional
   probability observations below 0.33.
3. Report class-wise calibration for DOWN, SIDEWAYS and UP.
4. Evaluate conditional UP/DOWN calibration separately from the
   three-class forecast.
5. Calculate confidence intervals for conditional directional AUC.
6. Compare index-only and index + options on paired timestamps using
   paired statistical procedures and confidence intervals.
7. Show 2023 and 2024 separately when predictions exist; do not select
   thresholds from 2024.
8. Preserve all existing Phase 1 and Phase 2.1/2.1.1 artifacts.

### After Phase 2.1.2

1. Decide whether the options-enhanced 5m model has sufficiently
   repeatable directional information to justify further experiments.
2. If signal quality is weak, revisit features and target definitions
   before increasing model complexity.
3. Obtain a genuinely untouched future chronological holdout.
4. Build a signal-level NIFTY underlying backtest first, with realistic
   timing and costs.
5. Develop the CE/PE contract decision layer only after underlying
   directional quality and options execution data are adequate.
6. Paper trade before considering any live orders.

### Current overall conclusion

The project has completed substantial data cleaning, feature
engineering, target audits, model training and diagnostic evaluation.
Phase 2.1 passed its regime-alignment checks. Phase 2.1.1 passed its
probability-data checks and found a modest options-enhanced improvement
in conditional directional ranking and probability scores. However,
hard predictions remain SIDEWAYS-dominated, directional discrimination
is weak, confidence reporting needs correction, and statistical
robustness has not yet been established.

The project does **not** yet have a proven reliable directional edge,
calibrated production probabilities, a profitable CE/PE strategy or a
validated live deployment. The immediate priority is probability
calibration and statistical robustness, not another model architecture
or threshold search.

