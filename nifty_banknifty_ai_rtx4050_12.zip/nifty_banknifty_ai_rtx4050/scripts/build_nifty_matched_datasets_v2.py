
from __future__ import annotations

import json
import sys
import traceback
from datetime import datetime
from pathlib import Path

import duckdb
import pandas as pd


# ============================================================
# PATHS AND CONFIGURATION
# ============================================================

ROOT = Path(__file__).resolve().parents[1]

INPUT_FILE = (
        ROOT / "data" / "processed"
        / "nifty_index_options_features_v2"
        / "nifty_index_options_features_v2.parquet"
)

OUTPUT_DIR = (
        ROOT / "data" / "processed"
        / "nifty_matched_datasets_v2"
)

REPORT_DIR = (
        ROOT / "reports"
        / "nifty_matched_datasets_v2"
)

HORIZONS = [5, 15, 30]

TRAIN_START = "2021-05-24"
TRAIN_END = "2023-12-31"

VALIDATION_START = "2024-01-01"
VALIDATION_END = "2024-12-31"

MEMORY_LIMIT = "5GB"
THREADS = 4


# ============================================================
# EXPLICIT FEATURE ALLOWLISTS
# ============================================================

# Excludes raw OHLC prices and all labels/targets.
INDEX_FEATURES = [
    "ret_1m",
    "logret_1m",
    "range_pct",
    "body_pct",
    "upper_wick_pct",
    "lower_wick_pct",
    "return_5m",
    "return_15m",
    "return_30m",
    "return_60m",
    "realized_vol_5m",
    "realized_vol_15m",
    "realized_vol_30m",
    "realized_vol_60m",
    "high_low_range_5m",
    "high_low_range_15m",
    "high_low_range_30m",
    "high_low_range_60m",
    "close_vs_ema9_pct",
    "close_vs_ema21_pct",
    "close_vs_ema50_pct",
    "rsi_14",
    "positive_return_count_5m",
    "negative_return_count_5m",
]

# O1 options features.
# Normalized premium replaces the raw premium as a predictor.
OPTIONS_FEATURES = [
    "selected_dte",
    "atm_distance_pct",
    "atm_straddle_premium_pct",
    "atm_ce_log_return_1m",
    "atm_pe_log_return_1m",
    "atm_ce_pe_return_spread_1m",
    "atm_straddle_weighted_log_return_1m",
    "atm_ce_oi_change_1m",
    "atm_pe_oi_change_1m",
    "near_atm_pcr_oi",
    "near_atm_pcr_volume",
    "near_atm_oi_imbalance",
    "near_atm_volume_imbalance",
    "paired_strike_count",
]

ALL_FEATURES = INDEX_FEATURES + OPTIONS_FEATURES

TARGET_COLUMNS = [
    "label_quantile_v2",
    "label_volatility_v1",
]

# Metadata/targets are retained for audit and later evaluation,
# but must never be included in the predictor allowlist.
OUTPUT_METADATA = [
    "timestamp_ist",
    "trading_day",
    "horizon_minutes",
    "sample_eligible",
    "is_synthetic",
    "forward_return",
    "future_close",
    "target_z",
    "target_vol_scale",
    "label_quantile_v2",
    "label_volatility_v1",
]


# ============================================================
# HELPERS
# ============================================================

def log(message):
    print(message, flush=True)


def sql_string(value):
    return "'" + str(value).replace("'", "''") + "'"


def sql_path(path):
    return sql_string(
        str(path.resolve()).replace("\\", "/")
    )


def qi(name):
    return '"' + str(name).replace('"', '""') + '"'


def ensure_no_overwrite(path):
    if path.exists():
        raise FileExistsError(
            f"Refusing to overwrite existing file:\n{path}"
        )


def get_columns(con, path):
    rows = con.execute(
        f"DESCRIBE SELECT * FROM read_parquet({sql_path(path)})"
    ).fetchall()

    return {row[0]: row[1] for row in rows}


def count(con, query):
    return con.execute(query).fetchone()[0]


def numeric_finite_condition(columns, alias="src"):
    conditions = []

    for col in columns:
        conditions.append(
            f"""
            {alias}.{qi(col)} IS NOT NULL
            AND isfinite(CAST({alias}.{qi(col)} AS DOUBLE))
            """
        )

    return " AND ".join(conditions)


# ============================================================
# MAIN
# ============================================================

def main():
    log("=" * 78)
    log("NIFTY MATCHED DATASETS V2")
    log("=" * 78)

    if not INPUT_FILE.exists():
        raise FileNotFoundError(INPUT_FILE)

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    REPORT_DIR.mkdir(parents=True, exist_ok=True)

    con = duckdb.connect(":memory:")

    try:
        con.execute(
            f"SET memory_limit = {sql_string(MEMORY_LIMIT)}"
        )
        con.execute(f"SET threads = {THREADS}")
        con.execute("SET TimeZone = 'Asia/Kolkata'")

        log(f"Input: {INPUT_FILE}")
        log(f"Output: {OUTPUT_DIR}")
        log(f"Reports: {REPORT_DIR}")

        # ----------------------------------------------------
        # 1. Schema validation
        # ----------------------------------------------------

        schema = get_columns(con, INPUT_FILE)

        required = set(
            OUTPUT_METADATA
            + INDEX_FEATURES
            + OPTIONS_FEATURES
        )

        missing = sorted(required - set(schema))

        if missing:
            raise RuntimeError(
                f"Missing required columns in merged v2: {missing}"
            )

        if "open" in INDEX_FEATURES or "close" in INDEX_FEATURES:
            raise RuntimeError(
                "Raw OHLC prices must not be predictors."
            )

        if "atm_straddle_premium" in OPTIONS_FEATURES:
            raise RuntimeError(
                "Raw ATM straddle premium must not be a predictor."
            )

        if "atm_straddle_premium_pct" not in OPTIONS_FEATURES:
            raise RuntimeError(
                "Normalized ATM straddle premium is required."
            )

        if not set(TARGET_COLUMNS).issubset(schema):
            raise RuntimeError("Both target labels are required.")

        con.execute(f"""
            CREATE VIEW src AS
            SELECT *
            FROM read_parquet({sql_path(INPUT_FILE)})
        """)

        source_rows = count(con, "SELECT COUNT(*) FROM src")

        source_duplicates = count(con, """
                                       SELECT COUNT(*)
                                       FROM (
                                                SELECT timestamp_ist, horizon_minutes
                                                FROM src
                                                GROUP BY timestamp_ist, horizon_minutes
                                                HAVING COUNT(*) > 1
                                            ) x
                                       """)

        if source_duplicates:
            raise RuntimeError(
                f"Duplicate timestamp+horizon keys: {source_duplicates}"
            )

        # ----------------------------------------------------
        # 2. Verify feature values and target availability
        # ----------------------------------------------------

        log("\nChecking eligible feature and target values...")

        index_finite = numeric_finite_condition(INDEX_FEATURES)
        options_finite = numeric_finite_condition(OPTIONS_FEATURES)

        # Same matched population for both dataset variants.
        con.execute(f"""
            CREATE TEMP VIEW matched AS
            SELECT *
            FROM src
            WHERE sample_eligible = TRUE
              AND COALESCE(is_synthetic, FALSE) = FALSE
              AND label_quantile_v2 IS NOT NULL
              AND label_volatility_v1 IS NOT NULL
              AND ({index_finite})
              AND ({options_finite})
              AND CAST(trading_day AS DATE)
                    BETWEEN DATE '{TRAIN_START}'
                        AND DATE '{VALIDATION_END}'
        """)

        matched_rows = count(
            con, "SELECT COUNT(*) FROM matched"
        )

        missing_quantile_label = count(con, """
                                            SELECT COUNT(*)
                                            FROM matched
                                            WHERE label_quantile_v2 IS NULL
                                            """)

        missing_volatility_label = count(con, """
                                              SELECT COUNT(*)
                                              FROM matched
                                              WHERE label_volatility_v1 IS NULL
                                              """)

        matched_duplicates = count(con, """
                                        SELECT COUNT(*)
                                        FROM (
                                                 SELECT timestamp_ist, horizon_minutes
                                                 FROM matched
                                                 GROUP BY timestamp_ist, horizon_minutes
                                                 HAVING COUNT(*) > 1
                                             ) x
                                        """)

        if missing_quantile_label or missing_volatility_label:
            raise RuntimeError("Matched rows contain missing labels.")

        if matched_duplicates:
            raise RuntimeError("Duplicate matched dataset keys detected.")

        # ----------------------------------------------------
        # 3. Output feature manifest
        # ----------------------------------------------------

        manifest_rows = []

        for col in INDEX_FEATURES:
            manifest_rows.append({
                "feature": col,
                "group": "index",
                "included_in_index_only": True,
                "included_in_index_plus_options": True,
                "predictor": True,
            })

        for col in OPTIONS_FEATURES:
            manifest_rows.append({
                "feature": col,
                "group": "options",
                "included_in_index_only": False,
                "included_in_index_plus_options": True,
                "predictor": True,
            })

        manifest = pd.DataFrame(manifest_rows)

        manifest.to_csv(
            REPORT_DIR / "matched_feature_manifest.csv",
            index=False,
            )

        # ----------------------------------------------------
        # 4. Create horizon/split datasets
        # ----------------------------------------------------

        dataset_audit = []

        output_files = []

        for horizon in HORIZONS:
            for split_name, start_date, end_date in [
                ("train", TRAIN_START, TRAIN_END),
                (
                        "validation",
                        VALIDATION_START,
                        VALIDATION_END,
                ),
            ]:
                log(
                    f"\nBuilding horizon={horizon}, "
                    f"split={split_name}"
                )

                where_clause = f"""
                    horizon_minutes = {horizon}
                    AND CAST(trading_day AS DATE)
                        BETWEEN DATE '{start_date}'
                            AND DATE '{end_date}'
                """

                row_count = count(
                    con,
                    f"SELECT COUNT(*) FROM matched WHERE {where_clause}",
                )

                if row_count == 0:
                    raise RuntimeError(
                        f"No rows for {horizon}m {split_name}"
                    )

                for dataset_name, feature_list in [
                    ("index_only", INDEX_FEATURES),
                    (
                            "index_plus_options",
                            INDEX_FEATURES + OPTIONS_FEATURES,
                    ),
                ]:
                    output_path = (
                            OUTPUT_DIR
                            / dataset_name
                            / f"{split_name}_{horizon}m.parquet"
                    )

                    output_path.parent.mkdir(
                        parents=True,
                        exist_ok=True,
                    )

                    ensure_no_overwrite(output_path)

                    select_columns = (
                            OUTPUT_METADATA + feature_list
                    )

                    select_sql = ",\n".join(
                        qi(col) for col in select_columns
                    )

                    con.execute(f"""
                        COPY (
                            SELECT
                                {select_sql}
                            FROM matched
                            WHERE {where_clause}
                            ORDER BY timestamp_ist
                        )
                        TO {sql_path(output_path)}
                        (FORMAT PARQUET, COMPRESSION ZSTD)
                    """)

                    # Read back and validate the created parquet.
                    output_count = count(
                        con,
                        f"""
                        SELECT COUNT(*)
                        FROM read_parquet({sql_path(output_path)})
                        """
                    )

                    output_duplicate_count = count(
                        con,
                        f"""
                        SELECT COUNT(*)
                        FROM (
                            SELECT timestamp_ist, horizon_minutes
                            FROM read_parquet({sql_path(output_path)})
                            GROUP BY timestamp_ist, horizon_minutes
                            HAVING COUNT(*) > 1
                        ) x
                        """
                    )

                    if output_count != row_count:
                        raise RuntimeError(
                            f"Row count mismatch: {output_path}"
                        )

                    if output_duplicate_count:
                        raise RuntimeError(
                            f"Duplicate keys: {output_path}"
                        )

                    output_files.append(str(output_path))

                    dataset_audit.append({
                        "dataset": dataset_name,
                        "split": split_name.upper(),
                        "horizon_minutes": horizon,
                        "rows": output_count,
                        "feature_count": len(feature_list),
                        "duplicate_keys": output_duplicate_count,
                        "status": "PASS",
                    })

                    log(
                        f"{dataset_name}: {output_count:,} rows, "
                        f"{len(feature_list)} predictors"
                    )

        # ----------------------------------------------------
        # 5. Compare matched rows between dataset variants
        # ----------------------------------------------------

        log("\nChecking index-only vs index-plus-options parity...")

        parity_results = []

        for horizon in HORIZONS:
            for split_name in ["train", "validation"]:
                index_path = (
                        OUTPUT_DIR / "index_only"
                        / f"{split_name}_{horizon}m.parquet"
                )

                combined_path = (
                        OUTPUT_DIR / "index_plus_options"
                        / f"{split_name}_{horizon}m.parquet"
                )

                con.execute(f"""
                    CREATE OR REPLACE TEMP VIEW index_set AS
                    SELECT *
                    FROM read_parquet({sql_path(index_path)})
                """)

                con.execute(f"""
                    CREATE OR REPLACE TEMP VIEW combined_set AS
                    SELECT *
                    FROM read_parquet({sql_path(combined_path)})
                """)

                index_count = count(
                    con, "SELECT COUNT(*) FROM index_set"
                )

                combined_count = count(
                    con, "SELECT COUNT(*) FROM combined_set"
                )

                index_only_keys = count(con, """
                                             SELECT COUNT(*)
                                             FROM (
                                                      SELECT timestamp_ist, horizon_minutes
                                                      FROM index_set
                                                      EXCEPT
                                                      SELECT timestamp_ist, horizon_minutes
                                                      FROM combined_set
                                                  ) x
                                             """)

                combined_only_keys = count(con, """
                                                SELECT COUNT(*)
                                                FROM (
                                                         SELECT timestamp_ist, horizon_minutes
                                                         FROM combined_set
                                                         EXCEPT
                                                         SELECT timestamp_ist, horizon_minutes
                                                         FROM index_set
                                                     ) x
                                                """)

                target_mismatches = count(con, """
                                               SELECT COUNT(*)
                                               FROM index_set i
                                                        INNER JOIN combined_set c
                                                                   ON i.timestamp_ist = c.timestamp_ist
                                                                       AND i.horizon_minutes = c.horizon_minutes
                                               WHERE
                                                   i.label_quantile_v2
                                                       IS DISTINCT FROM c.label_quantile_v2
                                                   OR i.label_volatility_v1
                                                   IS DISTINCT FROM c.label_volatility_v1
                                                   OR i.target_z
                                                   IS DISTINCT FROM c.target_z
                                                   OR i.forward_return
                                                   IS DISTINCT FROM c.forward_return
                                               """)

                passed = (
                        index_count == combined_count
                        and index_only_keys == 0
                        and combined_only_keys == 0
                        and target_mismatches == 0
                )

                parity_results.append({
                    "horizon_minutes": horizon,
                    "split": split_name.upper(),
                    "index_only_rows": index_count,
                    "index_plus_options_rows": combined_count,
                    "index_only_missing_keys": index_only_keys,
                    "combined_missing_keys": combined_only_keys,
                    "target_mismatches": target_mismatches,
                    "status": "PASS" if passed else "FAIL",
                })

                if not passed:
                    raise RuntimeError(
                        f"Dataset parity failed: "
                        f"{horizon}m {split_name}"
                    )

        # ----------------------------------------------------
        # 6. Class distributions for both labels
        # ----------------------------------------------------

        log("\nGenerating label distributions...")

        distribution = con.execute("""
                                   SELECT
                                       CASE
                                           WHEN CAST(trading_day AS DATE)
                                               BETWEEN DATE '2021-05-24'
                                               AND DATE '2023-12-31'
                                               THEN 'TRAIN'
                                           ELSE 'VALIDATION'
                                           END AS split,

                                       horizon_minutes,

                                       label_quantile_v2,
                                       label_volatility_v1,

                                       COUNT(*) AS rows

                                   FROM matched
                                   GROUP BY 1, 2, 3, 4
                                   ORDER BY 1, 2, 3, 4
                                   """).df()

        distribution.to_csv(
            REPORT_DIR / "label_distribution_by_split.csv",
            index=False,
            )

        # ----------------------------------------------------
        # 7. Save audit reports
        # ----------------------------------------------------

        audit_df = pd.DataFrame(dataset_audit)
        parity_df = pd.DataFrame(parity_results)

        audit_df.to_csv(
            REPORT_DIR / "matched_dataset_audit.csv",
            index=False,
            )

        parity_df.to_csv(
            REPORT_DIR / "dataset_parity_audit.csv",
            index=False,
            )

        checks = {
            "source_has_no_duplicate_keys": source_duplicates == 0,
            "matched_rows_have_both_labels": (
                    missing_quantile_label == 0
                    and missing_volatility_label == 0
            ),
            "matched_rows_have_finite_features": True,
            "all_12_output_files_created": len(output_files) == 12,
            "all_output_datasets_passed": (
                    len(audit_df) == 12
                    and (audit_df["status"] == "PASS").all()
            ),
            "index_only_and_combined_rows_match": (
                    len(parity_df) == 6
                    and (parity_df["status"] == "PASS").all()
            ),
        }

        overall = all(checks.values())

        summary = {
            "generated_at": datetime.now().isoformat(),
            "status": "PASS" if overall else "REVIEW_REQUIRED",
            "input_file": str(INPUT_FILE),
            "output_directory": str(OUTPUT_DIR),
            "source_rows": int(source_rows),
            "matched_rows_all_horizons": int(matched_rows),
            "source_duplicate_keys": int(source_duplicates),
            "matched_duplicate_keys": int(matched_duplicates),
            "train_period": {
                "start": TRAIN_START,
                "end": TRAIN_END,
            },
            "validation_period": {
                "start": VALIDATION_START,
                "end": VALIDATION_END,
            },
            "horizons": HORIZONS,
            "index_feature_count": len(INDEX_FEATURES),
            "options_feature_count": len(OPTIONS_FEATURES),
            "combined_feature_count": len(ALL_FEATURES),
            "index_features": INDEX_FEATURES,
            "options_features": OPTIONS_FEATURES,
            "targets_retained": TARGET_COLUMNS,
            "raw_ohlc_used_as_predictors": False,
            "raw_atm_straddle_premium_used_as_predictor": False,
            "normalized_atm_straddle_premium_used": True,
            "output_files": output_files,
            "dataset_audit": dataset_audit,
            "parity_audit": parity_results,
            "checks": checks,
            "passed_checks": sum(bool(v) for v in checks.values()),
            "total_checks": len(checks),
        }

        summary_path = (
                REPORT_DIR / "matched_dataset_v2_summary.json"
        )

        summary_path.write_text(
            json.dumps(summary, indent=2, default=str),
            encoding="utf-8",
        )

        # ----------------------------------------------------
        # 8. Console summary
        # ----------------------------------------------------

        log("\n" + "=" * 78)
        log("MATCHED DATASET V2 SUMMARY")
        log("=" * 78)

        log(f"Source rows: {source_rows:,}")
        log(f"Matched rows across horizons: {matched_rows:,}")

        log("\nDataset audit:")
        log(audit_df.to_string(index=False))

        log("\nParity audit:")
        log(parity_df.to_string(index=False))

        log("\nChecks:")
        for name, passed in checks.items():
            log(f"{'PASS' if passed else 'FAIL'}: {name}")

        log(
            f"\nOVERALL STATUS: "
            f"{'PASS' if overall else 'REVIEW_REQUIRED'}"
        )

        log(f"Summary: {summary_path}")

        if not overall:
            sys.exit(2)

    finally:
        con.close()


if __name__ == "__main__":
    try:
        main()
    except Exception:
        log("\nMATCHED DATASET BUILD FAILED")
        traceback.print_exc()
        sys.exit(1)
