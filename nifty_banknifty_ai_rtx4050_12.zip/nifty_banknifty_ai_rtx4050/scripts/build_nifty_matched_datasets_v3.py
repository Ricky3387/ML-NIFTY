
from pathlib import Path
from datetime import datetime, timezone
import json
import sys

import duckdb
import pandas as pd


# ============================================================
# CONFIGURATION
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parents[1]

INPUT_FILE = (
        PROJECT_ROOT
        / "data"
        / "processed"
        / "nifty_index_options_features_v3"
        / "nifty_index_options_features_v3.parquet"
)

OUTPUT_ROOT = (
        PROJECT_ROOT
        / "data"
        / "processed"
        / "nifty_matched_datasets_v3"
)

REPORT_DIR = (
        PROJECT_ROOT
        / "reports"
        / "nifty_matched_datasets_v3"
)

HORIZONS = [5, 15, 30]

TRAIN_START = "2021-05-24"
TRAIN_END = "2023-12-31"

VALIDATION_START = "2024-01-01"
VALIDATION_END = "2024-12-31"

# Prevent accidental overwriting of existing outputs.
ALLOW_OVERWRITE = False


# ============================================================
# FEATURE DEFINITIONS
# ============================================================

INDEX_FEATURES = [
    "ret_1m",
    "logret_1m",
    "range_pct",
    "body_pct",
    "upper_wick_pct",
    "lower_wick_pct",
    "return_5m",
    "return_15m",
    "return_30m",
    "return_60m",
    "realized_vol_5m",
    "realized_vol_15m",
    "realized_vol_30m",
    "realized_vol_60m",
    "high_low_range_5m",
    "high_low_range_15m",
    "high_low_range_30m",
    "high_low_range_60m",
    "close_vs_ema9_pct",
    "close_vs_ema21_pct",
    "close_vs_ema50_pct",
    "rsi_14",
    "positive_return_count_5m",
    "negative_return_count_5m",
]

OPTIONS_FEATURES = [
    "selected_dte",
    "atm_distance_pct",
    "atm_straddle_premium_pct",
    "atm_ce_log_return_1m",
    "atm_pe_log_return_1m",
    "atm_ce_pe_return_spread_1m",
    "atm_straddle_weighted_log_return_1m",
    "atm_ce_oi_change_1m",
    "atm_pe_oi_change_1m",
    "near_atm_pcr_oi",
    "near_atm_pcr_volume",
    "near_atm_oi_imbalance",
    "near_atm_volume_imbalance",
    "paired_strike_count",
]

ALL_FEATURES = INDEX_FEATURES + OPTIONS_FEATURES

METADATA_COLUMNS = [
    "timestamp_ist",
    "trading_day",
    "horizon_minutes",
    "target_z",
    "forward_return",
    "future_close",
    "sample_eligible",
    "is_synthetic",
    "label_quantile_v3",
    "label_volatility_v1",
    "quantile_lower_v3",
    "quantile_upper_v3",
]

# These are not model predictors.
OUTPUT_COLUMNS = METADATA_COLUMNS + ALL_FEATURES


# ============================================================
# HELPERS
# ============================================================

def sql_path(path: Path) -> str:
    value = str(path).replace("\\", "/").replace("'", "''")
    return f"'{value}'"


def ensure_columns(con, path, required):
    schema = con.execute(
        f"""
        DESCRIBE
        SELECT *
        FROM read_parquet({sql_path(path)})
        """
    ).fetchdf()

    available = set(schema["column_name"].tolist())

    missing = [column for column in required if column not in available]

    if missing:
        raise RuntimeError(
            f"Input is missing required columns: {missing}"
        )

    return schema


def check_output_paths(paths):
    if ALLOW_OVERWRITE:
        return

    existing = [str(path) for path in paths if path.exists()]

    if existing:
        raise FileExistsError(
            "Some v3 outputs already exist. Refusing to overwrite:\n"
            + "\n".join(existing)
            + "\nRemove only the generated v3 outputs or set "
              "ALLOW_OVERWRITE = True intentionally."
        )


def quote_columns(columns, prefix=None):
    if prefix:
        return ",\n".join(
            f"{prefix}.{column}" for column in columns
        )

    return ",\n".join(columns)


def validate_feature_lists():
    if len(INDEX_FEATURES) != 24:
        raise RuntimeError("Expected exactly 24 index features.")

    if len(OPTIONS_FEATURES) != 14:
        raise RuntimeError("Expected exactly 14 options features.")

    if len(set(ALL_FEATURES)) != len(ALL_FEATURES):
        raise RuntimeError("Duplicate feature names found.")

    if set(METADATA_COLUMNS).intersection(ALL_FEATURES):
        raise RuntimeError("A metadata column is also a predictor.")


# ============================================================
# MAIN
# ============================================================

def main():

    print("=" * 80)
    print("NIFTY MATCHED DATASETS V3")
    print("LEAKAGE-CONTROLLED QUANTILE LABELS")
    print("=" * 80)

    validate_feature_lists()

    if not INPUT_FILE.exists():
        raise FileNotFoundError(
            f"Input file not found:\n{INPUT_FILE}"
        )

    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    REPORT_DIR.mkdir(parents=True, exist_ok=True)

    output_files = []

    for dataset_name in ["index_only", "index_plus_options"]:
        for split in ["train", "validation"]:
            for horizon in HORIZONS:
                output_files.append(
                    OUTPUT_ROOT
                    / dataset_name
                    / f"{split}_{horizon}m.parquet"
                )

    report_files = [
        REPORT_DIR / "matched_dataset_v3_summary.json",
        REPORT_DIR / "matched_feature_manifest.csv",
        REPORT_DIR / "matched_dataset_audit.csv",
        REPORT_DIR / "dataset_parity_audit.csv",
        REPORT_DIR / "label_distribution_by_split.csv",
        ]

    check_output_paths(output_files + report_files)

    con = duckdb.connect(database=":memory:")

    try:

        # ----------------------------------------------------
        # 1. Schema validation
        # ----------------------------------------------------

        print("\n[1/7] Validating input schema...")

        required_columns = OUTPUT_COLUMNS

        schema = ensure_columns(
            con,
            INPUT_FILE,
            required_columns,
        )

        input_columns = schema["column_name"].tolist()

        input_sql = sql_path(INPUT_FILE)

        source_stats = con.execute(
            f"""
            SELECT
                COUNT(*) AS rows,
                COUNT(DISTINCT
                    CAST(timestamp_ist AS VARCHAR)
                    || '|'
                    || CAST(horizon_minutes AS VARCHAR)
                ) AS unique_keys
            FROM read_parquet({input_sql})
            """
        ).fetchdf().iloc[0]

        source_rows = int(source_stats["rows"])

        if source_rows != int(source_stats["unique_keys"]):
            raise RuntimeError(
                "Source contains duplicate timestamp+horizon keys."
            )

        print(f"Source rows: {source_rows:,}")

        # ----------------------------------------------------
        # 2. Validate v3 label availability
        # ----------------------------------------------------

        print("\n[2/7] Validating v3 labels...")

        label_check = con.execute(
            f"""
            SELECT
                COUNT(*) FILTER (
                    WHERE sample_eligible = TRUE
                      AND label_quantile_v3 IS NULL
                ) AS eligible_missing_v3,

                COUNT(*) FILTER (
                    WHERE sample_eligible = FALSE
                      AND label_quantile_v3 IS NOT NULL
                ) AS ineligible_with_v3,

                COUNT(*) FILTER (
                    WHERE sample_eligible = TRUE
                      AND label_volatility_v1 IS NULL
                ) AS eligible_missing_volatility

            FROM read_parquet({input_sql})
            """
        ).fetchdf().iloc[0]

        if int(label_check["eligible_missing_v3"]) != 0:
            raise RuntimeError(
                "Eligible rows have missing quantile v3 labels."
            )

        if int(label_check["ineligible_with_v3"]) != 0:
            raise RuntimeError(
                "Ineligible rows have quantile v3 labels."
            )

        if int(label_check["eligible_missing_volatility"]) != 0:
            raise RuntimeError(
                "Eligible rows have missing volatility labels."
            )

        # ----------------------------------------------------
        # 3. Construct common matched sample
        # ----------------------------------------------------

        print("\n[3/7] Building common matched sample...")

        # Both index-only and index-plus-options use this exact
        # same sample. This prevents sample-selection bias in
        # the comparison between the two model variants.

        non_null_conditions = [
            f"{column} IS NOT NULL"
            for column in ALL_FEATURES
        ]

        finite_conditions = [
            f"isfinite(CAST({column} AS DOUBLE))"
            for column in ALL_FEATURES
        ]

        feature_conditions = (
                non_null_conditions + finite_conditions
        )

        common_filter = " AND ".join(feature_conditions)

        con.execute(
            f"""
            CREATE TEMP TABLE matched_common AS

            SELECT
                {quote_columns(OUTPUT_COLUMNS)}

            FROM read_parquet({input_sql})

            WHERE
                sample_eligible = TRUE
                AND is_synthetic = FALSE

                AND label_quantile_v3 IS NOT NULL
                AND label_volatility_v1 IS NOT NULL

                AND CAST(trading_day AS DATE)
                    BETWEEN DATE '{TRAIN_START}'
                    AND DATE '{VALIDATION_END}'

                AND ({common_filter})
            """
        )

        common_stats = con.execute(
            """
            SELECT
                COUNT(*) AS rows,

                COUNT(DISTINCT
                    CAST(timestamp_ist AS VARCHAR)
                    || '|'
                    || CAST(horizon_minutes AS VARCHAR)
                ) AS unique_keys

            FROM matched_common
            """
        ).fetchdf().iloc[0]

        common_rows = int(common_stats["rows"])

        if common_rows != int(common_stats["unique_keys"]):
            raise RuntimeError(
                "Matched sample contains duplicate keys."
            )

        print(f"Matched rows across horizons: {common_rows:,}")

        # ----------------------------------------------------
        # 4. Build six train/validation pairs for both variants
        # ----------------------------------------------------

        print("\n[4/7] Writing matched Parquet datasets...")

        audit_records = []

        for horizon in HORIZONS:

            for split in ["train", "validation"]:

                if split == "train":
                    date_condition = (
                        f"CAST(trading_day AS DATE) "
                        f"BETWEEN DATE '{TRAIN_START}' "
                        f"AND DATE '{TRAIN_END}'"
                    )
                else:
                    date_condition = (
                        f"CAST(trading_day AS DATE) "
                        f"BETWEEN DATE '{VALIDATION_START}' "
                        f"AND DATE '{VALIDATION_END}'"
                    )

                base_query = f"""
                    SELECT *
                    FROM matched_common
                    WHERE
                        CAST(horizon_minutes AS INTEGER) = {horizon}
                        AND {date_condition}
                """

                count = con.execute(
                    f"SELECT COUNT(*) FROM ({base_query}) q"
                ).fetchone()[0]

                if count <= 0:
                    raise RuntimeError(
                        f"No rows for {split} {horizon}m."
                    )

                for dataset_name in [
                    "index_only",
                    "index_plus_options",
                ]:

                    output_path = (
                            OUTPUT_ROOT
                            / dataset_name
                            / f"{split}_{horizon}m.parquet"
                    )

                    output_path.parent.mkdir(
                        parents=True,
                        exist_ok=True,
                    )

                    if dataset_name == "index_only":
                        selected_columns = (
                                METADATA_COLUMNS + INDEX_FEATURES
                        )
                    else:
                        selected_columns = (
                                METADATA_COLUMNS + ALL_FEATURES
                        )

                    con.execute(
                        f"""
                        COPY (
                            SELECT
                                {quote_columns(selected_columns)}
                            FROM ({base_query}) AS matched
                            ORDER BY timestamp_ist
                        )
                        TO {sql_path(output_path)}
                        (FORMAT PARQUET, COMPRESSION ZSTD)
                        """
                    )

                    output_count = con.execute(
                        f"""
                        SELECT COUNT(*)
                        FROM read_parquet({sql_path(output_path)})
                        """
                    ).fetchone()[0]

                    if output_count != count:
                        raise RuntimeError(
                            f"Output row count mismatch: "
                            f"{dataset_name}/{split}/{horizon}m"
                        )

                    audit_records.append({
                        "dataset": dataset_name,
                        "split": split,
                        "horizon_minutes": horizon,
                        "rows": int(output_count),
                        "feature_count": (
                            len(INDEX_FEATURES)
                            if dataset_name == "index_only"
                            else len(ALL_FEATURES)
                        ),
                        "file": str(output_path),
                    })

                    print(
                        f"{dataset_name:18s} "
                        f"{split:10s} "
                        f"{horizon:2d}m "
                        f"{output_count:>10,} rows"
                    )

        audit_df = pd.DataFrame(audit_records)

        audit_df.to_csv(
            REPORT_DIR / "matched_dataset_audit.csv",
            index=False,
            )

        # ----------------------------------------------------
        # 5. Dataset parity validation
        # ----------------------------------------------------

        print("\n[5/7] Checking index-only/options parity...")

        parity_records = []

        for horizon in HORIZONS:

            for split in ["train", "validation"]:

                index_file = (
                        OUTPUT_ROOT
                        / "index_only"
                        / f"{split}_{horizon}m.parquet"
                )

                options_file = (
                        OUTPUT_ROOT
                        / "index_plus_options"
                        / f"{split}_{horizon}m.parquet"
                )

                index_sql = sql_path(index_file)
                options_sql = sql_path(options_file)

                key_columns = [
                    "timestamp_ist",
                    "horizon_minutes",
                    "label_quantile_v3",
                    "label_volatility_v1",
                    "target_z",
                    "forward_return",
                    "future_close",
                ]

                key_select = quote_columns(key_columns)

                left_only = con.execute(
                    f"""
                    SELECT COUNT(*)
                    FROM (
                        SELECT {key_select}
                        FROM read_parquet({index_sql})

                        EXCEPT

                        SELECT {key_select}
                        FROM read_parquet({options_sql})
                    ) q
                    """
                ).fetchone()[0]

                right_only = con.execute(
                    f"""
                    SELECT COUNT(*)
                    FROM (
                        SELECT {key_select}
                        FROM read_parquet({options_sql})

                        EXCEPT

                        SELECT {key_select}
                        FROM read_parquet({index_sql})
                    ) q
                    """
                ).fetchone()[0]

                index_count = con.execute(
                    f"SELECT COUNT(*) FROM read_parquet({index_sql})"
                ).fetchone()[0]

                options_count = con.execute(
                    f"SELECT COUNT(*) FROM read_parquet({options_sql})"
                ).fetchone()[0]

                passed = (
                        left_only == 0
                        and right_only == 0
                        and index_count == options_count
                )

                parity_records.append({
                    "horizon_minutes": horizon,
                    "split": split,
                    "index_only_rows": int(index_count),
                    "index_plus_options_rows": int(options_count),
                    "index_only_not_in_options": int(left_only),
                    "options_not_in_index_only": int(right_only),
                    "status": "PASS" if passed else "FAIL",
                })

                if not passed:
                    raise RuntimeError(
                        f"Dataset parity failed: {split} {horizon}m"
                    )

        parity_df = pd.DataFrame(parity_records)

        parity_df.to_csv(
            REPORT_DIR / "dataset_parity_audit.csv",
            index=False,
            )

        # ----------------------------------------------------
        # 6. Feature manifest and label distribution
        # ----------------------------------------------------

        print("\n[6/7] Writing feature manifest and label audit...")

        manifest_records = []

        for feature in INDEX_FEATURES:
            manifest_records.append({
                "dataset_group": "index_only",
                "feature": feature,
                "feature_type": "index",
                "included_as_predictor": True,
            })

        for feature in OPTIONS_FEATURES:
            manifest_records.append({
                "dataset_group": "index_plus_options",
                "feature": feature,
                "feature_type": "options",
                "included_as_predictor": True,
            })

        manifest_df = pd.DataFrame(manifest_records)

        manifest_df.to_csv(
            REPORT_DIR / "matched_feature_manifest.csv",
            index=False,
            )

        label_distribution = con.execute(
            """
            SELECT
                CASE
                    WHEN CAST(trading_day AS DATE)
                        BETWEEN DATE '2021-05-24'
                        AND DATE '2023-12-31'
                        THEN 'TRAIN_2021_2023'
                    WHEN CAST(trading_day AS DATE)
                        BETWEEN DATE '2024-01-01'
                        AND DATE '2024-12-31'
                        THEN 'VALIDATION_2024'
                    ELSE 'OUT_OF_SCOPE'
                    END AS split_period,

                CAST(horizon_minutes AS INTEGER) AS horizon_minutes,

                COUNT(*) AS rows,

                COUNT(*) FILTER (
                    WHERE label_quantile_v3 = 'DOWN'
                ) AS quantile_down,

                COUNT(*) FILTER (
                    WHERE label_quantile_v3 = 'SIDEWAYS'
                ) AS quantile_sideways,

                COUNT(*) FILTER (
                    WHERE label_quantile_v3 = 'UP'
                ) AS quantile_up,

                COUNT(*) FILTER (
                    WHERE label_volatility_v1 = 'DOWN'
                ) AS volatility_down,

                COUNT(*) FILTER (
                    WHERE label_volatility_v1 = 'SIDEWAYS'
                ) AS volatility_sideways,

                COUNT(*) FILTER (
                    WHERE label_volatility_v1 = 'UP'
                ) AS volatility_up

            FROM matched_common

            GROUP BY split_period, horizon_minutes

            ORDER BY split_period, horizon_minutes
            """
        ).fetchdf()

        label_distribution.to_csv(
            REPORT_DIR / "label_distribution_by_split.csv",
            index=False,
            )

        # ----------------------------------------------------
        # 7. Summary
        # ----------------------------------------------------

        print("\n[7/7] Writing summary...")

        summary = {
            "status": "PASS",
            "generated_utc": datetime.now(
                timezone.utc
            ).isoformat(),

            "input_file": str(INPUT_FILE),

            "output_root": str(OUTPUT_ROOT),
            "report_dir": str(REPORT_DIR),

            "source_rows": source_rows,
            "matched_rows_across_horizons": common_rows,

            "horizons": HORIZONS,

            "train_period": {
                "start": TRAIN_START,
                "end": TRAIN_END,
            },

            "validation_period": {
                "start": VALIDATION_START,
                "end": VALIDATION_END,
            },

            "index_feature_count": len(INDEX_FEATURES),
            "options_feature_count": len(OPTIONS_FEATURES),
            "combined_feature_count": len(ALL_FEATURES),

            "index_features": INDEX_FEATURES,
            "options_features": OPTIONS_FEATURES,

            "matching_policy": (
                "Eligible, non-synthetic rows with all 24 index "
                "and 14 options predictors present and finite. "
                "The exact same sample is used for index-only "
                "and index-plus-options."
            ),

            "targets_preserved": [
                "label_quantile_v3",
                "label_volatility_v1",
            ],

            "predictor_exclusions": [
                "raw OHLC",
                "raw option prices",
                "raw option OI levels",
                "raw option volume levels",
                "future target fields",
                "quantile thresholds",
                "availability flags",
            ],

            "checks": {
                "source_unique_keys": True,
                "matched_unique_keys": True,
                "all_features_non_null": True,
                "all_features_finite": True,
                "both_targets_available": True,
                "index_only_options_same_sample": True,
                "all_six_horizon_split_pairs_created": True,
                "no_synthetic_rows": True,
            },

            "output_files": [
                str(path) for path in output_files
            ],

            "reports": {
                "audit": str(
                    REPORT_DIR / "matched_dataset_audit.csv"
                ),
                "parity": str(
                    REPORT_DIR / "dataset_parity_audit.csv"
                ),
                "manifest": str(
                    REPORT_DIR / "matched_feature_manifest.csv"
                ),
                "label_distribution": str(
                    REPORT_DIR / "label_distribution_by_split.csv"
                ),
            },
        }

        with open(
                REPORT_DIR / "matched_dataset_v3_summary.json",
                "w",
                encoding="utf-8",
        ) as file:
            json.dump(
                summary,
                file,
                indent=2,
                default=str,
            )

        print("\n" + "=" * 80)
        print("MATCHED DATASETS V3 BUILD PASSED")
        print("=" * 80)

        print(f"Source rows: {source_rows:,}")
        print(f"Matched rows across horizons: {common_rows:,}")

        print(f"Index features: {len(INDEX_FEATURES)}")
        print(f"Options features: {len(OPTIONS_FEATURES)}")
        print(f"Combined features: {len(ALL_FEATURES)}")

        print("\nParity audit:")
        print(parity_df.to_string(index=False))

        print(f"\nOutput: {OUTPUT_ROOT}")
        print(f"Reports: {REPORT_DIR}")

    finally:
        con.close()


if __name__ == "__main__":
    try:
        main()

    except Exception as exc:
        print("\n" + "=" * 80)
        print("MATCHED DATASET V3 BUILD FAILED")
        print("=" * 80)
        print(str(exc))
        sys.exit(1)
