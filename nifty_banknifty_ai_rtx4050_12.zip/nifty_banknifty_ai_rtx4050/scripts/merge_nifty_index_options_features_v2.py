
from __future__ import annotations

import json
import sys
import traceback
from datetime import datetime
from pathlib import Path

import duckdb


ROOT = Path(__file__).resolve().parents[1]

INDEX_FILE = (
        ROOT / "data" / "processed" / "nifty_features_v2"
        / "nifty_features_labels_long_v2.parquet"
)

OPTIONS_FILE = (
        ROOT / "data" / "processed" / "nifty_options_features_v4"
        / "nifty_options_features_v4.parquet"
)

OUTPUT_DIR = (
        ROOT / "data" / "processed"
        / "nifty_index_options_features_v2"
)

REPORT_DIR = (
        ROOT / "reports" / "nifty_index_options_features_v2"
)

OUTPUT_FILE = (
        OUTPUT_DIR / "nifty_index_options_features_v2.parquet"
)

MEMORY_LIMIT = "5GB"
THREADS = 4


def log(message):
    print(message, flush=True)


def sql_string(value):
    return "'" + str(value).replace("'", "''") + "'"


def sql_path(path):
    return sql_string(str(path.resolve()).replace("\\", "/"))


def qi(name):
    return '"' + str(name).replace('"', '""') + '"'


def get_columns(con, path):
    rows = con.execute(
        f"DESCRIBE SELECT * FROM read_parquet({sql_path(path)})"
    ).fetchall()

    return [row[0] for row in rows]


def scalar(con, query):
    return con.execute(query).fetchone()[0]


def main():
    log("=" * 78)
    log("NIFTY INDEX + OPTIONS FEATURES V2 MERGE")
    log("=" * 78)

    for path in (INDEX_FILE, OPTIONS_FILE):
        if not path.exists():
            raise FileNotFoundError(path)

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    REPORT_DIR.mkdir(parents=True, exist_ok=True)

    # Never overwrite an existing output.
    if OUTPUT_FILE.exists():
        raise FileExistsError(
            f"Output already exists; refusing to overwrite:\n{OUTPUT_FILE}"
        )

    con = duckdb.connect(":memory:")

    try:
        con.execute(
            f"SET memory_limit = {sql_string(MEMORY_LIMIT)}"
        )
        con.execute(f"SET threads = {THREADS}")
        con.execute("SET TimeZone = 'Asia/Kolkata'")

        log(f"Index input  : {INDEX_FILE}")
        log(f"Options input: {OPTIONS_FILE}")
        log(f"Output       : {OUTPUT_FILE}")

        # ----------------------------------------------------
        # 1. Inspect schemas
        # ----------------------------------------------------

        index_columns = get_columns(con, INDEX_FILE)
        options_columns = get_columns(con, OPTIONS_FILE)

        required_index = {
            "timestamp_ist",
            "trading_day",
            "horizon_minutes",
            "close",
            "sample_eligible",
            "label_quantile_v2",
            "label_volatility_v1",
        }

        required_options = {
            "timestamp_ist",
            "atm_straddle_premium",
        }

        missing_index = sorted(required_index - set(index_columns))
        missing_options = sorted(required_options - set(options_columns))

        if missing_index:
            raise RuntimeError(
                f"Missing required index columns: {missing_index}"
            )

        if missing_options:
            raise RuntimeError(
                f"Missing required options columns: {missing_options}"
            )

        if "atm_straddle_premium_pct" in index_columns:
            raise RuntimeError(
                "Index input already contains atm_straddle_premium_pct"
            )

        if "atm_straddle_premium_pct" in options_columns:
            raise RuntimeError(
                "Options input already contains atm_straddle_premium_pct"
            )

        # Options may contain a spot_close used during its own build.
        # Keep it under a separate name to avoid column collisions.
        has_options_spot = "spot_close" in options_columns

        # Avoid duplicate join keys and duplicate trading_day.
        excluded_options = {
            "timestamp_ist",
            "trading_day",
        }

        if has_options_spot:
            excluded_options.add("spot_close")

        options_feature_columns = [
            col for col in options_columns
            if col not in excluded_options
        ]

        if "atm_straddle_premium" not in options_feature_columns:
            raise RuntimeError(
                "atm_straddle_premium was unexpectedly excluded"
            )

        # ----------------------------------------------------
        # 2. Register input views
        # ----------------------------------------------------

        con.execute(f"""
            CREATE VIEW idx AS
            SELECT *
            FROM read_parquet({sql_path(INDEX_FILE)})
        """)

        con.execute(f"""
            CREATE VIEW opt AS
            SELECT *
            FROM read_parquet({sql_path(OPTIONS_FILE)})
        """)

        index_rows = scalar(con, "SELECT COUNT(*) FROM idx")
        options_rows = scalar(con, "SELECT COUNT(*) FROM opt")

        index_unique_timestamps = scalar(con, """
                                              SELECT COUNT(*)
                                              FROM (
                                                       SELECT timestamp_ist
                                                       FROM idx
                                                       GROUP BY timestamp_ist
                                                   ) x
                                              """)

        options_unique_timestamps = scalar(con, """
                                                SELECT COUNT(*)
                                                FROM (
                                                         SELECT timestamp_ist
                                                         FROM opt
                                                         GROUP BY timestamp_ist
                                                     ) x
                                                """)

        index_duplicate_keys = index_rows - scalar(con, """
                                                        SELECT COUNT(*)
                                                        FROM (
                                                                 SELECT timestamp_ist, horizon_minutes
                                                                 FROM idx
                                                                 GROUP BY timestamp_ist, horizon_minutes
                                                             ) x
                                                        """)

        options_duplicate_keys = options_rows - options_unique_timestamps

        if index_duplicate_keys != 0:
            raise RuntimeError(
                f"Index duplicate timestamp+horizon rows: "
                f"{index_duplicate_keys}"
            )

        if options_duplicate_keys != 0:
            raise RuntimeError(
                f"Options duplicate timestamps: {options_duplicate_keys}"
            )

        # ----------------------------------------------------
        # 3. Check timestamp trading-day consistency
        # ----------------------------------------------------

        log("\nChecking timestamp and trading-day alignment...")

        index_day_mismatches = scalar(con, """
                                           SELECT COUNT(*)
                                           FROM idx
                                           WHERE CAST(timestamp_ist AS DATE)
                                                     <> CAST(trading_day AS DATE)
                                           """)

        options_day_mismatches = scalar(con, """
                                             SELECT COUNT(*)
                                             FROM opt
                                             WHERE CAST(timestamp_ist AS DATE) IS NULL
                                             """)

        if index_day_mismatches or options_day_mismatches:
            raise RuntimeError(
                "Trading-day mismatch detected. "
                f"Index={index_day_mismatches}, "
                f"Options={options_day_mismatches}"
            )

        # ----------------------------------------------------
        # 4. Check options spot price consistency if available
        # ----------------------------------------------------

        spot_mismatch_count = None
        spot_max_abs_difference = None

        if has_options_spot:
            spot_result = con.execute("""
                                      SELECT
                                          COUNT(*) FILTER (
                        WHERE o.spot_close IS NULL
                           OR i.close IS NULL
                    ) AS null_rows,

                                          COUNT(*) FILTER (
                        WHERE o.spot_close IS NOT NULL
                          AND i.close IS NOT NULL
                          AND abs(
                              CAST(o.spot_close AS DOUBLE)
                              - CAST(i.close AS DOUBLE)
                          ) > 1e-8
                    ) AS mismatch_rows,

                                          MAX(
                                                  abs(
                                                          CAST(o.spot_close AS DOUBLE)
                                                              - CAST(i.close AS DOUBLE)
                                                  )
                                          ) AS max_abs_difference

                                      FROM (
                                               SELECT DISTINCT timestamp_ist, close
                                               FROM idx
                                           ) i
                                               INNER JOIN opt o
                                                          ON i.timestamp_ist = o.timestamp_ist
                                      """).fetchone()

            spot_mismatch_count = int(spot_result[1])
            spot_max_abs_difference = spot_result[2]

            if spot_mismatch_count > 0:
                raise RuntimeError(
                    "Options spot_close does not match index close. "
                    f"Mismatch rows: {spot_mismatch_count}"
                )

        # ----------------------------------------------------
        # 5. Build SELECT lists
        # ----------------------------------------------------

        index_select = [
            f"i.{qi(col)}"
            for col in index_columns
        ]

        options_select = [
            f"o.{qi(col)}"
            for col in options_feature_columns
        ]

        if has_options_spot:
            options_select.append(
                "o.spot_close AS options_spot_close"
            )

        # Normalized premium uses index close, not an options
        # spot value from another row or a forward-filled value.
        premium_expression = """
            CASE
                WHEN o.atm_straddle_premium IS NOT NULL
                 AND i.close IS NOT NULL
                 AND CAST(i.close AS DOUBLE) > 0
                THEN
                    CAST(o.atm_straddle_premium AS DOUBLE)
                    / CAST(i.close AS DOUBLE) * 100.0
                ELSE NULL
            END AS atm_straddle_premium_pct
        """

        select_sql = ",\n".join(
            index_select + options_select + [premium_expression]
        )

        # ----------------------------------------------------
        # 6. Create merged parquet
        # ----------------------------------------------------

        log("\nBuilding exact-timestamp LEFT JOIN...")

        con.execute(f"""
            COPY (
                SELECT
                    {select_sql}
                FROM idx i
                LEFT JOIN opt o
                    ON i.timestamp_ist = o.timestamp_ist
            )
            TO {sql_path(OUTPUT_FILE)}
            (FORMAT PARQUET, COMPRESSION ZSTD)
        """)

        # ----------------------------------------------------
        # 7. Validate output
        # ----------------------------------------------------

        con.execute(f"""
            CREATE VIEW merged AS
            SELECT *
            FROM read_parquet({sql_path(OUTPUT_FILE)})
        """)

        output_rows = scalar(con, "SELECT COUNT(*) FROM merged")

        output_duplicate_keys = output_rows - scalar(con, """
                                                          SELECT COUNT(*)
                                                          FROM (
                                                                   SELECT timestamp_ist, horizon_minutes
                                                                   FROM merged
                                                                   GROUP BY timestamp_ist, horizon_minutes
                                                               ) x
                                                          """)

        missing_options_rows = scalar(con, """
                                           SELECT COUNT(*)
                                           FROM merged
                                           WHERE atm_straddle_premium IS NULL
                                           """)

        matched_options_rows = output_rows - missing_options_rows

        invalid_premium_pct = scalar(con, """
                                          SELECT COUNT(*)
                                          FROM merged
                                          WHERE atm_straddle_premium_pct IS NOT NULL
                                            AND (
                                              NOT isfinite(atm_straddle_premium_pct)
                                                  OR atm_straddle_premium_pct < 0
                                              )
                                          """)

        bad_normalization_rows = scalar(con, """
                                             SELECT COUNT(*)
                                             FROM merged
                                             WHERE atm_straddle_premium IS NOT NULL
                                               AND close IS NOT NULL
                                               AND close > 0
                                               AND (
                                                 atm_straddle_premium_pct IS NULL
                                                OR abs(
                                                 atm_straddle_premium_pct
                                                 - (
                                                 atm_straddle_premium / close * 100.0
                                                 )
                                                 ) > 1e-10
                                                 )
                                             """)

        # Verify all original index rows and labels are preserved.
        label_mismatches = scalar(con, """
                                       SELECT COUNT(*)
                                       FROM idx i
                                                LEFT JOIN merged m
                                                          ON i.timestamp_ist = m.timestamp_ist
                                                              AND i.horizon_minutes = m.horizon_minutes
                                       WHERE m.timestamp_ist IS NULL
                                          OR i.label_quantile_v2
                                           IS DISTINCT FROM m.label_quantile_v2
                                           OR i.label_volatility_v1
                                           IS DISTINCT FROM m.label_volatility_v1
                                           OR i.sample_eligible
                                           IS DISTINCT FROM m.sample_eligible
                                           OR i.target_z
                                           IS DISTINCT FROM m.target_z
                                           OR i.forward_return
                                           IS DISTINCT FROM m.forward_return
                                       """)

        # Verify no options values appear where no options timestamp exists.
        options_without_join = scalar(con, """
                                           SELECT COUNT(*)
                                           FROM merged m
                                           WHERE m.atm_straddle_premium IS NOT NULL
                                             AND NOT EXISTS (
                                               SELECT 1
                                               FROM opt o
                                               WHERE o.timestamp_ist = m.timestamp_ist
                                           )
                                           """)

        # Per-year options join coverage.
        coverage_by_year = con.execute("""
                                       SELECT
                                           YEAR(CAST(trading_day AS DATE)) AS year,
                                           COUNT(*) AS index_rows,
                                           COUNT(*) FILTER (
                                           WHERE atm_straddle_premium IS NOT NULL
                                           ) AS rows_with_atm_pair,
                                           COUNT(*) FILTER (
                                           WHERE atm_straddle_premium IS NULL
                                           ) AS rows_without_atm_pair,
                                           ROUND(
                                           100.0 * COUNT(*) FILTER (
                                           WHERE atm_straddle_premium IS NOT NULL
                                           ) / COUNT(*),
                                           4
                                           ) AS atm_pair_coverage_pct
                                       FROM merged
                                       GROUP BY 1
                                       ORDER BY 1
                                       """).df()

        coverage_by_year.to_csv(
            REPORT_DIR / "options_coverage_by_year.csv",
            index=False,
            )

        # ----------------------------------------------------
        # 8. Checks and report
        # ----------------------------------------------------

        checks = {
            "merged_rows_equal_index_rows": output_rows == index_rows,
            "no_duplicate_output_keys": output_duplicate_keys == 0,
            "index_and_options_days_aligned": (
                    index_day_mismatches == 0
                    and options_day_mismatches == 0
            ),
            "options_spot_matches_index_spot": (
                    spot_mismatch_count in (None, 0)
            ),
            "index_targets_and_eligibility_preserved": (
                    label_mismatches == 0
            ),
            "no_options_values_without_timestamp_join": (
                    options_without_join == 0
            ),
            "normalized_premium_valid": (
                    invalid_premium_pct == 0
                    and bad_normalization_rows == 0
            ),
        }

        overall = all(checks.values())

        summary = {
            "generated_at": datetime.now().isoformat(),
            "status": "PASS" if overall else "REVIEW_REQUIRED",
            "index_input": str(INDEX_FILE),
            "options_input": str(OPTIONS_FILE),
            "output": str(OUTPUT_FILE),
            "index_rows": int(index_rows),
            "options_rows": int(options_rows),
            "index_unique_timestamps": int(index_unique_timestamps),
            "options_unique_timestamps": int(options_unique_timestamps),
            "output_rows": int(output_rows),
            "matched_options_rows": int(matched_options_rows),
            "missing_options_rows": int(missing_options_rows),
            "output_duplicate_keys": int(output_duplicate_keys),
            "index_day_mismatches": int(index_day_mismatches),
            "options_day_mismatches": int(options_day_mismatches),
            "options_spot_column_available": has_options_spot,
            "options_spot_mismatches": spot_mismatch_count,
            "options_spot_max_abs_difference": spot_max_abs_difference,
            "label_mismatches": int(label_mismatches),
            "options_without_join": int(options_without_join),
            "invalid_premium_pct_rows": int(invalid_premium_pct),
            "bad_normalization_rows": int(bad_normalization_rows),
            "options_feature_columns_added": options_feature_columns,
            "normalized_feature": (
                "atm_straddle_premium_pct = "
                "atm_straddle_premium / close * 100"
            ),
            "checks": checks,
            "passed_checks": sum(bool(v) for v in checks.values()),
            "total_checks": len(checks),
        }

        summary_path = (
                REPORT_DIR / "merged_v2_summary.json"
        )

        summary_path.write_text(
            json.dumps(summary, indent=2, default=str),
            encoding="utf-8",
        )

        log("\n" + "=" * 78)
        log("MERGE AUDIT")
        log("=" * 78)

        log(f"Index rows           : {index_rows:,}")
        log(f"Options rows         : {options_rows:,}")
        log(f"Merged rows          : {output_rows:,}")
        log(f"Rows with ATM pair   : {matched_options_rows:,}")
        log(f"Rows without ATM pair: {missing_options_rows:,}")

        log("\nChecks:")
        for name, passed in checks.items():
            log(f"{'PASS' if passed else 'FAIL'}: {name}")

        log("\nYearly coverage:")
        log(coverage_by_year.to_string(index=False))

        log(f"\nStatus : {'PASS' if overall else 'REVIEW_REQUIRED'}")
        log(f"Output : {OUTPUT_FILE}")
        log(f"Report : {summary_path}")

        if not overall:
            sys.exit(2)

    finally:
        con.close()


if __name__ == "__main__":
    try:
        main()
    except Exception:
        log("\nMERGE FAILED")
        traceback.print_exc()
        sys.exit(1)
