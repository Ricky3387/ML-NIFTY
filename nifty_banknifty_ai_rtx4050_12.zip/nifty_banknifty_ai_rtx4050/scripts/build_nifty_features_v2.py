
#!/usr/bin/env python3
"""
NIFTY feature engineering v2.

Preserves v1 volatility labels and adds training-only quantile labels.

Input:
  data/processed/nifty_index_cleaned/nifty_index_cleaned_final.parquet

Outputs:
  data/processed/nifty_features_v2/
    nifty_features_labels_long_v2.parquet
    nifty_features_labels_long_v2_sample.csv
    nifty_feature_engineering_v2_summary.json
    nifty_feature_engineering_v2_daily_audit.csv
    quantile_thresholds_by_horizon.csv
    label_distribution_by_split.csv

No v1 files are modified.
"""

from pathlib import Path
import json
import time

import numpy as np
import pandas as pd


START = time.time()

SCRIPT_DIR = Path(__file__).resolve().parent
ROOT = SCRIPT_DIR.parent

INPUT = (
        ROOT / "data" / "processed" / "nifty_index_cleaned"
        / "nifty_index_cleaned_final.parquet"
)

OUT = ROOT / "data" / "processed" / "nifty_features_v2"

FULL_DAY_EXCLUSIONS = {"2022-03-07"}
HORIZONS = (5, 15, 30)
LOOKBACK = 60
Z_THRESHOLD = 0.5

TRAIN_END = "2023-12-31"
VALIDATION_START = "2024-01-01"
VALIDATION_END = "2024-12-31"

QUANTILE_LOW = 1.0 / 3.0
QUANTILE_HIGH = 2.0 / 3.0


def log(message):
    print(message, flush=True)


def ensure_no_overwrite():
    expected = [
        OUT / "nifty_features_labels_long_v2.parquet",
        OUT / "nifty_features_labels_long_v2_sample.csv",
        OUT / "nifty_feature_engineering_v2_summary.json",
        OUT / "nifty_feature_engineering_v2_daily_audit.csv",
        OUT / "quantile_thresholds_by_horizon.csv",
        OUT / "label_distribution_by_split.csv",
        ]

    existing = [str(p) for p in expected if p.exists()]
    if existing:
        raise FileExistsError(
            "Refusing to overwrite existing v2 outputs:\n"
            + "\n".join(existing)
        )


def make_label(z, lower, upper):
    return np.select(
        [z <= lower, z >= upper],
        ["DOWN", "UP"],
        default="SIDEWAYS",
    )


def main():
    if not INPUT.exists():
        raise FileNotFoundError(INPUT)

    OUT.mkdir(parents=True, exist_ok=True)
    ensure_no_overwrite()

    log(f"Reading: {INPUT}")
    df = pd.read_parquet(INPUT)

    required = {
        "timestamp_ist", "trading_day",
        "open", "high", "low", "close",
        "is_synthetic", "training_day_eligible",
    }

    missing = required - set(df.columns)
    if missing:
        raise RuntimeError(f"Missing required columns: {sorted(missing)}")

    log("Normalizing and validating input...")
    df["timestamp_ist"] = pd.to_datetime(df["timestamp_ist"])
    df["trading_day"] = (
        pd.to_datetime(df["trading_day"]).dt.strftime("%Y-%m-%d")
    )

    for col in ("open", "high", "low", "close"):
        df[col] = pd.to_numeric(df[col], errors="coerce")

    df["is_synthetic"] = df["is_synthetic"].astype(bool)
    df["training_day_eligible"] = (
        df["training_day_eligible"].astype(bool)
    )

    df = df.sort_values(
        ["trading_day", "timestamp_ist"]
    ).reset_index(drop=True)

    if df["timestamp_ist"].duplicated().any():
        raise RuntimeError("Duplicate timestamp_ist values found.")

    if df[["open", "high", "low", "close"]].isna().any().any():
        raise RuntimeError("Null OHLC values found.")

    df["day_allowed"] = (
            df["training_day_eligible"]
            & ~df["trading_day"].isin(FULL_DAY_EXCLUSIONS)
    )

    log("Building same-day index features...")
    pieces = []

    for day, group in df.groupby("trading_day", sort=True):
        g = group.copy().sort_values("timestamp_ist").reset_index(drop=True)

        delta = g["timestamp_ist"].diff().dt.total_seconds() / 60
        contiguous = delta.eq(1)
        contiguous.iloc[0] = True
        g["bar_contiguous_from_prev"] = contiguous

        close = g["close"].astype(float)
        logret = np.log(close).diff()

        g["ret_1m"] = close.pct_change(fill_method=None)
        g["logret_1m"] = logret
        g["trailing_sigma_60m"] = (
            logret.rolling(LOOKBACK, min_periods=LOOKBACK).std()
        )

        g["range_pct"] = (g["high"] - g["low"]) / close
        g["body_pct"] = (g["close"] - g["open"]) / g["open"]
        g["upper_wick_pct"] = (
                                      g["high"] - g[["open", "close"]].max(axis=1)
                              ) / close
        g["lower_wick_pct"] = (
                                      g[["open", "close"]].min(axis=1) - g["low"]
                              ) / close

        for w in (5, 15, 30, 60):
            g[f"return_{w}m"] = close.pct_change(w, fill_method=None)
            g[f"realized_vol_{w}m"] = (
                    logret.rolling(w, min_periods=w).std() * np.sqrt(w)
            )
            g[f"high_low_range_{w}m"] = (
                                                g["high"].rolling(w, min_periods=w).max()
                                                - g["low"].rolling(w, min_periods=w).min()
                                        ) / close

        for span in (9, 21, 50):
            ema = close.ewm(
                span=span, adjust=False, min_periods=span
            ).mean()
            g[f"close_vs_ema{span}_pct"] = close / ema - 1

        delta_close = close.diff()
        gain = delta_close.clip(lower=0).rolling(
            14, min_periods=14
        ).mean()
        loss = (-delta_close.clip(upper=0)).rolling(
            14, min_periods=14
        ).mean()

        rs = gain / loss.replace(0, np.nan)
        g["rsi_14"] = 100 - (100 / (1 + rs))

        g["positive_return_count_5m"] = (
            (g["ret_1m"] > 0).rolling(5, min_periods=5).sum()
        )
        g["negative_return_count_5m"] = (
            (g["ret_1m"] < 0).rolling(5, min_periods=5).sum()
        )

        g["feature_window_valid"] = (
                (~g["is_synthetic"])
                .rolling(LOOKBACK, min_periods=LOOKBACK)
                .sum().eq(LOOKBACK)
                & g["bar_contiguous_from_prev"]
                .rolling(LOOKBACK, min_periods=LOOKBACK)
                .sum().eq(LOOKBACK)
                & g["day_allowed"]
        )

        for h in HORIZONS:
            g[f"future_close_{h}m"] = close.shift(-h)

            future_synthetic = (
                g["is_synthetic"].astype("int8").shift(-1)
                .iloc[::-1]
                .rolling(h, min_periods=h)
                .sum()
                .iloc[::-1]
            )
            g[f"future_synthetic_count_{h}m"] = (
                future_synthetic.to_numpy()
            )

            future_delta = (
                    g["timestamp_ist"].shift(-h) - g["timestamp_ist"]
            )
            g[f"future_time_valid_{h}m"] = future_delta.eq(
                pd.to_timedelta(h, unit="m")
            )

        pieces.append(g)

    data = pd.concat(pieces, ignore_index=True)

    feature_cols = [
        "ret_1m", "logret_1m", "range_pct", "body_pct",
        "upper_wick_pct", "lower_wick_pct",
        "return_5m", "return_15m", "return_30m", "return_60m",
        "realized_vol_5m", "realized_vol_15m",
        "realized_vol_30m", "realized_vol_60m",
        "high_low_range_5m", "high_low_range_15m",
        "high_low_range_30m", "high_low_range_60m",
        "close_vs_ema9_pct", "close_vs_ema21_pct",
        "close_vs_ema50_pct", "rsi_14",
        "positive_return_count_5m",
        "negative_return_count_5m",
    ]

    base_cols = [
        "timestamp_ist", "trading_day",
        "open", "high", "low", "close",
        "is_synthetic", "training_day_eligible",
        "session_type",
    ]
    base_cols = [c for c in base_cols if c in data.columns]

    log("Building forward targets and v1 labels...")
    output_parts = []

    for h in HORIZONS:
        x = data[base_cols + feature_cols].copy()

        x["horizon_minutes"] = h
        x["future_close"] = data[f"future_close_{h}m"]
        x["forward_return"] = x["future_close"] / x["close"] - 1

        x["target_vol_scale"] = (
                data["trailing_sigma_60m"].to_numpy() * np.sqrt(h)
        )

        x["target_z"] = (
                np.log(x["future_close"] / x["close"])
                / x["target_vol_scale"]
        )

        x["label"] = make_label(
            x["target_z"].to_numpy(),
            -Z_THRESHOLD,
            Z_THRESHOLD,
        )
        x["label_volatility_v1"] = x["label"]

        valid = (
                data["feature_window_valid"].to_numpy()
                & data[f"future_time_valid_{h}m"].to_numpy()
                & data[f"future_synthetic_count_{h}m"].fillna(1).eq(0).to_numpy()
                & data[f"future_close_{h}m"].notna().to_numpy()
                & x["target_vol_scale"].gt(0).to_numpy()
                & np.isfinite(x["target_z"].to_numpy())
                & x[feature_cols].notna().all(axis=1).to_numpy()
                & data["day_allowed"].to_numpy()
        )

        x["sample_eligible"] = valid

        x["sample_exclusion_reason"] = np.where(
            ~data["day_allowed"].to_numpy(),
            "FULL_DAY_INELIGIBLE",
            np.where(
                ~data["feature_window_valid"].to_numpy(),
                "FEATURE_WINDOW_INVALID_OR_SYNTHETIC",
                np.where(
                    ~data[f"future_time_valid_{h}m"].to_numpy(),
                    "FUTURE_WINDOW_GAP_OR_SESSION_END",
                    np.where(
                        data[f"future_synthetic_count_{h}m"]
                        .fillna(1).to_numpy() > 0,
                        "FUTURE_WINDOW_SYNTHETIC",
                        np.where(
                            x["target_vol_scale"].le(0).to_numpy()
                            | ~np.isfinite(x["target_z"].to_numpy()),
                            "INVALID_VOL_SCALE_OR_TARGET",
                            np.where(
                                ~x[feature_cols].notna()
                                .all(axis=1).to_numpy(),
                                "FEATURES_NOT_READY",
                                "ELIGIBLE",
                                ),
                            ),
                        ),
                ),
            ),
        )

        x["sample_eligible"] = valid
        output_parts.append(x)

    result = pd.concat(output_parts, ignore_index=True)

    years = pd.to_datetime(result["trading_day"]).dt.year
    result["split"] = np.select(
        [
            years.le(2023),
            years.eq(2024),
        ],
        ["TRAIN", "VALIDATION"],
        default="NOT_IN_CURRENT_CLEANED_PERIOD",
    )

    log("Calculating quantile thresholds from TRAIN rows only...")
    thresholds = {}

    for h in HORIZONS:
        mask = (
                result["horizon_minutes"].eq(h)
                & result["sample_eligible"]
                & result["split"].eq("TRAIN")
                & np.isfinite(result["target_z"])
        )

        train_z = result.loc[mask, "target_z"].to_numpy()

        if len(train_z) == 0:
            raise RuntimeError(f"No eligible training target_z values for {h}m.")

        lower, upper = np.quantile(
            train_z, [QUANTILE_LOW, QUANTILE_HIGH]
        )

        if not np.isfinite(lower) or not np.isfinite(upper) or lower >= upper:
            raise RuntimeError(
                f"Invalid quantile thresholds for {h}m: {lower}, {upper}"
            )

        thresholds[h] = {
            "lower": float(lower),
            "upper": float(upper),
            "training_rows": int(len(train_z)),
        }

        hmask = result["horizon_minutes"].eq(h)
        result.loc[hmask, "quantile_lower"] = lower
        result.loc[hmask, "quantile_upper"] = upper

        result.loc[hmask, "label_quantile_v2"] = make_label(
            result.loc[hmask, "target_z"].to_numpy(),
            lower,
            upper,
        )

    result["label_quantile_v2"] = result["label_quantile_v2"].astype("string")

    # Quantile labels are only intended for eligible samples.
    result.loc[
        ~result["sample_eligible"], "label_quantile_v2"
    ] = pd.NA

    log("Creating audits...")
    eligible = result[result["sample_eligible"]].copy()

    threshold_rows = []
    for h, values in thresholds.items():
        threshold_rows.append({
            "horizon_minutes": h,
            "training_rows": values["training_rows"],
            "quantile_low": QUANTILE_LOW,
            "quantile_high": QUANTILE_HIGH,
            "quantile_lower": values["lower"],
            "quantile_upper": values["upper"],
        })

    threshold_df = pd.DataFrame(threshold_rows)

    distribution = (
        eligible.groupby(
            ["split", "horizon_minutes", "label_quantile_v2"],
            dropna=False,
        )
        .size()
        .reset_index(name="rows")
    )

    distribution["pct_within_split_horizon"] = (
            distribution["rows"]
            / distribution.groupby(
        ["split", "horizon_minutes"]
    )["rows"].transform("sum")
            * 100
    )

    daily = result.groupby(
        ["trading_day", "horizon_minutes"], as_index=False
    ).agg(
        rows=("sample_eligible", "size"),
        eligible_samples=("sample_eligible", "sum"),
        synthetic_source_rows=("is_synthetic", "sum"),
        excluded_full_day=(
            "training_day_eligible",
            lambda s: (~s).all(),
        ),
    )

    summary = {
        "status": "V2_FEATURES_AND_LABELS_GENERATED_REVIEW_REQUIRED",
        "input_file": str(INPUT),
        "output_directory": str(OUT),
        "rows_written": int(len(result)),
        "eligible_samples": int(result["sample_eligible"].sum()),
        "excluded_samples": int((~result["sample_eligible"]).sum()),
        "horizons": list(HORIZONS),
        "lookback_minutes": LOOKBACK,
        "feature_count": len(feature_cols),
        "index_feature_columns": feature_cols,
        "volatility_label": {
            "method": "forward log return / (trailing 60-bar log-return std * sqrt(horizon))",
            "threshold_abs_z": Z_THRESHOLD,
            "preserved_as": "label_volatility_v1",
        },
        "quantile_label": {
            "method": "training-only target_z quantiles per horizon",
            "lower_quantile": QUANTILE_LOW,
            "upper_quantile": QUANTILE_HIGH,
            "thresholds": thresholds,
            "applied_to_validation": True,
            "validation_used_for_thresholds": False,
        },
        "split_policy": "2021-2023 TRAIN; 2024 VALIDATION",
        "guard_policy": (
            "Same-day contiguous 60-bar feature window and future horizon; "
            "synthetic bars excluded; 2022-03-07 excluded"
        ),
        "raw_ohlc_retained_as_metadata": True,
        "raw_ohlc_predictor_policy": (
            "OHLC retained for target calculations and audit; "
            "must be excluded from model predictors in matched dataset builder"
        ),
        "elapsed_seconds": round(time.time() - START, 2),
    }

    parquet_path = OUT / "nifty_features_labels_long_v2.parquet"
    sample_path = OUT / "nifty_features_labels_long_v2_sample.csv"
    daily_path = OUT / "nifty_feature_engineering_v2_daily_audit.csv"
    summary_path = OUT / "nifty_feature_engineering_v2_summary.json"
    thresholds_path = OUT / "quantile_thresholds_by_horizon.csv"
    distribution_path = OUT / "label_distribution_by_split.csv"

    result.to_parquet(parquet_path, index=False, compression="zstd")
    result.head(5000).to_csv(sample_path, index=False)
    daily.to_csv(daily_path, index=False)
    threshold_df.to_csv(thresholds_path, index=False)
    distribution.to_csv(distribution_path, index=False)

    summary_path.write_text(
        json.dumps(summary, indent=2, default=str),
        encoding="utf-8",
    )

    log("\n" + "=" * 75)
    log("NIFTY FEATURE ENGINEERING V2 COMPLETE")
    log("=" * 75)
    log(json.dumps(summary, indent=2))
    log(f"\nPARQUET: {parquet_path}")
    log(f"THRESHOLDS: {thresholds_path}")
    log(f"DISTRIBUTION: {distribution_path}")
    log(f"SUMMARY: {summary_path}")


if __name__ == "__main__":
    main()
