
from pathlib import Path
import json
import joblib
import numpy as np
import pandas as pd

from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    f1_score,
    log_loss,
    roc_auc_score,
    confusion_matrix,
    classification_report,
)

# ============================================================
# CONFIGURATION
# ============================================================

ROOT = Path(__file__).resolve().parent.parent

DATA_ROOT = (
        ROOT / "data" / "processed"
        / "nifty_two_stage_matched_datasets_v1"
)

MODEL_ROOT = (
        ROOT / "models"
        / "nifty_two_stage_lightgbm_v1"
)

OUTPUT_ROOT = (
        ROOT / "reports"
        / "nifty_two_stage_end_to_end_v2"
)

HORIZONS = [5, 15, 30]
DATASETS = ["index_only", "index_plus_options"]

CLASSES = ["DOWN", "SIDEWAYS", "UP"]

INDEX_FEATURES = [
    "ret_1m",
    "logret_1m",
    "range_pct",
    "body_pct",
    "upper_wick_pct",
    "lower_wick_pct",
    "return_5m",
    "return_15m",
    "return_30m",
    "return_60m",
    "realized_vol_5m",
    "realized_vol_15m",
    "realized_vol_30m",
    "realized_vol_60m",
    "high_low_range_5m",
    "high_low_range_15m",
    "high_low_range_30m",
    "high_low_range_60m",
    "close_vs_ema9_pct",
    "close_vs_ema21_pct",
    "close_vs_ema50_pct",
    "rsi_14",
    "positive_return_count_5m",
    "negative_return_count_5m",
]

OPTIONS_FEATURES = [
    "selected_dte",
    "atm_distance_pct",
    "atm_straddle_premium_pct",
    "atm_ce_log_return_1m",
    "atm_pe_log_return_1m",
    "atm_ce_pe_return_spread_1m",
    "atm_straddle_weighted_log_return_1m",
    "atm_ce_oi_change_1m",
    "atm_pe_oi_change_1m",
    "near_atm_pcr_oi",
    "near_atm_pcr_volume",
    "near_atm_oi_imbalance",
    "near_atm_volume_imbalance",
    "paired_strike_count",
]


# ============================================================
# OUTPUT SAFETY
# ============================================================

OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)

if any(OUTPUT_ROOT.iterdir()):
    raise FileExistsError(
        "Output directory is not empty. "
        "Existing results will not be overwritten:\n"
        f"{OUTPUT_ROOT}"
    )


# ============================================================
# HELPERS
# ============================================================

def write_json(data, path):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(
            data,
            f,
            indent=2,
            default=str,
            allow_nan=False,
        )


def load_bundle(stage, dataset, horizon):
    path = (
            MODEL_ROOT
            / stage
            / dataset
            / f"{stage}_{horizon}m.joblib"
    )

    if not path.exists():
        raise FileNotFoundError(path)

    return joblib.load(path)


def validate_features(df, features, name):
    missing = set(features) - set(df.columns)

    if missing:
        raise ValueError(
            f"{name}: missing features: {sorted(missing)}"
        )

    X = df[features].copy()

    for col in features:
        X[col] = pd.to_numeric(X[col], errors="coerce")

    values = X.to_numpy(dtype=np.float64)

    if not np.isfinite(values).all():
        bad_columns = X.columns[
            ~np.isfinite(values).all(axis=0)
        ].tolist()

        raise ValueError(
            f"{name}: non-finite feature values: {bad_columns}"
        )

    return X.astype(np.float32)


def positive_probability(bundle, X):
    model = bundle["model"]
    probabilities = model.predict_proba(X)

    classes = list(model.classes_)

    if 1 not in classes:
        raise ValueError(
            f"Positive class 1 not found in model classes: {classes}"
        )

    positive_index = classes.index(1)

    return probabilities[:, positive_index]


def reconstruct_actual_classes(df):
    required = {
        "label_stage1_move_v1",
        "label_stage2_direction_v1",
    }

    missing = required - set(df.columns)

    if missing:
        raise ValueError(
            f"Missing two-stage label columns: {sorted(missing)}"
        )

    stage1 = (
        df["label_stage1_move_v1"]
        .astype(str)
        .to_numpy()
    )

    stage2_raw = df["label_stage2_direction_v1"]

    valid_stage1 = {"MOVE", "SIDEWAYS"}

    unexpected_stage1 = set(np.unique(stage1)) - valid_stage1

    if unexpected_stage1:
        raise ValueError(
            f"Unexpected Stage 1 labels: {unexpected_stage1}"
        )

    actual_class = np.where(
        stage1 == "SIDEWAYS",
        "SIDEWAYS",
        stage2_raw.astype(str).to_numpy(),
        )

    if not set(np.unique(actual_class)).issubset(CLASSES):
        raise ValueError(
            "Unexpected reconstructed three-class labels: "
            f"{set(np.unique(actual_class))}"
        )

    move_mask = stage1 == "MOVE"

    invalid_move_directions = (
            set(np.unique(actual_class[move_mask]))
            - {"DOWN", "UP"}
    )

    if invalid_move_directions:
        raise ValueError(
            "MOVE rows must have DOWN or UP direction labels: "
            f"{invalid_move_directions}"
        )

    sideways_mask = stage1 == "SIDEWAYS"

    return actual_class, stage1, stage2_raw, move_mask, sideways_mask


def calculate_metrics(y_true, probabilities):
    y_true = np.asarray(y_true)

    probabilities = np.asarray(
        probabilities,
        dtype=np.float64,
    )

    if probabilities.shape != (len(y_true), 3):
        raise ValueError(
            f"Invalid probability shape: {probabilities.shape}"
        )

    if not np.isfinite(probabilities).all():
        raise ValueError("Non-finite probabilities found.")

    if (probabilities < 0).any() or (probabilities > 1).any():
        raise ValueError("Probability outside [0, 1].")

    if not np.allclose(
            probabilities.sum(axis=1),
            1.0,
            atol=1e-6,
    ):
        raise ValueError(
            "Combined probabilities do not sum to 1."
        )

    predicted_index = probabilities.argmax(axis=1)
    y_pred = np.array(CLASSES)[predicted_index]

    y_numeric = pd.Categorical(
        y_true,
        categories=CLASSES,
    ).codes

    if (y_numeric < 0).any():
        raise ValueError("Unknown actual class found.")

    one_hot = np.eye(3)[y_numeric]

    metrics = {
        "rows": int(len(y_true)),
        "accuracy": float(
            accuracy_score(y_true, y_pred)
        ),
        "balanced_accuracy": float(
            balanced_accuracy_score(y_true, y_pred)
        ),
        "macro_f1": float(
            f1_score(
                y_true,
                y_pred,
                labels=CLASSES,
                average="macro",
                zero_division=0,
            )
        ),
        "weighted_f1": float(
            f1_score(
                y_true,
                y_pred,
                labels=CLASSES,
                average="weighted",
                zero_division=0,
            )
        ),
        "log_loss": float(
            log_loss(
                y_true,
                probabilities,
                labels=CLASSES,
            )
        ),
        "multiclass_brier_score": float(
            np.mean(
                np.sum(
                    (probabilities - one_hot) ** 2,
                    axis=1,
                    )
            )
        ),
        "macro_roc_auc_ovr": float(
            roc_auc_score(
                y_true,
                probabilities,
                labels=CLASSES,
                multi_class="ovr",
                average="macro",
            )
        ),
        "predicted_down_pct": float(
            (y_pred == "DOWN").mean() * 100
        ),
        "predicted_sideways_pct": float(
            (y_pred == "SIDEWAYS").mean() * 100
        ),
        "predicted_up_pct": float(
            (y_pred == "UP").mean() * 100
        ),
    }

    return metrics, y_pred


# ============================================================
# MAIN EVALUATION
# ============================================================

comparison_rows = []
audit_rows = []
prediction_files = []

for dataset in DATASETS:

    features = (
        INDEX_FEATURES
        if dataset == "index_only"
        else INDEX_FEATURES + OPTIONS_FEATURES
    )

    for horizon in HORIZONS:

        print()
        print("=" * 90)
        print(f"END-TO-END V2 | {dataset} | {horizon}m")
        print("=" * 90)

        # ----------------------------------------------------
        # 1. Load full Stage 1 validation dataset.
        # ----------------------------------------------------

        validation_path = (
                DATA_ROOT
                / "stage1"
                / dataset
                / f"validation_{horizon}m.parquet"
        )

        if not validation_path.exists():
            raise FileNotFoundError(validation_path)

        df = pd.read_parquet(validation_path)

        if df.empty:
            raise ValueError(
                f"Empty validation dataset: {validation_path}"
            )

        df["timestamp_ist"] = pd.to_datetime(
            df["timestamp_ist"],
            errors="raise",
        )

        if df["timestamp_ist"].duplicated().any():
            raise ValueError(
                f"Duplicate timestamps: {dataset} {horizon}m"
            )

        # ----------------------------------------------------
        # 2. Validate features.
        # ----------------------------------------------------

        X = validate_features(
            df,
            features,
            f"{dataset} {horizon}m",
        )

        # ----------------------------------------------------
        # 3. Load models.
        # ----------------------------------------------------

        stage1_bundle = load_bundle(
            "stage1",
            dataset,
            horizon,
        )

        stage2_bundle = load_bundle(
            "stage2",
            dataset,
            horizon,
        )

        if stage1_bundle["features"] != features:
            raise ValueError(
                "Stage 1 feature manifest mismatch."
            )

        if stage2_bundle["features"] != features:
            raise ValueError(
                "Stage 2 feature manifest mismatch."
            )

        # ----------------------------------------------------
        # 4. Stage 1: P(MOVE).
        # ----------------------------------------------------

        p_move = positive_probability(
            stage1_bundle,
            X,
        )

        # ----------------------------------------------------
        # 5. Stage 2: P(UP | MOVE).
        #
        # Apply Stage 2 to ALL rows, not only actual MOVE rows.
        # This is necessary for production inference.
        # ----------------------------------------------------

        p_up_given_move = positive_probability(
            stage2_bundle,
            X,
        )

        # ----------------------------------------------------
        # 6. Combine probabilities.
        # ----------------------------------------------------

        p_sideways = 1.0 - p_move

        p_down = p_move * (1.0 - p_up_given_move)

        p_up = p_move * p_up_given_move

        probabilities = np.column_stack([
            p_down,
            p_sideways,
            p_up,
        ])

        # ----------------------------------------------------
        # 7. Reconstruct two-stage ground truth.
        # ----------------------------------------------------

        (
            actual_class,
            actual_stage1,
            actual_stage2,
            move_mask,
            sideways_mask,
        ) = reconstruct_actual_classes(df)

        # ----------------------------------------------------
        # 8. Calculate end-to-end metrics.
        # ----------------------------------------------------

        metrics, predicted_class = calculate_metrics(
            actual_class,
            probabilities,
        )

        cm = confusion_matrix(
            actual_class,
            predicted_class,
            labels=CLASSES,
        )

        class_report = classification_report(
            actual_class,
            predicted_class,
            labels=CLASSES,
            output_dict=True,
            zero_division=0,
        )

        # ----------------------------------------------------
        # 9. Stage-level diagnostic metrics.
        # ----------------------------------------------------

        actual_move = move_mask.astype(int)

        stage1_predicted_move = (
                p_move >= 0.5
        ).astype(int)

        stage1_accuracy = float(
            accuracy_score(
                actual_move,
                stage1_predicted_move,
            )
        )

        stage1_balanced_accuracy = float(
            balanced_accuracy_score(
                actual_move,
                stage1_predicted_move,
            )
        )

        actual_direction = (
            actual_stage2[move_mask]
            .astype(str)
            .to_numpy()
        )

        stage2_probabilities = p_up_given_move[move_mask]

        stage2_predicted_direction = np.where(
            stage2_probabilities >= 0.5,
            "UP",
            "DOWN",
            )

        stage2_accuracy = float(
            accuracy_score(
                actual_direction,
                stage2_predicted_direction,
            )
        )

        stage2_macro_f1 = float(
            f1_score(
                actual_direction,
                stage2_predicted_direction,
                labels=["DOWN", "UP"],
                average="macro",
                zero_division=0,
            )
        )

        # ----------------------------------------------------
        # 10. Save predictions.
        # ----------------------------------------------------

        predictions = pd.DataFrame({
            "timestamp_ist": df["timestamp_ist"],
            "trading_day": df["trading_day"],
            "horizon_minutes": horizon,

            "actual_stage1": actual_stage1,
            "actual_stage2_direction": actual_stage2,
            "actual_class": actual_class,

            "two_stage_predicted_class": predicted_class,

            "prob_down": p_down,
            "prob_sideways": p_sideways,
            "prob_up": p_up,

            "prob_move": p_move,
            "prob_up_given_move": p_up_given_move,

            "target_z": df["target_z"],
            "forward_return": df["forward_return"],
        })

        prediction_path = (
                OUTPUT_ROOT
                / f"{dataset}_predictions_{horizon}m.csv"
        )

        predictions.to_csv(
            prediction_path,
            index=False,
        )

        prediction_files.append(str(prediction_path))

        # ----------------------------------------------------
        # 11. Save detailed metrics.
        # ----------------------------------------------------

        detail = {
            "dataset": dataset,
            "horizon_minutes": horizon,
            "validation_period": "2024",
            "rows": len(df),

            "actual_class_distribution": {
                label: int(
                    (actual_class == label).sum()
                )
                for label in CLASSES
            },

            "actual_move_rows": int(move_mask.sum()),
            "actual_sideways_rows": int(sideways_mask.sum()),

            "stage1_metrics": {
                "accuracy_at_0_5": stage1_accuracy,
                "balanced_accuracy_at_0_5": (
                    stage1_balanced_accuracy
                ),
            },

            "stage2_metrics_on_actual_move_rows": {
                "rows": int(move_mask.sum()),
                "accuracy_at_0_5": stage2_accuracy,
                "macro_f1": stage2_macro_f1,
            },

            "end_to_end_metrics": metrics,

            "confusion_matrix": {
                "class_order": CLASSES,
                "matrix": cm.tolist(),
            },

            "classification_report": class_report,

            "probability_combination": {
                "sideways": "1 - P(MOVE)",
                "down": "P(MOVE) * (1 - P(UP | MOVE))",
                "up": "P(MOVE) * P(UP | MOVE)",
            },

            "stage2_inference": (
                "Stage 2 evaluated on every validation row."
            ),

            "baseline_comparison": (
                "Not performed: Quantile V3 uses different "
                "three-class target definitions."
            ),
        }

        metrics_path = (
                OUTPUT_ROOT
                / f"{dataset}_metrics_{horizon}m.json"
        )

        write_json(detail, metrics_path)

        # ----------------------------------------------------
        # 12. Comparison summary row.
        # ----------------------------------------------------

        comparison_rows.append({
            "dataset": dataset,
            "horizon_minutes": horizon,
            "validation_rows": len(df),

            "actual_down_pct": (
                    (actual_class == "DOWN").mean() * 100
            ),
            "actual_sideways_pct": (
                    (actual_class == "SIDEWAYS").mean() * 100
            ),
            "actual_up_pct": (
                    (actual_class == "UP").mean() * 100
            ),

            "stage1_accuracy": stage1_accuracy,
            "stage1_balanced_accuracy": (
                stage1_balanced_accuracy
            ),

            "stage2_accuracy_on_actual_move": (
                stage2_accuracy
            ),
            "stage2_macro_f1_on_actual_move": (
                stage2_macro_f1
            ),

            "end_to_end_accuracy": metrics["accuracy"],
            "end_to_end_balanced_accuracy": (
                metrics["balanced_accuracy"]
            ),
            "end_to_end_macro_f1": metrics["macro_f1"],
            "end_to_end_weighted_f1": metrics["weighted_f1"],
            "end_to_end_log_loss": metrics["log_loss"],
            "end_to_end_brier": (
                metrics["multiclass_brier_score"]
            ),
            "end_to_end_roc_auc": (
                metrics["macro_roc_auc_ovr"]
            ),

            "predicted_down_pct": (
                metrics["predicted_down_pct"]
            ),
            "predicted_sideways_pct": (
                metrics["predicted_sideways_pct"]
            ),
            "predicted_up_pct": (
                metrics["predicted_up_pct"]
            ),

            "status": "PASS",
        })

        # ----------------------------------------------------
        # 13. Alignment and integrity audit.
        # ----------------------------------------------------

        audit_rows.append({
            "dataset": dataset,
            "horizon_minutes": horizon,
            "validation_rows": len(df),
            "unique_timestamps": (
                df["timestamp_ist"].nunique()
            ),
            "duplicate_timestamps": int(
                df["timestamp_ist"].duplicated().sum()
            ),
            "missing_features": 0,
            "nonfinite_features": 0,
            "invalid_actual_classes": 0,
            "probability_sum_max_error": float(
                np.max(
                    np.abs(probabilities.sum(axis=1) - 1.0)
                )
            ),
            "status": "PASS",
        })

        print(
            f"Stage 1 accuracy: {stage1_accuracy:.5f}"
        )
        print(
            f"Stage 2 accuracy on actual MOVE: "
            f"{stage2_accuracy:.5f}"
        )
        print(
            f"End-to-end accuracy: {metrics['accuracy']:.5f}"
        )
        print(
            f"End-to-end balanced accuracy: "
            f"{metrics['balanced_accuracy']:.5f}"
        )
        print(
            f"End-to-end macro F1: {metrics['macro_f1']:.5f}"
        )
        print(
            f"End-to-end log loss: {metrics['log_loss']:.5f}"
        )


# ============================================================
# FINAL REPORTS
# ============================================================

comparison_df = pd.DataFrame(comparison_rows)
audit_df = pd.DataFrame(audit_rows)

comparison_path = (
        OUTPUT_ROOT
        / "end_to_end_model_comparison_v2.csv"
)

audit_path = (
        OUTPUT_ROOT
        / "end_to_end_alignment_audit_v2.csv"
)

comparison_df.to_csv(
    comparison_path,
    index=False,
)

audit_df.to_csv(
    audit_path,
    index=False,
)

summary = {
    "status": (
        "PASS"
        if len(comparison_rows) == 6
           and len(audit_rows) == 6
           and all(
            row["status"] == "PASS"
            for row in audit_rows
        )
        else "FAIL"
    ),

    "evaluation": "TWO_STAGE_END_TO_END_V2",
    "validation_period": "2024",

    "models_evaluated": 6,

    "datasets": DATASETS,
    "horizons": HORIZONS,

    "ground_truth": (
        "Two-stage V1 labels: Stage 1 MOVE/SIDEWAYS; "
        "Stage 2 DOWN/UP conditional on MOVE."
    ),

    "comparison_baseline": None,

    "quantile_v3_comparison": (
        "Excluded because Quantile V3 and two-stage V1 "
        "use different target definitions."
    ),

    "probability_combination": {
        "sideways": "1 - P(MOVE)",
        "down": "P(MOVE) * (1 - P(UP | MOVE))",
        "up": "P(MOVE) * P(UP | MOVE)",
    },

    "stage2_inference": (
        "Stage 2 applied to every validation row, "
        "not only actual MOVE rows."
    ),

    "alignment_audit": audit_rows,

    "comparison_file": str(comparison_path),
    "audit_file": str(audit_path),
    "prediction_files": prediction_files,

    "important_caveats": [
        "2024 is diagnostic validation, not an untouched final test.",
        "Stage 2 probabilities on actual SIDEWAYS rows are "
        "out-of-training-distribution estimates.",
        "The end-to-end metrics evaluate the complete two-stage "
        "pipeline against the two-stage V1 labels.",
        "No trading profitability or tradable edge is established.",
    ],
}

write_json(
    summary,
    OUTPUT_ROOT / "end_to_end_summary_v2.json",
    )

print()
print("=" * 90)
print("TWO-STAGE END-TO-END V2 COMPLETED")
print("=" * 90)

print(comparison_df.to_string(index=False))

print()
print(json.dumps(summary, indent=2))

if summary["status"] != "PASS":
    raise RuntimeError(
        "End-to-end V2 evaluation failed."
    )
