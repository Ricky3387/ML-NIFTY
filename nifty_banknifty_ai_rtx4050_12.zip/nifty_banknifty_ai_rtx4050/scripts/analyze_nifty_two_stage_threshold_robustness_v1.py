
from pathlib import Path
import json
import warnings

import joblib
import lightgbm as lgb
import numpy as np
import pandas as pd

from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    f1_score,
    precision_score,
    recall_score,
    log_loss,
    roc_auc_score,
    confusion_matrix,
)
from sklearn.utils.class_weight import compute_sample_weight

warnings.filterwarnings("ignore")

# ============================================================
# CONFIGURATION
# ============================================================

ROOT = Path(__file__).resolve().parent.parent

DATA_ROOT = (
        ROOT / "data" / "processed"
        / "nifty_two_stage_matched_datasets_v1"
)

EXISTING_PREDICTION_ROOT = (
        ROOT / "reports"
        / "nifty_two_stage_end_to_end_v2"
)

OUTPUT_ROOT = (
        ROOT / "reports"
        / "nifty_two_stage_threshold_robustness_v1"
)

HORIZONS = [5, 15, 30]
DATASETS = ["index_only", "index_plus_options"]

INDEX_FEATURES = [
    "ret_1m",
    "logret_1m",
    "range_pct",
    "body_pct",
    "upper_wick_pct",
    "lower_wick_pct",
    "return_5m",
    "return_15m",
    "return_30m",
    "return_60m",
    "realized_vol_5m",
    "realized_vol_15m",
    "realized_vol_30m",
    "realized_vol_60m",
    "high_low_range_5m",
    "high_low_range_15m",
    "high_low_range_30m",
    "high_low_range_60m",
    "close_vs_ema9_pct",
    "close_vs_ema21_pct",
    "close_vs_ema50_pct",
    "rsi_14",
    "positive_return_count_5m",
    "negative_return_count_5m",
]

OPTIONS_FEATURES = [
    "selected_dte",
    "atm_distance_pct",
    "atm_straddle_premium_pct",
    "atm_ce_log_return_1m",
    "atm_pe_log_return_1m",
    "atm_ce_pe_return_spread_1m",
    "atm_straddle_weighted_log_return_1m",
    "atm_ce_oi_change_1m",
    "atm_pe_oi_change_1m",
    "near_atm_pcr_oi",
    "near_atm_pcr_volume",
    "near_atm_oi_imbalance",
    "near_atm_volume_imbalance",
    "paired_strike_count",
]

TARGETS = {
    "stage1": {
        "column": "label_stage1_move_v1",
        "negative": "SIDEWAYS",
        "positive": "MOVE",
    },
    "stage2": {
        "column": "label_stage2_direction_v1",
        "negative": "DOWN",
        "positive": "UP",
    },
}

PARAMS = {
    "objective": "binary",
    "metric": "binary_logloss",
    "learning_rate": 0.02,
    "n_estimators": 3000,
    "num_leaves": 15,
    "max_depth": -1,
    "min_child_samples": 300,
    "subsample": 0.8,
    "subsample_freq": 1,
    "colsample_bytree": 0.8,
    "reg_alpha": 0.5,
    "reg_lambda": 10.0,
    "max_bin": 127,
    "random_state": 42,
    "n_jobs": 4,
    "verbosity": -1,
    "deterministic": True,
    "force_col_wise": True,
}

EARLY_STOPPING_ROUNDS = 100

# Thresholds selected exclusively on 2023 predictions.
MOVE_THRESHOLDS = np.round(
    np.arange(0.30, 0.701, 0.01),
    2,
)

DIRECTION_THRESHOLD = 0.50

CLASSES = ["DOWN", "SIDEWAYS", "UP"]

# ============================================================
# OUTPUT SAFETY
# ============================================================

OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)

if any(OUTPUT_ROOT.iterdir()):
    raise FileExistsError(
        "Output directory is not empty. "
        "Previous results will not be overwritten:\n"
        f"{OUTPUT_ROOT}"
    )


# ============================================================
# HELPERS
# ============================================================

def write_json(data, path):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(
            data,
            f,
            indent=2,
            default=str,
            allow_nan=False,
        )


def load_data(stage, dataset, split, horizon):
    path = (
            DATA_ROOT
            / stage
            / dataset
            / f"{split}_{horizon}m.parquet"
    )

    if not path.exists():
        raise FileNotFoundError(path)

    return pd.read_parquet(path)


def get_features(dataset):
    if dataset == "index_only":
        return INDEX_FEATURES

    return INDEX_FEATURES + OPTIONS_FEATURES


def validate_matrix(df, features, name):
    missing = set(features) - set(df.columns)

    if missing:
        raise ValueError(
            f"{name}: missing features {sorted(missing)}"
        )

    X = df[features].copy()

    for col in features:
        X[col] = pd.to_numeric(
            X[col],
            errors="coerce",
        )

    values = X.to_numpy(dtype=np.float64)

    if not np.isfinite(values).all():
        bad = X.columns[
            ~np.isfinite(values).all(axis=0)
        ].tolist()

        raise ValueError(
            f"{name}: non-finite features: {bad}"
        )

    return X.astype(np.float32)


def make_target(series, negative, positive):
    mapping = {
        negative: 0,
        positive: 1,
    }

    target = series.map(mapping)

    if target.isna().any():
        unexpected = (
            series[target.isna()]
            .unique()
            .tolist()
        )

        raise ValueError(
            f"Unexpected target values: {unexpected}"
        )

    return target.astype(np.int8).to_numpy()


def train_temporary_model(
        stage,
        dataset,
        horizon,
        features,
):
    """
    Train temporary model:

    Fit: 2021
    Early stopping: 2022
    Final refit: 2021-2022

    This model generates out-of-sample 2023 predictions.
    """

    config = TARGETS[stage]
    target_column = config["column"]

    train_df = load_data(
        stage,
        dataset,
        "train",
        horizon,
    )

    days = pd.to_datetime(train_df["trading_day"])

    fit_df = train_df.loc[
        days.dt.year == 2021
        ].copy()

    early_df = train_df.loc[
        days.dt.year == 2022
        ].copy()

    if fit_df.empty or early_df.empty:
        raise ValueError(
            f"{stage}/{dataset}/{horizon}m: "
            "2021 fit or 2022 early-stop data is empty."
        )

    X_fit = validate_matrix(
        fit_df,
        features,
        f"{stage} fit 2021",
    )

    X_early = validate_matrix(
        early_df,
        features,
        f"{stage} early-stop 2022",
    )

    y_fit = make_target(
        fit_df[target_column],
        config["negative"],
        config["positive"],
    )

    y_early = make_target(
        early_df[target_column],
        config["negative"],
        config["positive"],
    )

    if len(np.unique(y_fit)) != 2:
        raise ValueError(
            f"{stage}: 2021 fit does not contain both classes."
        )

    if len(np.unique(y_early)) != 2:
        raise ValueError(
            f"{stage}: 2022 early-stop does not contain both classes."
        )

    fit_weights = compute_sample_weight(
        class_weight="balanced",
        y=y_fit,
    )

    early_weights = compute_sample_weight(
        class_weight="balanced",
        y=y_early,
    )

    estimator = lgb.LGBMClassifier(**PARAMS)

    estimator.fit(
        X_fit,
        y_fit,
        sample_weight=fit_weights,
        eval_set=[(X_early, y_early)],
        eval_sample_weight=[early_weights],
        callbacks=[
            lgb.early_stopping(
                EARLY_STOPPING_ROUNDS,
                verbose=False,
            ),
            lgb.log_evaluation(0),
        ],
    )

    best_iteration = (
            estimator.best_iteration_
            or PARAMS["n_estimators"]
    )

    # Refit on the full 2021-2022 period.
    full_df = pd.concat(
        [fit_df, early_df],
        ignore_index=True,
    )

    X_full = validate_matrix(
        full_df,
        features,
        f"{stage} final fit 2021-2022",
    )

    y_full = make_target(
        full_df[target_column],
        config["negative"],
        config["positive"],
    )

    full_weights = compute_sample_weight(
        class_weight="balanced",
        y=y_full,
    )

    final_params = PARAMS.copy()
    final_params["n_estimators"] = int(best_iteration)

    final_model = lgb.LGBMClassifier(
        **final_params
    )

    final_model.fit(
        X_full,
        y_full,
        sample_weight=full_weights,
    )

    return {
        "model": final_model,
        "stage": stage,
        "dataset": dataset,
        "horizon_minutes": horizon,
        "features": features,
        "best_iteration": int(best_iteration),
        "fit_rows_2021": len(fit_df),
        "early_stop_rows_2022": len(early_df),
        "final_fit_rows_2021_2022": len(full_df),
    }


def positive_probability(bundle, X):
    model = bundle["model"]
    probabilities = model.predict_proba(X)

    classes = list(model.classes_)

    if 1 not in classes:
        raise ValueError(
            f"Positive class 1 missing: {classes}"
        )

    return probabilities[:, classes.index(1)]


def reconstruct_actual_class(df):
    stage1 = (
        df["label_stage1_move_v1"]
        .astype(str)
        .to_numpy()
    )

    stage2 = (
        df["label_stage2_direction_v1"]
        .astype(str)
        .to_numpy()
    )

    actual = np.where(
        stage1 == "SIDEWAYS",
        "SIDEWAYS",
        stage2,
        )

    valid = set(np.unique(actual))

    if not valid.issubset(CLASSES):
        raise ValueError(
            f"Invalid actual classes: {valid}"
        )

    move_mask = stage1 == "MOVE"

    if not set(np.unique(actual[move_mask])).issubset(
            {"DOWN", "UP"}
    ):
        raise ValueError(
            "MOVE rows must have DOWN or UP labels."
        )

    return actual


def predict_with_threshold(
        p_move,
        p_up_given_move,
        threshold,
):
    """
    Decision policy:

    If P(MOVE) >= threshold:
        predict UP or DOWN using Stage 2.
    Otherwise:
        predict SIDEWAYS.
    """

    directional = p_move >= threshold

    predicted = np.full(
        len(p_move),
        "SIDEWAYS",
        dtype=object,
    )

    predicted[
        directional
        & (p_up_given_move >= DIRECTION_THRESHOLD)
        ] = "UP"

    predicted[
        directional
        & (p_up_given_move < DIRECTION_THRESHOLD)
        ] = "DOWN"

    return predicted


def calculate_classification_metrics(y_true, y_pred):
    return {
        "accuracy": float(
            accuracy_score(y_true, y_pred)
        ),
        "balanced_accuracy": float(
            balanced_accuracy_score(y_true, y_pred)
        ),
        "macro_f1": float(
            f1_score(
                y_true,
                y_pred,
                labels=CLASSES,
                average="macro",
                zero_division=0,
            )
        ),
        "weighted_f1": float(
            f1_score(
                y_true,
                y_pred,
                labels=CLASSES,
                average="weighted",
                zero_division=0,
            )
        ),
        "down_precision": float(
            precision_score(
                y_true,
                y_pred,
                labels=CLASSES,
                average=None,
                zero_division=0,
            )[0]
        ),
        "sideways_precision": float(
            precision_score(
                y_true,
                y_pred,
                labels=CLASSES,
                average=None,
                zero_division=0,
            )[1]
        ),
        "up_precision": float(
            precision_score(
                y_true,
                y_pred,
                labels=CLASSES,
                average=None,
                zero_division=0,
            )[2]
        ),
        "down_recall": float(
            recall_score(
                y_true,
                y_pred,
                labels=CLASSES,
                average=None,
                zero_division=0,
            )[0]
        ),
        "sideways_recall": float(
            recall_score(
                y_true,
                y_pred,
                labels=CLASSES,
                average=None,
                zero_division=0,
            )[1]
        ),
        "up_recall": float(
            recall_score(
                y_true,
                y_pred,
                labels=CLASSES,
                average=None,
                zero_division=0,
            )[2]
        ),
        "predicted_down_pct": float(
            (y_pred == "DOWN").mean() * 100
        ),
        "predicted_sideways_pct": float(
            (y_pred == "SIDEWAYS").mean() * 100
        ),
        "predicted_up_pct": float(
            (y_pred == "UP").mean() * 100
        ),
        "directional_prediction_coverage_pct": float(
            (y_pred != "SIDEWAYS").mean() * 100
        ),
    }


def calculate_probability_metrics(
        y_true,
        probabilities,
):
    y_numeric = pd.Categorical(
        y_true,
        categories=CLASSES,
    ).codes

    one_hot = np.eye(3)[y_numeric]

    return {
        "log_loss": float(
            log_loss(
                y_true,
                probabilities,
                labels=CLASSES,
            )
        ),
        "multiclass_brier_score": float(
            np.mean(
                np.sum(
                    (probabilities - one_hot) ** 2,
                    axis=1,
                    )
            )
        ),
        "macro_roc_auc_ovr": float(
            roc_auc_score(
                y_true,
                probabilities,
                labels=CLASSES,
                multi_class="ovr",
                average="macro",
            )
        ),
    }


# ============================================================
# MAIN EXPERIMENT
# ============================================================

threshold_rows = []
selection_rows = []
evaluation_rows = []
model_details = []

for dataset in DATASETS:

    features = get_features(dataset)

    for horizon in HORIZONS:

        print()
        print("=" * 90)
        print(
            f"THRESHOLD ROBUSTNESS | {dataset} | {horizon}m"
        )
        print("=" * 90)

        # ----------------------------------------------------
        # 1. Load full Stage 1 training data.
        # This contains all eligible 2023 rows.
        # ----------------------------------------------------

        stage1_train = load_data(
            "stage1",
            dataset,
            "train",
            horizon,
        )

        stage1_train["trading_day"] = pd.to_datetime(
            stage1_train["trading_day"]
        )

        rows_2023 = stage1_train.loc[
            stage1_train["trading_day"].dt.year == 2023
            ].copy()

        if rows_2023.empty:
            raise ValueError(
                f"No 2023 rows for {dataset} {horizon}m."
            )

        rows_2023["timestamp_ist"] = pd.to_datetime(
            rows_2023["timestamp_ist"],
            errors="raise",
        )

        if rows_2023["timestamp_ist"].duplicated().any():
            raise ValueError(
                "Duplicate 2023 timestamps."
            )

        X_2023 = validate_matrix(
            rows_2023,
            features,
            f"{dataset} {horizon}m 2023",
        )

        actual_2023 = reconstruct_actual_class(
            rows_2023
        )

        # ----------------------------------------------------
        # 2. Train temporary Stage 1 and Stage 2 models.
        # ----------------------------------------------------

        stage1_bundle = train_temporary_model(
            "stage1",
            dataset,
            horizon,
            features,
        )

        stage2_bundle = train_temporary_model(
            "stage2",
            dataset,
            horizon,
            features,
        )

        # ----------------------------------------------------
        # 3. Generate out-of-sample 2023 probabilities.
        # ----------------------------------------------------

        p_move_2023 = positive_probability(
            stage1_bundle,
            X_2023,
        )

        p_up_2023 = positive_probability(
            stage2_bundle,
            X_2023,
        )

        if not (
                np.isfinite(p_move_2023).all()
                and np.isfinite(p_up_2023).all()
        ):
            raise ValueError(
                "Non-finite 2023 probabilities."
            )

        # ----------------------------------------------------
        # 4. Evaluate every threshold on 2023.
        # ----------------------------------------------------

        current_threshold_results = []

        for threshold in MOVE_THRESHOLDS:

            predicted = predict_with_threshold(
                p_move_2023,
                p_up_2023,
                threshold,
            )

            metrics = calculate_classification_metrics(
                actual_2023,
                predicted,
            )

            row = {
                "dataset": dataset,
                "horizon_minutes": horizon,
                "threshold": float(threshold),
                "period": "THRESHOLD_SELECTION_2023",
                **metrics,
            }

            threshold_rows.append(row)
            current_threshold_results.append(row)

        threshold_df = pd.DataFrame(
            current_threshold_results
        )

        # Highest macro F1; balanced accuracy breaks ties.
        selected = threshold_df.sort_values(
            [
                "macro_f1",
                "balanced_accuracy",
                "directional_prediction_coverage_pct",
            ],
            ascending=[False, False, False],
            kind="stable",
        ).iloc[0]

        selected_threshold = float(
            selected["threshold"]
        )

        selection_rows.append({
            "dataset": dataset,
            "horizon_minutes": horizon,
            "selected_move_threshold": selected_threshold,
            "direction_threshold": DIRECTION_THRESHOLD,
            "selection_period": "2023",
            "selection_macro_f1": float(
                selected["macro_f1"]
            ),
            "selection_balanced_accuracy": float(
                selected["balanced_accuracy"]
            ),
            "selection_directional_coverage_pct": float(
                selected["directional_prediction_coverage_pct"]
            ),
            "stage1_best_iteration": (
                stage1_bundle["best_iteration"]
            ),
            "stage2_best_iteration": (
                stage2_bundle["best_iteration"]
            ),
        })

        # ----------------------------------------------------
        # 5. Save 2023 threshold-selection predictions.
        # ----------------------------------------------------

        pred_2023 = predict_with_threshold(
            p_move_2023,
            p_up_2023,
            selected_threshold,
        )

        export_2023 = pd.DataFrame({
            "timestamp_ist": rows_2023["timestamp_ist"],
            "trading_day": rows_2023["trading_day"],
            "actual_class": actual_2023,
            "p_move": p_move_2023,
            "p_up_given_move": p_up_2023,
            "selected_threshold": selected_threshold,
            "predicted_class": pred_2023,
        })

        export_2023.to_csv(
            OUTPUT_ROOT
            / f"{dataset}_threshold_selection_2023_{horizon}m.csv",
            index=False,
            )

        # ----------------------------------------------------
        # 6. Load existing 2024 V2 predictions.
        # ----------------------------------------------------

        validation_path = (
                EXISTING_PREDICTION_ROOT
                / f"{dataset}_predictions_{horizon}m.csv"
        )

        if not validation_path.exists():
            raise FileNotFoundError(validation_path)

        validation = pd.read_csv(validation_path)

        required = {
            "timestamp_ist",
            "actual_class",
            "prob_move",
            "prob_up_given_move",
        }

        missing = required - set(validation.columns)

        if missing:
            raise ValueError(
                f"2024 prediction file missing columns: {missing}"
            )

        validation["timestamp_ist"] = pd.to_datetime(
            validation["timestamp_ist"],
            errors="raise",
        )

        if validation["timestamp_ist"].duplicated().any():
            raise ValueError(
                "Duplicate 2024 prediction timestamps."
            )

        actual_2024 = (
            validation["actual_class"]
            .astype(str)
            .to_numpy()
        )

        if not set(np.unique(actual_2024)).issubset(CLASSES):
            raise ValueError(
                "Invalid 2024 actual classes."
            )

        p_move_2024 = validation[
            "prob_move"
        ].to_numpy(dtype=np.float64)

        p_up_2024 = validation[
            "prob_up_given_move"
        ].to_numpy(dtype=np.float64)

        if not (
                np.isfinite(p_move_2024).all()
                and np.isfinite(p_up_2024).all()
        ):
            raise ValueError(
                "Non-finite 2024 probabilities."
            )

        if (
                (p_move_2024 < 0).any()
                or (p_move_2024 > 1).any()
                or (p_up_2024 < 0).any()
                or (p_up_2024 > 1).any()
        ):
            raise ValueError(
                "2024 probabilities outside [0,1]."
            )

        # ----------------------------------------------------
        # 7. Apply selected threshold to 2024.
        # ----------------------------------------------------

        predicted_2024 = predict_with_threshold(
            p_move_2024,
            p_up_2024,
            selected_threshold,
        )

        metrics_selected = calculate_classification_metrics(
            actual_2024,
            predicted_2024,
        )

        # Original V2 argmax prediction.
        original_predicted = (
            validation["two_stage_predicted_class"]
            .astype(str)
            .to_numpy()
        )

        metrics_argmax = calculate_classification_metrics(
            actual_2024,
            original_predicted,
        )

        # Fixed 0.50 threshold comparison.
        predicted_050 = predict_with_threshold(
            p_move_2024,
            p_up_2024,
            0.50,
        )

        metrics_050 = calculate_classification_metrics(
            actual_2024,
            predicted_050,
        )

        # ----------------------------------------------------
        # 8. Probability metrics for original V2 model.
        # These are unaffected by threshold changes.
        # ----------------------------------------------------

        p_sideways = 1.0 - p_move_2024
        p_down = p_move_2024 * (1.0 - p_up_2024)
        p_up = p_move_2024 * p_up_2024

        probabilities_2024 = np.column_stack([
            p_down,
            p_sideways,
            p_up,
        ])

        probability_metrics = calculate_probability_metrics(
            actual_2024,
            probabilities_2024,
        )

        # ----------------------------------------------------
        # 9. Threshold robustness report.
        # ----------------------------------------------------

        for policy, policy_metrics in [
            ("ORIGINAL_ARGMAX", metrics_argmax),
            ("FIXED_0_50", metrics_050),
            ("SELECTED_2023_THRESHOLD", metrics_selected),
        ]:

            evaluation_rows.append({
                "dataset": dataset,
                "horizon_minutes": horizon,
                "policy": policy,
                "selected_threshold": (
                    selected_threshold
                    if policy == "SELECTED_2023_THRESHOLD"
                    else (
                        0.50
                        if policy == "FIXED_0_50"
                        else None
                    )
                ),
                "evaluation_period": "2024",
                **policy_metrics,
                **(
                    probability_metrics
                    if policy == "ORIGINAL_ARGMAX"
                    else {}
                ),
            })

        # ----------------------------------------------------
        # 10. Export 2024 predictions.
        # ----------------------------------------------------

        export_2024 = validation.copy()

        export_2024["selected_2023_move_threshold"] = (
            selected_threshold
        )

        export_2024["threshold_policy_predicted_class"] = (
            predicted_2024
        )

        export_2024["fixed_050_predicted_class"] = (
            predicted_050
        )

        export_2024["threshold_policy_directional"] = (
                predicted_2024 != "SIDEWAYS"
        )

        export_2024.to_csv(
            OUTPUT_ROOT
            / f"{dataset}_threshold_evaluation_2024_{horizon}m.csv",
            index=False,
            )

        # ----------------------------------------------------
        # 11. Confusion matrix.
        # ----------------------------------------------------

        cm = confusion_matrix(
            actual_2024,
            predicted_2024,
            labels=CLASSES,
        )

        detail = {
            "dataset": dataset,
            "horizon_minutes": horizon,
            "status": "PASS",

            "threshold_selection": {
                "period": "2023",
                "objective": "macro_f1",
                "tie_breaker": "balanced_accuracy",
                "selected_move_threshold": selected_threshold,
                "direction_threshold": DIRECTION_THRESHOLD,
                "selected_metrics": {
                    "macro_f1": float(
                        selected["macro_f1"]
                    ),
                    "balanced_accuracy": float(
                        selected["balanced_accuracy"]
                    ),
                    "directional_coverage_pct": float(
                        selected["directional_prediction_coverage_pct"]
                    ),
                },
            },

            "temporary_training": {
                "fit_period": "2021",
                "early_stop_period": "2022",
                "final_fit_period": "2021-2022",
                "stage1": stage1_bundle,
                "stage2": stage2_bundle,
            },

            "evaluation_period": "2024",

            "original_argmax_metrics": metrics_argmax,
            "fixed_050_metrics": metrics_050,
            "selected_threshold_metrics": metrics_selected,

            "original_probability_metrics": probability_metrics,

            "confusion_matrix": {
                "class_order": CLASSES,
                "matrix": cm.tolist(),
            },

            "important_caveat": (
                "2023 is used for threshold selection. "
                "2024 is diagnostic evaluation, not an untouched "
                "final test. The temporary 2021-2022 models and "
                "existing 2021-2023 V2 models have different "
                "training histories; threshold portability must "
                "therefore be interpreted cautiously."
            ),
        }

        write_json(
            detail,
            OUTPUT_ROOT
            / f"{dataset}_robustness_metrics_{horizon}m.json",
            )

        model_details.append({
            "dataset": dataset,
            "horizon_minutes": horizon,
            "selected_threshold": selected_threshold,
            "stage1_best_iteration": (
                stage1_bundle["best_iteration"]
            ),
            "stage2_best_iteration": (
                stage2_bundle["best_iteration"]
            ),
            "status": "PASS",
        })

        print(
            f"Selected 2023 MOVE threshold: "
            f"{selected_threshold:.2f}"
        )
        print(
            f"2024 original macro F1: "
            f"{metrics_argmax['macro_f1']:.5f}"
        )
        print(
            f"2024 fixed 0.50 macro F1: "
            f"{metrics_050['macro_f1']:.5f}"
        )
        print(
            f"2024 selected threshold macro F1: "
            f"{metrics_selected['macro_f1']:.5f}"
        )
        print(
            f"2024 selected threshold balanced accuracy: "
            f"{metrics_selected['balanced_accuracy']:.5f}"
        )
        print(
            f"2024 directional coverage: "
            f"{metrics_selected['directional_prediction_coverage_pct']:.2f}%"
        )


# ============================================================
# SAVE FINAL REPORTS
# ============================================================

threshold_df = pd.DataFrame(threshold_rows)
selection_df = pd.DataFrame(selection_rows)
evaluation_df = pd.DataFrame(evaluation_rows)

threshold_df.to_csv(
    OUTPUT_ROOT / "threshold_sensitivity_2023.csv",
    index=False,
    )

selection_df.to_csv(
    OUTPUT_ROOT / "selected_thresholds_2023.csv",
    index=False,
    )

evaluation_df.to_csv(
    OUTPUT_ROOT / "threshold_evaluation_2024.csv",
    index=False,
    )

summary = {
    "status": (
        "PASS"
        if len(selection_rows) == 6
           and len(model_details) == 6
        else "FAIL"
    ),

    "experiment": "TWO_STAGE_THRESHOLD_ROBUSTNESS_V1",

    "datasets": DATASETS,
    "horizons": HORIZONS,

    "threshold_selection_period": "2023",
    "evaluation_period": "2024",

    "temporary_model_training": {
        "fit": "2021",
        "early_stopping": "2022",
        "final_refit": "2021-2022",
        "sample_weighting": "balanced",
        "parameters": PARAMS,
    },

    "threshold_objective": "macro_f1",
    "threshold_tie_breaker": "balanced_accuracy",

    "move_threshold_grid": [
        float(x) for x in MOVE_THRESHOLDS
    ],

    "direction_threshold": DIRECTION_THRESHOLD,

    "models_evaluated": len(model_details),

    "selected_thresholds": selection_rows,

    "important_caveats": [
        "2023 predictions are out-of-sample from temporary models.",
        "Thresholds are selected only using 2023 labels.",
        "2024 is diagnostic evaluation, not an untouched final test.",
        "Temporary models are trained on 2021-2022, while "
        "existing V2 evaluation models were trained on 2021-2023.",
        "Threshold portability across these training histories "
        "must be interpreted cautiously.",
        "Improved classification metrics do not establish "
        "trading profitability.",
        "No live orders or paper trades are performed.",
    ],
}

write_json(
    summary,
    OUTPUT_ROOT / "threshold_robustness_summary_v1.json",
    )

print()
print("=" * 90)
print("THRESHOLD ROBUSTNESS EXPERIMENT COMPLETED")
print("=" * 90)

print()
print("SELECTED THRESHOLDS")
print(selection_df.to_string(index=False))

print()
print("2024 EVALUATION")
print(
    evaluation_df[
        [
            "dataset",
            "horizon_minutes",
            "policy",
            "macro_f1",
            "balanced_accuracy",
            "directional_prediction_coverage_pct",
        ]
    ].to_string(index=False)
)

print()
print(json.dumps({
    "status": summary["status"],
    "models_evaluated": len(model_details),
    "output_directory": str(OUTPUT_ROOT),
}, indent=2))

if summary["status"] != "PASS":
    raise RuntimeError(
        "Threshold robustness experiment failed."
    )
