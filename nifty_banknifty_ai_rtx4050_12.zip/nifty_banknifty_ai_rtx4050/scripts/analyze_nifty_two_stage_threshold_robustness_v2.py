
from pathlib import Path
import json
import warnings

import numpy as np
import pandas as pd
import lightgbm as lgb

from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    f1_score,
    log_loss,
    roc_auc_score,
    confusion_matrix,
    classification_report,
)
from sklearn.utils.class_weight import compute_sample_weight

warnings.filterwarnings("ignore")

# ============================================================
# CONFIGURATION
# ============================================================

ROOT = Path(__file__).resolve().parent.parent

DATA_ROOT = (
        ROOT / "data" / "processed"
        / "nifty_two_stage_matched_datasets_v1"
)

REPORT_ROOT = (
        ROOT / "reports"
        / "nifty_two_stage_threshold_robustness_v2"
)

HORIZONS = [5, 15, 30]
DATASETS = ["index_only", "index_plus_options"]

# Temporary-model chronology:
# Fit:              2021
# Early stopping:   2022
# Final refit:      2021-2022
# Threshold select: 2023
# Transfer test:    2024

FIT_YEAR = 2021
EARLY_STOP_YEAR = 2022
THRESHOLD_YEAR = 2023
EVALUATION_YEAR = 2024

THRESHOLD_GRID = np.round(
    np.arange(0.30, 0.701, 0.01), 2
).tolist()

FIXED_MOVE_THRESHOLD = 0.50
DIRECTION_THRESHOLD = 0.50
EARLY_STOPPING_ROUNDS = 100

INDEX_FEATURES = [
    "ret_1m",
    "logret_1m",
    "range_pct",
    "body_pct",
    "upper_wick_pct",
    "lower_wick_pct",
    "return_5m",
    "return_15m",
    "return_30m",
    "return_60m",
    "realized_vol_5m",
    "realized_vol_15m",
    "realized_vol_30m",
    "realized_vol_60m",
    "high_low_range_5m",
    "high_low_range_15m",
    "high_low_range_30m",
    "high_low_range_60m",
    "close_vs_ema9_pct",
    "close_vs_ema21_pct",
    "close_vs_ema50_pct",
    "rsi_14",
    "positive_return_count_5m",
    "negative_return_count_5m",
]

OPTIONS_FEATURES = [
    "selected_dte",
    "atm_distance_pct",
    "atm_straddle_premium_pct",
    "atm_ce_log_return_1m",
    "atm_pe_log_return_1m",
    "atm_ce_pe_return_spread_1m",
    "atm_straddle_weighted_log_return_1m",
    "atm_ce_oi_change_1m",
    "atm_pe_oi_change_1m",
    "near_atm_pcr_oi",
    "near_atm_pcr_volume",
    "near_atm_oi_imbalance",
    "near_atm_volume_imbalance",
    "paired_strike_count",
]

STAGE1_TARGET = "label_stage1_move_v1"
STAGE2_TARGET = "label_stage2_direction_v1"

CLASS_NAMES = ["DOWN", "SIDEWAYS", "UP"]
CLASS_TO_ID = {
    "DOWN": 0,
    "SIDEWAYS": 1,
    "UP": 2,
}

PARAMS = {
    "objective": "binary",
    "metric": "binary_logloss",
    "learning_rate": 0.02,
    "n_estimators": 3000,
    "num_leaves": 15,
    "max_depth": -1,
    "min_child_samples": 300,
    "subsample": 0.8,
    "subsample_freq": 1,
    "colsample_bytree": 0.8,
    "reg_alpha": 0.5,
    "reg_lambda": 10.0,
    "max_bin": 127,
    "random_state": 42,
    "n_jobs": 4,
    "verbosity": -1,
    "deterministic": True,
    "force_col_wise": True,
}

REPORT_ROOT.mkdir(parents=True, exist_ok=True)


# ============================================================
# GENERAL HELPERS
# ============================================================

def write_json(data, path):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(
            data,
            f,
            indent=2,
            default=str,
            allow_nan=False,
        )


def load_split(stage, dataset, split, horizon):
    path = (
            DATA_ROOT
            / stage
            / dataset
            / f"{split}_{horizon}m.parquet"
    )

    if not path.exists():
        raise FileNotFoundError(
            f"Required dataset not found: {path}"
        )

    df = pd.read_parquet(path)

    if df.empty:
        raise ValueError(f"Empty dataset: {path}")

    return df


def get_features(dataset):
    if dataset == "index_only":
        return INDEX_FEATURES.copy()

    if dataset == "index_plus_options":
        return INDEX_FEATURES + OPTIONS_FEATURES

    raise ValueError(f"Unknown dataset: {dataset}")


def validate_matrix(df, features, name):
    missing = sorted(set(features) - set(df.columns))

    if missing:
        raise ValueError(
            f"{name}: missing feature columns: {missing}"
        )

    X = df[features].copy()

    for col in features:
        X[col] = pd.to_numeric(
            X[col],
            errors="coerce",
        )

    values = X.to_numpy(dtype=np.float64)

    if not np.isfinite(values).all():
        bad_counts = (
            ~np.isfinite(values)
        ).sum(axis=0)

        bad = {
            features[i]: int(bad_counts[i])
            for i in range(len(features))
            if bad_counts[i] > 0
        }

        raise ValueError(
            f"{name}: non-finite feature values: {bad}"
        )

    return X.astype(np.float32)


def make_binary_target(series, negative, positive, name):
    mapping = {
        negative: 0,
        positive: 1,
    }

    target = series.map(mapping)

    if target.isna().any():
        unexpected = (
            series[target.isna()]
            .drop_duplicates()
            .tolist()
        )

        raise ValueError(
            f"{name}: unexpected target values: {unexpected}"
        )

    result = target.astype(np.int8).to_numpy()

    if len(np.unique(result)) != 2:
        raise ValueError(
            f"{name}: both binary classes are not present."
        )

    return result


def validate_dates(df, expected_year, name):
    if "trading_day" not in df.columns:
        raise ValueError(
            f"{name}: trading_day column missing."
        )

    dates = pd.to_datetime(
        df["trading_day"],
        errors="raise",
    )

    years = set(dates.dt.year.unique().tolist())

    if years != {expected_year}:
        raise ValueError(
            f"{name}: expected only {expected_year}, "
            f"found years {sorted(years)}"
        )


def validate_unique_keys(df, name):
    required = [
        "timestamp_ist",
        "horizon_minutes",
    ]

    missing = set(required) - set(df.columns)

    if missing:
        raise ValueError(
            f"{name}: missing key columns {sorted(missing)}"
        )

    duplicate_count = int(
        df.duplicated(required).sum()
    )

    if duplicate_count:
        raise ValueError(
            f"{name}: {duplicate_count} duplicate keys."
        )


def reconstruct_actual_classes(df, name):
    """
    Reconstruct the end-to-end actual class from the two-stage
    labels. Stage 2 direction is required only when Stage 1 says MOVE.
    """

    if STAGE1_TARGET not in df.columns:
        raise ValueError(
            f"{name}: missing {STAGE1_TARGET}"
        )

    if STAGE2_TARGET not in df.columns:
        raise ValueError(
            f"{name}: missing {STAGE2_TARGET}"
        )

    stage1 = df[STAGE1_TARGET].astype(str).to_numpy()
    stage2 = df[STAGE2_TARGET].astype(str).to_numpy()

    actual = np.empty(len(df), dtype=object)

    for i in range(len(df)):
        if stage1[i] == "SIDEWAYS":
            actual[i] = "SIDEWAYS"

        elif stage1[i] == "MOVE":
            if stage2[i] not in ("DOWN", "UP"):
                raise ValueError(
                    f"{name}: invalid Stage 2 direction "
                    f"at row {i}: {stage2[i]}"
                )

            actual[i] = stage2[i]

        else:
            raise ValueError(
                f"{name}: invalid Stage 1 label "
                f"at row {i}: {stage1[i]}"
            )

    return np.array(
        [CLASS_TO_ID[x] for x in actual],
        dtype=np.int8,
    )


# ============================================================
# TEMPORARY MODEL TRAINING
# ============================================================

def train_temporary_model(
        stage,
        dataset,
        horizon,
        features,
):
    """
    Stage 1 trains on all eligible rows.
    Stage 2 trains only on actual MOVE rows.

    Both models are finally refitted on 2021-2022.
    """

    train_df = load_split(
        stage,
        dataset,
        "train",
        horizon,
    )

    train_years = pd.to_datetime(
        train_df["trading_day"]
    ).dt.year

    fit_df = train_df.loc[
        train_years == FIT_YEAR
        ].copy()

    early_df = train_df.loc[
        train_years == EARLY_STOP_YEAR
        ].copy()

    if fit_df.empty or early_df.empty:
        raise ValueError(
            f"{stage}/{dataset}/{horizon}m: "
            "fit or early-stop partition is empty."
        )

    validate_dates(
        fit_df,
        FIT_YEAR,
        f"{stage} fit",
    )

    validate_dates(
        early_df,
        EARLY_STOP_YEAR,
        f"{stage} early stop",
    )

    target_column = (
        STAGE1_TARGET
        if stage == "stage1"
        else STAGE2_TARGET
    )

    negative = (
        "SIDEWAYS"
        if stage == "stage1"
        else "DOWN"
    )

    positive = (
        "MOVE"
        if stage == "stage1"
        else "UP"
    )

    X_fit = validate_matrix(
        fit_df,
        features,
        f"{stage} fit",
    )

    X_early = validate_matrix(
        early_df,
        features,
        f"{stage} early stop",
    )

    y_fit = make_binary_target(
        fit_df[target_column],
        negative,
        positive,
        f"{stage} fit target",
    )

    y_early = make_binary_target(
        early_df[target_column],
        negative,
        positive,
        f"{stage} early target",
    )

    fit_weights = compute_sample_weight(
        class_weight="balanced",
        y=y_fit,
    )

    early_weights = compute_sample_weight(
        class_weight="balanced",
        y=y_early,
    )

    early_model = lgb.LGBMClassifier(**PARAMS)

    early_model.fit(
        X_fit,
        y_fit,
        sample_weight=fit_weights,
        eval_set=[(X_early, y_early)],
        eval_sample_weight=[early_weights],
        callbacks=[
            lgb.early_stopping(
                EARLY_STOPPING_ROUNDS,
                verbose=False,
            ),
            lgb.log_evaluation(0),
        ],
    )

    best_iteration = (
            early_model.best_iteration_
            or PARAMS["n_estimators"]
    )

    # Final refit: all 2021-2022 rows only.
    final_train_df = train_df.loc[
        train_years <= EARLY_STOP_YEAR
        ].copy()

    final_years = set(
        pd.to_datetime(
            final_train_df["trading_day"]
        ).dt.year.unique().tolist()
    )

    if final_years != {FIT_YEAR, EARLY_STOP_YEAR}:
        raise ValueError(
            f"{stage}: final refit years incorrect: "
            f"{sorted(final_years)}"
        )

    X_final = validate_matrix(
        final_train_df,
        features,
        f"{stage} final refit",
    )

    y_final = make_binary_target(
        final_train_df[target_column],
        negative,
        positive,
        f"{stage} final target",
    )

    final_weights = compute_sample_weight(
        class_weight="balanced",
        y=y_final,
    )

    final_params = PARAMS.copy()
    final_params["n_estimators"] = int(best_iteration)

    final_model = lgb.LGBMClassifier(
        **final_params
    )

    final_model.fit(
        X_final,
        y_final,
        sample_weight=final_weights,
    )

    detail = {
        "stage": stage,
        "dataset": dataset,
        "horizon_minutes": horizon,
        "fit_year": FIT_YEAR,
        "early_stop_year": EARLY_STOP_YEAR,
        "final_refit_years": [FIT_YEAR, EARLY_STOP_YEAR],
        "fit_rows": len(fit_df),
        "early_stop_rows": len(early_df),
        "final_refit_rows": len(final_train_df),
        "feature_count": len(features),
        "best_iteration": int(best_iteration),
        "status": "PASS",
    }

    return final_model, detail


# ============================================================
# PROBABILITY COMBINATION AND DECISION POLICIES
# ============================================================

def combine_probabilities(p_move, p_up_given_move):
    """
    P(SIDEWAYS) = 1 - P(MOVE)
    P(DOWN) = P(MOVE) * (1 - P(UP | MOVE))
    P(UP) = P(MOVE) * P(UP | MOVE)
    """

    p_sideways = 1.0 - p_move
    p_down = p_move * (1.0 - p_up_given_move)
    p_up = p_move * p_up_given_move

    probabilities = np.column_stack([
        p_down,
        p_sideways,
        p_up,
    ])

    probabilities = np.clip(
        probabilities,
        0.0,
        1.0,
    )

    row_sums = probabilities.sum(axis=1)

    if not np.allclose(
            row_sums,
            1.0,
            atol=1e-10,
    ):
        raise ValueError(
            "Combined class probabilities do not sum to 1."
        )

    return probabilities


def predict_with_move_threshold(
        p_move,
        p_up_given_move,
        move_threshold,
):
    """
    If P(MOVE) is below threshold => SIDEWAYS.
    Otherwise use Stage 2 direction probability.
    """

    predicted = np.full(
        len(p_move),
        CLASS_TO_ID["SIDEWAYS"],
        dtype=np.int8,
    )

    move_mask = p_move >= move_threshold

    up_mask = (
            move_mask
            & (p_up_given_move >= DIRECTION_THRESHOLD)
    )

    down_mask = (
            move_mask
            & (p_up_given_move < DIRECTION_THRESHOLD)
    )

    predicted[down_mask] = CLASS_TO_ID["DOWN"]
    predicted[up_mask] = CLASS_TO_ID["UP"]

    return predicted


def calculate_metrics(
        y_true,
        probabilities,
        predicted,
        policy,
        threshold=None,
):
    result = {
        "policy": policy,
        "move_threshold": (
            None if threshold is None else float(threshold)
        ),
        "rows": int(len(y_true)),
        "accuracy": float(
            accuracy_score(y_true, predicted)
        ),
        "balanced_accuracy": float(
            balanced_accuracy_score(y_true, predicted)
        ),
        "macro_f1": float(
            f1_score(
                y_true,
                predicted,
                labels=[0, 1, 2],
                average="macro",
                zero_division=0,
            )
        ),
        "weighted_f1": float(
            f1_score(
                y_true,
                predicted,
                labels=[0, 1, 2],
                average="weighted",
                zero_division=0,
            )
        ),
        "log_loss": float(
            log_loss(
                y_true,
                probabilities,
                labels=[0, 1, 2],
            )
        ),
        "multiclass_brier_score": float(
            np.mean(
                np.sum(
                    (
                            probabilities
                            - np.eye(3)[y_true]
                    ) ** 2,
                    axis=1,
                    )
            )
        ),
        "predicted_down_pct": float(
            np.mean(predicted == 0) * 100
        ),
        "predicted_sideways_pct": float(
            np.mean(predicted == 1) * 100
        ),
        "predicted_up_pct": float(
            np.mean(predicted == 2) * 100
        ),
        "directional_coverage_pct": float(
            np.mean(predicted != 1) * 100
        ),
    }

    try:
        result["macro_roc_auc_ovr"] = float(
            roc_auc_score(
                y_true,
                probabilities,
                labels=[0, 1, 2],
                multi_class="ovr",
                average="macro",
            )
        )
    except ValueError:
        result["macro_roc_auc_ovr"] = None

    cm = confusion_matrix(
        y_true,
        predicted,
        labels=[0, 1, 2],
    )

    report = classification_report(
        y_true,
        predicted,
        labels=[0, 1, 2],
        target_names=CLASS_NAMES,
        output_dict=True,
        zero_division=0,
    )

    return result, cm.tolist(), report


# ============================================================
# MAIN EXPERIMENT
# ============================================================

all_results = []
all_thresholds = []
all_training_details = []
all_sensitivity = []
all_audits = []

for dataset in DATASETS:

    features = get_features(dataset)

    for horizon in HORIZONS:

        print()
        print("=" * 100)
        print(
            f"V2 THRESHOLD ROBUSTNESS | "
            f"{dataset.upper()} | {horizon} MINUTES"
        )
        print("=" * 100)

        # ----------------------------------------------------
        # Load full Stage 1 rows for 2023 and 2024.
        # These contain all eligible rows, including SIDEWAYS.
        # ----------------------------------------------------

        threshold_df = load_split(
            "stage1",
            dataset,
            "train",
            horizon,
        )

        threshold_years = pd.to_datetime(
            threshold_df["trading_day"]
        ).dt.year

        threshold_df = threshold_df.loc[
            threshold_years == THRESHOLD_YEAR
            ].copy()

        evaluation_df = load_split(
            "stage1",
            dataset,
            "validation",
            horizon,
        )

        validate_dates(
            threshold_df,
            THRESHOLD_YEAR,
            "2023 threshold data",
        )

        validate_dates(
            evaluation_df,
            EVALUATION_YEAR,
            "2024 evaluation data",
        )

        validate_unique_keys(
            threshold_df,
            "2023 threshold data",
        )

        validate_unique_keys(
            evaluation_df,
            "2024 evaluation data",
        )

        # Reconstruct actual 3-class labels from two-stage labels.
        y_2023 = reconstruct_actual_classes(
            threshold_df,
            "2023",
        )

        y_2024 = reconstruct_actual_classes(
            evaluation_df,
            "2024",
        )

        # ----------------------------------------------------
        # Train temporary Stage 1 model.
        # ----------------------------------------------------

        stage1_model, stage1_detail = (
            train_temporary_model(
                "stage1",
                dataset,
                horizon,
                features,
            )
        )

        # ----------------------------------------------------
        # Train temporary Stage 2 model.
        # Training uses MOVE-only stage2 rows.
        # Prediction below uses all Stage1 rows.
        # ----------------------------------------------------

        stage2_model, stage2_detail = (
            train_temporary_model(
                "stage2",
                dataset,
                horizon,
                features,
            )
        )

        all_training_details.extend([
            stage1_detail,
            stage2_detail,
        ])

        # ----------------------------------------------------
        # Predict 2023 and 2024 using the SAME model objects.
        # ----------------------------------------------------

        X_2023 = validate_matrix(
            threshold_df,
            features,
            "2023 inference",
        )

        X_2024 = validate_matrix(
            evaluation_df,
            features,
            "2024 inference",
        )

        p_move_2023 = stage1_model.predict_proba(
            X_2023
        )[:, 1]

        p_up_2023 = stage2_model.predict_proba(
            X_2023
        )[:, 1]

        p_move_2024 = stage1_model.predict_proba(
            X_2024
        )[:, 1]

        p_up_2024 = stage2_model.predict_proba(
            X_2024
        )[:, 1]

        probabilities_2023 = combine_probabilities(
            p_move_2023,
            p_up_2023,
        )

        probabilities_2024 = combine_probabilities(
            p_move_2024,
            p_up_2024,
        )

        # ----------------------------------------------------
        # Select MOVE threshold using 2023 only.
        # Tie-break: higher balanced accuracy.
        # ----------------------------------------------------

        threshold_candidates = []

        for threshold in THRESHOLD_GRID:

            predicted = predict_with_move_threshold(
                p_move_2023,
                p_up_2023,
                threshold,
            )

            macro_f1 = f1_score(
                y_2023,
                predicted,
                labels=[0, 1, 2],
                average="macro",
                zero_division=0,
            )

            balanced_acc = balanced_accuracy_score(
                y_2023,
                predicted,
            )

            threshold_candidates.append({
                "dataset": dataset,
                "horizon_minutes": horizon,
                "threshold": float(threshold),
                "macro_f1": float(macro_f1),
                "balanced_accuracy": float(balanced_acc),
                "directional_coverage_pct": float(
                    np.mean(predicted != 1) * 100
                ),
                "predicted_down_pct": float(
                    np.mean(predicted == 0) * 100
                ),
                "predicted_sideways_pct": float(
                    np.mean(predicted == 1) * 100
                ),
                "predicted_up_pct": float(
                    np.mean(predicted == 2) * 100
                ),
            })

        threshold_table = pd.DataFrame(
            threshold_candidates
        )

        threshold_table = threshold_table.sort_values(
            by=[
                "macro_f1",
                "balanced_accuracy",
                "threshold",
            ],
            ascending=[False, False, True],
            kind="mergesort",
        ).reset_index(drop=True)

        selected_threshold = float(
            threshold_table.iloc[0]["threshold"]
        )

        selected_2023_metrics = (
            threshold_table.iloc[0].to_dict()
        )

        for row in threshold_candidates:
            all_sensitivity.append(row)

        # ----------------------------------------------------
        # 2023: evaluate threshold-selection policies.
        # ----------------------------------------------------

        original_2023 = np.argmax(
            probabilities_2023,
            axis=1,
        )

        fixed_2023 = predict_with_move_threshold(
            p_move_2023,
            p_up_2023,
            FIXED_MOVE_THRESHOLD,
        )

        selected_2023 = predict_with_move_threshold(
            p_move_2023,
            p_up_2023,
            selected_threshold,
        )

        policies_2023 = [
            (
                "original_argmax",
                original_2023,
                None,
            ),
            (
                "fixed_0.50",
                fixed_2023,
                FIXED_MOVE_THRESHOLD,
            ),
            (
                "selected_on_2023",
                selected_2023,
                selected_threshold,
            ),
        ]

        for policy, predicted, threshold in policies_2023:

            metrics, cm, report = calculate_metrics(
                y_2023,
                probabilities_2023,
                predicted,
                policy,
                threshold,
            )

            all_results.append({
                "dataset": dataset,
                "horizon_minutes": horizon,
                "evaluation_year": THRESHOLD_YEAR,
                **metrics,
            })

        # ----------------------------------------------------
        # 2024: transfer selected threshold unchanged.
        # ----------------------------------------------------

        original_2024 = np.argmax(
            probabilities_2024,
            axis=1,
        )

        fixed_2024 = predict_with_move_threshold(
            p_move_2024,
            p_up_2024,
            FIXED_MOVE_THRESHOLD,
        )

        selected_2024 = predict_with_move_threshold(
            p_move_2024,
            p_up_2024,
            selected_threshold,
        )

        policies_2024 = [
            (
                "original_argmax",
                original_2024,
                None,
            ),
            (
                "fixed_0.50",
                fixed_2024,
                FIXED_MOVE_THRESHOLD,
            ),
            (
                "selected_on_2023",
                selected_2024,
                selected_threshold,
            ),
        ]

        prediction_output = evaluation_df[
            [
                "timestamp_ist",
                "trading_day",
                "horizon_minutes",
                STAGE1_TARGET,
                STAGE2_TARGET,
                "target_z",
                "forward_return",
            ]
        ].copy()

        prediction_output["actual_class"] = [
            CLASS_NAMES[int(x)]
            for x in y_2024
        ]

        prediction_output["p_move"] = p_move_2024
        prediction_output["p_up_given_move"] = p_up_2024
        prediction_output["p_down"] = probabilities_2024[:, 0]
        prediction_output["p_sideways"] = probabilities_2024[:, 1]
        prediction_output["p_up"] = probabilities_2024[:, 2]

        prediction_output["pred_original_argmax"] = [
            CLASS_NAMES[int(x)]
            for x in original_2024
        ]

        prediction_output["pred_fixed_050"] = [
            CLASS_NAMES[int(x)]
            for x in fixed_2024
        ]

        prediction_output["pred_selected_2023_threshold"] = [
            CLASS_NAMES[int(x)]
            for x in selected_2024
        ]

        prediction_output["selected_move_threshold"] = (
            selected_threshold
        )

        for policy, predicted, threshold in policies_2024:

            metrics, cm, report = calculate_metrics(
                y_2024,
                probabilities_2024,
                predicted,
                policy,
                threshold,
            )

            all_results.append({
                "dataset": dataset,
                "horizon_minutes": horizon,
                "evaluation_year": EVALUATION_YEAR,
                **metrics,
            })

            detail = {
                "dataset": dataset,
                "horizon_minutes": horizon,
                "evaluation_year": EVALUATION_YEAR,
                "policy": policy,
                "selected_threshold_from_2023": selected_threshold,
                "metrics": metrics,
                "confusion_matrix_labels": CLASS_NAMES,
                "confusion_matrix": cm,
                "classification_report": report,
                "status": "PASS",
            }

            detail_path = (
                    REPORT_ROOT
                    / f"metrics_{dataset}_{horizon}m_{policy}.json"
            )

            write_json(detail, detail_path)

        prediction_path = (
                REPORT_ROOT
                / f"predictions_2024_{dataset}_{horizon}m.csv"
        )

        prediction_output.to_csv(
            prediction_path,
            index=False,
        )

        # ----------------------------------------------------
        # Threshold selection record.
        # ----------------------------------------------------

        all_thresholds.append({
            "dataset": dataset,
            "horizon_minutes": horizon,
            "selected_move_threshold": selected_threshold,
            "selection_year": THRESHOLD_YEAR,
            "selection_macro_f1": float(
                selected_2023_metrics["macro_f1"]
            ),
            "selection_balanced_accuracy": float(
                selected_2023_metrics["balanced_accuracy"]
            ),
            "selection_directional_coverage_pct": float(
                selected_2023_metrics[
                    "directional_coverage_pct"
                ]
            ),
            "stage1_best_iteration": (
                stage1_detail["best_iteration"]
            ),
            "stage2_best_iteration": (
                stage2_detail["best_iteration"]
            ),
            "threshold_rows_2023": len(threshold_df),
            "evaluation_rows_2024": len(evaluation_df),
            "same_model_objects_used_for_2023_2024": True,
        })

        # ----------------------------------------------------
        # Data and inference audit.
        # ----------------------------------------------------

        all_audits.append({
            "dataset": dataset,
            "horizon_minutes": horizon,
            "threshold_rows_2023": len(threshold_df),
            "evaluation_rows_2024": len(evaluation_df),
            "duplicate_keys_2023": int(
                threshold_df.duplicated(
                    ["timestamp_ist", "horizon_minutes"]
                ).sum()
            ),
            "duplicate_keys_2024": int(
                evaluation_df.duplicated(
                    ["timestamp_ist", "horizon_minutes"]
                ).sum()
            ),
            "actual_classes_2023": sorted(
                set(CLASS_NAMES[int(x)] for x in np.unique(y_2023))
            ),
            "actual_classes_2024": sorted(
                set(CLASS_NAMES[int(x)] for x in np.unique(y_2024))
            ),
            "probability_sum_max_error_2023": float(
                np.max(
                    np.abs(
                        probabilities_2023.sum(axis=1) - 1.0
                    )
                )
            ),
            "probability_sum_max_error_2024": float(
                np.max(
                    np.abs(
                        probabilities_2024.sum(axis=1) - 1.0
                    )
                )
            ),
            "p_move_mean_2023": float(
                np.mean(p_move_2023)
            ),
            "p_move_mean_2024": float(
                np.mean(p_move_2024)
            ),
            "p_move_median_2023": float(
                np.median(p_move_2023)
            ),
            "p_move_median_2024": float(
                np.median(p_move_2024)
            ),
            "stage2_up_probability_mean_2023": float(
                np.mean(p_up_2023)
            ),
            "stage2_up_probability_mean_2024": float(
                np.mean(p_up_2024)
            ),
            "same_models_used_for_both_years": True,
            "status": "PASS",
        })

        print(
            f"Selected threshold: {selected_threshold:.2f}"
        )
        print(
            f"2023 selection macro F1: "
            f"{selected_2023_metrics['macro_f1']:.5f}"
        )
        print(
            f"2023 selection balanced accuracy: "
            f"{selected_2023_metrics['balanced_accuracy']:.5f}"
        )
        print(
            f"2023 rows: {len(threshold_df):,} | "
            f"2024 rows: {len(evaluation_df):,}"
        )


# ============================================================
# SAVE REPORTS
# ============================================================

results_df = pd.DataFrame(all_results)

results_path = (
        REPORT_ROOT
        / "threshold_policy_comparison_v2.csv"
)

results_df.to_csv(
    results_path,
    index=False,
)

thresholds_df = pd.DataFrame(all_thresholds)

thresholds_path = (
        REPORT_ROOT
        / "selected_thresholds_2023_v2.csv"
)

thresholds_df.to_csv(
    thresholds_path,
    index=False,
)

sensitivity_df = pd.DataFrame(all_sensitivity)

sensitivity_path = (
        REPORT_ROOT
        / "threshold_sensitivity_2023_v2.csv"
)

sensitivity_df.to_csv(
    sensitivity_path,
    index=False,
)

audit_df = pd.DataFrame(all_audits)

audit_path = (
        REPORT_ROOT
        / "threshold_robustness_audit_v2.csv"
)

audit_df.to_csv(
    audit_path,
    index=False,
)

training_df = pd.DataFrame(all_training_details)

training_path = (
        REPORT_ROOT
        / "temporary_model_training_v2.csv"
)

training_df.to_csv(
    training_path,
    index=False,
)

# ------------------------------------------------------------
# Automated checks.
# ------------------------------------------------------------

expected_model_count = (
        len(DATASETS) * len(HORIZONS) * 2
)

expected_policy_rows = (
        len(DATASETS) * len(HORIZONS) * 2 * 3
)

checks = {
    "all_temporary_models_trained": (
            len(all_training_details) == expected_model_count
    ),
    "all_temporary_models_passed": (
        all(x["status"] == "PASS" for x in all_training_details)
    ),
    "all_dataset_horizon_pairs_completed": (
            len(all_thresholds) == len(DATASETS) * len(HORIZONS)
    ),
    "all_policy_evaluations_completed": (
            len(results_df) == expected_policy_rows
    ),
    "all_audits_passed": (
            len(all_audits) == len(DATASETS) * len(HORIZONS)
            and all(x["status"] == "PASS" for x in all_audits)
    ),
    "same_models_used_for_2023_and_2024": (
        all(
            x["same_model_objects_used_for_2023_2024"]
            for x in all_thresholds
        )
    ),
    "all_thresholds_within_grid": (
        all(
            x["selected_move_threshold"] in THRESHOLD_GRID
            for x in all_thresholds
        )
    ),
}

overall_status = (
    "PASS"
    if all(checks.values())
    else "FAIL"
)

summary = {
    "experiment": "NIFTY_TWO_STAGE_THRESHOLD_ROBUSTNESS_V2",
    "status": overall_status,
    "dataset": "NIFTY",
    "datasets": DATASETS,
    "horizons": HORIZONS,
    "fit_year": FIT_YEAR,
    "early_stop_year": EARLY_STOP_YEAR,
    "final_refit_years": [FIT_YEAR, EARLY_STOP_YEAR],
    "threshold_selection_year": THRESHOLD_YEAR,
    "threshold_evaluation_year": EVALUATION_YEAR,
    "threshold_grid": THRESHOLD_GRID,
    "threshold_selection_metric": "macro_f1",
    "threshold_tie_break": "balanced_accuracy",
    "direction_threshold": DIRECTION_THRESHOLD,
    "fixed_move_threshold": FIXED_MOVE_THRESHOLD,
    "same_temporary_model_objects_used_for_2023_and_2024": True,
    "temporary_models_saved": False,
    "existing_models_modified": False,
    "existing_datasets_modified": False,
    "policy_comparison_file": str(results_path),
    "selected_thresholds_file": str(thresholds_path),
    "threshold_sensitivity_file": str(sensitivity_path),
    "audit_file": str(audit_path),
    "temporary_model_training_file": str(training_path),
    "checks": checks,
    "important_limitations": [
        "2024 is diagnostic and is not an untouched final test set.",
        "Stage 2 probabilities are generated for all rows, including actual SIDEWAYS rows; Stage 2 was trained only on actual MOVE rows.",
        "Threshold selection optimizes classification macro F1, not trading returns.",
        "No transaction costs, slippage, option execution prices, or position sizing are modeled.",
        "The threshold is selected independently for each dataset and horizon.",
        "The experiment does not establish a profitable or tradeable edge.",
    ],
}

summary_path = (
        REPORT_ROOT
        / "threshold_robustness_summary_v2.json"
)

write_json(summary, summary_path)

print()
print("=" * 100)
print("TWO-STAGE THRESHOLD ROBUSTNESS V2 COMPLETED")
print("=" * 100)

print()
print("POLICY COMPARISON")
print(
    results_df[
        [
            "dataset",
            "horizon_minutes",
            "evaluation_year",
            "policy",
            "move_threshold",
            "accuracy",
            "balanced_accuracy",
            "macro_f1",
            "directional_coverage_pct",
            "predicted_sideways_pct",
        ]
    ].to_string(index=False)
)

print()
print("SELECTED THRESHOLDS")
print(thresholds_df.to_string(index=False))

print()
print("AUTOMATED CHECKS")
print(json.dumps(checks, indent=2))

print()
print(f"OVERALL STATUS: {overall_status}")
print(f"Reports: {REPORT_ROOT}")
