
from __future__ import annotations

import argparse
import json
import re
import sys
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    f1_score,
    log_loss,
    roc_auc_score,
)

# ============================================================
# NIFTY PHASE 2.1.1
# Probability and directional discrimination audit
#
# READ ONLY:
#   - No model training.
#   - No threshold optimisation.
#   - No changes to existing prediction or regime files.
#   - Each run writes to a unique new output directory.
#
# Main analyses:
#   1. Multiclass probability quality
#   2. UP / DOWN probability distributions
#   3. Fixed descriptive confidence bands
#   4. Directional hit rate and coverage
#   5. Class-wise calibration and ECE
#   6. Year-wise and regime-wise analysis
#   7. Paired index-only vs index-plus-options comparison
# ============================================================

ROOT = Path(__file__).resolve().parents[1]

DEFAULT_PREDICTIONS_DIR = (
        ROOT / "reports/nifty_two_stage_end_to_end_v2"
)
DEFAULT_REGIME_DIR = ROOT / "reports/nifty_market_regimes_v1"
DEFAULT_OUTPUT_DIR = ROOT / "reports/nifty_probability_discrimination_v1"

HORIZONS = [5, 15, 30]
CLASSES = ["DOWN", "SIDEWAYS", "UP"]
PROB_COLS = ["p_down", "p_sideways", "p_up"]

# Fixed descriptive bands. These are NOT tuned thresholds.
DIRECTIONAL_CONFIDENCE_BINS = [
    0.33, 0.40, 0.50, 0.60, 0.70, 0.80, 1.000001
]

PROBABILITY_BINS = np.linspace(0.0, 1.0, 11)

REGIME_COLUMNS = [
    "trend_regime",
    "volatility_regime",
    "momentum_regime",
    "time_regime",
    "combined_regime",
]

TIMESTAMP_ALIASES = [
    "timestamp_ist", "timestamp", "datetime",
    "prediction_timestamp", "bar_timestamp"
]

ACTUAL_ALIASES = [
    "actual_class", "actual_label", "y_true",
    "actual", "true_class", "target_class"
]

HORIZON_ALIASES = [
    "horizon_minutes", "horizon", "minutes"
]

PROBABILITY_ALIASES = {
    "DOWN": [
        "p_down", "prob_down", "down_probability",
        "probability_down", "down_prob",
        "prob_down_end_to_end", "p_down_final"
    ],
    "SIDEWAYS": [
        "p_sideways", "prob_sideways",
        "sideways_probability", "probability_sideways",
        "sideways_prob", "prob_sideways_end_to_end",
        "p_sideways_final"
    ],
    "UP": [
        "p_up", "prob_up", "up_probability",
        "probability_up", "up_prob",
        "prob_up_end_to_end", "p_up_final"
    ],
}


def log(message):
    print(f"[INFO] {message}", flush=True)


def fail(message):
    raise RuntimeError(message)


def find_column(columns, aliases):
    lookup = {str(c).strip().lower(): c for c in columns}
    for alias in aliases:
        if alias.lower() in lookup:
            return lookup[alias.lower()]
    return None


def normalize_class(value):
    if pd.isna(value):
        return None

    value = str(value).strip().upper()

    mapping = {
        "DOWN": "DOWN",
        "BEARISH": "DOWN",
        "SELL": "DOWN",
        "0": "DOWN",
        "SIDEWAYS": "SIDEWAYS",
        "SIDEWAY": "SIDEWAYS",
        "NEUTRAL": "SIDEWAYS",
        "RANGE": "SIDEWAYS",
        "1": "SIDEWAYS",
        "UP": "UP",
        "BULLISH": "UP",
        "BUY": "UP",
        "2": "UP",
    }
    return mapping.get(value, value)


def infer_horizon(path):
    text = path.stem.lower()
    patterns = [
        r"(?<!\d)(5|15|30)\s*m(?!\w)",
        r"(?<!\d)(5|15|30)\s*min",
        r"horizon[_-]?(5|15|30)",
        r"predictions?[_-](5|15|30)m",
    ]

    for pattern in patterns:
        match = re.search(pattern, text)
        if match:
            return int(match.group(1))

    return None


def parse_timestamp(series):
    ts = pd.to_datetime(series, errors="coerce")

    if ts.dt.tz is not None:
        ts = ts.dt.tz_convert("Asia/Kolkata").dt.tz_localize(None)

    return ts


def create_output_dir(base):
    base.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    path = base / f"run_{stamp}"

    suffix = 1
    while path.exists():
        path = base / f"run_{stamp}_{suffix}"
        suffix += 1

    path.mkdir(parents=True, exist_ok=False)
    return path


def discover_regime_file(regime_dir):
    candidates = list(regime_dir.glob("run_*/market_regime_features.csv"))

    if not candidates:
        candidates = list(regime_dir.glob("**/market_regime_features.csv"))

    if not candidates:
        fail(
            "Could not find market_regime_features.csv under "
            f"{regime_dir}. Pass --regime-file explicitly."
        )

    return max(candidates, key=lambda p: p.stat().st_mtime)


def discover_prediction_files(prediction_dir, explicit_files=None):
    if explicit_files:
        files = [Path(p) for p in explicit_files]
    else:
        files = sorted(prediction_dir.glob("*.csv"))

    # Only the six end-to-end model prediction files should be used.
    # Exclude aggregate summaries and diagnostic reports.
    excluded_tokens = [
        "comparison", "summary", "audit", "sensitivity",
        "threshold", "confusion", "classification",
        "feature_importance", "alignment"
    ]

    selected = []
    for path in files:
        name = path.name.lower()
        if any(token in name for token in excluded_tokens):
            continue

        if "prediction" in name or "predict" in name:
            selected.append(path)

    if not selected:
        fail(
            f"No end-to-end prediction CSV files found in {prediction_dir}. "
            "Use --prediction-files with the six existing prediction files."
        )

    return selected


def load_regimes(regime_file):
    if not regime_file.exists():
        fail(f"Regime file does not exist: {regime_file}")

    df = pd.read_csv(regime_file)

    timestamp_col = find_column(
        df.columns, TIMESTAMP_ALIASES
    )
    if timestamp_col is None:
        fail(
            "Regime file has no timestamp column. "
            f"Columns: {list(df.columns)}"
        )

    df["timestamp_ist"] = parse_timestamp(df[timestamp_col])
    df = df.dropna(subset=["timestamp_ist"]).copy()

    required = ["trading_day"] + REGIME_COLUMNS[:4]
    missing = [c for c in required if c not in df.columns]

    if missing:
        fail(
            f"Regime file is missing required columns: {missing}. "
            f"Available: {list(df.columns)}"
        )

    if "combined_regime" not in df.columns:
        df["combined_regime"] = (
                df["trend_regime"].astype(str) + "_"
                + df["volatility_regime"].astype(str) + "_"
                + df["momentum_regime"].astype(str) + "_"
                + df["time_regime"].astype(str)
        )

    df["trading_day"] = pd.to_datetime(
        df["trading_day"], errors="coerce"
    ).dt.date

    duplicate_count = int(df["timestamp_ist"].duplicated().sum())
    if duplicate_count:
        fail(
            f"Regime file has {duplicate_count} duplicate timestamps."
        )

    keep = [
        "timestamp_ist", "trading_day",
        "trend_regime", "volatility_regime",
        "momentum_regime", "time_regime",
        "combined_regime",
    ]

    if "is_synthetic" in df.columns:
        keep.append("is_synthetic")
    else:
        df["is_synthetic"] = False
        keep.append("is_synthetic")

    return df[keep].copy()


def load_prediction_file(path):
    df = pd.read_csv(path)

    timestamp_col = find_column(df.columns, TIMESTAMP_ALIASES)
    actual_col = find_column(df.columns, ACTUAL_ALIASES)
    horizon_col = find_column(df.columns, HORIZON_ALIASES)

    if timestamp_col is None or actual_col is None:
        fail(
            f"Missing timestamp or actual-class column in {path}\n"
            f"Columns: {list(df.columns)}"
        )

    prob_source_cols = {}
    for label, aliases in PROBABILITY_ALIASES.items():
        col = find_column(df.columns, aliases)
        if col is None:
            fail(
                f"Missing end-to-end probability for {label} in {path}.\n"
                f"Columns found: {list(df.columns)}\n"
                "Use the end-to-end probability CSV, not a Stage 2 "
                "conditional-only prediction file."
            )
        prob_source_cols[label] = col

    df["timestamp_ist"] = parse_timestamp(df[timestamp_col])
    df["actual_class"] = df[actual_col].map(normalize_class)

    if horizon_col:
        df["horizon_minutes"] = pd.to_numeric(
            df[horizon_col], errors="coerce"
        )
    else:
        h = infer_horizon(path)
        if h is None:
            fail(
                f"Cannot infer horizon from {path}. "
                "Add horizon_minutes or include 5m/15m/30m in filename."
            )
        df["horizon_minutes"] = h

    df["p_down"] = pd.to_numeric(
        df[prob_source_cols["DOWN"]], errors="coerce"
    )
    df["p_sideways"] = pd.to_numeric(
        df[prob_source_cols["SIDEWAYS"]], errors="coerce"
    )
    df["p_up"] = pd.to_numeric(
        df[prob_source_cols["UP"]], errors="coerce"
    )

    df["model_name"] = path.stem
    lower_name = path.stem.lower()

    if "index_plus_options" in lower_name:
        df["model_family"] = "index_plus_options"
    elif "index_only" in lower_name:
        df["model_family"] = "index_only"
    else:
        fail(
            f"Cannot determine model family from filename {path.name}. "
            "Filename must contain index_only or index_plus_options."
        )

    df["prediction_file"] = str(path)

    needed = [
        "timestamp_ist", "actual_class", "horizon_minutes",
        "p_down", "p_sideways", "p_up"
    ]

    before = len(df)
    df = df.dropna(subset=needed).copy()
    dropped_null = before - len(df)

    df["horizon_minutes"] = df["horizon_minutes"].astype(int)

    df = df[
        df["horizon_minutes"].isin(HORIZONS)
        & df["actual_class"].isin(CLASSES)
        ].copy()

    # Do not silently repair invalid probability rows.
    p = df[PROB_COLS].to_numpy(dtype=float)
    finite = np.isfinite(p).all(axis=1)
    nonnegative = (p >= 0).all(axis=1)
    sums = p.sum(axis=1)

    valid = finite & nonnegative & (sums > 0)
    invalid_probability_rows = int((~valid).sum())

    df = df.loc[valid].copy()
    p = df[PROB_COLS].to_numpy(dtype=float)
    sums = p.sum(axis=1)

    # Permit only small numerical drift. Large deviations indicate
    # that the file may not contain end-to-end probabilities.
    sum_error = np.abs(sums - 1.0)
    large_error = sum_error > 0.01

    if large_error.any():
        fail(
            f"{int(large_error.sum())} probability rows in {path} "
            "do not sum to 1 within 0.01. Check whether these are "
            "end-to-end probabilities."
        )

    # Normalize tiny floating-point drift only.
    df[PROB_COLS] = p / sums[:, None]

    df["predicted_class_from_probability"] = np.array(CLASSES)[
        np.argmax(df[PROB_COLS].to_numpy(), axis=1)
    ]

    df["max_probability"] = df[PROB_COLS].max(axis=1)
    df["directional_probability"] = df[["p_down", "p_up"]].max(axis=1)
    df["directional_margin"] = (
            df["p_up"] - df["p_down"]
    ).abs()

    df["directional_class"] = np.where(
        df["p_up"] >= df["p_down"], "UP", "DOWN"
    )

    # Conditional UP probability, ignoring SIDEWAYS mass.
    direction_sum = df["p_up"] + df["p_down"]
    df["conditional_p_up"] = np.where(
        direction_sum > 0,
        df["p_up"] / direction_sum,
        np.nan
    )

    df["year"] = df["timestamp_ist"].dt.year

    df.attrs["dropped_null_rows"] = dropped_null
    df.attrs["invalid_probability_rows"] = invalid_probability_rows
    df.attrs["max_probability_sum_error"] = float(
        sum_error.max() if len(sum_error) else 0.0
    )

    return df


def load_predictions(files):
    frames = []
    file_audits = []

    for path in files:
        log(f"Loading: {path}")
        frame = load_prediction_file(path)
        frames.append(frame)

        file_audits.append({
            "file": str(path),
            "rows_loaded": int(len(frame)),
            "dropped_null_rows": int(
                frame.attrs.get("dropped_null_rows", 0)
            ),
            "invalid_probability_rows": int(
                frame.attrs.get("invalid_probability_rows", 0)
            ),
            "max_probability_sum_error": float(
                frame.attrs.get("max_probability_sum_error", 0.0)
            ),
        })

    df = pd.concat(frames, ignore_index=True)

    key = ["model_name", "timestamp_ist", "horizon_minutes"]
    duplicate_count = int(df.duplicated(key).sum())

    if duplicate_count:
        fail(
            f"Duplicate prediction keys found: {duplicate_count}. "
            "Check duplicate or overlapping prediction files."
        )

    return df, pd.DataFrame(file_audits)


def multiclass_brier(y_true, probs):
    mapping = {"DOWN": 0, "SIDEWAYS": 1, "UP": 2}
    y = pd.Series(y_true).map(mapping).to_numpy()
    one_hot = np.eye(3)[y]
    return float(np.mean(np.sum((probs - one_hot) ** 2, axis=1)))


def expected_calibration_error(y_binary, probability, bins=PROBABILITY_BINS):
    y = np.asarray(y_binary, dtype=float)
    p = np.asarray(probability, dtype=float)

    edges = np.asarray(bins, dtype=float)
    bin_ids = np.digitize(p, edges[1:-1], right=False)

    total = len(y)
    ece = 0.0
    rows = []

    for idx in range(len(edges) - 1):
        mask = bin_ids == idx
        n = int(mask.sum())

        if n == 0:
            continue

        mean_probability = float(p[mask].mean())
        observed_rate = float(y[mask].mean())
        gap = abs(mean_probability - observed_rate)

        ece += (n / total) * gap

        rows.append({
            "bin_lower": float(edges[idx]),
            "bin_upper": float(edges[idx + 1]),
            "rows": n,
            "mean_predicted_probability": mean_probability,
            "observed_frequency": observed_rate,
            "absolute_calibration_gap": gap,
        })

    return float(ece), rows


def calculate_overall_metrics(group):
    y = group["actual_class"].to_numpy()
    probs = group[PROB_COLS].to_numpy(dtype=float)
    pred = np.array(CLASSES)[np.argmax(probs, axis=1)]

    mapping = {"DOWN": 0, "SIDEWAYS": 1, "UP": 2}
    y_num = pd.Series(y).map(mapping).to_numpy()

    result = {
        "model_name": group["model_name"].iloc[0],
        "model_family": group["model_family"].iloc[0],
        "horizon_minutes": int(group["horizon_minutes"].iloc[0]),
        "year": "ALL",
        "regime_dimension": "ALL",
        "regime": "ALL",
        "rows": int(len(group)),
        "accuracy": float(accuracy_score(y, pred)),
        "balanced_accuracy": float(
            balanced_accuracy_score(y, pred)
        ),
        "macro_f1": float(
            f1_score(
                y, pred, labels=CLASSES,
                average="macro", zero_division=0
            )
        ),
        "log_loss": float(
            log_loss(y_num, probs, labels=[0, 1, 2])
        ),
        "multiclass_brier_score": multiclass_brier(y, probs),
        "mean_p_down": float(group["p_down"].mean()),
        "mean_p_sideways": float(group["p_sideways"].mean()),
        "mean_p_up": float(group["p_up"].mean()),
        "median_p_down": float(group["p_down"].median()),
        "median_p_sideways": float(group["p_sideways"].median()),
        "median_p_up": float(group["p_up"].median()),
        "p_down_p90": float(group["p_down"].quantile(0.90)),
        "p_sideways_p90": float(group["p_sideways"].quantile(0.90)),
        "p_up_p90": float(group["p_up"].quantile(0.90)),
        "predicted_down_pct": float((pred == "DOWN").mean() * 100),
        "predicted_sideways_pct": float(
            (pred == "SIDEWAYS").mean() * 100
        ),
        "predicted_up_pct": float((pred == "UP").mean() * 100),
    }

    try:
        result["macro_roc_auc_ovr"] = float(
            roc_auc_score(
                y_num, probs,
                labels=[0, 1, 2],
                multi_class="ovr",
                average="macro"
            )
        )
    except Exception:
        result["macro_roc_auc_ovr"] = np.nan

    return result


def calculate_directional_metrics(group):
    # A directional indication is the larger of P(UP) and P(DOWN).
    # This is a descriptive score, not a recommended trading threshold.
    out = group.copy()

    out["direction_hit"] = (
            out["directional_class"] == out["actual_class"]
    )

    out["actual_is_directional"] = (
        out["actual_class"].isin(["UP", "DOWN"])
    )

    out["actual_up"] = (out["actual_class"] == "UP")
    out["actual_down"] = (out["actual_class"] == "DOWN")

    rows = []

    for lower, upper in zip(
            DIRECTIONAL_CONFIDENCE_BINS[:-1],
            DIRECTIONAL_CONFIDENCE_BINS[1:]
    ):
        mask = (
                (out["directional_probability"] >= lower)
                & (out["directional_probability"] < upper)
        )
        g = out.loc[mask]

        if g.empty:
            continue

        directional = g[g["actual_is_directional"]]

        rows.append({
            "model_name": g["model_name"].iloc[0],
            "model_family": g["model_family"].iloc[0],
            "horizon_minutes": int(g["horizon_minutes"].iloc[0]),
            "year": int(g["year"].iloc[0])
            if g["year"].nunique() == 1 else "ALL",
            "confidence_lower": float(lower),
            "confidence_upper": float(upper),
            "rows": int(len(g)),
            "coverage_pct": float(len(g) / len(out) * 100),
            "mean_p_down": float(g["p_down"].mean()),
            "mean_p_sideways": float(g["p_sideways"].mean()),
            "mean_p_up": float(g["p_up"].mean()),
            "mean_directional_margin": float(
                g["directional_margin"].mean()
            ),
            "direction_hit_rate_including_sideways": float(
                g["direction_hit"].mean()
            ),
            "directional_actual_rows": int(len(directional)),
            "direction_hit_rate_conditional_up_down": (
                float(directional["direction_hit"].mean())
                if len(directional) else np.nan
            ),
            "actual_up_pct": float(
                (g["actual_class"] == "UP").mean() * 100
            ),
            "actual_down_pct": float(
                (g["actual_class"] == "DOWN").mean() * 100
            ),
            "actual_sideways_pct": float(
                (g["actual_class"] == "SIDEWAYS").mean() * 100
            ),
            "predicted_direction_up_pct": float(
                (g["directional_class"] == "UP").mean() * 100
            ),
        })

    return rows


def calibration_tables(group, dimension, value):
    rows = []

    for label, col in zip(CLASSES, PROB_COLS):
        actual_binary = (group["actual_class"] == label).astype(int)
        ece, bins = expected_calibration_error(
            actual_binary, group[col]
        )

        for item in bins:
            rows.append({
                "model_name": group["model_name"].iloc[0],
                "model_family": group["model_family"].iloc[0],
                "horizon_minutes": int(
                    group["horizon_minutes"].iloc[0]
                ),
                "year": (
                    int(group["year"].iloc[0])
                    if group["year"].nunique() == 1 else "ALL"
                ),
                "regime_dimension": dimension,
                "regime": value,
                "class": label,
                "ece": ece,
                **item,
            })

    return rows


def paired_comparison(df):
    results = []

    for horizon in HORIZONS:
        a = df[
            (df["model_family"] == "index_only")
            & (df["horizon_minutes"] == horizon)
            ].copy()

        b = df[
            (df["model_family"] == "index_plus_options")
            & (df["horizon_minutes"] == horizon)
            ].copy()

        # Pair on exact timestamp and horizon.
        keys = ["timestamp_ist", "horizon_minutes"]

        a_cols = keys + [
            "actual_class", "p_down", "p_sideways", "p_up"
        ]
        b_cols = keys + [
            "actual_class", "p_down", "p_sideways", "p_up"
        ]

        paired = a[a_cols].merge(
            b[b_cols],
            on=keys,
            how="inner",
            suffixes=("_index", "_options"),
            validate="one_to_one"
        )

        if paired.empty:
            results.append({
                "horizon_minutes": horizon,
                "paired_rows": 0,
                "status": "NO_MATCHED_ROWS",
            })
            continue

        actual_match = (
                paired["actual_class_index"]
                == paired["actual_class_options"]
        )

        if not actual_match.all():
            fail(
                f"Actual labels differ between model variants "
                f"for {horizon}m paired rows."
            )

        y = paired["actual_class_index"].to_numpy()

        p_index = paired[
            ["p_down_index", "p_sideways_index", "p_up_index"]
        ].to_numpy(dtype=float)

        p_options = paired[
            ["p_down_options", "p_sideways_options", "p_up_options"]
        ].to_numpy(dtype=float)

        mapping = {"DOWN": 0, "SIDEWAYS": 1, "UP": 2}
        y_num = pd.Series(y).map(mapping).to_numpy()

        pred_index = np.array(CLASSES)[np.argmax(p_index, axis=1)]
        pred_options = np.array(CLASSES)[np.argmax(p_options, axis=1)]

        ll_index = log_loss(y_num, p_index, labels=[0, 1, 2])
        ll_options = log_loss(y_num, p_options, labels=[0, 1, 2])

        brier_index = multiclass_brier(y, p_index)
        brier_options = multiclass_brier(y, p_options)

        results.append({
            "horizon_minutes": horizon,
            "paired_rows": int(len(paired)),
            "actual_label_mismatches": int((~actual_match).sum()),
            "index_accuracy": float(accuracy_score(y, pred_index)),
            "options_accuracy": float(accuracy_score(y, pred_options)),
            "accuracy_delta_options_minus_index": float(
                accuracy_score(y, pred_options)
                - accuracy_score(y, pred_index)
            ),
            "index_balanced_accuracy": float(
                balanced_accuracy_score(y, pred_index)
            ),
            "options_balanced_accuracy": float(
                balanced_accuracy_score(y, pred_options)
            ),
            "index_macro_f1": float(
                f1_score(
                    y, pred_index, labels=CLASSES,
                    average="macro", zero_division=0
                )
            ),
            "options_macro_f1": float(
                f1_score(
                    y, pred_options, labels=CLASSES,
                    average="macro", zero_division=0
                )
            ),
            "index_log_loss": float(ll_index),
            "options_log_loss": float(ll_options),
            "log_loss_delta_options_minus_index": float(
                ll_options - ll_index
            ),
            "index_brier": float(brier_index),
            "options_brier": float(brier_options),
            "brier_delta_options_minus_index": float(
                brier_options - brier_index
            ),
            "index_mean_p_down": float(p_index[:, 0].mean()),
            "options_mean_p_down": float(p_options[:, 0].mean()),
            "index_mean_p_sideways": float(p_index[:, 1].mean()),
            "options_mean_p_sideways": float(p_options[:, 1].mean()),
            "index_mean_p_up": float(p_index[:, 2].mean()),
            "options_mean_p_up": float(p_options[:, 2].mean()),
            "status": "PASS",
        })

    return pd.DataFrame(results)


def build_all_reports(df, output_dir):
    overall_rows = []
    calibration_rows = []
    confidence_rows = []
    regime_rows = []

    # Overall and year-wise metrics.
    for (model, horizon), group in df.groupby(
            ["model_name", "horizon_minutes"]
    ):
        overall_rows.append(calculate_overall_metrics(group))

        confidence_rows.extend(calculate_directional_metrics(group))

        calibration_rows.extend(
            calibration_tables(group, "ALL", "ALL")
        )

        for year, yg in group.groupby("year"):
            row = calculate_overall_metrics(yg)
            row["year"] = int(year)
            overall_rows.append(row)

            confidence_rows.extend(calculate_directional_metrics(yg))

            calibration_rows.extend(
                calibration_tables(yg, "YEAR", str(year))
            )

        # Regime-wise metrics.
        for regime_col in REGIME_COLUMNS:
            for regime_value, rg in group.groupby(
                    regime_col, dropna=False
            ):
                metric = calculate_overall_metrics(rg)
                metric["regime_dimension"] = regime_col
                metric["regime"] = str(regime_value)
                regime_rows.append(metric)

                calibration_rows.extend(
                    calibration_tables(
                        rg, regime_col, str(regime_value)
                    )
                )

    overall = pd.DataFrame(overall_rows)
    confidence = pd.DataFrame(confidence_rows)
    calibration = pd.DataFrame(calibration_rows)
    regimes = pd.DataFrame(regime_rows)

    overall.to_csv(
        output_dir / "overall_and_yearly_metrics.csv",
        index=False
    )
    confidence.to_csv(
        output_dir / "directional_confidence_bands.csv",
        index=False
    )
    calibration.to_csv(
        output_dir / "class_probability_calibration.csv",
        index=False
    )
    regimes.to_csv(
        output_dir / "regime_probability_metrics.csv",
        index=False
    )

    return overall, confidence, calibration, regimes


def probability_distribution(df):
    rows = []

    group_cols = ["model_name", "model_family", "horizon_minutes"]

    for keys, group in df.groupby(group_cols):
        for label, col in zip(CLASSES, PROB_COLS):
            s = group[col]

            rows.append({
                "model_name": keys[0],
                "model_family": keys[1],
                "horizon_minutes": int(keys[2]),
                "probability_class": label,
                "rows": int(len(s)),
                "mean": float(s.mean()),
                "std": float(s.std()),
                "min": float(s.min()),
                "p10": float(s.quantile(0.10)),
                "p25": float(s.quantile(0.25)),
                "median": float(s.median()),
                "p75": float(s.quantile(0.75)),
                "p90": float(s.quantile(0.90)),
                "p95": float(s.quantile(0.95)),
                "max": float(s.max()),
            })

    return pd.DataFrame(rows)


def audit_inputs(df, regimes, aligned, file_audit):
    checks = []

    def add(name, passed, observed, expected):
        checks.append({
            "check": name,
            "status": "PASS" if passed else "FAIL",
            "observed": observed,
            "expected": expected,
        })

    add(
        "all_probability_rows_sum_to_one",
        bool(
            np.allclose(
                df[PROB_COLS].sum(axis=1).to_numpy(),
                1.0,
                atol=1e-8
            )
        ),
        float(
            np.abs(df[PROB_COLS].sum(axis=1) - 1).max()
        ),
        "maximum absolute sum error <= 1e-8 after tiny-drift normalization"
    )

    add(
        "probabilities_nonnegative",
        bool((df[PROB_COLS] >= 0).all().all()),
        float(df[PROB_COLS].min().min()),
        ">= 0"
    )

    add(
        "probabilities_finite",
        bool(np.isfinite(df[PROB_COLS].to_numpy()).all()),
        int(np.isfinite(df[PROB_COLS].to_numpy()).sum()),
        "all finite"
    )

    key = ["model_name", "timestamp_ist", "horizon_minutes"]
    duplicate_count = int(df.duplicated(key).sum())

    add(
        "unique_model_prediction_keys",
        duplicate_count == 0,
        duplicate_count,
        0
    )

    regime_duplicates = int(regimes["timestamp_ist"].duplicated().sum())

    add(
        "unique_regime_timestamps",
        regime_duplicates == 0,
        regime_duplicates,
        0
    )

    unmatched = int(aligned["trend_regime"].isna().sum())

    add(
        "all_predictions_aligned_to_regimes",
        unmatched == 0,
        unmatched,
        0
    )

    actual_mismatches = 0
    for _, group in df.groupby(
            ["timestamp_ist", "horizon_minutes"]
    ):
        if group["actual_class"].nunique() > 1:
            actual_mismatches += 1

    add(
        "actual_labels_consistent_across_model_variants",
        actual_mismatches == 0,
        actual_mismatches,
        0
    )

    invalid_families = sorted(
        set(df["model_family"].unique())
        - {"index_only", "index_plus_options"}
    )

    add(
        "recognized_model_families",
        len(invalid_families) == 0,
        invalid_families,
        ["index_only", "index_plus_options"]
    )

    add(
        "all_expected_horizons_present",
        set(HORIZONS).issubset(set(df["horizon_minutes"].unique())),
        sorted(df["horizon_minutes"].unique().tolist()),
        HORIZONS
    )

    add(
        "six_expected_model_files",
        df["model_name"].nunique() == 6,
        int(df["model_name"].nunique()),
        6
    )

    add(
        "all_source_files_have_zero_invalid_probability_rows",
        bool(
            (file_audit["invalid_probability_rows"] == 0).all()
        ),
        int(file_audit["invalid_probability_rows"].sum()),
        0
    )

    return pd.DataFrame(checks)


def main():
    parser = argparse.ArgumentParser(
        description="NIFTY probability and directional discrimination audit"
    )

    parser.add_argument(
        "--predictions-dir",
        type=Path,
        default=DEFAULT_PREDICTIONS_DIR
    )
    parser.add_argument(
        "--regime-dir",
        type=Path,
        default=DEFAULT_REGIME_DIR
    )
    parser.add_argument(
        "--regime-file",
        type=Path,
        default=None
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=DEFAULT_OUTPUT_DIR
    )
    parser.add_argument(
        "--prediction-files",
        nargs="*",
        type=Path,
        default=None
    )

    args = parser.parse_args()

    output_dir = create_output_dir(args.output_dir)
    log(f"Output directory: {output_dir}")

    regime_file = (
        args.regime_file
        if args.regime_file
        else discover_regime_file(args.regime_dir)
    )

    log(f"Regime file: {regime_file}")

    regimes = load_regimes(regime_file)

    prediction_files = discover_prediction_files(
        args.predictions_dir,
        args.prediction_files
    )

    log(f"Prediction files discovered: {len(prediction_files)}")

    if len(prediction_files) != 6:
        fail(
            f"Expected six end-to-end prediction files, "
            f"found {len(prediction_files)}. "
            "Pass exactly the six intended files explicitly."
        )

    df, file_audit = load_predictions(prediction_files)

    file_audit.to_csv(
        output_dir / "input_file_audit.csv",
        index=False
    )

    log(f"Valid prediction rows: {len(df):,}")

    # Merge regime labels onto every model prediction.
    aligned = df.merge(
        regimes,
        on="timestamp_ist",
        how="left",
        validate="many_to_one"
    )

    # Exclude unmatched or synthetic market timestamps.
    if "is_synthetic" in aligned.columns:
        aligned["is_synthetic"] = (
            aligned["is_synthetic"].fillna(False).astype(bool)
        )
    else:
        aligned["is_synthetic"] = False

    aligned_valid = aligned[
        aligned["trend_regime"].notna()
        & (~aligned["is_synthetic"])
        ].copy()

    aligned.to_csv(
        output_dir / "prediction_regime_probability_alignment.csv",
        index=False
    )

    # Core analyses.
    overall, confidence, calibration, regime_metrics = (
        build_all_reports(aligned_valid, output_dir)
    )

    distribution = probability_distribution(aligned_valid)
    distribution.to_csv(
        output_dir / "probability_distribution_summary.csv",
        index=False
    )

    paired = paired_comparison(aligned_valid)
    paired.to_csv(
        output_dir / "paired_index_vs_options_comparison.csv",
        index=False
    )

    # Class-specific directional ranking:
    # Conditional probability P(UP | UP or DOWN).
    directional_auc_rows = []

    for (model, horizon, year), group in aligned_valid.groupby(
            ["model_name", "horizon_minutes", "year"]
    ):
        directional = group[
            group["actual_class"].isin(["UP", "DOWN"])
        ].copy()

        if len(directional) == 0:
            continue

        y_binary = (directional["actual_class"] == "UP").astype(int)

        try:
            auc = roc_auc_score(
                y_binary,
                directional["conditional_p_up"]
            )
        except Exception:
            auc = np.nan

        directional_auc_rows.append({
            "model_name": model,
            "model_family": group["model_family"].iloc[0],
            "horizon_minutes": int(horizon),
            "year": int(year),
            "directional_actual_rows": int(len(directional)),
            "actual_up_pct": float(y_binary.mean() * 100),
            "conditional_up_probability_mean": float(
                directional["conditional_p_up"].mean()
            ),
            "conditional_direction_roc_auc": float(auc)
            if pd.notna(auc) else np.nan,
        })

    directional_auc = pd.DataFrame(directional_auc_rows)
    directional_auc.to_csv(
        output_dir / "conditional_direction_ranking.csv",
        index=False
    )

    # Audit.
    audit = audit_inputs(
        df, regimes, aligned, file_audit
    )
    audit.to_csv(
        output_dir / "probability_discrimination_audit.csv",
        index=False
    )

    # Summary.
    summary = {
        "project": "NIFTY_PHASE_2_1_1_PROBABILITY_DISCRIMINATION_V1",
        "generated_at": datetime.now().isoformat(),
        "overall_status": (
            "PASS"
            if (audit["status"] == "PASS").all()
            else "FAIL"
        ),
        "inputs": {
            "regime_file": str(regime_file),
            "prediction_files": [str(p) for p in prediction_files],
            "prediction_rows_valid": int(len(df)),
            "aligned_prediction_rows": int(len(aligned_valid)),
            "model_count": int(df["model_name"].nunique()),
            "horizons": sorted(
                df["horizon_minutes"].unique().tolist()
            ),
        },
        "definitions": {
            "directional_probability": "max(P(UP), P(DOWN))",
            "directional_class": (
                "UP when P(UP) >= P(DOWN), otherwise DOWN"
            ),
            "directional_margin": "abs(P(UP) - P(DOWN))",
            "conditional_p_up": (
                "P(UP) / (P(UP) + P(DOWN))"
            ),
            "confidence_bands": DIRECTIONAL_CONFIDENCE_BINS,
            "probability_calibration_bins": [
                float(x) for x in PROBABILITY_BINS
            ],
            "threshold_optimisation": False,
        },
        "paired_comparison": paired.to_dict(orient="records"),
        "audit_passed": int((audit["status"] == "PASS").sum()),
        "audit_failed": int((audit["status"] == "FAIL").sum()),
        "notes": [
            "No models were trained or modified.",
            "No prediction thresholds were optimised.",
            "Confidence bands are descriptive fixed bins.",
            "Directional hit rate including SIDEWAYS counts only exact UP/DOWN hits.",
            "Conditional UP/DOWN hit rate excludes actual SIDEWAYS observations.",
            "Conditional direction AUC evaluates UP versus DOWN only.",
            "Calibration is measured against the three-class labels.",
            "2024 is diagnostic and is not an untouched test set.",
            "Probability discrimination is not equivalent to trading profitability.",
            "No option bid/ask, slippage, fees or execution assumptions are included.",
        ],
    }

    with open(
            output_dir / "probability_discrimination_summary.json",
            "w",
            encoding="utf-8"
    ) as f:
        json.dump(summary, f, indent=2, default=str)

    log("=" * 72)
    log("NIFTY PHASE 2.1.1 COMPLETE")
    log(f"Status: {summary['overall_status']}")
    log(f"Predictions: {len(df):,}")
    log(f"Aligned predictions: {len(aligned_valid):,}")
    log(f"Models: {df['model_name'].nunique()}")
    log(f"Metric rows: {len(overall):,}")
    log(f"Regime metric rows: {len(regime_metrics):,}")
    log(f"Confidence-band rows: {len(confidence):,}")
    log(f"Calibration rows: {len(calibration):,}")
    log(f"Audit PASS: {summary['audit_passed']}")
    log(f"Audit FAIL: {summary['audit_failed']}")
    log(f"Output: {output_dir}")
    log("=" * 72)

    if summary["overall_status"] != "PASS":
        print(
            audit[audit["status"] == "FAIL"].to_string(index=False)
        )
        sys.exit(2)


if __name__ == "__main__":
    main()
