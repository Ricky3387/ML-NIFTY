
from __future__ import annotations

import json
import sys
import traceback
from datetime import datetime
from pathlib import Path

import joblib
import lightgbm as lgb
import numpy as np
import pandas as pd

from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    log_loss,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.utils.class_weight import compute_sample_weight


# ============================================================
# CONFIGURATION
# ============================================================

ROOT = Path(__file__).resolve().parents[1]

DATA_DIR = ROOT / "data" / "processed" / "nifty_matched_datasets_v2"

MODEL_DIR = ROOT / "models" / "nifty_lightgbm_v2"

REPORT_DIR = ROOT / "reports" / "nifty_lightgbm_v2"

DATASETS = [
    "index_only",
    "index_plus_options",
]

HORIZONS = [5, 15, 30]

TARGETS = {
    "quantile_v2": "label_quantile_v2",
    "volatility_v1": "label_volatility_v1",
}

LABELS = ["DOWN", "SIDEWAYS", "UP"]

FIT_START = "2021-05-24"
FIT_END = "2022-12-31"

EARLY_STOP_START = "2023-01-01"
EARLY_STOP_END = "2023-12-31"

VALIDATION_START = "2024-01-01"
VALIDATION_END = "2024-12-31"

RANDOM_STATE = 42
N_JOBS = 4

# Model configuration.
MODEL_PARAMS = {
    "objective": "multiclass",
    "num_class": 3,
    "n_estimators": 3000,
    "learning_rate": 0.02,
    "num_leaves": 15,
    "max_depth": -1,
    "min_child_samples": 300,
    "subsample": 0.80,
    "subsample_freq": 1,
    "colsample_bytree": 0.80,
    "reg_alpha": 0.5,
    "reg_lambda": 10.0,
    "max_bin": 127,
    "random_state": RANDOM_STATE,
    "n_jobs": N_JOBS,
    "verbosity": -1,
    "deterministic": True,
    "force_col_wise": True,
}

EARLY_STOPPING_ROUNDS = 100

# Explicit predictor lists.
INDEX_FEATURES = [
    "ret_1m",
    "logret_1m",
    "range_pct",
    "body_pct",
    "upper_wick_pct",
    "lower_wick_pct",
    "return_5m",
    "return_15m",
    "return_30m",
    "return_60m",
    "realized_vol_5m",
    "realized_vol_15m",
    "realized_vol_30m",
    "realized_vol_60m",
    "high_low_range_5m",
    "high_low_range_15m",
    "high_low_range_30m",
    "high_low_range_60m",
    "close_vs_ema9_pct",
    "close_vs_ema21_pct",
    "close_vs_ema50_pct",
    "rsi_14",
    "positive_return_count_5m",
    "negative_return_count_5m",
]

OPTIONS_FEATURES = [
    "selected_dte",
    "atm_distance_pct",
    "atm_straddle_premium_pct",
    "atm_ce_log_return_1m",
    "atm_pe_log_return_1m",
    "atm_ce_pe_return_spread_1m",
    "atm_straddle_weighted_log_return_1m",
    "atm_ce_oi_change_1m",
    "atm_pe_oi_change_1m",
    "near_atm_pcr_oi",
    "near_atm_pcr_volume",
    "near_atm_oi_imbalance",
    "near_atm_volume_imbalance",
    "paired_strike_count",
]

FEATURE_MAP = {
    "index_only": INDEX_FEATURES,
    "index_plus_options": INDEX_FEATURES + OPTIONS_FEATURES,
}


# ============================================================
# HELPERS
# ============================================================

def log(message):
    print(message, flush=True)


def json_safe(value):
    if isinstance(value, dict):
        return {str(k): json_safe(v) for k, v in value.items()}

    if isinstance(value, (list, tuple)):
        return [json_safe(v) for v in value]

    if isinstance(value, (np.integer,)):
        return int(value)

    if isinstance(value, (np.floating,)):
        return float(value)

    if isinstance(value, np.ndarray):
        return value.tolist()

    if isinstance(value, (pd.Timestamp,)):
        return value.isoformat()

    if isinstance(value, Path):
        return str(value)

    if isinstance(value, float) and not np.isfinite(value):
        return None

    return value


def ensure_no_overwrite(path):
    if path.exists():
        raise FileExistsError(
            f"Refusing to overwrite existing file:\n{path}"
        )


def get_input_path(dataset, split, horizon):
    return (
            DATA_DIR
            / dataset
            / f"{split}_{horizon}m.parquet"
    )


def get_date_mask(df, start, end):
    return (
            (df["_trading_day"] >= pd.Timestamp(start))
            & (df["_trading_day"] <= pd.Timestamp(end))
    )


def validate_input(df, features, target, file_path):
    required = (
            features
            + [
                target,
                "timestamp_ist",
                "trading_day",
                "horizon_minutes",
                "forward_return",
                "target_z",
            ]
    )

    missing = sorted(set(required) - set(df.columns))

    if missing:
        raise RuntimeError(
            f"Missing columns in {file_path}: {missing}"
        )

    if df.empty:
        raise RuntimeError(f"Empty dataset: {file_path}")

    if df["timestamp_ist"].duplicated().any():
        raise RuntimeError(
            f"Duplicate timestamps found: {file_path}"
        )

    if df[target].isna().any():
        raise RuntimeError(
            f"Null target labels found: {file_path}"
        )

    unexpected = sorted(
        set(df[target].astype(str).unique()) - set(LABELS)
    )

    if unexpected:
        raise RuntimeError(
            f"Unexpected labels in {file_path}: {unexpected}"
        )

    # Ensure model features are numeric and finite.
    for col in features:
        if not pd.api.types.is_numeric_dtype(df[col]):
            raise RuntimeError(
                f"Non-numeric predictor {col}: {file_path}"
            )

        values = df[col].to_numpy(dtype=np.float64)

        if not np.isfinite(values).all():
            raise RuntimeError(
                f"NaN or infinity in predictor {col}: {file_path}"
            )

    # Guard against accidental target leakage.
    forbidden = {
        "open",
        "high",
        "low",
        "close",
        "future_close",
        "future_timestamp",
        "forward_return",
        "target_z",
        "target_vol_scale",
        "label",
        "label_quantile_v2",
        "label_volatility_v1",
        "sample_eligible",
        "is_synthetic",
        "trading_day",
        "timestamp_ist",
        "horizon_minutes",
        "atm_straddle_premium",
    }

    bad_features = sorted(set(features) & forbidden)

    if bad_features:
        raise RuntimeError(
            f"Forbidden predictors detected: {bad_features}"
        )


def class_distribution(y):
    counts = y.value_counts().reindex(
        LABELS, fill_value=0
    )

    total = int(counts.sum())

    return {
        label: {
            "count": int(counts[label]),
            "percentage": (
                float(counts[label] / total * 100)
                if total else 0.0
            ),
        }
        for label in LABELS
    }


def multiclass_brier_score(y_true, probabilities):
    actual = np.zeros_like(probabilities, dtype=np.float64)

    label_index = {
        label: i for i, label in enumerate(LABELS)
    }

    for row_index, label in enumerate(y_true):
        actual[row_index, label_index[label]] = 1.0

    return float(
        np.mean(np.sum((probabilities - actual) ** 2, axis=1))
    )


def calculate_metrics(y_true, y_pred, probabilities):
    result = {
        "accuracy": accuracy_score(y_true, y_pred),
        "balanced_accuracy": balanced_accuracy_score(
            y_true, y_pred
        ),
        "macro_f1": f1_score(
            y_true, y_pred,
            labels=LABELS,
            average="macro",
            zero_division=0,
        ),
        "weighted_f1": f1_score(
            y_true, y_pred,
            labels=LABELS,
            average="weighted",
            zero_division=0,
        ),
        "macro_precision": precision_score(
            y_true, y_pred,
            labels=LABELS,
            average="macro",
            zero_division=0,
        ),
        "macro_recall": recall_score(
            y_true, y_pred,
            labels=LABELS,
            average="macro",
            zero_division=0,
        ),
        "log_loss": log_loss(
            y_true,
            probabilities,
            labels=LABELS,
        ),
        "multiclass_brier_score": multiclass_brier_score(
            np.asarray(y_true),
            probabilities,
        ),
    }

    try:
        result["macro_roc_auc_ovr"] = roc_auc_score(
            y_true,
            probabilities,
            labels=LABELS,
            multi_class="ovr",
            average="macro",
        )
    except ValueError:
        result["macro_roc_auc_ovr"] = None

    result["predicted_distribution"] = class_distribution(
        pd.Series(y_pred)
    )

    result["actual_distribution"] = class_distribution(
        pd.Series(y_true)
    )

    result["confusion_matrix"] = confusion_matrix(
        y_true,
        y_pred,
        labels=LABELS,
    ).tolist()

    result["classification_report"] = classification_report(
        y_true,
        y_pred,
        labels=LABELS,
        output_dict=True,
        zero_division=0,
    )

    return result


# ============================================================
# TRAIN ONE MODEL
# ============================================================

def train_one_model(
        dataset,
        horizon,
        target_name,
        target_column,
):
    log("\n" + "=" * 78)
    log(
        f"DATASET={dataset} | HORIZON={horizon}m | "
        f"TARGET={target_name}"
    )
    log("=" * 78)

    features = FEATURE_MAP[dataset]

    train_path = get_input_path(
        dataset, "train", horizon
    )

    validation_path = get_input_path(
        dataset, "validation", horizon
    )

    for path in (train_path, validation_path):
        if not path.exists():
            raise FileNotFoundError(path)

    # --------------------------------------------------------
    # Load data
    # --------------------------------------------------------

    log("Loading training data...")

    train_df = pd.read_parquet(train_path)
    validation_df = pd.read_parquet(validation_path)

    log("Loading validation data complete.")

    # --------------------------------------------------------
    # Validate input
    # --------------------------------------------------------

    validate_input(
        train_df, features, target_column, train_path
    )

    validate_input(
        validation_df, features, target_column, validation_path
    )

    train_df["_trading_day"] = pd.to_datetime(
        train_df["trading_day"]
    )

    validation_df["_trading_day"] = pd.to_datetime(
        validation_df["trading_day"]
    )

    if not (
            (train_df["_trading_day"] >= pd.Timestamp(FIT_START))
            & (train_df["_trading_day"] <= pd.Timestamp(2023, 12, 31))
    ).all():
        raise RuntimeError(
            "Unexpected dates in training dataset."
        )

    if not (
            (validation_df["_trading_day"] >= pd.Timestamp(VALIDATION_START))
            & (validation_df["_trading_day"] <= pd.Timestamp(VALIDATION_END))
    ).all():
        raise RuntimeError(
            "Unexpected dates in validation dataset."
        )

    # --------------------------------------------------------
    # Split fit and early stopping
    # --------------------------------------------------------

    fit_mask = get_date_mask(
        train_df, FIT_START, FIT_END
    )

    early_mask = get_date_mask(
        train_df, EARLY_STOP_START, EARLY_STOP_END
    )

    fit_df = train_df.loc[fit_mask].copy()
    early_df = train_df.loc[early_mask].copy()

    if fit_df.empty or early_df.empty:
        raise RuntimeError(
            "Fit or early-stopping partition is empty."
        )

    X_fit = fit_df[features]
    y_fit = fit_df[target_column].astype(str)

    X_early = early_df[features]
    y_early = early_df[target_column].astype(str)

    X_train_all = train_df[features]
    y_train_all = train_df[target_column].astype(str)

    X_validation = validation_df[features]
    y_validation = validation_df[target_column].astype(str)

    log(f"Fit rows         : {len(fit_df):,}")
    log(f"Early-stop rows  : {len(early_df):,}")
    log(f"Final train rows : {len(train_df):,}")
    log(f"Validation rows  : {len(validation_df):,}")
    log(f"Predictor count  : {len(features)}")

    log("\nFit class distribution:")
    log(json.dumps(class_distribution(y_fit), indent=2))

    log("\nEarly-stop class distribution:")
    log(json.dumps(class_distribution(y_early), indent=2))

    # --------------------------------------------------------
    # Balanced sample weights
    # --------------------------------------------------------

    fit_weights = compute_sample_weight(
        class_weight="balanced",
        y=y_fit,
    )

    final_weights = compute_sample_weight(
        class_weight="balanced",
        y=y_train_all,
    )

    # --------------------------------------------------------
    # Early-stopping model
    # --------------------------------------------------------

    log("\nTraining early-stopping model...")

    early_model = lgb.LGBMClassifier(**MODEL_PARAMS)

    early_model.fit(
        X_fit,
        y_fit,
        sample_weight=fit_weights,
        eval_set=[(X_early, y_early)],
        eval_metric="multi_logloss",
        callbacks=[
            lgb.early_stopping(
                EARLY_STOPPING_ROUNDS,
                verbose=False,
            ),
            lgb.log_evaluation(period=0),
        ],
    )

    best_iteration = int(
        early_model.best_iteration_
        or MODEL_PARAMS["n_estimators"]
    )

    log(f"Best iteration: {best_iteration}")

    # --------------------------------------------------------
    # Final model: refit all 2021-2023 training rows
    # --------------------------------------------------------

    log("\nRefitting final model on 2021-2023...")

    final_params = dict(MODEL_PARAMS)
    final_params["n_estimators"] = best_iteration

    final_model = lgb.LGBMClassifier(**final_params)

    final_model.fit(
        X_train_all,
        y_train_all,
        sample_weight=final_weights,
    )

    # --------------------------------------------------------
    # Predict 2024 validation
    # --------------------------------------------------------

    log("\nPredicting 2024 validation...")

    probabilities = final_model.predict_proba(
        X_validation
    )

    model_classes = list(final_model.classes_)

    if model_classes != LABELS:
        raise RuntimeError(
            f"Unexpected model class order: {model_classes}"
        )

    predicted = final_model.predict(X_validation)

    metrics = calculate_metrics(
        y_validation.to_numpy(),
        predicted,
        probabilities,
    )

    # --------------------------------------------------------
    # Output directories and paths
    # --------------------------------------------------------

    model_subdir = (
            MODEL_DIR / target_name / dataset
    )

    report_subdir = (
            REPORT_DIR / target_name / dataset
    )

    model_subdir.mkdir(parents=True, exist_ok=True)
    report_subdir.mkdir(parents=True, exist_ok=True)

    model_path = (
            model_subdir / f"lightgbm_{horizon}m.joblib"
    )

    prediction_path = (
            report_subdir / f"validation_predictions_{horizon}m.csv"
    )

    importance_path = (
            report_subdir / f"feature_importance_{horizon}m.csv"
    )

    metrics_path = (
            report_subdir / f"metrics_{horizon}m.json"
    )

    for path in (
            model_path,
            prediction_path,
            importance_path,
            metrics_path,
    ):
        ensure_no_overwrite(path)

    # --------------------------------------------------------
    # Save final model
    # --------------------------------------------------------

    joblib.dump(final_model, model_path)

    # --------------------------------------------------------
    # Feature importance
    # --------------------------------------------------------

    importance = pd.DataFrame({
        "feature": features,
        "split_importance": final_model.booster_.feature_importance(
            importance_type="split"
        ),
        "gain_importance": final_model.booster_.feature_importance(
            importance_type="gain"
        ),
    })

    importance = importance.sort_values(
        "gain_importance",
        ascending=False,
    )

    importance.to_csv(
        importance_path,
        index=False,
    )

    # --------------------------------------------------------
    # Validation prediction export
    # --------------------------------------------------------

    prediction_df = pd.DataFrame({
        "timestamp_ist": validation_df["timestamp_ist"].values,
        "trading_day": validation_df["trading_day"].values,
        "horizon_minutes": horizon,
        "actual_label": y_validation.values,
        "predicted_label": predicted,
        "prob_down": probabilities[:, 0],
        "prob_sideways": probabilities[:, 1],
        "prob_up": probabilities[:, 2],
        "forward_return": validation_df["forward_return"].values,
        "target_z": validation_df["target_z"].values,
    })

    prediction_df.to_csv(
        prediction_path,
        index=False,
    )

    # --------------------------------------------------------
    # Metrics report
    # --------------------------------------------------------

    report = {
        "generated_at": datetime.now().isoformat(),
        "dataset": dataset,
        "target_name": target_name,
        "target_column": target_column,
        "horizon_minutes": horizon,
        "predictor_count": len(features),
        "predictors": features,
        "fit_period": {
            "start": FIT_START,
            "end": FIT_END,
            "rows": len(fit_df),
        },
        "early_stopping_period": {
            "start": EARLY_STOP_START,
            "end": EARLY_STOP_END,
            "rows": len(early_df),
        },
        "final_training_period": {
            "start": FIT_START,
            "end": "2023-12-31",
            "rows": len(train_df),
        },
        "validation_period": {
            "start": VALIDATION_START,
            "end": VALIDATION_END,
            "rows": len(validation_df),
        },
        "best_iteration": best_iteration,
        "sample_weighting": "balanced",
        "fit_class_distribution": class_distribution(y_fit),
        "early_stop_class_distribution": class_distribution(y_early),
        "validation_metrics": metrics,
        "model_path": str(model_path),
        "prediction_path": str(prediction_path),
        "feature_importance_path": str(importance_path),
        "model_parameters": final_params,
        "lightgbm_version": lgb.__version__,
    }

    metrics_path.write_text(
        json.dumps(
            json_safe(report),
            indent=2,
        ),
        encoding="utf-8",
    )

    log("\nValidation metrics:")
    log(f"Accuracy          : {metrics['accuracy']:.6f}")
    log(f"Balanced accuracy : {metrics['balanced_accuracy']:.6f}")
    log(f"Macro F1           : {metrics['macro_f1']:.6f}")
    log(f"Weighted F1        : {metrics['weighted_f1']:.6f}")
    log(f"Log loss           : {metrics['log_loss']:.6f}")
    log(f"Macro ROC-AUC      : {metrics['macro_roc_auc_ovr']}")

    log("\nPredicted class distribution:")
    log(json.dumps(
        metrics["predicted_distribution"],
        indent=2,
    ))

    log(f"\nModel saved: {model_path}")
    log(f"Metrics saved: {metrics_path}")

    return {
        "dataset": dataset,
        "target_name": target_name,
        "target_column": target_column,
        "horizon_minutes": horizon,
        "train_rows": len(train_df),
        "fit_rows": len(fit_df),
        "early_stop_rows": len(early_df),
        "validation_rows": len(validation_df),
        "feature_count": len(features),
        "best_iteration": best_iteration,
        "accuracy": metrics["accuracy"],
        "balanced_accuracy": metrics["balanced_accuracy"],
        "macro_f1": metrics["macro_f1"],
        "weighted_f1": metrics["weighted_f1"],
        "log_loss": metrics["log_loss"],
        "macro_roc_auc_ovr": metrics["macro_roc_auc_ovr"],
        "multiclass_brier_score": metrics["multiclass_brier_score"],
        "predicted_down_pct": (
            metrics["predicted_distribution"]["DOWN"]["percentage"]
        ),
        "predicted_sideways_pct": (
            metrics["predicted_distribution"]["SIDEWAYS"]["percentage"]
        ),
        "predicted_up_pct": (
            metrics["predicted_distribution"]["UP"]["percentage"]
        ),
        "sample_weighting": "balanced",
        "status": "PASS",
    }


# ============================================================
# MAIN
# ============================================================

def main():
    log("=" * 78)
    log("NIFTY LIGHTGBM V2 TRAINING")
    log("=" * 78)

    log(f"LightGBM version: {lgb.__version__}")
    log(f"Fit: {FIT_START} to {FIT_END}")
    log(f"Early stop: {EARLY_STOP_START} to {EARLY_STOP_END}")
    log(f"Validation: {VALIDATION_START} to {VALIDATION_END}")

    if not DATA_DIR.exists():
        raise FileNotFoundError(DATA_DIR)

    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    REPORT_DIR.mkdir(parents=True, exist_ok=True)

    # Prevent partial reruns from overwriting existing models.
    for target_name in TARGETS:
        for dataset in DATASETS:
            for horizon in HORIZONS:
                model_path = (
                        MODEL_DIR / target_name / dataset
                        / f"lightgbm_{horizon}m.joblib"
                )

                prediction_path = (
                        REPORT_DIR / target_name / dataset
                        / f"validation_predictions_{horizon}m.csv"
                )

                metrics_path = (
                        REPORT_DIR / target_name / dataset
                        / f"metrics_{horizon}m.json"
                )

                importance_path = (
                        REPORT_DIR / target_name / dataset
                        / f"feature_importance_{horizon}m.csv"
                )

                for path in (
                        model_path,
                        prediction_path,
                        metrics_path,
                        importance_path,
                ):
                    ensure_no_overwrite(path)

    results = []

    total_models = (
            len(TARGETS) * len(DATASETS) * len(HORIZONS)
    )

    completed = 0

    for target_name, target_column in TARGETS.items():
        for dataset in DATASETS:
            for horizon in HORIZONS:
                result = train_one_model(
                    dataset=dataset,
                    horizon=horizon,
                    target_name=target_name,
                    target_column=target_column,
                )

                results.append(result)
                completed += 1

                log(
                    f"\nPROGRESS: {completed}/{total_models} models completed"
                )

    # --------------------------------------------------------
    # Combined comparison
    # --------------------------------------------------------

    results_df = pd.DataFrame(results)

    comparison_path = (
            REPORT_DIR / "model_comparison_v2.csv"
    )

    summary_path = (
            REPORT_DIR / "training_summary_v2.json"
    )

    ensure_no_overwrite(comparison_path)
    ensure_no_overwrite(summary_path)

    results_df.to_csv(
        comparison_path,
        index=False,
    )

    summary = {
        "generated_at": datetime.now().isoformat(),
        "status": (
            "PASS"
            if len(results) == total_models
            else "REVIEW_REQUIRED"
        ),
        "models_expected": total_models,
        "models_completed": len(results),
        "targets": TARGETS,
        "datasets": DATASETS,
        "horizons": HORIZONS,
        "fit_period": [FIT_START, FIT_END],
        "early_stopping_period": [
            EARLY_STOP_START,
            EARLY_STOP_END,
        ],
        "final_training_period": [
            FIT_START,
            "2023-12-31",
        ],
        "validation_period": [
            VALIDATION_START,
            VALIDATION_END,
        ],
        "sample_weighting": "balanced",
        "model_parameters": MODEL_PARAMS,
        "comparison_file": str(comparison_path),
        "results": results,
    }

    summary_path.write_text(
        json.dumps(json_safe(summary), indent=2),
        encoding="utf-8",
    )

    log("\n" + "=" * 78)
    log("ALL MODEL TRAINING COMPLETED")
    log("=" * 78)

    display_columns = [
        "target_name",
        "dataset",
        "horizon_minutes",
        "best_iteration",
        "accuracy",
        "balanced_accuracy",
        "macro_f1",
        "log_loss",
        "macro_roc_auc_ovr",
        "predicted_down_pct",
        "predicted_sideways_pct",
        "predicted_up_pct",
    ]

    log(results_df[display_columns].to_string(index=False))

    log(f"\nComparison: {comparison_path}")
    log(f"Summary: {summary_path}")


if __name__ == "__main__":
    try:
        main()
    except Exception:
        log("\nTRAINING FAILED")
        traceback.print_exc()
        sys.exit(1)
