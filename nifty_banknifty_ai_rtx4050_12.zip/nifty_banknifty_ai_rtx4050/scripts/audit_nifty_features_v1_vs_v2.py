
from __future__ import annotations

import json
import sys
import traceback
from pathlib import Path
from datetime import datetime

import duckdb
import pandas as pd


# ============================================================
# CONFIGURATION
# ============================================================

ROOT = Path(__file__).resolve().parents[1]

V1_FILE = (
        ROOT / "data" / "processed" / "nifty_features_v1"
        / "nifty_features_labels_long.parquet"
)

V2_FILE = (
        ROOT / "data" / "processed" / "nifty_features_v2"
        / "nifty_features_labels_long_v2.parquet"
)

REPORT_DIR = ROOT / "reports" / "nifty_features_v1_vs_v2"

MEMORY_LIMIT = "5GB"
THREADS = 4

KEYS = ["timestamp_ist", "horizon_minutes"]

# Numerical tolerance for floating-point comparisons.
ABS_TOLERANCE = 1e-12
REL_TOLERANCE = 1e-10

NUMERIC_COLUMNS = [
    "forward_return",
    "future_close",
    "target_z",
    "target_vol_scale",
]

STRING_COLUMNS = [
    "trading_day",
    "label",
]

BOOLEAN_COLUMNS = [
    "sample_eligible",
    "is_synthetic",
    "training_day_eligible",
]


# ============================================================
# HELPERS
# ============================================================

def log(message):
    print(message, flush=True)


def qstr(value):
    return "'" + str(value).replace("'", "''") + "'"


def qpath(path):
    return qstr(str(path.resolve()).replace("\\", "/"))


def qid(name):
    return '"' + str(name).replace('"', '""') + '"'


def ensure_inputs():
    for path in (V1_FILE, V2_FILE):
        if not path.exists():
            raise FileNotFoundError(path)


def ensure_report_directory():
    REPORT_DIR.mkdir(parents=True, exist_ok=True)


def describe(con, path):
    return con.execute(
        f"DESCRIBE SELECT * FROM read_parquet({qpath(path)})"
    ).fetchall()


def schema_map(rows):
    return {row[0]: row[1] for row in rows}


def check_required_columns(v1_schema, v2_schema):
    required = set(KEYS + NUMERIC_COLUMNS + STRING_COLUMNS)

    required.update(
        ["sample_eligible", "is_synthetic", "training_day_eligible"]
    )

    missing_v1 = sorted(required - set(v1_schema))
    missing_v2 = sorted(required - set(v2_schema))

    if missing_v1:
        raise RuntimeError(
            f"Missing columns in v1: {missing_v1}"
        )

    if missing_v2:
        raise RuntimeError(
            f"Missing columns in v2: {missing_v2}"
        )

    if "label_volatility_v1" not in v2_schema:
        raise RuntimeError(
            "v2 is missing label_volatility_v1. "
            "Cannot independently verify preserved volatility labels."
        )

    if "label_quantile_v2" not in v2_schema:
        raise RuntimeError(
            "v2 is missing label_quantile_v2."
        )


def count(con, query):
    return con.execute(query).fetchone()[0]


# ============================================================
# MAIN AUDIT
# ============================================================

def main():
    log("=" * 78)
    log("NIFTY FEATURE V1 VS V2 TARGET-PRESERVATION AUDIT")
    log("=" * 78)

    ensure_inputs()
    ensure_report_directory()

    con = duckdb.connect(":memory:")

    try:
        con.execute(
            f"SET memory_limit = {qstr(MEMORY_LIMIT)}"
        )
        con.execute(f"SET threads = {THREADS}")
        con.execute("SET TimeZone = 'Asia/Kolkata'")

        log(f"V1 input: {V1_FILE}")
        log(f"V2 input: {V2_FILE}")
        log(f"Reports : {REPORT_DIR}")

        # ----------------------------------------------------
        # 1. Schema checks
        # ----------------------------------------------------

        log("\n1. Inspecting schemas...")

        v1_schema = schema_map(describe(con, V1_FILE))
        v2_schema = schema_map(describe(con, V2_FILE))

        check_required_columns(v1_schema, v2_schema)

        con.execute(f"""
            CREATE VIEW v1 AS
            SELECT *
            FROM read_parquet({qpath(V1_FILE)})
        """)

        con.execute(f"""
            CREATE VIEW v2 AS
            SELECT *
            FROM read_parquet({qpath(V2_FILE)})
        """)

        # ----------------------------------------------------
        # 2. Overall counts and duplicate keys
        # ----------------------------------------------------

        log("\n2. Checking row counts and duplicate keys...")

        v1_rows = count(con, "SELECT COUNT(*) FROM v1")
        v2_rows = count(con, "SELECT COUNT(*) FROM v2")

        v1_duplicates = count(con, """
                                   SELECT COUNT(*)
                                   FROM (
                                            SELECT timestamp_ist, horizon_minutes
                                            FROM v1
                                            GROUP BY timestamp_ist, horizon_minutes
                                            HAVING COUNT(*) > 1
                                        ) d
                                   """)

        v2_duplicates = count(con, """
                                   SELECT COUNT(*)
                                   FROM (
                                            SELECT timestamp_ist, horizon_minutes
                                            FROM v2
                                            GROUP BY timestamp_ist, horizon_minutes
                                            HAVING COUNT(*) > 1
                                        ) d
                                   """)

        # ----------------------------------------------------
        # 3. Exact key alignment
        # ----------------------------------------------------

        log("\n3. Checking exact timestamp+horizon alignment...")

        v1_only = count(con, """
                             SELECT COUNT(*)
                             FROM (
                                      SELECT timestamp_ist, horizon_minutes FROM v1
                                      EXCEPT
                                      SELECT timestamp_ist, horizon_minutes FROM v2
                                  ) d
                             """)

        v2_only = count(con, """
                             SELECT COUNT(*)
                             FROM (
                                      SELECT timestamp_ist, horizon_minutes FROM v2
                                      EXCEPT
                                      SELECT timestamp_ist, horizon_minutes FROM v1
                                  ) d
                             """)

        # ----------------------------------------------------
        # 4. Build matched comparison view
        # ----------------------------------------------------

        log("\n4. Joining v1 and v2 on exact keys...")

        con.execute("""
                    CREATE TEMP VIEW comparison AS
                    SELECT
                        v1.timestamp_ist,
                        v1.horizon_minutes,

                        v1.trading_day AS v1_trading_day,
                        v2.trading_day AS v2_trading_day,

                        v1.label AS v1_label,
                        v2.label AS v2_label,
                        v2.label_volatility_v1,

                        v1.sample_eligible AS v1_sample_eligible,
                        v2.sample_eligible AS v2_sample_eligible,

                        v1.is_synthetic AS v1_is_synthetic,
                        v2.is_synthetic AS v2_is_synthetic,

                        v1.training_day_eligible AS v1_training_day_eligible,
                        v2.training_day_eligible AS v2_training_day_eligible,

                        v1.forward_return AS v1_forward_return,
                        v2.forward_return AS v2_forward_return,

                        v1.future_close AS v1_future_close,
                        v2.future_close AS v2_future_close,

                        v1.target_z AS v1_target_z,
                        v2.target_z AS v2_target_z,

                        v1.target_vol_scale AS v1_target_vol_scale,
                        v2.target_vol_scale AS v2_target_vol_scale,

                        v2.label_quantile_v2,
                        v2.quantile_lower,
                        v2.quantile_upper

                    FROM v1
                             INNER JOIN v2
                                        ON v1.timestamp_ist = v2.timestamp_ist
                                            AND v1.horizon_minutes = v2.horizon_minutes
                    """)

        matched_rows = count(
            con, "SELECT COUNT(*) FROM comparison"
        )

        # ----------------------------------------------------
        # 5. Numeric comparisons
        # ----------------------------------------------------

        log("\n5. Comparing numeric target columns...")

        numeric_results = []

        for col in NUMERIC_COLUMNS:
            a = f"v1_{col}"
            b = f"v2_{col}"

            result = con.execute(f"""
                SELECT
                    COUNT(*) AS total_rows,

                    COUNT(*) FILTER (
                        WHERE {a} IS NULL
                    ) AS v1_nulls,

                    COUNT(*) FILTER (
                        WHERE {b} IS NULL
                    ) AS v2_nulls,

                    COUNT(*) FILTER (
                        WHERE ({a} IS NULL) <> ({b} IS NULL)
                    ) AS null_status_mismatches,

                    COUNT(*) FILTER (
                        WHERE {a} IS NOT NULL
                          AND {b} IS NOT NULL
                          AND NOT isfinite(CAST({a} AS DOUBLE))
                    ) AS v1_nonfinite,

                    COUNT(*) FILTER (
                        WHERE {a} IS NOT NULL
                          AND {b} IS NOT NULL
                          AND NOT isfinite(CAST({b} AS DOUBLE))
                    ) AS v2_nonfinite,

                    COUNT(*) FILTER (
                        WHERE {a} IS NOT NULL
                          AND {b} IS NOT NULL
                          AND isfinite(CAST({a} AS DOUBLE))
                          AND isfinite(CAST({b} AS DOUBLE))
                          AND NOT (
                              abs(CAST({a} AS DOUBLE)
                                  - CAST({b} AS DOUBLE))
                              <= {ABS_TOLERANCE}
                                 + {REL_TOLERANCE}
                                 * greatest(
                                     abs(CAST({a} AS DOUBLE)),
                                     abs(CAST({b} AS DOUBLE))
                                 )
                          )
                    ) AS value_mismatches,

                    MAX(
                        abs(
                            CAST({a} AS DOUBLE)
                            - CAST({b} AS DOUBLE)
                        )
                    ) FILTER (
                        WHERE {a} IS NOT NULL
                          AND {b} IS NOT NULL
                          AND isfinite(CAST({a} AS DOUBLE))
                          AND isfinite(CAST({b} AS DOUBLE))
                    ) AS max_absolute_difference

                FROM comparison
            """).fetchone()

            numeric_results.append({
                "column": col,
                "total_rows": result[0],
                "v1_nulls": result[1],
                "v2_nulls": result[2],
                "null_status_mismatches": result[3],
                "v1_nonfinite": result[4],
                "v2_nonfinite": result[5],
                "value_mismatches": result[6],
                "max_absolute_difference": result[7],
                "status": (
                    "PASS"
                    if result[3] == 0
                       and result[4] == 0
                       and result[5] == 0
                       and result[6] == 0
                    else "FAIL"
                ),
            })

        # ----------------------------------------------------
        # 6. String and boolean comparisons
        # ----------------------------------------------------

        log("\n6. Comparing labels, dates and eligibility...")

        categorical_results = []

        compare_columns = [
            ("trading_day", "v1_trading_day", "v2_trading_day"),
            ("label", "v1_label", "v2_label"),
            (
                "label_volatility_v1",
                "v1_label",
                "label_volatility_v1",
            ),
            (
                "sample_eligible",
                "v1_sample_eligible",
                "v2_sample_eligible",
            ),
            (
                "is_synthetic",
                "v1_is_synthetic",
                "v2_is_synthetic",
            ),
            (
                "training_day_eligible",
                "v1_training_day_eligible",
                "v2_training_day_eligible",
            ),
        ]

        for name, a, b in compare_columns:
            mismatch = count(con, f"""
                SELECT COUNT(*)
                FROM comparison
                WHERE ({qid(a)} IS NULL) <> ({qid(b)} IS NULL)
                   OR (
                       {qid(a)} IS NOT NULL
                       AND {qid(b)} IS NOT NULL
                       AND CAST({qid(a)} AS VARCHAR)
                           <> CAST({qid(b)} AS VARCHAR)
                   )
            """)

            categorical_results.append({
                "column": name,
                "mismatches": mismatch,
                "status": "PASS" if mismatch == 0 else "FAIL",
            })

        # ----------------------------------------------------
        # 7. Per-horizon target and eligibility comparison
        # ----------------------------------------------------

        log("\n7. Building per-horizon audit...")

        horizon_audit = con.execute("""
                                    SELECT
                                        horizon_minutes,

                                        COUNT(*) AS matched_rows,

                                        COUNT(*) FILTER (
                    WHERE v1_sample_eligible = TRUE
                ) AS v1_eligible,

                                        COUNT(*) FILTER (
                    WHERE v2_sample_eligible = TRUE
                ) AS v2_eligible,

                                        COUNT(*) FILTER (
                    WHERE v1_sample_eligible
                      <> v2_sample_eligible
                ) AS eligibility_mismatches,

                                        COUNT(*) FILTER (
                    WHERE v1_label <> v2_label
                ) AS volatility_label_mismatches,

                                        COUNT(*) FILTER (
                    WHERE v1_target_z IS NOT NULL
                      AND v2_target_z IS NOT NULL
                      AND abs(v1_target_z - v2_target_z) > 1e-12
                ) AS target_z_mismatches,

                                        COUNT(*) FILTER (
                    WHERE v1_forward_return IS NOT NULL
                      AND v2_forward_return IS NOT NULL
                      AND abs(v1_forward_return - v2_forward_return)
                          > 1e-12
                ) AS forward_return_mismatches,

                                        COUNT(*) FILTER (
                    WHERE label_quantile_v2 IS NULL
                      AND v2_sample_eligible = TRUE
                ) AS eligible_rows_missing_quantile_label,

                                        COUNT(*) FILTER (
                    WHERE label_quantile_v2 IS NOT NULL
                      AND v2_sample_eligible = FALSE
                ) AS ineligible_rows_with_quantile_label

                                    FROM comparison
                                    GROUP BY horizon_minutes
                                    ORDER BY horizon_minutes
                                    """).df()

        # ----------------------------------------------------
        # 8. Quantile thresholds are constant per horizon
        # ----------------------------------------------------

        log("\n8. Validating threshold consistency...")

        threshold_audit = con.execute("""
                                      SELECT
                                          horizon_minutes,
                                          COUNT(DISTINCT quantile_lower) AS lower_value_count,
                                          COUNT(DISTINCT quantile_upper) AS upper_value_count,
                                          MIN(quantile_lower) AS lower_threshold,
                                          MAX(quantile_lower) AS max_lower_threshold,
                                          MIN(quantile_upper) AS upper_threshold,
                                          MAX(quantile_upper) AS max_upper_threshold,

                                          COUNT(*) FILTER (
                    WHERE quantile_lower IS NULL
                       OR quantile_upper IS NULL
                ) AS null_threshold_rows

                                      FROM comparison
                                      GROUP BY horizon_minutes
                                      ORDER BY horizon_minutes
                                      """).df()

        threshold_audit["status"] = threshold_audit.apply(
            lambda r: (
                "PASS"
                if r["lower_value_count"] == 1
                   and r["upper_value_count"] == 1
                   and r["null_threshold_rows"] == 0
                   and r["lower_threshold"] < r["upper_threshold"]
                else "FAIL"
            ),
            axis=1,
        )

        # ----------------------------------------------------
        # 9. Sample mismatches for debugging
        # ----------------------------------------------------

        log("\n9. Exporting mismatch samples...")

        mismatch_sample = con.execute("""
                                      SELECT *
                                      FROM comparison
                                      WHERE v1_trading_day <> v2_trading_day
                                         OR v1_label <> v2_label
                                         OR label_volatility_v1 <> v1_label
                                         OR v1_sample_eligible <> v2_sample_eligible
                                         OR abs(v1_forward_return - v2_forward_return) > 1e-12
                                         OR abs(v1_target_z - v2_target_z) > 1e-12
                                          LIMIT 1000
                                      """).df()

        # ----------------------------------------------------
        # 10. Overall checks
        # ----------------------------------------------------

        numeric_pass = all(
            row["status"] == "PASS"
            for row in numeric_results
        )

        categorical_pass = all(
            row["status"] == "PASS"
            for row in categorical_results
        )

        horizon_pass = (
                len(horizon_audit) == 3
                and (
                        horizon_audit["eligibility_mismatches"].sum() == 0
                )
                and (
                        horizon_audit["volatility_label_mismatches"].sum() == 0
                )
                and (
                        horizon_audit["target_z_mismatches"].sum() == 0
                )
                and (
                        horizon_audit["forward_return_mismatches"].sum() == 0
                )
                and (
                        horizon_audit[
                            "eligible_rows_missing_quantile_label"
                        ].sum() == 0
                )
                and (
                        horizon_audit[
                            "ineligible_rows_with_quantile_label"
                        ].sum() == 0
                )
        )

        checks = {
            "v1_v2_total_rows_equal": v1_rows == v2_rows,
            "no_v1_duplicate_keys": v1_duplicates == 0,
            "no_v2_duplicate_keys": v2_duplicates == 0,
            "no_v1_only_keys": v1_only == 0,
            "no_v2_only_keys": v2_only == 0,
            "matched_rows_equal_v1_rows": matched_rows == v1_rows,
            "numeric_target_columns_preserved": numeric_pass,
            "labels_dates_and_flags_preserved": categorical_pass,
            "per_horizon_targets_and_eligibility_preserved": horizon_pass,
            "quantile_thresholds_consistent": (
                (threshold_audit["status"] == "PASS").all()
            ),
        }

        overall = all(checks.values())

        # ----------------------------------------------------
        # 11. Save reports
        # ----------------------------------------------------

        numeric_df = pd.DataFrame(numeric_results)
        categorical_df = pd.DataFrame(categorical_results)

        numeric_df.to_csv(
            REPORT_DIR / "numeric_target_comparison.csv",
            index=False,
            )

        categorical_df.to_csv(
            REPORT_DIR / "categorical_target_comparison.csv",
            index=False,
            )

        horizon_audit.to_csv(
            REPORT_DIR / "target_alignment_by_horizon.csv",
            index=False,
            )

        threshold_audit.to_csv(
            REPORT_DIR / "quantile_threshold_consistency.csv",
            index=False,
            )

        mismatch_sample.to_csv(
            REPORT_DIR / "target_mismatch_samples.csv",
            index=False,
            )

        summary = {
            "generated_at": datetime.now().isoformat(),
            "v1_file": str(V1_FILE),
            "v2_file": str(V2_FILE),
            "v1_rows": int(v1_rows),
            "v2_rows": int(v2_rows),
            "matched_rows": int(matched_rows),
            "v1_duplicate_keys": int(v1_duplicates),
            "v2_duplicate_keys": int(v2_duplicates),
            "v1_only_keys": int(v1_only),
            "v2_only_keys": int(v2_only),
            "numeric_comparisons": numeric_results,
            "categorical_comparisons": categorical_results,
            "per_horizon_audit": horizon_audit.to_dict("records"),
            "threshold_consistency": threshold_audit.to_dict("records"),
            "checks": checks,
            "passed_checks": sum(bool(v) for v in checks.values()),
            "total_checks": len(checks),
            "overall_status": "PASS" if overall else "REVIEW_REQUIRED",
            "tolerances": {
                "absolute": ABS_TOLERANCE,
                "relative": REL_TOLERANCE,
            },
        }

        summary_path = (
                REPORT_DIR / "v1_vs_v2_target_preservation_summary.json"
        )

        summary_path.write_text(
            json.dumps(summary, indent=2, default=str),
            encoding="utf-8",
        )

        # ----------------------------------------------------
        # 12. Console output
        # ----------------------------------------------------

        log("\n" + "=" * 78)
        log("V1 VS V2 TARGET-PRESERVATION AUDIT RESULTS")
        log("=" * 78)

        log(f"V1 rows       : {v1_rows:,}")
        log(f"V2 rows       : {v2_rows:,}")
        log(f"Matched rows  : {matched_rows:,}")
        log(f"V1-only keys  : {v1_only:,}")
        log(f"V2-only keys  : {v2_only:,}")

        log("\nNumeric comparisons:")
        log(numeric_df.to_string(index=False))

        log("\nCategorical comparisons:")
        log(categorical_df.to_string(index=False))

        log("\nPer-horizon audit:")
        log(horizon_audit.to_string(index=False))

        log("\nOverall checks:")
        for name, passed in checks.items():
            log(f"{'PASS' if passed else 'FAIL'}: {name}")

        log("\n" + "=" * 78)
        log(f"OVERALL STATUS: {'PASS' if overall else 'REVIEW_REQUIRED'}")
        log(f"Summary: {summary_path}")
        log("=" * 78)

        if not overall:
            sys.exit(2)

    finally:
        con.close()


if __name__ == "__main__":
    try:
        main()
    except Exception:
        log("\nAUDIT FAILED")
        traceback.print_exc()
        sys.exit(1)
