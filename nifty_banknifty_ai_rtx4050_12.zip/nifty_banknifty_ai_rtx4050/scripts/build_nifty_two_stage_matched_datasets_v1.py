
from pathlib import Path
import json
import duckdb
import pandas as pd

# ============================================================
# CONFIGURATION
# ============================================================

ROOT = Path(__file__).resolve().parent.parent

INPUT_FILE = (
        ROOT / "data" / "processed"
        / "nifty_index_options_features_v4"
        / "nifty_index_options_features_v4.parquet"
)

OUTPUT_ROOT = (
        ROOT / "data" / "processed"
        / "nifty_two_stage_matched_datasets_v1"
)

REPORT_DIR = (
        ROOT / "reports"
        / "nifty_two_stage_matched_datasets_v1"
)

HORIZONS = [5, 15, 30]
DATASETS = ["index_only", "index_plus_options"]
STAGES = ["stage1", "stage2"]

TRAIN_START = "2021-05-24"
TRAIN_END = "2023-12-31"
VALIDATION_START = "2024-01-01"
VALIDATION_END = "2024-12-31"

INDEX_FEATURES = [
    "ret_1m",
    "logret_1m",
    "range_pct",
    "body_pct",
    "upper_wick_pct",
    "lower_wick_pct",
    "return_5m",
    "return_15m",
    "return_30m",
    "return_60m",
    "realized_vol_5m",
    "realized_vol_15m",
    "realized_vol_30m",
    "realized_vol_60m",
    "high_low_range_5m",
    "high_low_range_15m",
    "high_low_range_30m",
    "high_low_range_60m",
    "close_vs_ema9_pct",
    "close_vs_ema21_pct",
    "close_vs_ema50_pct",
    "rsi_14",
    "positive_return_count_5m",
    "negative_return_count_5m",
]

OPTIONS_FEATURES = [
    "selected_dte",
    "atm_distance_pct",
    "atm_straddle_premium_pct",
    "atm_ce_log_return_1m",
    "atm_pe_log_return_1m",
    "atm_ce_pe_return_spread_1m",
    "atm_straddle_weighted_log_return_1m",
    "atm_ce_oi_change_1m",
    "atm_pe_oi_change_1m",
    "near_atm_pcr_oi",
    "near_atm_pcr_volume",
    "near_atm_oi_imbalance",
    "near_atm_volume_imbalance",
    "paired_strike_count",
]

STAGE1_TARGET = "label_stage1_move_v1"
STAGE2_TARGET = "label_stage2_direction_v1"

OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
REPORT_DIR.mkdir(parents=True, exist_ok=True)

if not INPUT_FILE.exists():
    raise FileNotFoundError(INPUT_FILE)

# Refuse to overwrite an existing output tree.
if OUTPUT_ROOT.exists() and any(OUTPUT_ROOT.iterdir()):
    raise FileExistsError(
        f"Output directory is not empty. "
        f"Preserve existing artifacts and choose a new version:\n"
        f"{OUTPUT_ROOT}"
    )


# ============================================================
# HELPERS
# ============================================================

def sql_string(value):
    return "'" + str(value).replace("'", "''") + "'"


def quoted_column(column):
    return '"' + column.replace('"', '""') + '"'


def finite_condition(features):
    return " AND ".join(
        f"isfinite(TRY_CAST({quoted_column(c)} AS DOUBLE))"
        for c in features
    )


def write_json(data, path):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(
            data,
            f,
            indent=2,
            default=str,
            allow_nan=False,
        )


# ============================================================
# CONNECT
# ============================================================

con = duckdb.connect()

input_sql = sql_string(str(INPUT_FILE))

con.execute(f"""
    CREATE VIEW source_data AS
    SELECT *
    FROM read_parquet({input_sql})
""")

source_columns = set(
    con.execute(
        "DESCRIBE SELECT * FROM source_data"
    ).fetchdf()["column_name"].tolist()
)

required = {
    "timestamp_ist",
    "trading_day",
    "horizon_minutes",
    "sample_eligible",
    "is_synthetic",
    "target_z",
    "forward_return",
    STAGE1_TARGET,
    STAGE2_TARGET,
}

missing = required - source_columns

if missing:
    raise ValueError(
        f"Missing required source columns: {sorted(missing)}"
    )

all_features = INDEX_FEATURES + OPTIONS_FEATURES

missing_features = set(all_features) - source_columns

if missing_features:
    raise ValueError(
        f"Missing predictor columns: {sorted(missing_features)}"
    )

source_rows = con.execute("""
                          SELECT COUNT(*) FROM source_data
                          """).fetchone()[0]

source_duplicates = con.execute("""
                                SELECT COUNT(*)
                                FROM (
                                         SELECT timestamp_ist, horizon_minutes
                                         FROM source_data
                                         GROUP BY timestamp_ist, horizon_minutes
                                         HAVING COUNT(*) > 1
                                     )
                                """).fetchone()[0]

if source_duplicates:
    raise ValueError(
        f"Duplicate source keys found: {source_duplicates}"
    )


# ============================================================
# CREATE COMMON MATCHED SAMPLE
# ============================================================

# Both index-only and options models use the same complete
# 38-feature sample. This avoids comparing different rows.
#
# Stage 1 includes all eligible matched rows.
# Stage 2 is a strict subset: actual Stage 1 label must be MOVE.

feature_filter = finite_condition(all_features)

con.execute(f"""
    CREATE TEMP VIEW matched_base AS

    SELECT *
    FROM source_data

    WHERE sample_eligible = TRUE
      AND COALESCE(is_synthetic, FALSE) = FALSE
      AND target_z IS NOT NULL
      AND {feature_filter}
      AND {STAGE1_TARGET} IN ('MOVE', 'SIDEWAYS')
      AND (
          ({STAGE1_TARGET} = 'SIDEWAYS'
              AND {STAGE2_TARGET} IS NULL)
          OR
          ({STAGE1_TARGET} = 'MOVE'
              AND {STAGE2_TARGET} IN ('DOWN', 'UP'))
      )
      AND CAST(trading_day AS DATE)
          BETWEEN DATE '{TRAIN_START}'
          AND DATE '{VALIDATION_END}'
""")

matched_rows = con.execute("""
                           SELECT COUNT(*) FROM matched_base
                           """).fetchone()[0]

if matched_rows == 0:
    raise ValueError("No matched rows available.")

print(f"Source rows: {source_rows:,}")
print(f"Matched complete rows: {matched_rows:,}")


# ============================================================
# BUILD OUTPUT FILES
# ============================================================

dataset_audit = []
parity_audit = []
stage_relationship_audit = []

metadata_columns = [
    "timestamp_ist",
    "trading_day",
    "horizon_minutes",
    "target_z",
    "forward_return",
    STAGE1_TARGET,
    STAGE2_TARGET,
]

for horizon in HORIZONS:

    for split_name, start_date, end_date in [
        ("train", TRAIN_START, TRAIN_END),
        ("validation", VALIDATION_START, VALIDATION_END),
    ]:

        period_filter = f"""
            CAST(trading_day AS DATE)
            BETWEEN DATE '{start_date}'
            AND DATE '{end_date}'
        """

        for stage in STAGES:

            if stage == "stage1":
                stage_filter = "TRUE"
                target_column = STAGE1_TARGET
            else:
                stage_filter = (
                    f"{STAGE1_TARGET} = 'MOVE' "
                    f"AND {STAGE2_TARGET} IN ('DOWN', 'UP')"
                )
                target_column = STAGE2_TARGET

            for dataset in DATASETS:

                features = (
                    INDEX_FEATURES
                    if dataset == "index_only"
                    else INDEX_FEATURES + OPTIONS_FEATURES
                )

                output_dir = (
                        OUTPUT_ROOT / stage / dataset
                )

                output_dir.mkdir(
                    parents=True,
                    exist_ok=True,
                )

                output_file = (
                        output_dir
                        / f"{split_name}_{horizon}m.parquet"
                )

                if output_file.exists():
                    raise FileExistsError(output_file)

                selected_columns = (
                        metadata_columns + features
                )

                selected_sql = ", ".join(
                    quoted_column(c)
                    for c in selected_columns
                )

                con.execute(f"""
                    COPY (
                        SELECT
                            {selected_sql}
                        FROM matched_base
                        WHERE CAST(horizon_minutes AS INTEGER)
                              = {horizon}
                          AND {period_filter}
                          AND {stage_filter}
                    )
                    TO {sql_string(str(output_file))}
                    (
                        FORMAT PARQUET,
                        COMPRESSION ZSTD
                    )
                """)

                row_count = con.execute(f"""
                    SELECT COUNT(*)
                    FROM read_parquet(
                        {sql_string(str(output_file))}
                    )
                """).fetchone()[0]

                duplicate_count = con.execute(f"""
                    SELECT COUNT(*)
                    FROM (
                        SELECT timestamp_ist, horizon_minutes
                        FROM read_parquet(
                            {sql_string(str(output_file))}
                        )
                        GROUP BY timestamp_ist, horizon_minutes
                        HAVING COUNT(*) > 1
                    )
                """).fetchone()[0]

                null_target_count = con.execute(f"""
                    SELECT COUNT(*)
                    FROM read_parquet(
                        {sql_string(str(output_file))}
                    )
                    WHERE {quoted_column(target_column)} IS NULL
                """).fetchone()[0]

                null_feature_expression = " OR ".join(
                    f"{quoted_column(c)} IS NULL"
                    for c in features
                )

                null_feature_count = con.execute(f"""
                    SELECT COUNT(*)
                    FROM read_parquet(
                        {sql_string(str(output_file))}
                    )
                    WHERE {null_feature_expression}
                """).fetchone()[0]

                dataset_audit.append({
                    "stage": stage,
                    "dataset": dataset,
                    "split": split_name,
                    "horizon_minutes": horizon,
                    "target_column": target_column,
                    "rows": row_count,
                    "feature_count": len(features),
                    "duplicate_keys": duplicate_count,
                    "null_targets": null_target_count,
                    "null_features": null_feature_count,
                    "file": str(output_file),
                    "status": (
                        "PASS"
                        if duplicate_count == 0
                           and null_target_count == 0
                           and null_feature_count == 0
                        else "FAIL"
                    ),
                })

                print(
                    f"{stage:7s} | {dataset:16s} | "
                    f"{split_name:10s} | {horizon:2d}m | "
                    f"{row_count:,} rows"
                )


# ============================================================
# INDEX-ONLY VS OPTIONS PARITY
# ============================================================

for row in dataset_audit:

    if row["dataset"] != "index_only":
        continue

    matching = next(
        x for x in dataset_audit
        if x["stage"] == row["stage"]
        and x["split"] == row["split"]
        and x["horizon_minutes"] == row["horizon_minutes"]
        and x["dataset"] == "index_plus_options"
    )

    left_path = (
            OUTPUT_ROOT / row["stage"] / "index_only"
            / f"{row['split']}_{row['horizon_minutes']}m.parquet"
    )

    right_path = (
            OUTPUT_ROOT / row["stage"] / "index_plus_options"
            / f"{row['split']}_{row['horizon_minutes']}m.parquet"
    )

    left_sql = sql_string(str(left_path))
    right_sql = sql_string(str(right_path))

    left_count = con.execute(f"""
        SELECT COUNT(*) FROM read_parquet({left_sql})
    """).fetchone()[0]

    right_count = con.execute(f"""
        SELECT COUNT(*) FROM read_parquet({right_sql})
    """).fetchone()[0]

    key_mismatches = con.execute(f"""
        SELECT COUNT(*)
        FROM (
            (
                SELECT timestamp_ist, horizon_minutes,
                       {STAGE1_TARGET}, {STAGE2_TARGET}
                FROM read_parquet({left_sql})

                EXCEPT

                SELECT timestamp_ist, horizon_minutes,
                       {STAGE1_TARGET}, {STAGE2_TARGET}
                FROM read_parquet({right_sql})
            )

            UNION ALL

            (
                SELECT timestamp_ist, horizon_minutes,
                       {STAGE1_TARGET}, {STAGE2_TARGET}
                FROM read_parquet({right_sql})

                EXCEPT

                SELECT timestamp_ist, horizon_minutes,
                       {STAGE1_TARGET}, {STAGE2_TARGET}
                FROM read_parquet({left_sql})
            )
        )
    """).fetchone()[0]

    parity_audit.append({
        "stage": row["stage"],
        "split": row["split"],
        "horizon_minutes": row["horizon_minutes"],
        "index_only_rows": left_count,
        "index_plus_options_rows": right_count,
        "key_and_label_mismatches": key_mismatches,
        "status": (
            "PASS"
            if left_count == right_count
               and key_mismatches == 0
            else "FAIL"
        ),
    })


# ============================================================
# STAGE 2 MUST BE A STRICT MOVE SUBSET OF STAGE 1
# ============================================================

for horizon in HORIZONS:

    for split_name in ["train", "validation"]:

        stage1_path = (
                OUTPUT_ROOT / "stage1" / "index_only"
                / f"{split_name}_{horizon}m.parquet"
        )

        stage2_path = (
                OUTPUT_ROOT / "stage2" / "index_only"
                / f"{split_name}_{horizon}m.parquet"
        )

        stage1_sql = sql_string(str(stage1_path))
        stage2_sql = sql_string(str(stage2_path))

        stage1_move_count = con.execute(f"""
            SELECT COUNT(*)
            FROM read_parquet({stage1_sql})
            WHERE {STAGE1_TARGET} = 'MOVE'
        """).fetchone()[0]

        stage2_count = con.execute(f"""
            SELECT COUNT(*) FROM read_parquet({stage2_sql})
        """).fetchone()[0]

        mismatch = con.execute(f"""
            SELECT COUNT(*)
            FROM (
                SELECT timestamp_ist, horizon_minutes
                FROM read_parquet({stage1_sql})
                WHERE {STAGE1_TARGET} = 'MOVE'

                EXCEPT

                SELECT timestamp_ist, horizon_minutes
                FROM read_parquet({stage2_sql})
            )
        """).fetchone()[0]

        stage_relationship_audit.append({
            "horizon_minutes": horizon,
            "split": split_name,
            "stage1_move_rows": stage1_move_count,
            "stage2_rows": stage2_count,
            "missing_stage2_rows": mismatch,
            "status": (
                "PASS"
                if stage1_move_count == stage2_count
                   and mismatch == 0
                else "FAIL"
            ),
        })


# ============================================================
# LABEL DISTRIBUTION
# ============================================================

distribution = con.execute("""
                           SELECT
                               CAST(horizon_minutes AS INTEGER) AS horizon_minutes,

                               CASE
                                   WHEN CAST(trading_day AS DATE)
                                       <= DATE '2022-12-31'
                                       THEN 'FIT_2021_2022'

                                   WHEN CAST(trading_day AS DATE)
                                       <= DATE '2023-12-31'
                                       THEN 'EARLY_STOP_2023'

                                   ELSE 'VALIDATION_2024'
                                   END AS period,

                               COUNT(*) AS total_rows,

                               COUNT(*) FILTER (
            WHERE label_stage1_move_v1 = 'SIDEWAYS'
        ) AS sideways_rows,

                               COUNT(*) FILTER (
            WHERE label_stage1_move_v1 = 'MOVE'
        ) AS move_rows,

                               COUNT(*) FILTER (
            WHERE label_stage2_direction_v1 = 'DOWN'
        ) AS down_rows,

                               COUNT(*) FILTER (
            WHERE label_stage2_direction_v1 = 'UP'
        ) AS up_rows

                           FROM matched_base

                           GROUP BY 1, 2
                           ORDER BY 1, 2
                           """).fetchdf()

distribution["move_pct"] = (
        distribution["move_rows"]
        / distribution["total_rows"] * 100
)

distribution["sideways_pct"] = (
        distribution["sideways_rows"]
        / distribution["total_rows"] * 100
)

distribution["down_pct_of_move"] = (
        distribution["down_rows"]
        / distribution["move_rows"].replace(0, pd.NA) * 100
)

distribution["up_pct_of_move"] = (
        distribution["up_rows"]
        / distribution["move_rows"].replace(0, pd.NA) * 100
)


# ============================================================
# SAVE REPORTS
# ============================================================

audit_df = pd.DataFrame(dataset_audit)
parity_df = pd.DataFrame(parity_audit)
relationship_df = pd.DataFrame(stage_relationship_audit)

audit_df.to_csv(
    REPORT_DIR / "two_stage_dataset_audit.csv",
    index=False,
    )

parity_df.to_csv(
    REPORT_DIR / "two_stage_dataset_parity_audit.csv",
    index=False,
    )

relationship_df.to_csv(
    REPORT_DIR / "stage1_stage2_relationship_audit.csv",
    index=False,
    )

distribution.to_csv(
    REPORT_DIR / "matched_label_distribution.csv",
    index=False,
    )

manifest_rows = []

for dataset in DATASETS:
    features = (
        INDEX_FEATURES
        if dataset == "index_only"
        else INDEX_FEATURES + OPTIONS_FEATURES
    )

    for i, feature in enumerate(features, start=1):
        manifest_rows.append({
            "dataset": dataset,
            "feature_order": i,
            "feature": feature,
            "feature_group": (
                "index"
                if feature in INDEX_FEATURES
                else "options"
            ),
        })

pd.DataFrame(manifest_rows).to_csv(
    REPORT_DIR / "two_stage_feature_manifest.csv",
    index=False,
    )


# ============================================================
# FINAL SUMMARY
# ============================================================

all_checks = (
        all(x["status"] == "PASS" for x in dataset_audit)
        and all(x["status"] == "PASS" for x in parity_audit)
        and all(x["status"] == "PASS" for x in stage_relationship_audit)
)

summary = {
    "status": "PASS" if all_checks else "FAIL",
    "builder": "NIFTY_TWO_STAGE_MATCHED_DATASETS_V1",
    "input_file": str(INPUT_FILE),
    "output_root": str(OUTPUT_ROOT),
    "source_rows": int(source_rows),
    "matched_source_rows": int(matched_rows),
    "source_duplicate_keys": int(source_duplicates),
    "index_feature_count": len(INDEX_FEATURES),
    "options_feature_count": len(OPTIONS_FEATURES),
    "combined_feature_count": len(all_features),
    "stage1_target": STAGE1_TARGET,
    "stage2_target": STAGE2_TARGET,
    "stage1_samples": "All eligible matched rows",
    "stage2_samples": "Actual MOVE rows only",
    "fit_period": "2021-2022",
    "early_stop_period": "2023",
    "validation_period": "2024",
    "dataset_audit_rows": len(dataset_audit),
    "parity_checks": len(parity_audit),
    "stage_relationship_checks": len(stage_relationship_audit),
    "all_checks_pass": all_checks,
    "source_modified": False,
    "existing_v1_v3_artifacts_modified": False,
}

write_json(
    summary,
    REPORT_DIR / "two_stage_matched_dataset_summary.json",
    )

print()
print("=" * 90)
print("TWO-STAGE MATCHED DATASET BUILD SUMMARY")
print("=" * 90)

print(json.dumps(summary, indent=2))

print()
print("DATASET AUDIT")
print(audit_df.to_string(index=False))

print()
print("PARITY AUDIT")
print(parity_df.to_string(index=False))

print()
print("STAGE RELATIONSHIP AUDIT")
print(relationship_df.to_string(index=False))

print()
print("LABEL DISTRIBUTION")
print(distribution.to_string(index=False))

con.close()

if not all_checks:
    raise RuntimeError(
        "Dataset audit failed. Review reports before training."
    )

print()
print("SUCCESS: TWO-STAGE MATCHED DATASETS CREATED")
