
from __future__ import annotations

import argparse
import json
import re
import sys
from datetime import datetime
from pathlib import Path

import duckdb
import numpy as np
import pandas as pd

from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    log_loss,
    precision_score,
    recall_score,
    roc_auc_score,
)

# ============================================================
# NIFTY MARKET REGIME ANALYSIS V1
#
# Read-only:
#   - Does not modify source Parquet files.
#   - Does not modify Phase 1 models or predictions.
#   - Creates a unique timestamped report folder per run.
#
# Regimes:
#   - Trend: UP / DOWN / RANGE / WARMUP
#   - Volatility: LOW / NORMAL / HIGH / WARMUP
#   - Momentum: POSITIVE / NEGATIVE / NEUTRAL / WARMUP
#   - Time: OPENING / MORNING / AFTERNOON / CLOSING
#
# All price features use completed minute bars.
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parents[1]

DEFAULT_MERGED = (
        PROJECT_ROOT
        / "data/processed/nifty_index_options_features_v1/"
        / "nifty_index_options_features_v1.parquet"
)

DEFAULT_PREDICTIONS_DIR = (
        PROJECT_ROOT / "reports/nifty_two_stage_end_to_end_v2"
)

DEFAULT_MODELS_DIR = (
        PROJECT_ROOT / "models/nifty_two_stage_lightgbm_v1"
)

DEFAULT_REPORTS_DIR = (
        PROJECT_ROOT / "reports/nifty_market_regimes_v1"
)

START_DATE = "2021-05-24"
END_DATE = "2024-12-31"

SESSION_START = "09:15"
SESSION_END = "15:29"

HORIZONS = [5, 15, 30]
CLASSES = ["DOWN", "SIDEWAYS", "UP"]

# A trend score is a trailing 30-minute return divided by
# trailing 1-minute return volatility scaled to 30 minutes.
TREND_THRESHOLD = 0.75

# Momentum uses the trailing 5-minute return normalized by
# trailing 1-minute volatility scaled to 5 minutes.
MOMENTUM_THRESHOLD = 0.50

VOL_LOOKBACK_MINUTES = 60
VOL_HISTORY_DAYS = 20
VOL_MIN_HISTORY_DAYS = 10

# Prediction CSV aliases. Add aliases here if your existing
# prediction files use different names.
TIMESTAMP_ALIASES = [
    "timestamp_ist", "timestamp", "datetime",
    "prediction_timestamp", "bar_timestamp"
]
HORIZON_ALIASES = ["horizon_minutes", "horizon", "minutes"]
ACTUAL_ALIASES = [
    "actual_class", "actual_label", "y_true",
    "actual", "true_class", "target_class"
]
PREDICTED_ALIASES = [
    "predicted_class", "prediction", "y_pred",
    "predicted_label", "predicted", "model_prediction"
]

PROBABILITY_ALIASES = {
    "DOWN": ["p_down", "prob_down", "down_probability",
             "probability_down", "down_prob"],
    "SIDEWAYS": ["p_sideways", "prob_sideways",
                 "sideways_probability", "probability_sideways",
                 "sideways_prob"],
    "UP": ["p_up", "prob_up", "up_probability",
           "probability_up", "up_prob"],
}


def log(message: str) -> None:
    print(f"[INFO] {message}", flush=True)


def fail(message: str) -> None:
    raise RuntimeError(message)


def first_existing_column(columns, aliases):
    lookup = {str(c).lower(): c for c in columns}
    for alias in aliases:
        if alias.lower() in lookup:
            return lookup[alias.lower()]
    return None


def normalize_class(value):
    if pd.isna(value):
        return None

    value = str(value).strip().upper()

    aliases = {
        "DOWN": "DOWN",
        "BEARISH": "DOWN",
        "SELL": "DOWN",
        "0": "DOWN",
        "SIDEWAYS": "SIDEWAYS",
        "SIDEWAY": "SIDEWAYS",
        "NEUTRAL": "SIDEWAYS",
        "RANGE": "SIDEWAYS",
        "1": "SIDEWAYS",
        "UP": "UP",
        "BULLISH": "UP",
        "BUY": "UP",
        "2": "UP",
    }

    return aliases.get(value, value)


def parse_horizon_from_name(path: Path):
    text = str(path).lower()

    patterns = [
        r"(?<!\d)(5|15|30)\s*m(?!\w)",
        r"(?<!\d)(5|15|30)\s*min",
        r"horizon[_-]?(5|15|30)",
    ]

    for pattern in patterns:
        match = re.search(pattern, text)
        if match:
            return int(match.group(1))

    return None


def create_run_directory(base_dir: Path) -> Path:
    base_dir.mkdir(parents=True, exist_ok=True)

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir = base_dir / f"run_{stamp}"

    suffix = 1
    while run_dir.exists():
        run_dir = base_dir / f"run_{stamp}_{suffix}"
        suffix += 1

    run_dir.mkdir(parents=True, exist_ok=False)
    return run_dir


def load_market_data(merged_path: Path) -> pd.DataFrame:
    if not merged_path.exists():
        fail(f"Merged Parquet not found: {merged_path}")

    log(f"Reading canonical merged Parquet: {merged_path}")

    con = duckdb.connect(database=":memory:")

    # The merged dataset is long-format: one row per timestamp
    # and horizon. Use 5m rows to obtain one unique index row
    # per timestamp. OHLC values are shared across horizons.
    query = f"""
        SELECT *
        FROM read_parquet('{str(merged_path).replace("'", "''")}')
        WHERE horizon_minutes = 5
        ORDER BY timestamp_ist
    """

    try:
        df = con.execute(query).df()
    finally:
        con.close()

    if df.empty:
        fail("No 5-minute rows found in merged Parquet.")

    timestamp_col = first_existing_column(
        df.columns, ["timestamp_ist", "timestamp"]
    )
    if timestamp_col is None:
        fail(
            "Could not find timestamp_ist/timestamp in merged "
            f"dataset. Columns: {list(df.columns)}"
        )

    close_col = first_existing_column(
        df.columns, ["close", "index_close", "spot_close", "nifty_close"]
    )
    if close_col is None:
        fail(
            "Could not find NIFTY close column. "
            f"Columns: {list(df.columns)}"
        )

    open_col = first_existing_column(
        df.columns, ["open", "index_open", "spot_open", "nifty_open"]
    )
    high_col = first_existing_column(
        df.columns, ["high", "index_high", "spot_high", "nifty_high"]
    )
    low_col = first_existing_column(
        df.columns, ["low", "index_low", "spot_low", "nifty_low"]
    )

    if not all([open_col, high_col, low_col]):
        fail(
            "OHLC columns are required for regime analysis. "
            f"Detected open={open_col}, high={high_col}, low={low_col}."
        )

    df = df.rename(columns={
        timestamp_col: "timestamp_ist",
        close_col: "close",
        open_col: "open",
        high_col: "high",
        low_col: "low",
    })

    df["timestamp_ist"] = pd.to_datetime(
        df["timestamp_ist"], errors="coerce"
    )

    # DuckDB may return timezone-aware or timezone-naive timestamps.
    # If timezone-aware, convert to IST. If naive, interpret as IST.
    if df["timestamp_ist"].dt.tz is not None:
        df["timestamp_ist"] = (
            df["timestamp_ist"].dt.tz_convert("Asia/Kolkata")
        )
        df["timestamp_ist"] = (
            df["timestamp_ist"].dt.tz_localize(None)
        )

    df = df.dropna(subset=["timestamp_ist"]).copy()

    for col in ["open", "high", "low", "close"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    df = df.dropna(subset=["open", "high", "low", "close"]).copy()

    df["trading_day"] = df["timestamp_ist"].dt.date
    df["clock_time"] = df["timestamp_ist"].dt.strftime("%H:%M")

    df = df[
        (df["trading_day"] >= pd.Timestamp(START_DATE).date())
        & (df["trading_day"] <= pd.Timestamp(END_DATE).date())
        & (df["clock_time"] >= SESSION_START)
        & (df["clock_time"] <= SESSION_END)
        ].copy()

    df = df.sort_values("timestamp_ist").reset_index(drop=True)

    duplicate_count = int(
        df.duplicated(subset=["timestamp_ist"]).sum()
    )

    if duplicate_count:
        fail(
            f"Duplicate timestamp rows in 5m market data: "
            f"{duplicate_count}"
        )

    df["minute_of_session"] = (
            df["timestamp_ist"].dt.hour * 60
            + df["timestamp_ist"].dt.minute
            - (9 * 60 + 15)
    )

    # Preserve synthetic flag if available.
    synthetic_col = first_existing_column(
        df.columns, ["is_synthetic", "synthetic"]
    )

    if synthetic_col:
        df["is_synthetic"] = (
            df[synthetic_col].fillna(False).astype(bool)
        )
    else:
        df["is_synthetic"] = False

    log(
        f"Market rows={len(df):,}; "
        f"days={df['trading_day'].nunique():,}; "
        f"synthetic={int(df['is_synthetic'].sum()):,}"
    )

    return df


def add_regime_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.sort_values("timestamp_ist").copy()

    # Never let rolling calculations cross overnight boundaries.
    grouped = df.groupby("trading_day", sort=False)

    df["log_return_1m"] = grouped["close"].transform(
        lambda s: np.log(s / s.shift(1))
    )

    df["return_5m"] = grouped["close"].transform(
        lambda s: s / s.shift(5) - 1.0
    )

    df["return_30m"] = grouped["close"].transform(
        lambda s: s / s.shift(30) - 1.0
    )

    df["volatility_60m"] = grouped["log_return_1m"].transform(
        lambda s: s.rolling(
            VOL_LOOKBACK_MINUTES,
            min_periods=45
        ).std()
    ) * np.sqrt(VOL_LOOKBACK_MINUTES)

    df["volatility_30m"] = grouped["log_return_1m"].transform(
        lambda s: s.rolling(30, min_periods=25).std()
    ) * np.sqrt(30)

    df["trend_score"] = (
            df["return_30m"]
            / (df["volatility_30m"].replace(0, np.nan))
    )

    df["momentum_score"] = (
            df["return_5m"]
            / (
                    grouped["log_return_1m"].transform(
                        lambda s: s.rolling(30, min_periods=20).std()
                    ) * np.sqrt(5)
            ).replace(0, np.nan)
    )

    # Volatility regime:
    # Compare current trailing 60-minute realized volatility
    # with the same minute-of-session over the prior 20 days.
    #
    # shift(1) is critical: today's value is never included
    # in its own historical comparison threshold.
    df["vol_low_threshold"] = np.nan
    df["vol_high_threshold"] = np.nan

    for _, group in df.groupby("minute_of_session", sort=False):
        group = group.sort_values("trading_day")

        low = group["volatility_60m"].shift(1).rolling(
            VOL_HISTORY_DAYS,
            min_periods=VOL_MIN_HISTORY_DAYS
        ).quantile(0.33)

        high = group["volatility_60m"].shift(1).rolling(
            VOL_HISTORY_DAYS,
            min_periods=VOL_MIN_HISTORY_DAYS
        ).quantile(0.67)

        df.loc[group.index, "vol_low_threshold"] = low.to_numpy()
        df.loc[group.index, "vol_high_threshold"] = high.to_numpy()

    # Regime classifications.
    df["trend_regime"] = "WARMUP"
    valid = df["trend_score"].notna()

    df.loc[
        valid & (df["trend_score"] >= TREND_THRESHOLD),
        "trend_regime"
    ] = "UP"

    df.loc[
        valid & (df["trend_score"] <= -TREND_THRESHOLD),
        "trend_regime"
    ] = "DOWN"

    df.loc[
        valid
        & (df["trend_score"] > -TREND_THRESHOLD)
        & (df["trend_score"] < TREND_THRESHOLD),
        "trend_regime"
    ] = "RANGE"

    df["momentum_regime"] = "WARMUP"
    valid = df["momentum_score"].notna()

    df.loc[
        valid & (df["momentum_score"] >= MOMENTUM_THRESHOLD),
        "momentum_regime"
    ] = "POSITIVE"

    df.loc[
        valid & (df["momentum_score"] <= -MOMENTUM_THRESHOLD),
        "momentum_regime"
    ] = "NEGATIVE"

    df.loc[
        valid
        & (df["momentum_score"] > -MOMENTUM_THRESHOLD)
        & (df["momentum_score"] < MOMENTUM_THRESHOLD),
        "momentum_regime"
    ] = "NEUTRAL"

    df["volatility_regime"] = "WARMUP"

    vol_valid = (
            df["volatility_60m"].notna()
            & df["vol_low_threshold"].notna()
            & df["vol_high_threshold"].notna()
    )

    df.loc[
        vol_valid
        & (df["volatility_60m"] < df["vol_low_threshold"]),
        "volatility_regime"
    ] = "LOW"

    df.loc[
        vol_valid
        & (df["volatility_60m"] >= df["vol_low_threshold"])
        & (df["volatility_60m"] <= df["vol_high_threshold"]),
        "volatility_regime"
    ] = "NORMAL"

    df.loc[
        vol_valid
        & (df["volatility_60m"] > df["vol_high_threshold"]),
        "volatility_regime"
    ] = "HIGH"

    # Session segments, based on timestamp of the completed bar.
    minute = df["minute_of_session"]

    df["time_regime"] = np.select(
        [
            minute < 45,
            (minute >= 45) & (minute < 135),
            (minute >= 135) & (minute < 285),
            minute >= 285,
            ],
        [
            "OPENING",
            "MORNING",
            "AFTERNOON",
            "CLOSING",
        ],
        default="UNKNOWN"
    )

    df["combined_regime"] = (
            df["trend_regime"].astype(str) + "_"
            + df["volatility_regime"].astype(str) + "_"
            + df["momentum_regime"].astype(str) + "_"
            + df["time_regime"].astype(str)
    )

    # Prediction decision time is after the source minute bar ends.
    df["decision_time_ist"] = (
            df["timestamp_ist"] + pd.Timedelta(minutes=1)
    )

    return df


def discover_prediction_files(predictions_dir: Path):
    if not predictions_dir.exists():
        return []

    files = sorted(predictions_dir.rglob("*.csv"))

    selected = []
    for path in files:
        name = path.name.lower()

        # Exclude aggregate metrics/audit files.
        if any(token in name for token in [
            "comparison", "summary", "audit", "sensitivity",
            "threshold", "confusion", "classification",
            "feature_importance"
        ]):
            continue

        if "predict" in name or "end_to_end" in str(path).lower():
            selected.append(path)

    return selected


def discover_column(df, aliases):
    return first_existing_column(df.columns, aliases)


def load_prediction_file(path: Path):
    df = pd.read_csv(path)

    timestamp_col = discover_column(df, TIMESTAMP_ALIASES)
    actual_col = discover_column(df, ACTUAL_ALIASES)
    predicted_col = discover_column(df, PREDICTED_ALIASES)
    horizon_col = discover_column(df, HORIZON_ALIASES)

    if timestamp_col is None or actual_col is None:
        fail(
            f"Prediction file schema not recognized: {path}\n"
            f"Columns: {list(df.columns)}\n"
            "Required: timestamp and actual class."
        )

    if predicted_col is None:
        # If probability columns exist, use their argmax.
        prob_cols = {}
        for label, aliases in PROBABILITY_ALIASES.items():
            col = discover_column(df, aliases)
            if col:
                prob_cols[label] = col

        if len(prob_cols) == 3:
            values = df[
                [prob_cols["DOWN"], prob_cols["SIDEWAYS"],
                 prob_cols["UP"]]
            ].apply(pd.to_numeric, errors="coerce")

            df["__predicted_class"] = (
                values.idxmax(axis=1)
                .map({
                    prob_cols["DOWN"]: "DOWN",
                    prob_cols["SIDEWAYS"]: "SIDEWAYS",
                    prob_cols["UP"]: "UP",
                })
            )
            predicted_col = "__predicted_class"
        else:
            fail(
                f"No predicted class or complete probability triplet "
                f"found in {path}. Columns: {list(df.columns)}"
            )

    df["timestamp_ist"] = pd.to_datetime(
        df[timestamp_col], errors="coerce"
    )

    if df["timestamp_ist"].dt.tz is not None:
        df["timestamp_ist"] = (
            df["timestamp_ist"].dt.tz_convert("Asia/Kolkata")
            .dt.tz_localize(None)
        )

    df["actual_class"] = df[actual_col].map(normalize_class)
    df["predicted_class"] = df[predicted_col].map(normalize_class)

    if horizon_col:
        df["horizon_minutes"] = pd.to_numeric(
            df[horizon_col], errors="coerce"
        )
    else:
        horizon = parse_horizon_from_name(path)
        if horizon is None:
            fail(
                f"Cannot determine horizon for {path}. "
                "Add horizon_minutes column or include 5m/15m/30m "
                "in the filename."
            )
        df["horizon_minutes"] = horizon

    # Find probability columns, if present.
    for label, aliases in PROBABILITY_ALIASES.items():
        col = discover_column(df, aliases)
        if col:
            df[f"p_{label.lower()}"] = pd.to_numeric(
                df[col], errors="coerce"
            )

    # Stage 2 probability names can be mapped into the final
    # end-to-end class probabilities if those are provided.
    # We deliberately do not reconstruct probabilities here.
    # The input should be the end-to-end prediction output.

    df["model_name"] = path.stem
    df["prediction_file"] = str(path)

    df = df.dropna(
        subset=[
            "timestamp_ist", "horizon_minutes",
            "actual_class", "predicted_class"
        ]
    ).copy()

    df["horizon_minutes"] = df["horizon_minutes"].astype(int)

    df = df[
        df["horizon_minutes"].isin(HORIZONS)
        & df["actual_class"].isin(CLASSES)
        & df["predicted_class"].isin(CLASSES)
        ].copy()

    return df


def load_all_predictions(predictions_dir: Path, explicit_files=None):
    files = explicit_files or discover_prediction_files(predictions_dir)

    if not files:
        fail(
            f"No prediction CSV files discovered under {predictions_dir}.\n"
            "Use --prediction-files with the six end-to-end prediction "
            "CSV paths. Do not use Stage 2 conditional-only predictions "
            "as end-to-end three-class predictions."
        )

    frames = []
    for path in files:
        log(f"Loading predictions: {path}")
        frames.append(load_prediction_file(path))

    predictions = pd.concat(frames, ignore_index=True)

    key = ["model_name", "timestamp_ist", "horizon_minutes"]
    duplicates = int(predictions.duplicated(key).sum())

    if duplicates:
        fail(
            f"Duplicate prediction keys detected: {duplicates}. "
            "Check whether the same prediction file was discovered twice."
        )

    return predictions


def add_probabilistic_metrics(group):
    result = {}

    prob_cols = ["p_down", "p_sideways", "p_up"]

    if not all(col in group.columns for col in prob_cols):
        return result

    probs = group[prob_cols].apply(pd.to_numeric, errors="coerce")
    valid = probs.notna().all(axis=1)

    if valid.sum() == 0:
        return result

    probs = probs.loc[valid].to_numpy()
    actual = group.loc[valid, "actual_class"]

    # Normalize only for floating-point drift; reject invalid rows.
    row_sums = probs.sum(axis=1)
    valid_sum = (
            np.isfinite(probs).all(axis=1)
            & (probs >= 0).all(axis=1)
            & (row_sums > 0)
    )

    probs = probs[valid_sum]
    actual = actual.iloc[np.where(valid_sum)[0]]

    if len(actual) == 0:
        return result

    probs = probs / probs.sum(axis=1, keepdims=True)

    mapping = {"DOWN": 0, "SIDEWAYS": 1, "UP": 2}
    y = actual.map(mapping).to_numpy()

    result["probability_rows"] = int(len(y))
    result["log_loss"] = float(
        log_loss(y, probs, labels=[0, 1, 2])
    )

    try:
        result["macro_roc_auc_ovr"] = float(
            roc_auc_score(
                y, probs, multi_class="ovr", average="macro",
                labels=[0, 1, 2]
            )
        )
    except Exception:
        result["macro_roc_auc_ovr"] = None

    one_hot = np.eye(3)[y]
    result["multiclass_brier_score"] = float(
        np.mean(np.sum((probs - one_hot) ** 2, axis=1))
    )

    return result


def calculate_metrics(group, regime_name, regime_value):
    y_true = group["actual_class"]
    y_pred = group["predicted_class"]

    result = {
        "model_name": group["model_name"].iloc[0],
        "horizon_minutes": int(group["horizon_minutes"].iloc[0]),
        "regime_dimension": regime_name,
        "regime": regime_value,
        "rows": int(len(group)),
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "balanced_accuracy": float(
            balanced_accuracy_score(y_true, y_pred)
        ),
        "macro_f1": float(
            f1_score(
                y_true, y_pred, labels=CLASSES,
                average="macro", zero_division=0
            )
        ),
        "weighted_f1": float(
            f1_score(
                y_true, y_pred, labels=CLASSES,
                average="weighted", zero_division=0
            )
        ),
        "macro_precision": float(
            precision_score(
                y_true, y_pred, labels=CLASSES,
                average="macro", zero_division=0
            )
        ),
        "macro_recall": float(
            recall_score(
                y_true, y_pred, labels=CLASSES,
                average="macro", zero_division=0
            )
        ),
        "down_recall": float(
            recall_score(
                y_true, y_pred, labels=CLASSES,
                average=None, zero_division=0
            )[0]
        ),
        "sideways_recall": float(
            recall_score(
                y_true, y_pred, labels=CLASSES,
                average=None, zero_division=0
            )[1]
        ),
        "up_recall": float(
            recall_score(
                y_true, y_pred, labels=CLASSES,
                average=None, zero_division=0
            )[2]
        ),
        "predicted_down_pct": float(
            (y_pred == "DOWN").mean() * 100
        ),
        "predicted_sideways_pct": float(
            (y_pred == "SIDEWAYS").mean() * 100
        ),
        "predicted_up_pct": float(
            (y_pred == "UP").mean() * 100
        ),
    }

    result.update(add_probabilistic_metrics(group))
    return result


def evaluate_predictions(predictions, market, output_dir):
    regime_cols = [
        "trend_regime",
        "volatility_regime",
        "momentum_regime",
        "time_regime",
        "combined_regime",
    ]

    market_cols = [
        "timestamp_ist",
        "trading_day",
        "decision_time_ist",
        "trend_score",
        "momentum_score",
        "volatility_60m",
        "trend_regime",
        "volatility_regime",
        "momentum_regime",
        "time_regime",
        "combined_regime",
        "is_synthetic",
    ]

    joined = predictions.merge(
        market[market_cols],
        on="timestamp_ist",
        how="left",
        validate="many_to_one"
    )

    unmatched = int(joined["trend_regime"].isna().sum())

    # Do not evaluate predictions that cannot be aligned to a
    # valid market timestamp.
    joined = joined.dropna(subset=["trend_regime"]).copy()

    # Synthetic rows are excluded from regime performance.
    joined = joined[~joined["is_synthetic"]].copy()

    all_metrics = []

    for (model_name, horizon), model_group in joined.groupby(
            ["model_name", "horizon_minutes"]
    ):
        for regime_col in regime_cols:
            for regime_value, group in model_group.groupby(
                    regime_col, dropna=False
            ):
                if len(group) == 0:
                    continue

                metric = calculate_metrics(
                    group, regime_col, str(regime_value)
                )
                all_metrics.append(metric)

    metrics_df = pd.DataFrame(all_metrics)

    metrics_df.to_csv(
        output_dir / "regime_performance_metrics.csv",
        index=False
    )

    joined.to_csv(
        output_dir / "prediction_regime_alignment.csv",
        index=False
    )

    # Confusion matrices by model/horizon/regime dimension.
    confusion_rows = []

    for (model_name, horizon, regime), group in joined.groupby(
            ["model_name", "horizon_minutes", "trend_regime"]
    ):
        matrix = confusion_matrix(
            group["actual_class"],
            group["predicted_class"],
            labels=CLASSES
        )

        for i, actual in enumerate(CLASSES):
            for j, predicted in enumerate(CLASSES):
                confusion_rows.append({
                    "model_name": model_name,
                    "horizon_minutes": int(horizon),
                    "trend_regime": regime,
                    "actual_class": actual,
                    "predicted_class": predicted,
                    "count": int(matrix[i, j]),
                })

    pd.DataFrame(confusion_rows).to_csv(
        output_dir / "trend_regime_confusion_matrices.csv",
        index=False
    )

    # Sample counts and actual/predicted class distribution.
    distribution_rows = []

    for (model_name, horizon), group in joined.groupby(
            ["model_name", "horizon_minutes"]
    ):
        for regime_col in regime_cols:
            for regime_value, regime_group in group.groupby(regime_col):
                row = {
                    "model_name": model_name,
                    "horizon_minutes": int(horizon),
                    "regime_dimension": regime_col,
                    "regime": str(regime_value),
                    "rows": int(len(regime_group)),
                }

                for label in CLASSES:
                    row[f"actual_{label.lower()}_pct"] = float(
                        (regime_group["actual_class"] == label).mean()
                        * 100
                    )
                    row[f"predicted_{label.lower()}_pct"] = float(
                        (regime_group["predicted_class"] == label).mean()
                        * 100
                    )

                distribution_rows.append(row)

    pd.DataFrame(distribution_rows).to_csv(
        output_dir / "regime_class_distributions.csv",
        index=False
    )

    return joined, metrics_df, unmatched


def build_regime_summary(market, predictions, joined, metrics, unmatched):
    return {
        "project": "NIFTY_PHASE_2_1_MARKET_REGIME_ANALYSIS_V1",
        "status": "COMPLETED",
        "generated_at": datetime.now().isoformat(),
        "scope": {
            "start_date": START_DATE,
            "end_date": END_DATE,
            "session_start_ist": SESSION_START,
            "session_end_ist": SESSION_END,
            "horizons_minutes": HORIZONS,
            "classes": CLASSES,
        },
        "input": {
            "market_rows": int(len(market)),
            "market_days": int(market["trading_day"].nunique()),
            "prediction_rows": int(len(predictions)),
            "prediction_files": sorted(
                predictions["prediction_file"].unique().tolist()
            ),
            "model_names": sorted(
                predictions["model_name"].unique().tolist()
            ),
        },
        "alignment": {
            "unmatched_prediction_rows": int(unmatched),
            "matched_prediction_rows": int(len(joined)),
            "synthetic_prediction_rows_excluded": int(
                predictions.merge(
                    market[["timestamp_ist", "is_synthetic"]],
                    on="timestamp_ist",
                    how="left"
                )["is_synthetic"].fillna(False).sum()
            ),
        },
        "regime_definitions": {
            "trend": {
                "method": "trailing 30m return / trailing 30m realized volatility",
                "up_threshold": TREND_THRESHOLD,
                "down_threshold": -TREND_THRESHOLD,
            },
            "momentum": {
                "method": "trailing 5m return / trailing 30m 1m volatility scaled to 5m",
                "positive_threshold": MOMENTUM_THRESHOLD,
                "negative_threshold": -MOMENTUM_THRESHOLD,
            },
            "volatility": {
                "method": "trailing 60m realized volatility compared with same minute-of-session historical quantiles",
                "lookback_days": VOL_HISTORY_DAYS,
                "minimum_history_days": VOL_MIN_HISTORY_DAYS,
                "quantiles": [0.33, 0.67],
                "history_shifted_by_one_session": True,
            },
            "time_of_day": {
                "opening": "09:15–09:59",
                "morning": "10:00–11:29",
                "afternoon": "11:30–13:59",
                "closing": "14:00–15:29",
            },
        },
        "regime_counts": {
            col: {
                str(k): int(v)
                for k, v in market[col].value_counts(dropna=False).items()
            }
            for col in [
                "trend_regime", "volatility_regime",
                "momentum_regime", "time_regime"
            ]
        },
        "metric_rows": int(len(metrics)),
        "notes": [
            "Regime features are calculated from completed index bars only.",
            "Intraday rolling calculations reset at each trading day.",
            "Volatility thresholds use prior sessions at the same minute of session.",
            "Warmup regimes are retained and reported separately.",
            "2024 remains diagnostic validation, not an untouched final test.",
            "This analysis measures prediction quality, not trading profitability.",
            "No bid/ask or execution-cost assumptions are used.",
        ],
    }


def build_audit(market, predictions, joined, unmatched):
    checks = []

    def add(name, passed, observed, expected):
        checks.append({
            "check": name,
            "status": "PASS" if passed else "FAIL",
            "observed": observed,
            "expected": expected,
        })

    add(
        "unique_market_timestamps",
        not market["timestamp_ist"].duplicated().any(),
        int(market["timestamp_ist"].duplicated().sum()),
        0
    )

    add(
        "market_rows_inside_regular_session",
        bool(
            (
                    (market["clock_time"] >= SESSION_START)
                    & (market["clock_time"] <= SESSION_END)
            ).all()
        ),
        "all rows checked",
        "09:15–15:29 IST"
    )

    add(
        "prediction_keys_unique",
        not predictions.duplicated(
            ["model_name", "timestamp_ist", "horizon_minutes"]
        ).any(),
        int(predictions.duplicated(
            ["model_name", "timestamp_ist", "horizon_minutes"]
        ).sum()),
        0
    )

    add(
        "unmatched_predictions",
        unmatched == 0,
        int(unmatched),
        0
    )

    add(
        "synthetic_rows_excluded",
        not joined["is_synthetic"].any(),
        int(joined["is_synthetic"].sum()),
        0
    )

    add(
        "valid_horizons",
        bool(predictions["horizon_minutes"].isin(HORIZONS).all()),
        sorted(predictions["horizon_minutes"].unique().tolist()),
        HORIZONS
    )

    add(
        "valid_actual_classes",
        bool(predictions["actual_class"].isin(CLASSES).all()),
        sorted(predictions["actual_class"].dropna().unique().tolist()),
        CLASSES
    )

    add(
        "valid_predicted_classes",
        bool(predictions["predicted_class"].isin(CLASSES).all()),
        sorted(predictions["predicted_class"].dropna().unique().tolist()),
        CLASSES
    )

    # A basic guard: no trend/momentum feature should be available
    # on the first bars of a day.
    first_bars = market.groupby("trading_day", sort=False).head(1)

    first_bar_warmup = bool(
        (first_bars["trend_regime"] == "WARMUP").all()
        and (first_bars["momentum_regime"] == "WARMUP").all()
    )

    add(
        "intraday_feature_warmup",
        first_bar_warmup,
        first_bar_warmup,
        True
    )

    # Verify historical volatility thresholds are only populated
    # when both historical thresholds exist.
    vol_non_warmup = market["volatility_regime"] != "WARMUP"

    vol_thresholds_valid = bool(
        (
                market.loc[vol_non_warmup, "vol_low_threshold"].notna()
                & market.loc[vol_non_warmup, "vol_high_threshold"].notna()
        ).all()
    )

    add(
        "volatility_threshold_history_available",
        vol_thresholds_valid,
        vol_thresholds_valid,
        True
    )

    return pd.DataFrame(checks)


def inventory_models(models_dir: Path, output_dir: Path):
    rows = []

    if models_dir.exists():
        for path in sorted(models_dir.rglob("*")):
            if path.is_file():
                rows.append({
                    "relative_path": str(path.relative_to(models_dir)),
                    "file_name": path.name,
                    "size_bytes": path.stat().st_size,
                    "modified_at": datetime.fromtimestamp(
                        path.stat().st_mtime
                    ).isoformat(),
                })

    inventory = pd.DataFrame(rows)
    inventory.to_csv(
        output_dir / "phase1_model_inventory.csv",
        index=False
    )

    return inventory


def main():
    parser = argparse.ArgumentParser(
        description="NIFTY Phase 2.1 market regime analysis"
    )

    parser.add_argument(
        "--merged",
        type=Path,
        default=DEFAULT_MERGED
    )

    parser.add_argument(
        "--predictions-dir",
        type=Path,
        default=DEFAULT_PREDICTIONS_DIR
    )

    parser.add_argument(
        "--models-dir",
        type=Path,
        default=DEFAULT_MODELS_DIR
    )

    parser.add_argument(
        "--reports-dir",
        type=Path,
        default=DEFAULT_REPORTS_DIR
    )

    parser.add_argument(
        "--prediction-files",
        nargs="*",
        type=Path,
        default=None,
        help="Explicit end-to-end prediction CSV files."
    )

    args = parser.parse_args()

    run_dir = create_run_directory(args.reports_dir)

    log(f"Output directory: {run_dir}")

    market = load_market_data(args.merged)
    market = add_regime_features(market)

    market.to_csv(
        run_dir / "market_regime_features.csv",
        index=False
    )

    predictions = load_all_predictions(
        args.predictions_dir,
        explicit_files=args.prediction_files
    )

    joined, metrics, unmatched = evaluate_predictions(
        predictions, market, run_dir
    )

    model_inventory = inventory_models(
        args.models_dir, run_dir
    )

    audit = build_audit(
        market, predictions, joined, unmatched
    )

    audit.to_csv(
        run_dir / "regime_analysis_audit.csv",
        index=False
    )

    summary = build_regime_summary(
        market, predictions, joined, metrics, unmatched
    )

    summary["model_inventory_files"] = int(len(model_inventory))
    summary["audit_passed"] = int(
        (audit["status"] == "PASS").sum()
    )
    summary["audit_failed"] = int(
        (audit["status"] == "FAIL").sum()
    )
    summary["overall_status"] = (
        "PASS"
        if summary["audit_failed"] == 0
        else "FAIL"
    )

    with open(
            run_dir / "regime_analysis_summary.json",
            "w",
            encoding="utf-8"
    ) as f:
        json.dump(summary, f, indent=2, default=str)

    log("=" * 70)
    log("NIFTY MARKET REGIME ANALYSIS COMPLETE")
    log(f"Status: {summary['overall_status']}")
    log(f"Market rows: {len(market):,}")
    log(f"Prediction rows aligned: {len(joined):,}")
    log(f"Metric rows: {len(metrics):,}")
    log(f"Audit PASS: {summary['audit_passed']}")
    log(f"Audit FAIL: {summary['audit_failed']}")
    log(f"Output: {run_dir}")
    log("=" * 70)

    if summary["audit_failed"] > 0:
        print(
            audit[audit["status"] == "FAIL"].to_string(index=False)
        )
        sys.exit(2)


if __name__ == "__main__":
    main()
