
from pathlib import Path
import json
import warnings

import numpy as np
import pandas as pd

from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    log_loss,
    precision_recall_fscore_support,
    roc_auc_score,
)

warnings.filterwarnings("ignore")

# ============================================================
# CONFIGURATION
# ============================================================

ROOT = Path(__file__).resolve().parent.parent

INPUT_ROOT = (
        ROOT
        / "reports"
        / "nifty_lightgbm_quantile_v3"
)

OUTPUT_DIR = (
        ROOT
        / "reports"
        / "nifty_monthly_robustness_v1"
)

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

DATASETS = ["index_only", "index_plus_options"]
HORIZONS = [5, 15, 30]

CLASSES = ["DOWN", "SIDEWAYS", "UP"]

PROBABILITY_COLUMNS = [
    "prob_down",
    "prob_sideways",
    "prob_up",
]

CONFIDENCE_BUCKETS = [
    0.0,
    0.40,
    0.50,
    0.60,
    0.70,
    1.000001,
]

CONFIDENCE_LABELS = [
    "<=0.40",
    "0.40-0.50",
    "0.50-0.60",
    "0.60-0.70",
    ">=0.70",
]

REQUIRED_PREDICTION_COLUMNS = [
    "timestamp_ist",
    "trading_day",
    "horizon_minutes",
    "actual_class",
    "predicted_class",
    "prob_down",
    "prob_sideways",
    "prob_up",
    "confidence",
]


# ============================================================
# HELPERS
# ============================================================

def json_safe(value):
    if isinstance(value, dict):
        return {str(k): json_safe(v) for k, v in value.items()}

    if isinstance(value, list):
        return [json_safe(v) for v in value]

    if isinstance(value, (np.integer,)):
        return int(value)

    if isinstance(value, (np.floating,)):
        if not np.isfinite(value):
            return None
        return float(value)

    if isinstance(value, (np.bool_,)):
        return bool(value)

    if pd.isna(value):
        return None

    return value


def write_csv(df, filename):
    path = OUTPUT_DIR / filename
    df.to_csv(path, index=False)
    print(f"Generated: {path}")


def write_json(data, filename):
    path = OUTPUT_DIR / filename

    with open(path, "w", encoding="utf-8") as f:
        json.dump(
            json_safe(data),
            f,
            indent=2,
            allow_nan=False,
        )

    print(f"Generated: {path}")


def validate_prediction_file(df, dataset, horizon):
    missing = [
        c for c in REQUIRED_PREDICTION_COLUMNS
        if c not in df.columns
    ]

    if missing:
        raise ValueError(
            f"{dataset} {horizon}m missing columns: {missing}"
        )

    df = df.copy()

    df["timestamp_ist"] = pd.to_datetime(
        df["timestamp_ist"],
        errors="coerce",
    )

    df["trading_day"] = pd.to_datetime(
        df["trading_day"],
        errors="coerce",
    ).dt.date

    df["actual_class"] = (
        df["actual_class"].astype(str).str.upper()
    )

    df["predicted_class"] = (
        df["predicted_class"].astype(str).str.upper()
    )

    for col in PROBABILITY_COLUMNS + ["confidence"]:
        df[col] = pd.to_numeric(
            df[col],
            errors="coerce",
        )

    if df["timestamp_ist"].isna().any():
        raise ValueError(
            f"Invalid timestamps in {dataset} {horizon}m"
        )

    if df["trading_day"].isna().any():
        raise ValueError(
            f"Invalid trading_day in {dataset} {horizon}m"
        )

    if not set(df["actual_class"].unique()).issubset(CLASSES):
        raise ValueError(
            f"Unexpected actual classes in {dataset} {horizon}m"
        )

    if not set(df["predicted_class"].unique()).issubset(CLASSES):
        raise ValueError(
            f"Unexpected predicted classes in {dataset} {horizon}m"
        )

    if df["timestamp_ist"].duplicated().any():
        raise ValueError(
            f"Duplicate timestamps in {dataset} {horizon}m"
        )

    if df[PROBABILITY_COLUMNS].isna().any().any():
        raise ValueError(
            f"Missing probabilities in {dataset} {horizon}m"
        )

    probabilities = df[PROBABILITY_COLUMNS].to_numpy()

    if not np.isfinite(probabilities).all():
        raise ValueError(
            f"Non-finite probabilities in {dataset} {horizon}m"
        )

    if (probabilities < 0).any() or (probabilities > 1).any():
        raise ValueError(
            f"Probability outside [0,1] in {dataset} {horizon}m"
        )

    probability_sums = probabilities.sum(axis=1)

    if not np.allclose(
            probability_sums,
            1.0,
            atol=1e-4,
    ):
        raise ValueError(
            f"Probability sums do not equal 1 in {dataset} {horizon}m"
        )

    # Recalculate confidence from the three probabilities.
    # This allows us to detect any inconsistent stored confidence.
    calculated_confidence = probabilities.max(axis=1)

    confidence_difference = np.abs(
        calculated_confidence - df["confidence"].to_numpy()
    )

    if np.nanmax(confidence_difference) > 1e-4:
        print(
            f"WARNING: Stored confidence differs from max probability "
            f"for {dataset} {horizon}m. Using recalculated confidence."
        )

    df["confidence"] = calculated_confidence

    df["month"] = pd.to_datetime(
        df["trading_day"].astype(str)
    ).dt.to_period("M").astype(str)

    df["dataset"] = dataset
    df["horizon_minutes"] = horizon

    return df


def calculate_metrics(df):
    if len(df) == 0:
        return {
            "support": 0,
            "accuracy": None,
            "balanced_accuracy": None,
            "macro_f1": None,
            "weighted_f1": None,
            "log_loss": None,
            "multiclass_brier_score": None,
            "macro_roc_auc_ovr": None,
        }

    y_true = df["actual_class"].to_numpy()
    y_pred = df["predicted_class"].to_numpy()

    probabilities = df[
        PROBABILITY_COLUMNS
    ].to_numpy()

    actual_numeric = pd.Categorical(
        y_true,
        categories=CLASSES,
    ).codes

    result = {
        "support": len(df),
        "accuracy": accuracy_score(y_true, y_pred),
        "balanced_accuracy": balanced_accuracy_score(
            y_true,
            y_pred,
        ),
        "macro_f1": f1_score(
            y_true,
            y_pred,
            labels=CLASSES,
            average="macro",
            zero_division=0,
        ),
        "weighted_f1": f1_score(
            y_true,
            y_pred,
            labels=CLASSES,
            average="weighted",
            zero_division=0,
        ),
        "log_loss": log_loss(
            y_true,
            probabilities,
            labels=CLASSES,
        ),
        "multiclass_brier_score": float(
            np.mean(
                np.sum(
                    (
                            probabilities
                            - np.eye(3)[actual_numeric]
                    ) ** 2,
                    axis=1,
                    )
            )
        ),
    }

    try:
        result["macro_roc_auc_ovr"] = roc_auc_score(
            y_true,
            probabilities,
            labels=CLASSES,
            multi_class="ovr",
            average="macro",
        )
    except Exception:
        result["macro_roc_auc_ovr"] = None

    return result


# ============================================================
# LOAD ALL SIX PREDICTION FILES
# ============================================================

print("=" * 90)
print("NIFTY MONTHLY ROBUSTNESS AUDIT V1")
print("=" * 90)

prediction_frames = {}
importance_frames = {}

load_audit = []

for dataset in DATASETS:
    for horizon in HORIZONS:

        model_dir = INPUT_ROOT / dataset

        prediction_path = (
                model_dir
                / f"validation_predictions_{horizon}m.csv"
        )

        importance_path = (
                model_dir
                / f"feature_importance_{horizon}m.csv"
        )

        if not prediction_path.exists():
            raise FileNotFoundError(
                f"Missing prediction file: {prediction_path}"
            )

        df = pd.read_csv(prediction_path)

        df = validate_prediction_file(
            df,
            dataset,
            horizon,
        )

        prediction_frames[(dataset, horizon)] = df

        load_audit.append({
            "dataset": dataset,
            "horizon_minutes": horizon,
            "prediction_file": str(prediction_path),
            "rows": len(df),
            "unique_timestamps": df["timestamp_ist"].nunique(),
            "first_trading_day": str(df["trading_day"].min()),
            "last_trading_day": str(df["trading_day"].max()),
            "status": "PASS",
        })

        if importance_path.exists():
            importance = pd.read_csv(importance_path)

            required_importance = [
                "feature",
                "importance_gain",
                "importance_split",
            ]

            missing = [
                c for c in required_importance
                if c not in importance.columns
            ]

            if missing:
                raise ValueError(
                    f"{importance_path} missing columns: {missing}"
                )

            importance["dataset"] = dataset
            importance["horizon_minutes"] = horizon

            importance_frames[(dataset, horizon)] = importance

        else:
            print(
                f"WARNING: Feature importance file missing: "
                f"{importance_path}"
            )


write_csv(
    pd.DataFrame(load_audit),
    "input_file_audit.csv",
)


# ============================================================
# 1. MONTHLY MODEL METRICS
# ============================================================

monthly_metrics = []
monthly_class_metrics = []
monthly_confusion = []

for (dataset, horizon), df in prediction_frames.items():

    for month, group in df.groupby("month"):

        metrics = calculate_metrics(group)

        monthly_metrics.append({
            "dataset": dataset,
            "horizon_minutes": horizon,
            "month": month,
            **metrics,
        })

        y_true = group["actual_class"]
        y_pred = group["predicted_class"]

        precision, recall, f1, support = (
            precision_recall_fscore_support(
                y_true,
                y_pred,
                labels=CLASSES,
                zero_division=0,
            )
        )

        for i, class_name in enumerate(CLASSES):
            monthly_class_metrics.append({
                "dataset": dataset,
                "horizon_minutes": horizon,
                "month": month,
                "class": class_name,
                "precision": precision[i],
                "recall": recall[i],
                "f1": f1[i],
                "support": support[i],
            })

        matrix = confusion_matrix(
            y_true,
            y_pred,
            labels=CLASSES,
        )

        for actual_idx, actual_class in enumerate(CLASSES):
            for predicted_idx, predicted_class in enumerate(CLASSES):

                monthly_confusion.append({
                    "dataset": dataset,
                    "horizon_minutes": horizon,
                    "month": month,
                    "actual_class": actual_class,
                    "predicted_class": predicted_class,
                    "count": int(
                        matrix[actual_idx, predicted_idx]
                    ),
                })


monthly_metrics_df = pd.DataFrame(monthly_metrics)
monthly_class_df = pd.DataFrame(monthly_class_metrics)
monthly_confusion_df = pd.DataFrame(monthly_confusion)

write_csv(
    monthly_metrics_df,
    "monthly_model_metrics.csv",
)

write_csv(
    monthly_class_df,
    "monthly_class_metrics.csv",
)

write_csv(
    monthly_confusion_df,
    "monthly_confusion_matrices.csv",
)


# ============================================================
# 2. MONTHLY OPTIONS VS INDEX-ONLY COMPARISON
# ============================================================

paired_comparison = []
paired_alignment_audit = []

for horizon in HORIZONS:

    index_df = prediction_frames[
        ("index_only", horizon)
    ].copy()

    options_df = prediction_frames[
        ("index_plus_options", horizon)
    ].copy()

    index_keys = set(index_df["timestamp_ist"])
    options_keys = set(options_df["timestamp_ist"])

    same_keys = index_keys == options_keys

    merged = index_df.merge(
        options_df,
        on="timestamp_ist",
        how="outer",
        suffixes=("_index", "_options"),
        indicator=True,
    )

    unmatched = int(
        (merged["_merge"] != "both").sum()
    )

    both = merged[
        merged["_merge"] == "both"
        ].copy()

    actual_mismatch = int(
        (
                both["actual_class_index"]
                != both["actual_class_options"]
        ).sum()
    )

    month_mismatch = int(
        (
                both["month_index"]
                != both["month_options"]
        ).sum()
    )

    paired_alignment_audit.append({
        "horizon_minutes": horizon,
        "index_rows": len(index_df),
        "options_rows": len(options_df),
        "common_rows": len(both),
        "unmatched_rows": unmatched,
        "actual_label_mismatches": actual_mismatch,
        "month_mismatches": month_mismatch,
        "identical_timestamp_sets": same_keys,
        "status": (
            "PASS"
            if same_keys
               and unmatched == 0
               and actual_mismatch == 0
               and month_mismatch == 0
            else "FAIL"
        ),
    })

    if not same_keys or unmatched > 0:
        raise ValueError(
            f"Timestamp mismatch between index-only and options "
            f"predictions for {horizon}m"
        )

    if actual_mismatch > 0 or month_mismatch > 0:
        raise ValueError(
            f"Actual target/month mismatch for {horizon}m"
        )

    for month, group in both.groupby("month_index"):

        index_group = pd.DataFrame({
            "actual_class": group["actual_class_index"],
            "predicted_class": group["predicted_class_index"],
            "prob_down": group["prob_down_index"],
            "prob_sideways": group["prob_sideways_index"],
            "prob_up": group["prob_up_index"],
        })

        options_group = pd.DataFrame({
            "actual_class": group["actual_class_options"],
            "predicted_class": group["predicted_class_options"],
            "prob_down": group["prob_down_options"],
            "prob_sideways": group["prob_sideways_options"],
            "prob_up": group["prob_up_options"],
        })

        index_metrics = calculate_metrics(index_group)
        options_metrics = calculate_metrics(options_group)

        paired_comparison.append({
            "horizon_minutes": horizon,
            "month": month,
            "common_rows": len(group),

            "index_macro_f1": index_metrics["macro_f1"],
            "options_macro_f1": options_metrics["macro_f1"],
            "macro_f1_delta_options_minus_index": (
                    options_metrics["macro_f1"]
                    - index_metrics["macro_f1"]
            ),

            "index_balanced_accuracy": (
                index_metrics["balanced_accuracy"]
            ),
            "options_balanced_accuracy": (
                options_metrics["balanced_accuracy"]
            ),
            "balanced_accuracy_delta": (
                    options_metrics["balanced_accuracy"]
                    - index_metrics["balanced_accuracy"]
            ),

            "index_log_loss": index_metrics["log_loss"],
            "options_log_loss": options_metrics["log_loss"],
            "log_loss_delta_options_minus_index": (
                    options_metrics["log_loss"]
                    - index_metrics["log_loss"]
            ),

            "index_brier": (
                index_metrics["multiclass_brier_score"]
            ),
            "options_brier": (
                options_metrics["multiclass_brier_score"]
            ),
            "brier_delta_options_minus_index": (
                    options_metrics["multiclass_brier_score"]
                    - index_metrics["multiclass_brier_score"]
            ),
        })


paired_comparison_df = pd.DataFrame(paired_comparison)

paired_alignment_df = pd.DataFrame(
    paired_alignment_audit
)

write_csv(
    paired_alignment_df,
    "paired_timestamp_alignment_audit.csv",
)

write_csv(
    paired_comparison_df,
    "monthly_options_vs_index_comparison.csv",
)


# ============================================================
# 3. CONFIDENCE BUCKET ANALYSIS
# ============================================================

confidence_results = []

for (dataset, horizon), df in prediction_frames.items():

    temp = df.copy()

    temp["confidence_bucket"] = pd.cut(
        temp["confidence"],
        bins=CONFIDENCE_BUCKETS,
        labels=CONFIDENCE_LABELS,
        right=True,
        include_lowest=True,
    )

    for bucket in CONFIDENCE_LABELS:

        group = temp[
            temp["confidence_bucket"] == bucket
            ]

        if len(group) == 0:
            confidence_results.append({
                "dataset": dataset,
                "horizon_minutes": horizon,
                "confidence_bucket": bucket,
                "support": 0,
                "mean_confidence": None,
                "accuracy": None,
                "balanced_accuracy": None,
                "macro_f1": None,
                "log_loss": None,
            })
            continue

        metrics = calculate_metrics(group)

        confidence_results.append({
            "dataset": dataset,
            "horizon_minutes": horizon,
            "confidence_bucket": bucket,
            "support": len(group),
            "mean_confidence": group["confidence"].mean(),
            "accuracy": metrics["accuracy"],
            "balanced_accuracy": metrics["balanced_accuracy"],
            "macro_f1": metrics["macro_f1"],
            "log_loss": metrics["log_loss"],
        })


confidence_df = pd.DataFrame(confidence_results)

write_csv(
    confidence_df,
    "confidence_bucket_metrics.csv",
)


# ============================================================
# 4. CONFIDENCE SUMMARY
# ============================================================

confidence_summary = []

for (dataset, horizon), df in prediction_frames.items():

    correct = (
            df["actual_class"] == df["predicted_class"]
    )

    confidence_summary.append({
        "dataset": dataset,
        "horizon_minutes": horizon,
        "rows": len(df),
        "mean_confidence": df["confidence"].mean(),
        "median_confidence": df["confidence"].median(),
        "p75_confidence": df["confidence"].quantile(0.75),
        "p90_confidence": df["confidence"].quantile(0.90),
        "p95_confidence": df["confidence"].quantile(0.95),
        "accuracy": correct.mean(),
        "accuracy_when_confidence_ge_050": (
            correct[df["confidence"] >= 0.50].mean()
            if (df["confidence"] >= 0.50).any()
            else None
        ),
        "accuracy_when_confidence_ge_060": (
            correct[df["confidence"] >= 0.60].mean()
            if (df["confidence"] >= 0.60).any()
            else None
        ),
        "rows_confidence_ge_050": int(
            (df["confidence"] >= 0.50).sum()
        ),
        "rows_confidence_ge_060": int(
            (df["confidence"] >= 0.60).sum()
        ),
    })


confidence_summary_df = pd.DataFrame(
    confidence_summary
)

write_csv(
    confidence_summary_df,
    "confidence_summary.csv",
)


# ============================================================
# 5. MONTHLY PERFORMANCE STABILITY
# ============================================================

stability_results = []

for (dataset, horizon), group in monthly_metrics_df.groupby(
        ["dataset", "horizon_minutes"]
):

    valid = group.dropna(
        subset=["macro_f1", "balanced_accuracy", "log_loss"]
    )

    if len(valid) == 0:
        continue

    stability_results.append({
        "dataset": dataset,
        "horizon_minutes": horizon,
        "months_evaluated": len(valid),

        "macro_f1_mean": valid["macro_f1"].mean(),
        "macro_f1_std": valid["macro_f1"].std(ddof=0),
        "macro_f1_min": valid["macro_f1"].min(),
        "macro_f1_max": valid["macro_f1"].max(),

        "balanced_accuracy_mean": (
            valid["balanced_accuracy"].mean()
        ),
        "balanced_accuracy_std": (
            valid["balanced_accuracy"].std(ddof=0)
        ),
        "balanced_accuracy_min": (
            valid["balanced_accuracy"].min()
        ),

        "log_loss_mean": valid["log_loss"].mean(),
        "log_loss_std": valid["log_loss"].std(ddof=0),
        "log_loss_min": valid["log_loss"].min(),
        "log_loss_max": valid["log_loss"].max(),

        "months_macro_f1_above_0333": int(
            (valid["macro_f1"] > 1 / 3).sum()
        ),

        "months_balanced_accuracy_above_0333": int(
            (valid["balanced_accuracy"] > 1 / 3).sum()
        ),
    })


stability_df = pd.DataFrame(stability_results)

write_csv(
    stability_df,
    "monthly_performance_stability.csv",
)


# ============================================================
# 6. FEATURE IMPORTANCE STABILITY
# ============================================================

importance_stability = []

for dataset in DATASETS:

    available_horizons = [
        h for h in HORIZONS
        if (dataset, h) in importance_frames
    ]

    if len(available_horizons) < 2:
        continue

    for i in range(len(available_horizons)):
        for j in range(i + 1, len(available_horizons)):

            h1 = available_horizons[i]
            h2 = available_horizons[j]

            first = importance_frames[
                (dataset, h1)
            ][["feature", "importance_gain"]].copy()

            second = importance_frames[
                (dataset, h2)
            ][["feature", "importance_gain"]].copy()

            first = first.rename(
                columns={
                    "importance_gain": "gain_h1"
                }
            )

            second = second.rename(
                columns={
                    "importance_gain": "gain_h2"
                }
            )

            first["gain_rank_h1"] = (
                first["gain_h1"].rank(
                    ascending=False,
                    method="average",
                )
            )

            second["gain_rank_h2"] = (
                second["gain_h2"].rank(
                    ascending=False,
                    method="average",
                )
            )

            merged = first.merge(
                second,
                on="feature",
                how="inner",
            )

            if len(merged) >= 3:
                rank_correlation = (
                    merged["gain_rank_h1"].corr(
                        merged["gain_rank_h2"],
                        method="spearman",
                    )
                )
            else:
                rank_correlation = None

            importance_stability.append({
                "dataset": dataset,
                "horizon_1": h1,
                "horizon_2": h2,
                "common_features": len(merged),
                "spearman_gain_rank_correlation": (
                    rank_correlation
                ),
            })


importance_stability_df = pd.DataFrame(
    importance_stability
)

write_csv(
    importance_stability_df,
    "feature_importance_rank_stability.csv",
)


# ============================================================
# 7. OVERALL SUMMARY AND AUDIT STATUS
# ============================================================

all_files_pass = (
        len(load_audit) == 6
        and all(x["status"] == "PASS" for x in load_audit)
)

all_paired_pass = (
        len(paired_alignment_audit) == 3
        and all(
    x["status"] == "PASS"
    for x in paired_alignment_audit
)
)

summary = {
    "status": (
        "PASS"
        if all_files_pass and all_paired_pass
        else "REVIEW_REQUIRED"
    ),
    "audit_name": "NIFTY_MONTHLY_ROBUSTNESS_V1",
    "validation_period": "2024",
    "datasets": DATASETS,
    "horizons": HORIZONS,
    "classes": CLASSES,
    "prediction_files_loaded": len(load_audit),
    "monthly_metric_rows": len(monthly_metrics_df),
    "monthly_class_metric_rows": len(monthly_class_df),
    "paired_alignment_checks": paired_alignment_audit,
    "checks": {
        "six_prediction_files_loaded": all_files_pass,
        "same_timestamps_for_index_and_options": all_paired_pass,
        "actual_labels_match_between_variants": all_paired_pass,
        "monthly_metrics_generated": len(monthly_metrics_df) > 0,
        "confidence_analysis_generated": len(confidence_df) > 0,
    },
    "interpretation_notes": [
        "2024 is a diagnostic validation period, not an untouched final test.",
        "Confidence buckets are descriptive and are not trading thresholds.",
        "A higher confidence value is not proof of probability calibration.",
        "Feature importance rank correlation is a stability diagnostic, not causal evidence.",
        "Options versus index comparisons use timestamp-aligned validation predictions.",
        "No trading profitability or execution-cost conclusion is produced by this audit.",
    ],
}

summary["checks"]["all_checks_pass"] = all(
    summary["checks"].values()
)

write_json(
    summary,
    "monthly_robustness_summary.json",
)


# ============================================================
# CONSOLE SUMMARY
# ============================================================

print()
print("=" * 90)
print("MONTHLY ROBUSTNESS AUDIT COMPLETED")
print("=" * 90)

print(json.dumps(
    json_safe(summary),
    indent=2,
))

print()
print("OUTPUT DIRECTORY:")
print(OUTPUT_DIR)

print()
print("IMPORTANT:")
print("This is a diagnostic audit of 2024 validation results.")
print("Do not treat confidence buckets as trading signals.")
print("Do not select a model based on one strong month.")
