
from pathlib import Path
import json
import sys
from datetime import datetime, timezone

import duckdb
import pandas as pd


# ============================================================
# CONFIGURATION
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parents[1]

INPUT_FILE = (
        PROJECT_ROOT
        / "data"
        / "processed"
        / "nifty_index_options_features_v2"
        / "nifty_index_options_features_v2.parquet"
)

OUTPUT_DIR = (
        PROJECT_ROOT
        / "data"
        / "processed"
        / "nifty_index_options_features_v3"
)

OUTPUT_FILE = OUTPUT_DIR / "nifty_index_options_features_v3.parquet"

REPORT_DIR = PROJECT_ROOT / "reports" / "nifty_quantile_labels_v3"

THRESHOLD_REPORT = (
        REPORT_DIR / "quantile_thresholds_fit_2021_2022.csv"
)

DISTRIBUTION_REPORT = (
        REPORT_DIR / "label_distribution_by_split.csv"
)

SUMMARY_REPORT = (
        REPORT_DIR / "quantile_v3_build_summary.json"
)

# Thresholds are calculated ONLY from these dates.
FIT_START = "2021-05-24"
FIT_END = "2022-12-31"

# The fixed thresholds are applied to this early-stopping period.
EARLY_STOP_START = "2023-01-01"
EARLY_STOP_END = "2023-12-31"

# The same fixed thresholds are applied to this validation period.
VALIDATION_START = "2024-01-01"
VALIDATION_END = "2024-12-31"

LOWER_QUANTILE = 1.0 / 3.0
UPPER_QUANTILE = 2.0 / 3.0

HORIZONS = [5, 15, 30]

# Source columns that must remain exactly unchanged.
PRESERVED_COLUMNS = [
    "timestamp_ist",
    "trading_day",
    "horizon_minutes",
    "target_z",
    "forward_return",
    "future_close",
    "label_volatility_v1",
    "sample_eligible",
    "is_synthetic",
]

NEW_COLUMNS = [
    "label_quantile_v3",
    "quantile_lower_v3",
    "quantile_upper_v3",
]

# Set True only if intentionally rebuilding the output.
# Existing reports with the same names will also be replaced.
ALLOW_OVERWRITE = False


# ============================================================
# HELPERS
# ============================================================

def sql_path(path: Path) -> str:
    """Return a safely quoted DuckDB file path."""
    value = str(path).replace("\\", "/").replace("'", "''")
    return f"'{value}'"


def ensure_columns(con, parquet_file, required_columns):
    schema = con.execute(
        f"""
        DESCRIBE
        SELECT *
        FROM read_parquet({sql_path(parquet_file)})
        """
    ).fetchdf()

    available = set(schema["column_name"].tolist())

    missing = [
        column
        for column in required_columns
        if column not in available
    ]

    if missing:
        raise RuntimeError(
            f"Input file is missing required columns: {missing}"
        )

    return schema


def check_file_not_existing(path: Path):
    if path.exists() and not ALLOW_OVERWRITE:
        raise FileExistsError(
            f"\nOutput already exists:\n{path}\n\n"
            "To prevent accidental overwriting, the script stopped.\n"
            "If you intentionally want to rebuild, set "
            "ALLOW_OVERWRITE = True near the top of the script."
        )


def validate_thresholds(thresholds):
    returned_horizons = sorted(
        thresholds["horizon_minutes"].astype(int).tolist()
    )

    if returned_horizons != HORIZONS:
        raise RuntimeError(
            "Threshold calculation did not return all expected horizons. "
            f"Expected={HORIZONS}, returned={returned_horizons}"
        )

    if thresholds["fit_rows"].isna().any():
        raise RuntimeError("Threshold fit-row count contains NULL.")

    if (thresholds["fit_rows"] <= 0).any():
        raise RuntimeError("A horizon has no eligible threshold-fit rows.")

    if thresholds["lower_threshold"].isna().any():
        raise RuntimeError("Lower quantile threshold contains NULL.")

    if thresholds["upper_threshold"].isna().any():
        raise RuntimeError("Upper quantile threshold contains NULL.")

    if (
            thresholds["lower_threshold"]
            >= thresholds["upper_threshold"]
    ).any():
        raise RuntimeError(
            "Invalid thresholds: lower threshold must be below upper."
        )


# ============================================================
# MAIN
# ============================================================

def main():

    print("=" * 80)
    print("NIFTY QUANTILE LABEL V3")
    print("STRICT TEMPORAL THRESHOLD CONSTRUCTION")
    print("=" * 80)

    # --------------------------------------------------------
    # 0. Validate paths and output policy.
    # --------------------------------------------------------

    if not INPUT_FILE.exists():
        raise FileNotFoundError(
            f"Input file not found:\n{INPUT_FILE}"
        )

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    REPORT_DIR.mkdir(parents=True, exist_ok=True)

    for output_path in [
        OUTPUT_FILE,
        THRESHOLD_REPORT,
        DISTRIBUTION_REPORT,
        SUMMARY_REPORT,
    ]:
        check_file_not_existing(output_path)

    print(f"\nInput file : {INPUT_FILE}")
    print(f"Output file: {OUTPUT_FILE}")
    print(f"Reports    : {REPORT_DIR}")

    con = duckdb.connect(database=":memory:")

    try:

        # ----------------------------------------------------
        # 1. Inspect input schema.
        # ----------------------------------------------------

        print("\n[1/7] Inspecting input schema...")

        schema = ensure_columns(
            con,
            INPUT_FILE,
            PRESERVED_COLUMNS,
        )

        input_columns = schema["column_name"].tolist()

        existing_new_columns = [
            column
            for column in NEW_COLUMNS
            if column in input_columns
        ]

        if existing_new_columns:
            raise RuntimeError(
                "Input already contains v3 columns: "
                f"{existing_new_columns}. "
                "Use the original merged v2 input."
            )

        input_sql = sql_path(INPUT_FILE)

        input_stats = con.execute(
            f"""
            SELECT
                COUNT(*) AS row_count,
                COUNT(DISTINCT
                    CAST(timestamp_ist AS VARCHAR)
                    || '|'
                    || CAST(horizon_minutes AS VARCHAR)
                ) AS unique_keys
            FROM read_parquet({input_sql})
            """
        ).fetchdf().iloc[0]

        input_rows = int(input_stats["row_count"])
        input_unique_keys = int(input_stats["unique_keys"])

        if input_rows != input_unique_keys:
            raise RuntimeError(
                "Input contains duplicate timestamp+horizon keys."
            )

        print(f"Input rows: {input_rows:,}")
        print(f"Unique keys: {input_unique_keys:,}")

        # ----------------------------------------------------
        # 2. Calculate thresholds using 2021-2022 only.
        # ----------------------------------------------------

        print(
            "\n[2/7] Calculating thresholds using "
            "eligible 2021-2022 rows only..."
        )

        thresholds = con.execute(
            f"""
            SELECT
                CAST(horizon_minutes AS INTEGER) AS horizon_minutes,

                COUNT(*) AS fit_rows,

                quantile_cont(
                    target_z,
                    {LOWER_QUANTILE}
                ) AS lower_threshold,

                quantile_cont(
                    target_z,
                    {UPPER_QUANTILE}
                ) AS upper_threshold

            FROM read_parquet({input_sql})

            WHERE
                CAST(trading_day AS DATE)
                    BETWEEN DATE '{FIT_START}'
                    AND DATE '{FIT_END}'

                AND sample_eligible = TRUE
                AND target_z IS NOT NULL

            GROUP BY CAST(horizon_minutes AS INTEGER)

            ORDER BY horizon_minutes
            """
        ).fetchdf()

        validate_thresholds(thresholds)

        thresholds["lower_quantile"] = LOWER_QUANTILE
        thresholds["upper_quantile"] = UPPER_QUANTILE

        thresholds["threshold_fit_start"] = FIT_START
        thresholds["threshold_fit_end"] = FIT_END

        thresholds.to_csv(
            THRESHOLD_REPORT,
            index=False,
        )

        print("\nFixed v3 thresholds:")
        print(thresholds.to_string(index=False))

        # Register fixed thresholds with DuckDB.
        con.register(
            "v3_thresholds_dataframe",
            thresholds,
        )

        con.execute(
            """
            CREATE TEMP TABLE v3_thresholds AS
            SELECT
                CAST(horizon_minutes AS INTEGER)
                    AS horizon_minutes,

                CAST(lower_threshold AS DOUBLE)
                    AS lower_threshold,

                CAST(upper_threshold AS DOUBLE)
                    AS upper_threshold

            FROM v3_thresholds_dataframe
            """
        )

        threshold_count = con.execute(
            "SELECT COUNT(*) FROM v3_thresholds"
        ).fetchone()[0]

        if threshold_count != len(HORIZONS):
            raise RuntimeError(
                "Unexpected number of threshold rows."
            )

        # ----------------------------------------------------
        # 3. Generate v3 labels.
        # ----------------------------------------------------

        print(
            "\n[3/7] Applying fixed thresholds "
            "to 2021-2024 rows..."
        )

        con.execute(
            f"""
            COPY (

                SELECT
                    src.*,

                    CASE

                        WHEN src.sample_eligible = TRUE
                             AND src.target_z IS NOT NULL
                             AND src.target_z <= th.lower_threshold
                            THEN 'DOWN'

                        WHEN src.sample_eligible = TRUE
                             AND src.target_z IS NOT NULL
                             AND src.target_z >= th.upper_threshold
                            THEN 'UP'

                        WHEN src.sample_eligible = TRUE
                             AND src.target_z IS NOT NULL
                            THEN 'SIDEWAYS'

                        ELSE NULL

                    END AS label_quantile_v3,

                    CASE
                        WHEN src.sample_eligible = TRUE
                             AND src.target_z IS NOT NULL
                            THEN th.lower_threshold
                        ELSE NULL
                    END AS quantile_lower_v3,

                    CASE
                        WHEN src.sample_eligible = TRUE
                             AND src.target_z IS NOT NULL
                            THEN th.upper_threshold
                        ELSE NULL
                    END AS quantile_upper_v3

                FROM read_parquet({input_sql}) AS src

                LEFT JOIN v3_thresholds AS th
                    ON CAST(src.horizon_minutes AS INTEGER)
                       = th.horizon_minutes

            )

            TO {sql_path(OUTPUT_FILE)}

            (FORMAT PARQUET, COMPRESSION ZSTD)
            """
        )

        if not OUTPUT_FILE.exists():
            raise RuntimeError(
                "DuckDB completed without producing the output file."
            )

        # ----------------------------------------------------
        # 4. Validate output row count and unique keys.
        # ----------------------------------------------------

        print(
            "\n[4/7] Validating output row count "
            "and unique keys..."
        )

        output_stats = con.execute(
            f"""
            SELECT
                COUNT(*) AS row_count,

                COUNT(DISTINCT
                    CAST(timestamp_ist AS VARCHAR)
                    || '|'
                    || CAST(horizon_minutes AS VARCHAR)
                ) AS unique_keys

            FROM read_parquet({sql_path(OUTPUT_FILE)})
            """
        ).fetchdf().iloc[0]

        output_rows = int(output_stats["row_count"])
        output_unique_keys = int(output_stats["unique_keys"])

        if output_rows != input_rows:
            raise RuntimeError(
                f"Row count mismatch: input={input_rows:,}, "
                f"output={output_rows:,}"
            )

        if output_rows != output_unique_keys:
            raise RuntimeError(
                "Duplicate timestamp+horizon keys found in v3 output."
            )

        # ----------------------------------------------------
        # 5. Verify original columns are unchanged.
        # ----------------------------------------------------

        print(
            "\n[5/7] Verifying source columns "
            "are exactly preserved..."
        )

        join_condition = """
            src.timestamp_ist = out.timestamp_ist
            AND CAST(src.horizon_minutes AS INTEGER)
                = CAST(out.horizon_minutes AS INTEGER)
        """

        mismatch_expressions = [
            f"src.{column} IS DISTINCT FROM out.{column}"
            for column in PRESERVED_COLUMNS
        ]

        mismatch_sql = " OR ".join(mismatch_expressions)

        preservation_mismatches = con.execute(
            f"""
            SELECT COUNT(*)

            FROM read_parquet({input_sql}) AS src

            INNER JOIN read_parquet({sql_path(OUTPUT_FILE)}) AS out

                ON {join_condition}

            WHERE {mismatch_sql}
            """
        ).fetchone()[0]

        if preservation_mismatches != 0:
            raise RuntimeError(
                "Source-column preservation failed. "
                f"Mismatched rows={preservation_mismatches:,}"
            )

        # Verify exact output schema.
        output_schema = con.execute(
            f"""
            DESCRIBE
            SELECT *
            FROM read_parquet({sql_path(OUTPUT_FILE)})
            """
        ).fetchdf()

        output_columns = output_schema["column_name"].tolist()

        expected_columns = input_columns + NEW_COLUMNS

        if output_columns != expected_columns:
            raise RuntimeError(
                "Output schema mismatch.\n"
                f"Expected columns: {expected_columns}\n"
                f"Actual columns: {output_columns}"
            )

        # ----------------------------------------------------
        # 6. Build corrected distribution audit.
        # ----------------------------------------------------

        print(
            "\n[6/7] Creating label distribution "
            "by period and horizon..."
        )

        # IMPORTANT:
        # split_period is calculated in the inner query.
        # The outer query groups by split_period.
        # This avoids collision with any original source column
        # named split and prevents the DuckDB GROUP BY error.

        distribution = con.execute(
            f"""
            SELECT

                split_period,

                horizon_minutes,

                COUNT(*) FILTER (
                    WHERE sample_eligible = TRUE
                ) AS eligible_rows,

                COUNT(*) FILTER (
                    WHERE label_quantile_v3 = 'DOWN'
                ) AS down_count,

                COUNT(*) FILTER (
                    WHERE label_quantile_v3 = 'SIDEWAYS'
                ) AS sideways_count,

                COUNT(*) FILTER (
                    WHERE label_quantile_v3 = 'UP'
                ) AS up_count,

                COUNT(*) FILTER (
                    WHERE sample_eligible = TRUE
                      AND label_quantile_v3 IS NULL
                ) AS eligible_missing_label,

                COUNT(*) FILTER (
                    WHERE sample_eligible = FALSE
                      AND label_quantile_v3 IS NOT NULL
                ) AS ineligible_with_label

            FROM (

                SELECT

                    CASE

                        WHEN CAST(trading_day AS DATE)
                             BETWEEN DATE '{FIT_START}'
                             AND DATE '{FIT_END}'
                            THEN 'FIT_2021_2022'

                        WHEN CAST(trading_day AS DATE)
                             BETWEEN DATE '{EARLY_STOP_START}'
                             AND DATE '{EARLY_STOP_END}'
                            THEN 'EARLY_STOP_2023'

                        WHEN CAST(trading_day AS DATE)
                             BETWEEN DATE '{VALIDATION_START}'
                             AND DATE '{VALIDATION_END}'
                            THEN 'VALIDATION_2024'

                        ELSE 'OUT_OF_SCOPE'

                    END AS split_period,

                    CAST(horizon_minutes AS INTEGER)
                        AS horizon_minutes,

                    sample_eligible,

                    label_quantile_v3

                FROM read_parquet({sql_path(OUTPUT_FILE)})

            ) AS classified

            GROUP BY
                split_period,
                horizon_minutes

            ORDER BY
                split_period,
                horizon_minutes
            """
        ).fetchdf()

        distribution.to_csv(
            DISTRIBUTION_REPORT,
            index=False,
        )

        if (distribution["eligible_missing_label"] != 0).any():
            raise RuntimeError(
                "Some eligible rows have missing v3 labels."
            )

        if (distribution["ineligible_with_label"] != 0).any():
            raise RuntimeError(
                "Some ineligible rows unexpectedly have v3 labels."
            )

        # Verify each expected period and horizon is represented.
        expected_periods = {
            "FIT_2021_2022",
            "EARLY_STOP_2023",
            "VALIDATION_2024",
        }

        actual_periods = set(distribution["split_period"].tolist())

        missing_periods = expected_periods - actual_periods

        if missing_periods:
            raise RuntimeError(
                f"Missing expected periods in distribution: {missing_periods}"
            )

        for period in expected_periods:
            period_horizons = set(
                distribution.loc[
                    distribution["split_period"] == period,
                    "horizon_minutes",
                ].astype(int).tolist()
            )

            if period_horizons != set(HORIZONS):
                raise RuntimeError(
                    f"Period {period} has unexpected horizons: "
                    f"{period_horizons}"
                )

        print("\nLabel distribution:")
        print(distribution.to_string(index=False))

        # ----------------------------------------------------
        # 7. Write final summary.
        # ----------------------------------------------------

        print("\n[7/7] Writing build summary...")

        threshold_records = thresholds.to_dict(
            orient="records"
        )

        summary = {
            "status": "PASS",

            "generated_utc": datetime.now(
                timezone.utc
            ).isoformat(),

            "input_file": str(INPUT_FILE),
            "output_file": str(OUTPUT_FILE),

            "input_rows": input_rows,
            "output_rows": output_rows,
            "unique_output_keys": output_unique_keys,

            "preserved_column_mismatches": int(
                preservation_mismatches
            ),

            "horizons": HORIZONS,

            "threshold_method": "DuckDB quantile_cont",

            "lower_quantile": LOWER_QUANTILE,
            "upper_quantile": UPPER_QUANTILE,

            "threshold_fit_period": {
                "start": FIT_START,
                "end": FIT_END,
                "description": (
                    "Eligible observations from 2021-2022 only"
                ),
            },

            "thresholds": threshold_records,

            "label_rule": (
                "DOWN if target_z <= lower threshold; "
                "UP if target_z >= upper threshold; "
                "otherwise SIDEWAYS. "
                "Ineligible observations remain NULL."
            ),

            "application_periods": {
                "fit": f"{FIT_START} to {FIT_END}",
                "early_stop": (
                    f"{EARLY_STOP_START} to {EARLY_STOP_END}"
                ),
                "validation": (
                    f"{VALIDATION_START} to {VALIDATION_END}"
                ),
            },

            "preserved_columns": PRESERVED_COLUMNS,
            "new_columns": NEW_COLUMNS,

            "volatility_labels_changed": False,
            "source_file_modified": False,

            "checks": {
                "input_unique_keys": True,
                "row_count_preserved": True,
                "output_unique_keys": True,
                "preserved_columns_exact": True,
                "expected_output_schema": True,
                "all_eligible_rows_labeled": True,
                "ineligible_rows_unlabeled": True,
                "all_periods_and_horizons_present": True,
                "thresholds_fit_on_2021_2022_only": True,
            },

            "reports": {
                "thresholds": str(THRESHOLD_REPORT),
                "distribution": str(DISTRIBUTION_REPORT),
                "summary": str(SUMMARY_REPORT),
            },
        }

        with open(
                SUMMARY_REPORT,
                "w",
                encoding="utf-8",
        ) as file:
            json.dump(
                summary,
                file,
                indent=2,
                default=str,
            )

        # ----------------------------------------------------
        # FINAL
        # ----------------------------------------------------

        print("\n" + "=" * 80)
        print("NIFTY QUANTILE LABEL V3 BUILD PASSED")
        print("=" * 80)

        print(f"Input rows                  : {input_rows:,}")
        print(f"Output rows                 : {output_rows:,}")
        print(f"Unique output keys          : {output_unique_keys:,}")
        print(
            "Preserved-column mismatches : "
            f"{preservation_mismatches:,}"
        )

        print(f"\nOutput parquet:")
        print(OUTPUT_FILE)

        print(f"\nThreshold report:")
        print(THRESHOLD_REPORT)

        print(f"\nDistribution report:")
        print(DISTRIBUTION_REPORT)

        print(f"\nSummary report:")
        print(SUMMARY_REPORT)

        print("\nAll validation checks passed.")

    finally:
        con.close()


# ============================================================
# ENTRY POINT
# ============================================================

if __name__ == "__main__":

    try:
        main()

    except Exception as exc:

        print("\n" + "=" * 80)
        print("BUILD FAILED")
        print("=" * 80)

        print(str(exc))

        sys.exit(1)
