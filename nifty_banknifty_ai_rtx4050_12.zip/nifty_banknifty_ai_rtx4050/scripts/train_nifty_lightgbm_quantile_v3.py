
from pathlib import Path
from datetime import datetime, timezone
import json
import sys
import warnings

import joblib
import lightgbm as lgb
import numpy as np
import pandas as pd

from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    log_loss,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.utils.class_weight import compute_sample_weight


warnings.filterwarnings("ignore", category=UserWarning)


# ============================================================
# CONFIGURATION
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parents[1]

DATA_ROOT = (
        PROJECT_ROOT
        / "data"
        / "processed"
        / "nifty_matched_datasets_v3"
)

MODEL_ROOT = (
        PROJECT_ROOT
        / "models"
        / "nifty_lightgbm_quantile_v3"
)

REPORT_ROOT = (
        PROJECT_ROOT
        / "reports"
        / "nifty_lightgbm_quantile_v3"
)

HORIZONS = [5, 15, 30]

DATASETS = [
    "index_only",
    "index_plus_options",
]

TARGET_COLUMN = "label_quantile_v3"

CLASSES = ["DOWN", "SIDEWAYS", "UP"]
CLASS_TO_INT = {
    "DOWN": 0,
    "SIDEWAYS": 1,
    "UP": 2,
}

FIT_START = "2021-05-24"
FIT_END = "2022-12-31"

EARLY_STOP_START = "2023-01-01"
EARLY_STOP_END = "2023-12-31"

VALIDATION_START = "2024-01-01"
VALIDATION_END = "2024-12-31"

# Same model configuration as the v2 experiment.
MODEL_PARAMS = {
    "objective": "multiclass",
    "num_class": 3,
    "n_estimators": 3000,
    "learning_rate": 0.02,
    "num_leaves": 15,
    "max_depth": -1,
    "min_child_samples": 300,
    "subsample": 0.8,
    "subsample_freq": 1,
    "colsample_bytree": 0.8,
    "reg_alpha": 0.5,
    "reg_lambda": 10.0,
    "max_bin": 127,
    "random_state": 42,
    "n_jobs": 4,
    "verbosity": -1,
    "deterministic": True,
    "force_col_wise": True,
}

EARLY_STOPPING_ROUNDS = 100

# Avoid accidental replacement of previous experiment outputs.
ALLOW_OVERWRITE = False

PREDICTION_COLUMNS = [
    "timestamp_ist",
    "trading_day",
    "horizon_minutes",
    "target_z",
    "forward_return",
    "label_quantile_v3",
]


# ============================================================
# HELPERS
# ============================================================

def ensure_directory(path):
    path.mkdir(parents=True, exist_ok=True)


def validate_input_columns(df, required_columns, file_path):
    missing = [
        column
        for column in required_columns
        if column not in df.columns
    ]

    if missing:
        raise RuntimeError(
            f"Missing columns in {file_path}: {missing}"
        )


def get_feature_columns(dataset_name):
    if dataset_name == "index_only":
        return [
            "ret_1m",
            "logret_1m",
            "range_pct",
            "body_pct",
            "upper_wick_pct",
            "lower_wick_pct",
            "return_5m",
            "return_15m",
            "return_30m",
            "return_60m",
            "realized_vol_5m",
            "realized_vol_15m",
            "realized_vol_30m",
            "realized_vol_60m",
            "high_low_range_5m",
            "high_low_range_15m",
            "high_low_range_30m",
            "high_low_range_60m",
            "close_vs_ema9_pct",
            "close_vs_ema21_pct",
            "close_vs_ema50_pct",
            "rsi_14",
            "positive_return_count_5m",
            "negative_return_count_5m",
        ]

    if dataset_name == "index_plus_options":
        return [
            "ret_1m",
            "logret_1m",
            "range_pct",
            "body_pct",
            "upper_wick_pct",
            "lower_wick_pct",
            "return_5m",
            "return_15m",
            "return_30m",
            "return_60m",
            "realized_vol_5m",
            "realized_vol_15m",
            "realized_vol_30m",
            "realized_vol_60m",
            "high_low_range_5m",
            "high_low_range_15m",
            "high_low_range_30m",
            "high_low_range_60m",
            "close_vs_ema9_pct",
            "close_vs_ema21_pct",
            "close_vs_ema50_pct",
            "rsi_14",
            "positive_return_count_5m",
            "negative_return_count_5m",

            "selected_dte",
            "atm_distance_pct",
            "atm_straddle_premium_pct",
            "atm_ce_log_return_1m",
            "atm_pe_log_return_1m",
            "atm_ce_pe_return_spread_1m",
            "atm_straddle_weighted_log_return_1m",
            "atm_ce_oi_change_1m",
            "atm_pe_oi_change_1m",
            "near_atm_pcr_oi",
            "near_atm_pcr_volume",
            "near_atm_oi_imbalance",
            "near_atm_volume_imbalance",
            "paired_strike_count",
        ]

    raise ValueError(f"Unknown dataset: {dataset_name}")


def validate_matrix(X, name):
    values = X.to_numpy(dtype=np.float64)

    if np.isnan(values).any():
        raise RuntimeError(f"{name}: NaN values found.")

    if np.isinf(values).any():
        raise RuntimeError(f"{name}: infinite values found.")

    return int(values.size)


def load_dataset(path, feature_columns, horizon):
    if not path.exists():
        raise FileNotFoundError(path)

    df = pd.read_parquet(path)

    required = (
            feature_columns
            + PREDICTION_COLUMNS
            + ["sample_eligible", "is_synthetic"]
    )

    validate_input_columns(df, required, path)

    df["trading_day"] = pd.to_datetime(
        df["trading_day"]
    ).dt.date

    df["horizon_minutes"] = pd.to_numeric(
        df["horizon_minutes"],
        errors="raise",
    ).astype(int)

    df = df.loc[
        df["horizon_minutes"] == horizon
        ].copy()

    if df.empty:
        raise RuntimeError(
            f"No rows for horizon {horizon}: {path}"
        )

    if not df["sample_eligible"].all():
        raise RuntimeError(
            f"Ineligible rows found in matched dataset: {path}"
        )

    if df["is_synthetic"].astype(bool).any():
        raise RuntimeError(
            f"Synthetic rows found in matched dataset: {path}"
        )

    if df[TARGET_COLUMN].isna().any():
        raise RuntimeError(
            f"Missing {TARGET_COLUMN} values: {path}"
        )

    invalid_labels = sorted(
        set(df[TARGET_COLUMN].astype(str).unique())
        - set(CLASSES)
    )

    if invalid_labels:
        raise RuntimeError(
            f"Unexpected labels in {path}: {invalid_labels}"
        )

    if df.duplicated(
            subset=["timestamp_ist", "horizon_minutes"]
    ).any():
        raise RuntimeError(
            f"Duplicate timestamp+horizon keys: {path}"
        )

    validate_matrix(
        df[feature_columns],
        str(path),
    )

    return df


def date_filter(df, start_date, end_date):
    return df.loc[
        (df["trading_day"] >= pd.Timestamp(start_date).date())
        & (df["trading_day"] <= pd.Timestamp(end_date).date())
        ].copy()


def make_model(n_estimators):
    params = dict(MODEL_PARAMS)
    params["n_estimators"] = int(n_estimators)

    return lgb.LGBMClassifier(**params)


def safe_auc(y_true, probabilities):
    try:
        return float(
            roc_auc_score(
                y_true,
                probabilities,
                labels=[0, 1, 2],
                multi_class="ovr",
                average="macro",
            )
        )
    except Exception:
        return None


def evaluate_model(y_true, y_pred, probabilities):
    return {
        "accuracy": float(
            accuracy_score(y_true, y_pred)
        ),

        "balanced_accuracy": float(
            balanced_accuracy_score(y_true, y_pred)
        ),

        "macro_f1": float(
            f1_score(
                y_true,
                y_pred,
                labels=[0, 1, 2],
                average="macro",
                zero_division=0,
            )
        ),

        "weighted_f1": float(
            f1_score(
                y_true,
                y_pred,
                labels=[0, 1, 2],
                average="weighted",
                zero_division=0,
            )
        ),

        "macro_precision": float(
            precision_score(
                y_true,
                y_pred,
                labels=[0, 1, 2],
                average="macro",
                zero_division=0,
            )
        ),

        "macro_recall": float(
            recall_score(
                y_true,
                y_pred,
                labels=[0, 1, 2],
                average="macro",
                zero_division=0,
            )
        ),

        "log_loss": float(
            log_loss(
                y_true,
                probabilities,
                labels=[0, 1, 2],
            )
        ),

        "macro_roc_auc_ovr": safe_auc(
            y_true,
            probabilities,
        ),

        # Mean sum of squared errors across the three classes.
        "multiclass_brier_score": float(
            np.mean(
                np.sum(
                    (
                            probabilities
                            - np.eye(3)[y_true]
                    ) ** 2,
                    axis=1,
                    )
            )
        ),
    }


def class_percentages(y_pred):
    total = len(y_pred)

    return {
        "predicted_down_pct": float(
            np.mean(y_pred == 0) * 100
        ),
        "predicted_sideways_pct": float(
            np.mean(y_pred == 1) * 100
        ),
        "predicted_up_pct": float(
            np.mean(y_pred == 2) * 100
        ),
    }


def make_prediction_frame(df, y_true, y_pred, probabilities):
    result = df[PREDICTION_COLUMNS].copy()

    result["actual_class"] = [
        CLASSES[value] for value in y_true
    ]

    result["predicted_class"] = [
        CLASSES[value] for value in y_pred
    ]

    result["prob_down"] = probabilities[:, 0]
    result["prob_sideways"] = probabilities[:, 1]
    result["prob_up"] = probabilities[:, 2]

    result["confidence"] = probabilities.max(axis=1)

    return result


# ============================================================
# TRAIN ONE MODEL
# ============================================================

def train_one_model(dataset_name, horizon):

    print("\n" + "=" * 80)
    print(
        f"TRAINING: {dataset_name.upper()} | "
        f"QUANTILE V3 | {horizon} MIN"
    )
    print("=" * 80)

    feature_columns = get_feature_columns(dataset_name)

    train_file = (
            DATA_ROOT
            / dataset_name
            / f"train_{horizon}m.parquet"
    )

    validation_file = (
            DATA_ROOT
            / dataset_name
            / f"validation_{horizon}m.parquet"
    )

    train_df = load_dataset(
        train_file,
        feature_columns,
        horizon,
    )

    validation_df = load_dataset(
        validation_file,
        feature_columns,
        horizon,
    )

    # --------------------------------------------------------
    # Split training period into fit and early-stop portions.
    # --------------------------------------------------------

    fit_df = date_filter(
        train_df,
        FIT_START,
        FIT_END,
    )

    early_stop_df = date_filter(
        train_df,
        EARLY_STOP_START,
        EARLY_STOP_END,
    )

    validation_df = date_filter(
        validation_df,
        VALIDATION_START,
        VALIDATION_END,
    )

    if fit_df.empty or early_stop_df.empty or validation_df.empty:
        raise RuntimeError(
            "Fit, early-stop or validation partition is empty."
        )

    # Verify chronological boundaries.
    if fit_df["trading_day"].max() >= early_stop_df["trading_day"].min():
        raise RuntimeError("Fit and early-stop dates overlap.")

    if early_stop_df["trading_day"].max() >= validation_df["trading_day"].min():
        raise RuntimeError("Early-stop and validation dates overlap.")

    # --------------------------------------------------------
    # Convert class labels.
    # --------------------------------------------------------

    y_fit = fit_df[TARGET_COLUMN].map(
        CLASS_TO_INT
    ).to_numpy(dtype=np.int32)

    y_early = early_stop_df[TARGET_COLUMN].map(
        CLASS_TO_INT
    ).to_numpy(dtype=np.int32)

    y_train_all = train_df[TARGET_COLUMN].map(
        CLASS_TO_INT
    ).to_numpy(dtype=np.int32)

    y_validation = validation_df[TARGET_COLUMN].map(
        CLASS_TO_INT
    ).to_numpy(dtype=np.int32)

    if set(np.unique(y_fit)) != {0, 1, 2}:
        raise RuntimeError("Fit partition does not contain all classes.")

    if set(np.unique(y_early)) != {0, 1, 2}:
        raise RuntimeError("Early-stop partition does not contain all classes.")

    if set(np.unique(y_train_all)) != {0, 1, 2}:
        raise RuntimeError("Final training partition does not contain all classes.")

    if set(np.unique(y_validation)) != {0, 1, 2}:
        raise RuntimeError("Validation partition does not contain all classes.")

    X_fit = fit_df[feature_columns]
    X_early = early_stop_df[feature_columns]
    X_train_all = train_df[feature_columns]
    X_validation = validation_df[feature_columns]

    # --------------------------------------------------------
    # Fit model with early stopping.
    # --------------------------------------------------------

    print(f"Fit rows: {len(fit_df):,}")
    print(f"Early-stop rows: {len(early_stop_df):,}")
    print(f"Final train rows: {len(train_df):,}")
    print(f"Validation rows: {len(validation_df):,}")
    print(f"Feature count: {len(feature_columns)}")

    fit_weights = compute_sample_weight(
        class_weight="balanced",
        y=y_fit,
    )

    early_model = make_model(
        MODEL_PARAMS["n_estimators"]
    )

    early_model.fit(
        X_fit,
        y_fit,
        sample_weight=fit_weights,
        eval_set=[
            (X_early, y_early)
        ],
        eval_metric="multi_logloss",
        callbacks=[
            lgb.early_stopping(
                stopping_rounds=EARLY_STOPPING_ROUNDS,
                verbose=False,
            ),
            lgb.log_evaluation(period=100),
        ],
    )

    best_iteration = int(
        early_model.best_iteration_
        if early_model.best_iteration_
        else MODEL_PARAMS["n_estimators"]
    )

    if best_iteration < 1:
        raise RuntimeError("Invalid best iteration.")

    print(f"Best iteration: {best_iteration}")

    # --------------------------------------------------------
    # Final refit on the full 2021-2023 training period.
    # --------------------------------------------------------

    print("\nRefitting on complete 2021-2023 training data...")

    final_weights = compute_sample_weight(
        class_weight="balanced",
        y=y_train_all,
    )

    final_model = make_model(best_iteration)

    final_model.fit(
        X_train_all,
        y_train_all,
        sample_weight=final_weights,
    )

    # --------------------------------------------------------
    # 2024 diagnostic validation.
    # --------------------------------------------------------

    print("\nEvaluating on 2024 validation...")

    probabilities = final_model.predict_proba(
        X_validation
    )

    y_pred = np.argmax(
        probabilities,
        axis=1,
    )

    metrics = evaluate_model(
        y_validation,
        y_pred,
        probabilities,
    )

    metrics.update(
        class_percentages(y_pred)
    )

    # --------------------------------------------------------
    # Confusion matrix and classification report.
    # --------------------------------------------------------

    matrix = confusion_matrix(
        y_validation,
        y_pred,
        labels=[0, 1, 2],
    )

    class_report = classification_report(
        y_validation,
        y_pred,
        labels=[0, 1, 2],
        target_names=CLASSES,
        output_dict=True,
        zero_division=0,
    )

    # --------------------------------------------------------
    # Output paths.
    # --------------------------------------------------------

    model_dir = MODEL_ROOT / dataset_name
    report_dir = REPORT_ROOT / dataset_name

    ensure_directory(model_dir)
    ensure_directory(report_dir)

    model_path = (
            model_dir
            / f"lightgbm_quantile_v3_{horizon}m.joblib"
    )

    prediction_path = (
            report_dir
            / f"validation_predictions_{horizon}m.csv"
    )

    importance_path = (
            report_dir
            / f"feature_importance_{horizon}m.csv"
    )

    metrics_path = (
            report_dir
            / f"metrics_{horizon}m.json"
    )

    confusion_path = (
            report_dir
            / f"confusion_matrix_{horizon}m.csv"
    )

    class_report_path = (
            report_dir
            / f"classification_report_{horizon}m.csv"
    )

    output_paths = [
        model_path,
        prediction_path,
        importance_path,
        metrics_path,
        confusion_path,
        class_report_path,
    ]

    if not ALLOW_OVERWRITE:
        existing = [
            str(path)
            for path in output_paths
            if path.exists()
        ]

        if existing:
            raise FileExistsError(
                "Refusing to overwrite existing model outputs:\n"
                + "\n".join(existing)
            )

    # --------------------------------------------------------
    # Save model.
    # --------------------------------------------------------

    joblib.dump(
        final_model,
        model_path,
        compress=3,
    )

    # --------------------------------------------------------
    # Save validation predictions.
    # --------------------------------------------------------

    prediction_df = make_prediction_frame(
        validation_df,
        y_validation,
        y_pred,
        probabilities,
    )

    prediction_df.to_csv(
        prediction_path,
        index=False,
    )

    # --------------------------------------------------------
    # Feature importance.
    # --------------------------------------------------------

    importance_df = pd.DataFrame({
        "feature": feature_columns,
        "importance_gain": final_model.booster_.feature_importance(
            importance_type="gain"
        ),
        "importance_split": final_model.booster_.feature_importance(
            importance_type="split"
        ),
    }).sort_values(
        "importance_gain",
        ascending=False,
    )

    importance_df.to_csv(
        importance_path,
        index=False,
    )

    # --------------------------------------------------------
    # Confusion matrix.
    # --------------------------------------------------------

    confusion_df = pd.DataFrame(
        matrix,
        index=[
            f"actual_{name.lower()}"
            for name in CLASSES
        ],
        columns=[
            f"predicted_{name.lower()}"
            for name in CLASSES
        ],
    )

    confusion_df.to_csv(
        confusion_path
    )

    # --------------------------------------------------------
    # Classification report.
    # --------------------------------------------------------

    class_report_df = pd.DataFrame(
        class_report
    ).transpose()

    class_report_df.to_csv(
        class_report_path
    )

    # --------------------------------------------------------
    # Model metrics.
    # --------------------------------------------------------

    result = {
        "status": "PASS",
        "generated_utc": datetime.now(
            timezone.utc
        ).isoformat(),

        "dataset": dataset_name,
        "target": TARGET_COLUMN,
        "horizon_minutes": horizon,

        "feature_count": len(feature_columns),
        "features": feature_columns,

        "train_rows": int(len(train_df)),
        "fit_rows": int(len(fit_df)),
        "early_stop_rows": int(len(early_stop_df)),
        "validation_rows": int(len(validation_df)),

        "fit_period": {
            "start": FIT_START,
            "end": FIT_END,
        },

        "early_stop_period": {
            "start": EARLY_STOP_START,
            "end": EARLY_STOP_END,
        },

        "validation_period": {
            "start": VALIDATION_START,
            "end": VALIDATION_END,
        },

        "best_iteration": best_iteration,

        "sample_weighting": "balanced",

        "model_parameters": MODEL_PARAMS,

        "metrics": metrics,

        "confusion_matrix": matrix.tolist(),

        "classification_report": class_report,

        "class_order": CLASSES,

        "model_file": str(model_path),
        "prediction_file": str(prediction_path),
        "feature_importance_file": str(importance_path),

        "training_policy": (
            "Fit 2021-2022, early stop on 2023, "
            "refit all 2021-2023 using selected iteration, "
            "evaluate once on 2024."
        ),
    }

    with open(
            metrics_path,
            "w",
            encoding="utf-8",
    ) as file:
        json.dump(
            result,
            file,
            indent=2,
            default=str,
        )

    # --------------------------------------------------------
    # Console output.
    # --------------------------------------------------------

    print("\nValidation metrics:")

    for name, value in metrics.items():
        print(f"{name:30s}: {value}")

    print("\nConfusion matrix:")
    print(confusion_df)

    print("\nClassification report:")
    print(class_report_df)

    print(f"\nModel saved: {model_path}")
    print(f"Metrics saved: {metrics_path}")

    return {
        "dataset": dataset_name,
        "horizon_minutes": horizon,
        "train_rows": len(train_df),
        "fit_rows": len(fit_df),
        "early_stop_rows": len(early_stop_df),
        "validation_rows": len(validation_df),
        "feature_count": len(feature_columns),
        "best_iteration": best_iteration,
        **metrics,
        "sample_weighting": "balanced",
        "status": "PASS",
    }


# ============================================================
# MAIN
# ============================================================

def main():

    print("=" * 80)
    print("NIFTY LIGHTGBM QUANTILE V3 TRAINING")
    print("=" * 80)

    print("\nTarget:", TARGET_COLUMN)
    print("Class order:", CLASSES)
    print("Datasets:", DATASETS)
    print("Horizons:", HORIZONS)

    print("\nModel parameters:")
    for key, value in MODEL_PARAMS.items():
        print(f"{key}: {value}")

    results = []

    for dataset_name in DATASETS:

        for horizon in HORIZONS:

            result = train_one_model(
                dataset_name,
                horizon,
            )

            results.append(result)

    # --------------------------------------------------------
    # Comparison report.
    # --------------------------------------------------------

    comparison_df = pd.DataFrame(results)

    REPORT_ROOT.mkdir(
        parents=True,
        exist_ok=True,
    )

    comparison_path = (
            REPORT_ROOT / "model_comparison_quantile_v3.csv"
    )

    summary_path = (
            REPORT_ROOT / "training_summary_quantile_v3.json"
    )

    if not ALLOW_OVERWRITE:
        existing = [
            str(path)
            for path in [
                comparison_path,
                summary_path,
            ]
            if path.exists()
        ]

        if existing:
            raise FileExistsError(
                "Refusing to overwrite summary outputs:\n"
                + "\n".join(existing)
            )

    comparison_df.to_csv(
        comparison_path,
        index=False,
    )

    summary = {
        "status": (
            "PASS"
            if len(results) == 6
               and all(r["status"] == "PASS" for r in results)
            else "FAIL"
        ),

        "generated_utc": datetime.now(
            timezone.utc
        ).isoformat(),

        "target": TARGET_COLUMN,

        "models_completed": len(results),

        "expected_models": 6,

        "datasets": DATASETS,

        "horizons": HORIZONS,

        "class_order": CLASSES,

        "model_parameters": MODEL_PARAMS,

        "fit_period": f"{FIT_START} to {FIT_END}",

        "early_stop_period": (
            f"{EARLY_STOP_START} to {EARLY_STOP_END}"
        ),

        "final_refit_period": (
            f"{FIT_START} to {EARLY_STOP_END}"
        ),

        "validation_period": (
            f"{VALIDATION_START} to {VALIDATION_END}"
        ),

        "sample_weighting": "balanced",

        "results": results,

        "comparison_file": str(comparison_path),
    }

    with open(
            summary_path,
            "w",
            encoding="utf-8",
    ) as file:
        json.dump(
            summary,
            file,
            indent=2,
            default=str,
        )

    print("\n" + "=" * 80)
    print("QUANTILE V3 TRAINING COMPLETED")
    print("=" * 80)

    print(comparison_df.to_string(index=False))

    print(f"\nComparison: {comparison_path}")
    print(f"Summary: {summary_path}")

    if summary["status"] != "PASS":
        raise RuntimeError(
            "Not all six models completed successfully."
        )


if __name__ == "__main__":

    try:
        main()

    except Exception as exc:

        print("\n" + "=" * 80)
        print("TRAINING FAILED")
        print("=" * 80)

        print(str(exc))

        sys.exit(1)
