
from pathlib import Path
import json
import warnings
import joblib
import numpy as np
import pandas as pd
import lightgbm as lgb

from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    f1_score,
    precision_score,
    recall_score,
    log_loss,
    roc_auc_score,
    confusion_matrix,
    classification_report,
)
from sklearn.utils.class_weight import compute_sample_weight

warnings.filterwarnings("ignore")

# ============================================================
# CONFIGURATION
# ============================================================

ROOT = Path(__file__).resolve().parent.parent

DATA_ROOT = (
        ROOT / "data" / "processed"
        / "nifty_two_stage_matched_datasets_v1"
)

MODEL_ROOT = (
        ROOT / "models"
        / "nifty_two_stage_lightgbm_v1"
)

REPORT_ROOT = (
        ROOT / "reports"
        / "nifty_two_stage_lightgbm_v1"
)

HORIZONS = [5, 15, 30]
DATASETS = ["index_only", "index_plus_options"]
STAGES = ["stage1", "stage2"]

INDEX_FEATURES = [
    "ret_1m",
    "logret_1m",
    "range_pct",
    "body_pct",
    "upper_wick_pct",
    "lower_wick_pct",
    "return_5m",
    "return_15m",
    "return_30m",
    "return_60m",
    "realized_vol_5m",
    "realized_vol_15m",
    "realized_vol_30m",
    "realized_vol_60m",
    "high_low_range_5m",
    "high_low_range_15m",
    "high_low_range_30m",
    "high_low_range_60m",
    "close_vs_ema9_pct",
    "close_vs_ema21_pct",
    "close_vs_ema50_pct",
    "rsi_14",
    "positive_return_count_5m",
    "negative_return_count_5m",
]

OPTIONS_FEATURES = [
    "selected_dte",
    "atm_distance_pct",
    "atm_straddle_premium_pct",
    "atm_ce_log_return_1m",
    "atm_pe_log_return_1m",
    "atm_ce_pe_return_spread_1m",
    "atm_straddle_weighted_log_return_1m",
    "atm_ce_oi_change_1m",
    "atm_pe_oi_change_1m",
    "near_atm_pcr_oi",
    "near_atm_pcr_volume",
    "near_atm_oi_imbalance",
    "near_atm_volume_imbalance",
    "paired_strike_count",
]

TARGETS = {
    "stage1": {
        "column": "label_stage1_move_v1",
        "negative": "SIDEWAYS",
        "positive": "MOVE",
        "classes": ["SIDEWAYS", "MOVE"],
    },
    "stage2": {
        "column": "label_stage2_direction_v1",
        "negative": "DOWN",
        "positive": "UP",
        "classes": ["DOWN", "UP"],
    },
}

# Binary LightGBM configuration.
PARAMS = {
    "objective": "binary",
    "metric": "binary_logloss",
    "learning_rate": 0.02,
    "n_estimators": 3000,
    "num_leaves": 15,
    "max_depth": -1,
    "min_child_samples": 300,
    "subsample": 0.8,
    "subsample_freq": 1,
    "colsample_bytree": 0.8,
    "reg_alpha": 0.5,
    "reg_lambda": 10.0,
    "max_bin": 127,
    "random_state": 42,
    "n_jobs": 4,
    "verbosity": -1,
    "deterministic": True,
    "force_col_wise": True,
}

EARLY_STOPPING_ROUNDS = 100

MODEL_ROOT.mkdir(parents=True, exist_ok=True)
REPORT_ROOT.mkdir(parents=True, exist_ok=True)


# ============================================================
# HELPERS
# ============================================================

def write_json(data, path):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(
            data,
            f,
            indent=2,
            default=str,
            allow_nan=False,
        )


def load_data(stage, dataset, split, horizon):
    path = (
            DATA_ROOT / stage / dataset
            / f"{split}_{horizon}m.parquet"
    )

    if not path.exists():
        raise FileNotFoundError(path)

    return pd.read_parquet(path)


def get_features(dataset):
    if dataset == "index_only":
        return INDEX_FEATURES

    return INDEX_FEATURES + OPTIONS_FEATURES


def make_binary_target(series, negative, positive):
    mapping = {
        negative: 0,
        positive: 1,
    }

    target = series.map(mapping)

    if target.isna().any():
        unexpected = series[target.isna()].unique().tolist()
        raise ValueError(
            f"Unexpected target values: {unexpected}"
        )

    return target.astype(np.int8).to_numpy()


def validate_matrix(df, features, name):
    missing = set(features) - set(df.columns)

    if missing:
        raise ValueError(
            f"{name}: missing features {sorted(missing)}"
        )

    X = df[features].copy()

    for column in features:
        X[column] = pd.to_numeric(
            X[column],
            errors="coerce",
        )

    values = X.to_numpy(dtype=np.float64)

    if not np.isfinite(values).all():
        raise ValueError(
            f"{name}: NaN or infinite feature values found"
        )

    return X.astype(np.float32)


def metric_bundle(y_true, probability, target_config):
    y_pred = (probability >= 0.5).astype(np.int8)

    result = {
        "rows": len(y_true),
        "accuracy": accuracy_score(y_true, y_pred),
        "balanced_accuracy": balanced_accuracy_score(
            y_true, y_pred
        ),
        "macro_f1": f1_score(
            y_true, y_pred, average="macro", zero_division=0
        ),
        "weighted_f1": f1_score(
            y_true, y_pred, average="weighted", zero_division=0
        ),
        "precision_positive": precision_score(
            y_true, y_pred, zero_division=0
        ),
        "recall_positive": recall_score(
            y_true, y_pred, zero_division=0
        ),
        "log_loss": log_loss(
            y_true,
            np.column_stack([1 - probability, probability]),
            labels=[0, 1],
        ),
        "roc_auc": (
            roc_auc_score(y_true, probability)
            if len(np.unique(y_true)) == 2
            else None
        ),
        "predicted_negative_pct": float(
            (y_pred == 0).mean() * 100
        ),
        "predicted_positive_pct": float(
            (y_pred == 1).mean() * 100
        ),
    }

    return result, y_pred


# ============================================================
# TRAINING
# ============================================================

results = []
training_details = []

for stage in STAGES:

    target_config = TARGETS[stage]
    target_column = target_config["column"]

    for dataset in DATASETS:

        features = get_features(dataset)

        model_dir = MODEL_ROOT / stage / dataset
        report_dir = REPORT_ROOT / stage / dataset

        model_dir.mkdir(parents=True, exist_ok=True)
        report_dir.mkdir(parents=True, exist_ok=True)

        for horizon in HORIZONS:

            print()
            print("=" * 90)
            print(
                f"TRAINING {stage.upper()} | {dataset} | "
                f"{horizon} MINUTES"
            )
            print("=" * 90)

            fit_df = load_data(
                stage, dataset, "train", horizon
            )

            validation_df = load_data(
                stage, dataset, "validation", horizon
            )

            # Split the training period chronologically.
            fit_days = pd.to_datetime(
                fit_df["trading_day"]
            )

            fit_mask = (
                    fit_days.dt.year <= 2022
            )

            early_mask = (
                    fit_days.dt.year == 2023
            )

            fit_part = fit_df.loc[fit_mask].copy()
            early_part = fit_df.loc[early_mask].copy()

            if len(fit_part) == 0 or len(early_part) == 0:
                raise ValueError(
                    "Fit or early-stop subset is empty."
                )

            X_fit = validate_matrix(
                fit_part, features, "fit"
            )

            X_early = validate_matrix(
                early_part, features, "early_stop"
            )

            X_validation = validate_matrix(
                validation_df, features, "validation"
            )

            y_fit = make_binary_target(
                fit_part[target_column],
                target_config["negative"],
                target_config["positive"],
            )

            y_early = make_binary_target(
                early_part[target_column],
                target_config["negative"],
                target_config["positive"],
            )

            y_validation = make_binary_target(
                validation_df[target_column],
                target_config["negative"],
                target_config["positive"],
            )

            # Check both classes exist in all partitions.
            for name, target in [
                ("fit", y_fit),
                ("early_stop", y_early),
                ("validation", y_validation),
            ]:
                if len(np.unique(target)) != 2:
                    raise ValueError(
                        f"{name} does not contain both classes."
                    )

            # Balanced weights for the fitting subset.
            fit_weights = compute_sample_weight(
                class_weight="balanced",
                y=y_fit,
            )

            early_weights = compute_sample_weight(
                class_weight="balanced",
                y=y_early,
            )

            estimator = lgb.LGBMClassifier(**PARAMS)

            estimator.fit(
                X_fit,
                y_fit,
                sample_weight=fit_weights,
                eval_set=[(X_early, y_early)],
                eval_sample_weight=[early_weights],
                callbacks=[
                    lgb.early_stopping(
                        EARLY_STOPPING_ROUNDS,
                        verbose=False,
                    ),
                    lgb.log_evaluation(0),
                ],
            )

            best_iteration = (
                    estimator.best_iteration_
                    or PARAMS["n_estimators"]
            )

            print(f"Best iteration: {best_iteration}")

            # Refit on all 2021-2023 training data.
            X_train_all = validate_matrix(
                fit_df, features, "final_train"
            )

            y_train_all = make_binary_target(
                fit_df[target_column],
                target_config["negative"],
                target_config["positive"],
            )

            train_weights = compute_sample_weight(
                class_weight="balanced",
                y=y_train_all,
            )

            final_params = PARAMS.copy()
            final_params["n_estimators"] = int(best_iteration)

            final_model = lgb.LGBMClassifier(
                **final_params
            )

            final_model.fit(
                X_train_all,
                y_train_all,
                sample_weight=train_weights,
            )

            # Diagnostic 2024 predictions.
            probability = final_model.predict_proba(
                X_validation
            )[:, 1]

            metrics, predicted = metric_bundle(
                y_validation,
                probability,
                target_config,
            )

            model_path = (
                    model_dir
                    / f"{stage}_{horizon}m.joblib"
            )

            if model_path.exists():
                raise FileExistsError(model_path)

            joblib.dump(
                {
                    "model": final_model,
                    "stage": stage,
                    "dataset": dataset,
                    "horizon_minutes": horizon,
                    "target_column": target_column,
                    "features": features,
                    "classes": target_config["classes"],
                    "negative_class": target_config["negative"],
                    "positive_class": target_config["positive"],
                    "best_iteration": int(best_iteration),
                    "training_parameters": final_params,
                },
                model_path,
            )

            # Prediction export.
            predictions = validation_df[
                [
                    "timestamp_ist",
                    "trading_day",
                    "horizon_minutes",
                    target_column,
                    "target_z",
                    "forward_return",
                ]
            ].copy()

            predictions["actual_class"] = (
                target_config["negative"]
            )

            predictions.loc[
                y_validation == 1,
                "actual_class",
            ] = target_config["positive"]

            predictions["predicted_class"] = (
                target_config["negative"]
            )

            predictions.loc[
                predicted == 1,
                "predicted_class",
            ] = target_config["positive"]

            predictions["prob_negative"] = (
                    1 - probability
            )

            predictions["prob_positive"] = probability
            predictions["confidence"] = np.maximum(
                probability,
                1 - probability,
                )

            prediction_path = (
                    report_dir
                    / f"validation_predictions_{horizon}m.csv"
            )

            predictions.to_csv(
                prediction_path,
                index=False,
            )

            # Feature importance.
            importance = pd.DataFrame({
                "feature": features,
                "importance_gain": (
                    final_model.booster_
                    .feature_importance(importance_type="gain")
                ),
                "importance_split": (
                    final_model.booster_
                    .feature_importance(importance_type="split")
                ),
            }).sort_values(
                "importance_gain",
                ascending=False,
            )

            importance.to_csv(
                report_dir
                / f"feature_importance_{horizon}m.csv",
                index=False,
                )

            # Confusion matrix and class report.
            cm = confusion_matrix(
                y_validation,
                predicted,
                labels=[0, 1],
            )

            report = classification_report(
                y_validation,
                predicted,
                labels=[0, 1],
                target_names=target_config["classes"],
                output_dict=True,
                zero_division=0,
            )

            detail = {
                "stage": stage,
                "dataset": dataset,
                "horizon_minutes": horizon,
                "target_column": target_column,
                "fit_rows_2021_2022": len(fit_part),
                "early_stop_rows_2023": len(early_part),
                "final_train_rows_2021_2023": len(fit_df),
                "validation_rows_2024": len(validation_df),
                "feature_count": len(features),
                "best_iteration": int(best_iteration),
                "model_file": str(model_path),
                "prediction_file": str(prediction_path),
                "metrics": metrics,
                "confusion_matrix": cm.tolist(),
                "classification_report": report,
                "status": "PASS",
            }

            write_json(
                detail,
                report_dir
                / f"metrics_{horizon}m.json",
                )

            results.append({
                "stage": stage,
                "dataset": dataset,
                "horizon_minutes": horizon,
                "train_rows": len(fit_df),
                "fit_rows": len(fit_part),
                "early_stop_rows": len(early_part),
                "validation_rows": len(validation_df),
                "feature_count": len(features),
                "best_iteration": int(best_iteration),
                **metrics,
                "status": "PASS",
            })

            training_details.append(detail)

            print(
                f"Accuracy: {metrics['accuracy']:.5f}"
            )
            print(
                f"Balanced accuracy: "
                f"{metrics['balanced_accuracy']:.5f}"
            )
            print(
                f"Macro F1: {metrics['macro_f1']:.5f}"
            )
            print(
                f"Log loss: {metrics['log_loss']:.5f}"
            )


# ============================================================
# SAVE COMPARISON
# ============================================================

comparison = pd.DataFrame(results)

comparison.to_csv(
    REPORT_ROOT / "two_stage_model_comparison_v1.csv",
    index=False,
    )

summary = {
    "status": (
        "PASS"
        if len(results) == 12
           and all(x["status"] == "PASS" for x in results)
        else "FAIL"
    ),
    "models_expected": 12,
    "models_trained": len(results),
    "stages": STAGES,
    "datasets": DATASETS,
    "horizons": HORIZONS,
    "fit_period": "2021-2022",
    "early_stop_period": "2023",
    "final_refit_period": "2021-2023",
    "validation_period": "2024",
    "sample_weighting": "balanced",
    "model_comparison_file": str(
        REPORT_ROOT / "two_stage_model_comparison_v1.csv"
    ),
    "models": training_details,
}

write_json(
    summary,
    REPORT_ROOT / "two_stage_training_summary_v1.json",
    )

print()
print("=" * 90)
print("TWO-STAGE MODEL TRAINING COMPLETED")
print("=" * 90)

print(comparison.to_string(index=False))
print()
print(json.dumps({
    "status": summary["status"],
    "models_trained": len(results),
}, indent=2))
