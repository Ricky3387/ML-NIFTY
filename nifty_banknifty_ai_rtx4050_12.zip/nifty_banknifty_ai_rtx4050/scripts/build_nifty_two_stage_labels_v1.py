
from pathlib import Path
import json
import duckdb
import pandas as pd

# ============================================================
# NIFTY TWO-STAGE LABEL BUILDER V1
# ============================================================

ROOT = Path(__file__).resolve().parent.parent

INPUT_FILE = (
        ROOT
        / "data"
        / "processed"
        / "nifty_index_options_features_v3"
        / "nifty_index_options_features_v3.parquet"
)

OUTPUT_DIR = (
        ROOT
        / "data"
        / "processed"
        / "nifty_index_options_features_v4"
)

REPORT_DIR = (
        ROOT
        / "reports"
        / "nifty_two_stage_labels_v1"
)

OUTPUT_FILE = (
        OUTPUT_DIR
        / "nifty_index_options_features_v4.parquet"
)

THRESHOLD_FILE = (
        REPORT_DIR
        / "two_stage_thresholds_2021_2022.csv"
)

DISTRIBUTION_FILE = (
        REPORT_DIR
        / "two_stage_label_distribution.csv"
)

SUMMARY_FILE = (
        REPORT_DIR
        / "two_stage_label_build_summary.json"
)

FIT_START = "2021-05-24"
FIT_END = "2022-12-31"

TRAIN_END = "2023-12-31"
VALIDATION_START = "2024-01-01"
VALIDATION_END = "2024-12-31"

HORIZONS = [5, 15, 30]

STAGE1_COLUMN = "label_stage1_move_v1"
STAGE2_COLUMN = "label_stage2_direction_v1"
THRESHOLD_COLUMN = "stage1_move_threshold_v1"


# ============================================================
# HELPERS
# ============================================================

def sql_string(value):
    return "'" + str(value).replace("'", "''") + "'"


def write_json(data, path):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(
            data,
            f,
            indent=2,
            default=str,
            allow_nan=False,
        )


def check(condition, name, checks):
    checks.append({
        "check": name,
        "status": "PASS" if condition else "FAIL",
    })


# ============================================================
# INITIALIZATION
# ============================================================

print("=" * 90)
print("NIFTY TWO-STAGE LABEL BUILDER V1")
print("=" * 90)

if not INPUT_FILE.exists():
    raise FileNotFoundError(INPUT_FILE)

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
REPORT_DIR.mkdir(parents=True, exist_ok=True)

if OUTPUT_FILE.exists():
    raise FileExistsError(
        f"Output already exists. Refusing to overwrite:\n{OUTPUT_FILE}"
    )

con = duckdb.connect()

checks = []

input_path_sql = sql_string(str(INPUT_FILE))
output_path_sql = sql_string(str(OUTPUT_FILE))

con.execute(f"""
    CREATE VIEW source_data AS
    SELECT *
    FROM read_parquet({input_path_sql})
""")

# ============================================================
# 1. SOURCE SCHEMA VALIDATION
# ============================================================

columns = con.execute("""
    DESCRIBE SELECT * FROM source_data
""").fetchdf()

source_columns = set(columns["column_name"].tolist())

required_columns = {
    "timestamp_ist",
    "trading_day",
    "horizon_minutes",
    "target_z",
    "sample_eligible",
    "is_synthetic",
}

missing_columns = required_columns - source_columns

if missing_columns:
    raise ValueError(
        f"Required source columns missing: {sorted(missing_columns)}"
    )

if STAGE1_COLUMN in source_columns:
    raise ValueError(
        f"Output column already exists: {STAGE1_COLUMN}"
    )

if STAGE2_COLUMN in source_columns:
    raise ValueError(
        f"Output column already exists: {STAGE2_COLUMN}"
    )

if THRESHOLD_COLUMN in source_columns:
    raise ValueError(
        f"Output column already exists: {THRESHOLD_COLUMN}"
    )

source_row_count = con.execute("""
                               SELECT COUNT(*) FROM source_data
                               """).fetchone()[0]

source_duplicate_count = con.execute("""
                                     SELECT COUNT(*)
                                     FROM (
                                              SELECT timestamp_ist, horizon_minutes
                                              FROM source_data
                                              GROUP BY timestamp_ist, horizon_minutes
                                              HAVING COUNT(*) > 1
                                          )
                                     """).fetchone()[0]

if source_duplicate_count != 0:
    raise ValueError(
        f"Source contains duplicate timestamp/horizon keys: "
        f"{source_duplicate_count}"
    )

print(f"Source rows: {source_row_count:,}")
print(f"Source duplicate keys: {source_duplicate_count}")


# ============================================================
# 2. CALCULATE TRAINING-ONLY MEDIAN ABSOLUTE TARGET Z
# ============================================================

print()
print("Calculating movement thresholds using 2021-2022 only...")

threshold_df = con.execute(f"""
    SELECT
        CAST(horizon_minutes AS INTEGER) AS horizon_minutes,

        COUNT(*) AS fit_rows,

        quantile_cont(
            ABS(CAST(target_z AS DOUBLE)),
            0.50
        ) AS median_abs_target_z

    FROM source_data

    WHERE CAST(trading_day AS DATE)
          BETWEEN DATE '{FIT_START}' AND DATE '{FIT_END}'

      AND sample_eligible = TRUE
      AND target_z IS NOT NULL
      AND COALESCE(is_synthetic, FALSE) = FALSE

    GROUP BY CAST(horizon_minutes AS INTEGER)

    ORDER BY horizon_minutes
""").fetchdf()

if threshold_df["horizon_minutes"].tolist() != HORIZONS:
    raise ValueError(
        "Expected thresholds for horizons 5, 15 and 30. "
        f"Found: {threshold_df['horizon_minutes'].tolist()}"
    )

if (threshold_df["fit_rows"] <= 0).any():
    raise ValueError("No eligible threshold-fitting observations.")

if threshold_df["median_abs_target_z"].isna().any():
    raise ValueError("One or more thresholds are NULL.")

threshold_df["method"] = (
    "median of abs(target_z), eligible 2021-2022 only"
)

threshold_df["fit_start"] = FIT_START
threshold_df["fit_end"] = FIT_END

threshold_df.to_csv(
    THRESHOLD_FILE,
    index=False,
)

thresholds = {}

for _, row in threshold_df.iterrows():
    thresholds[int(row["horizon_minutes"])] = float(
        row["median_abs_target_z"]
    )

print(threshold_df.to_string(index=False))

# ============================================================
# 3. BUILD SQL LABEL EXPRESSIONS
# ============================================================

threshold_case = "CASE "

for horizon in HORIZONS:
    threshold = thresholds[horizon]

    threshold_case += f"""
        WHEN CAST(horizon_minutes AS INTEGER) = {horizon}
        THEN {threshold:.17g}
    """

threshold_case += " ELSE NULL END"

stage1_case = "CASE "

for horizon in HORIZONS:
    threshold = thresholds[horizon]

    stage1_case += f"""
        WHEN CAST(horizon_minutes AS INTEGER) = {horizon}
             AND ABS(CAST(target_z AS DOUBLE)) <= {threshold:.17g}
        THEN 'SIDEWAYS'

        WHEN CAST(horizon_minutes AS INTEGER) = {horizon}
             AND ABS(CAST(target_z AS DOUBLE)) > {threshold:.17g}
        THEN 'MOVE'
    """

stage1_case += " ELSE NULL END"

stage2_case = """
    CASE
        WHEN stage1_move_label = 'MOVE'
             AND CAST(target_z AS DOUBLE) < 0
        THEN 'DOWN'

        WHEN stage1_move_label = 'MOVE'
             AND CAST(target_z AS DOUBLE) > 0
        THEN 'UP'

        ELSE NULL
    END
"""

# ============================================================
# 4. CREATE V4 DATASET
# ============================================================

print()
print("Creating V4 two-stage label dataset...")

con.execute(f"""
    CREATE TEMP VIEW labeled_data AS

    SELECT
        *,

        CASE
            WHEN sample_eligible = TRUE
                 AND target_z IS NOT NULL
                 AND COALESCE(is_synthetic, FALSE) = FALSE
            THEN {threshold_case}
            ELSE NULL
        END AS {THRESHOLD_COLUMN},

        CASE
            WHEN sample_eligible = TRUE
                 AND target_z IS NOT NULL
                 AND COALESCE(is_synthetic, FALSE) = FALSE
            THEN {stage1_case}
            ELSE NULL
        END AS stage1_move_label,

        NULL::VARCHAR AS unused_placeholder

    FROM source_data
""")

# Recreate the final view with Stage 2 based on Stage 1.
con.execute("""
            CREATE TEMP VIEW final_data AS

            SELECT
                * EXCLUDE (
            stage1_move_label,
            unused_placeholder
        ),

                stage1_move_label AS label_stage1_move_v1,

                CASE
                    WHEN stage1_move_label = 'MOVE'
                        AND CAST(target_z AS DOUBLE) < 0
                        THEN 'DOWN'

                    WHEN stage1_move_label = 'MOVE'
                        AND CAST(target_z AS DOUBLE) > 0
                        THEN 'UP'

                    ELSE NULL
                    END AS label_stage2_direction_v1

            FROM labeled_data
            """)

con.execute(f"""
    COPY (
        SELECT *
        FROM final_data
    )
    TO {output_path_sql}
    (
        FORMAT PARQUET,
        COMPRESSION ZSTD
    )
""")

print(f"Generated: {OUTPUT_FILE}")


# ============================================================
# 5. OUTPUT VALIDATION
# ============================================================

con.execute(f"""
    CREATE VIEW output_data AS
    SELECT *
    FROM read_parquet({output_path_sql})
""")

output_row_count = con.execute("""
                               SELECT COUNT(*) FROM output_data
                               """).fetchone()[0]

output_duplicate_count = con.execute("""
                                     SELECT COUNT(*)
                                     FROM (
                                              SELECT timestamp_ist, horizon_minutes
                                              FROM output_data
                                              GROUP BY timestamp_ist, horizon_minutes
                                              HAVING COUNT(*) > 1
                                          )
                                     """).fetchone()[0]

output_columns = set(
    con.execute("""
        DESCRIBE SELECT * FROM output_data
    """).fetchdf()["column_name"].tolist()
)

eligible_rows = con.execute("""
                            SELECT COUNT(*)
                            FROM output_data
                            WHERE sample_eligible = TRUE
                              AND target_z IS NOT NULL
                              AND COALESCE(is_synthetic, FALSE) = FALSE
                            """).fetchone()[0]

stage1_missing_eligible = con.execute("""
                                      SELECT COUNT(*)
                                      FROM output_data
                                      WHERE sample_eligible = TRUE
                                        AND target_z IS NOT NULL
                                        AND COALESCE(is_synthetic, FALSE) = FALSE
                                        AND label_stage1_move_v1 IS NULL
                                      """).fetchone()[0]

stage2_invalid = con.execute("""
                             SELECT COUNT(*)
                             FROM output_data
                             WHERE label_stage2_direction_v1 IS NOT NULL
                               AND label_stage1_move_v1 != 'MOVE'
                             """).fetchone()[0]

stage2_missing_move = con.execute("""
                                  SELECT COUNT(*)
                                  FROM output_data
                                  WHERE label_stage1_move_v1 = 'MOVE'
                                    AND label_stage2_direction_v1 IS NULL
                                  """).fetchone()[0]

stage2_present_sideways = con.execute("""
                                      SELECT COUNT(*)
                                      FROM output_data
                                      WHERE label_stage1_move_v1 = 'SIDEWAYS'
                                        AND label_stage2_direction_v1 IS NOT NULL
                                      """).fetchone()[0]

ineligible_with_labels = con.execute("""
                                     SELECT COUNT(*)
                                     FROM output_data
                                     WHERE (
                                         sample_eligible != TRUE
        OR target_z IS NULL
        OR COALESCE(is_synthetic, FALSE) = TRUE
                                         )
                                       AND (
                                         label_stage1_move_v1 IS NOT NULL
                                             OR label_stage2_direction_v1 IS NOT NULL
                                             OR stage1_move_threshold_v1 IS NOT NULL
                                         )
                                     """).fetchone()[0]

threshold_mismatches = con.execute(f"""
    SELECT COUNT(*)
    FROM output_data
    WHERE sample_eligible = TRUE
      AND target_z IS NOT NULL
      AND COALESCE(is_synthetic, FALSE) = FALSE
      AND (
          stage1_move_threshold_v1 IS NULL
          OR ABS(
              stage1_move_threshold_v1
              - ({threshold_case})
          ) > 1e-12
      )
""").fetchone()[0]

source_key_mismatch = con.execute("""
                                  SELECT COUNT(*)
                                  FROM (
                                           SELECT
                                               s.timestamp_ist,
                                               s.horizon_minutes
                                           FROM source_data s
                                               ANTI JOIN output_data o
                                           ON s.timestamp_ist = o.timestamp_ist
                                               AND s.horizon_minutes = o.horizon_minutes

                                           UNION ALL

                                           SELECT
                                               o.timestamp_ist,
                                               o.horizon_minutes
                                           FROM output_data o
                                               ANTI JOIN source_data s
                                           ON s.timestamp_ist = o.timestamp_ist
                                               AND s.horizon_minutes = o.horizon_minutes
                                       )
                                  """).fetchone()[0]

checks.append({
    "check": "row_count_preserved",
    "status": "PASS" if source_row_count == output_row_count else "FAIL",
})

checks.append({
    "check": "duplicate_keys_zero",
    "status": "PASS" if output_duplicate_count == 0 else "FAIL",
})

checks.append({
    "check": "original_columns_preserved",
    "status": (
        "PASS"
        if source_columns.issubset(output_columns)
        else "FAIL"
    ),
})

checks.append({
    "check": "new_label_columns_present",
    "status": (
        "PASS"
        if {
            STAGE1_COLUMN,
            STAGE2_COLUMN,
            THRESHOLD_COLUMN,
        }.issubset(output_columns)
        else "FAIL"
    ),
})

checks.append({
    "check": "stage1_labels_complete_for_eligible_rows",
    "status": (
        "PASS"
        if stage1_missing_eligible == 0
        else "FAIL"
    ),
})

checks.append({
    "check": "stage2_labels_only_for_move",
    "status": (
        "PASS"
        if stage2_invalid == 0
           and stage2_present_sideways == 0
        else "FAIL"
    ),
})

checks.append({
    "check": "all_move_rows_have_direction",
    "status": (
        "PASS"
        if stage2_missing_move == 0
        else "FAIL"
    ),
})

checks.append({
    "check": "ineligible_rows_have_no_new_labels",
    "status": (
        "PASS"
        if ineligible_with_labels == 0
        else "FAIL"
    ),
})

checks.append({
    "check": "thresholds_match_fitted_values",
    "status": (
        "PASS"
        if threshold_mismatches == 0
        else "FAIL"
    ),
})

checks.append({
    "check": "source_keys_preserved",
    "status": (
        "PASS"
        if source_key_mismatch == 0
        else "FAIL"
    ),
})


# ============================================================
# 6. LABEL DISTRIBUTION BY PERIOD AND HORIZON
# ============================================================

distribution_df = con.execute("""
                              SELECT
                                  CASE
                                      WHEN CAST(trading_day AS DATE)
                                          BETWEEN DATE '2021-05-24' AND DATE '2022-12-31'
                                          THEN 'FIT_2021_2022'

                                      WHEN CAST(trading_day AS DATE)
                                          BETWEEN DATE '2023-01-01' AND DATE '2023-12-31'
                                          THEN 'EARLY_STOP_2023'

                                      WHEN CAST(trading_day AS DATE)
                                          BETWEEN DATE '2024-01-01' AND DATE '2024-12-31'
                                          THEN 'VALIDATION_2024'

                                      ELSE 'OUTSIDE_DEFINED_PERIOD'
                                      END AS split_period,

                                  CAST(horizon_minutes AS INTEGER) AS horizon_minutes,

                                  COUNT(*) FILTER (
            WHERE label_stage1_move_v1 IS NOT NULL
        ) AS stage1_eligible_rows,

                                  COUNT(*) FILTER (
            WHERE label_stage1_move_v1 = 'SIDEWAYS'
        ) AS sideways_count,

                                  COUNT(*) FILTER (
            WHERE label_stage1_move_v1 = 'MOVE'
        ) AS move_count,

                                  COUNT(*) FILTER (
            WHERE label_stage2_direction_v1 = 'DOWN'
        ) AS down_count,

                                  COUNT(*) FILTER (
            WHERE label_stage2_direction_v1 = 'UP'
        ) AS up_count

                              FROM output_data

                              GROUP BY 1, 2
                              ORDER BY 1, 2
                              """).fetchdf()

distribution_df["sideways_pct"] = (
        distribution_df["sideways_count"]
        / distribution_df["stage1_eligible_rows"].replace(0, pd.NA)
        * 100
)

distribution_df["move_pct"] = (
        distribution_df["move_count"]
        / distribution_df["stage1_eligible_rows"].replace(0, pd.NA)
        * 100
)

distribution_df["down_pct_of_move"] = (
        distribution_df["down_count"]
        / distribution_df["move_count"].replace(0, pd.NA)
        * 100
)

distribution_df["up_pct_of_move"] = (
        distribution_df["up_count"]
        / distribution_df["move_count"].replace(0, pd.NA)
        * 100
)

distribution_df.to_csv(
    DISTRIBUTION_FILE,
    index=False,
)

print(f"Generated: {DISTRIBUTION_FILE}")


# ============================================================
# 7. FINAL SUMMARY
# ============================================================

all_pass = all(
    item["status"] == "PASS"
    for item in checks
)

summary = {
    "status": "PASS" if all_pass else "FAIL",
    "builder": "NIFTY_TWO_STAGE_LABEL_BUILDER_V1",

    "input_file": str(INPUT_FILE),
    "output_file": str(OUTPUT_FILE),

    "source_rows": int(source_row_count),
    "output_rows": int(output_row_count),
    "eligible_rows": int(eligible_rows),

    "fit_period": {
        "start": FIT_START,
        "end": FIT_END,
    },

    "early_stop_period": {
        "start": "2023-01-01",
        "end": TRAIN_END,
    },

    "validation_period": {
        "start": VALIDATION_START,
        "end": VALIDATION_END,
    },

    "threshold_method": (
        "Per-horizon median of absolute target_z, "
        "calculated from eligible 2021-2022 observations only"
    ),

    "thresholds": threshold_df.to_dict(orient="records"),

    "stage1_rule": (
        "SIDEWAYS when abs(target_z) <= threshold; "
        "MOVE when abs(target_z) > threshold"
    ),

    "stage2_rule": (
        "For MOVE only: DOWN when target_z < 0; "
        "UP when target_z > 0"
    ),

    "audit_counts": {
        "source_duplicates": int(source_duplicate_count),
        "output_duplicates": int(output_duplicate_count),
        "stage1_missing_eligible": int(stage1_missing_eligible),
        "stage2_invalid": int(stage2_invalid),
        "stage2_missing_move": int(stage2_missing_move),
        "stage2_present_sideways": int(stage2_present_sideways),
        "ineligible_rows_with_new_labels": int(ineligible_with_labels),
        "threshold_mismatches": int(threshold_mismatches),
        "source_key_mismatches": int(source_key_mismatch),
    },

    "checks": checks,
    "checks_passed": sum(
        item["status"] == "PASS"
        for item in checks
    ),
    "checks_total": len(checks),

    "source_modified": False,
    "existing_v3_artifacts_modified": False,
}

write_json(summary, SUMMARY_FILE)

print(f"Generated: {THRESHOLD_FILE}")
print(f"Generated: {SUMMARY_FILE}")

print()
print("=" * 90)
print("TWO-STAGE LABEL BUILD SUMMARY")
print("=" * 90)

print(json.dumps(summary, indent=2, default=str))

print()
print("LABEL DISTRIBUTION")
print(distribution_df.to_string(index=False))

con.close()

if not all_pass:
    raise RuntimeError(
        "Two-stage label validation FAILED. "
        "Review the summary JSON before proceeding."
    )

print()
print("SUCCESS: TWO-STAGE LABEL DATASET V4 CREATED")
